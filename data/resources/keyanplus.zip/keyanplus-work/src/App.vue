<template>
  <div id="app">
    <!-- 导航栏 -->
    <router-view name="nav" />
    <!-- 主体 -->
    <router-view name="main" />
    <!-- 底部 -->
    <router-view name="foo" />
  </div>
</template>

<script>
export default {
  name: "app",
  data() {
    return {
      doing: {
        time: 300,
        count: 300,
        down: null,
      },
      timeout: null,
      listen: false,
    };
  },
  watch: {
    $route() {
      this.checkLogin();
    },
  },
  mounted() {
    this.listenHtml();
  },
  methods: {
    // 跳转登录
    goLogin() {
      // let list = ["/", "/login", "/regist"];
      // if (list.includes(this.$route.path)) return;

      let go = window.location.href;
      go = go.replace(/[&]/g, "@");
      let path = this.path.main + "login?go=" + go;
      window.location.href = path;
    },
    // 检察登录状态
    checkLogin() {
      let onetime = this.getCookie("onetime");
      let sevenday = this.getCookie("sevenday");
      let refresh_token = this.getCookie("refresh_token");
      if (onetime == "" || onetime < Date.now()) {
        // token失效
        if (sevenday != "" && sevenday < Date.now()) {
          // 刷新token失效，跳转登录
          this.goLogin();
        }
        if (sevenday != "" && sevenday > Date.now()) {
          // 刷新token有效，刷新token
          this.refreshToken();
        }
        if (sevenday == "" && refresh_token == "") {
          // 刷新token失效，跳转登录
          this.goLogin();
        }
        if (sevenday == "" && refresh_token != "") {
          // 刷新token有效，刷新token
          this.refreshToken();
        }
      } else {
        // token有效
        this.$store.commit("setLogin", true);
        this.loginCountDown();
        this.checkWork();
      }
    },
    // 检察是否在实验室
    checkWork() {
      let curLab = this.getCookie("currentlab");
      if (curLab != "") return;
      window.location.href = this.path.main + "create";
    },
    // 刷新token
    refreshToken() {
      let access_token = this.getCookie("access_token");
      let refresh_token = this.getCookie("refresh_token");
      if (access_token == "" || refresh_token == "") {
        return;
      }
      let path = "/api/v1/oauth/refresh/";
      let data = {
        access_token: access_token,
        refresh_token: refresh_token,
      };
      this.axios.post(path, data).then((res) => {
        if (res.data.data && res.data.data.access_token) {
          this.setCookie("access_token", res.data.data.access_token, 7);
          let onetime = Date.now() + 60 * 60 * 1000;
          this.setCookie("onetime", onetime + "", 7);
          this.loginCountDown();
        } else if (res.data.code == 40399) {
          this.getLogin();
        } else {
          this.clearLoginCount();
          setTimeout(() => {
            this.refreshToken();
          }, 2000);
        }
      });
    },
    // 监听页面操作
    listenHtml() {
      window.addEventListener("click", this.onDoing);
      window.addEventListener("scroll", this.onDoing);
      this.doingCountDown();
      this.listen = true;
    },
    // 移除监听
    removeListen() {
      window.removeEventListener("click", this.onDoing);
      window.removeEventListener("scroll", this.onDoing);
      clearInterval(this.doing.down);
      this.listen = false;
    },
    // 倒计时，定时刷新token
    loginCountDown() {
      this.clearLoginCount();
      let onetime = this.getCookie("onetime");
      let length = onetime - Date.now();
      this.timeout = setTimeout(() => {
        this.refreshToken();
      }, length);
    },
    // 清除login计时
    clearLoginCount() {
      if (this.timeout == null) return;
      clearTimeout(this.timeout);
      this.timeout = null;
    },
    // 倒计时，超时移除cookie
    doingCountDown() {
      this.doing.down = setInterval(() => {
        // 7天免登陆
        let sevenday = this.getCookie("sevenday");
        let endtime = Date.now() + this.doing.time * 6000;
        if (sevenday != "" && sevenday > endtime) {
          this.doing.count = this.doing.time;
          return;
        }
        this.doing.count -= 1;
        if (this.doing.count < 1) {
          // 清空对应cookie
          this.setCookie("access_token", null, -1);
          this.setCookie("refresh_token", null, -1);
          this.setCookie("sevenday", null, -1);
          this.setCookie("onetime", null, -1);
          this.setCookie("currentlab", null, -1);
          // 移除监听，提示登录失效
          this.removeListen();
          this.clearLoginCount();
          alert("当前登录已失效，请重新登录");
          // 登录失效后前往登录
          this.goLogin();
        }
      }, 6000);
    },
    // 页面有操作时重置倒计时
    onDoing() {
      this.doing.count = this.doing.time;
      if (!this.listen) {
        this.listenHtml();
      }
    },
  },
  destroyed() {
    this.removeListen();
    this.clearLoginCount();
  },
};
</script>

<style>
html {
  font-size: 12px;
}
#app {
  height: 100vh;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow: hidden;
}
#app input::placeholder,
#app textarea::placeholder {
  color: var(--text4);
}

@media (max-width: 1366px) {
  html {
    font-size: 9.6px;
  }
}

@media (max-width: 1024px) {
  html {
    font-size: 8.8px;
  }
}

@media (max-width: 760px) {
  html {
    font-size: 7.2px;
  }
  #app > .el-scrollbar__bar.is-vertical {
    display: none;
  }
}
</style>
