import axios from 'axios'
import Vue from 'vue'
import 'util'

//添加请求拦截器
axios.interceptors.request.use(
  config => {
    // 携带token
    let token = Vue.prototype.getCookie('access_token');
    if (token) config.headers['Authentication'] = token;

    return config;
  },
  error => {
    return Promise.reject(error);
  });

//添加响应拦截器
axios.interceptors.response.use(
  response => {
    const data = response.data;
    const config = response.config;
    let isTokenError = data && (data.code + '').slice(0, 4) == '4039';
    let isRefreshToken = config.url == '/api/v1/oauth/refresh/';
    let isTokenError2 = data && data.message == "校验失败，请重新获取登录凭证";
    if ((isTokenError || isTokenError2) && !isRefreshToken) {
      return new Promise((resolve) => {
        tokenUtil.checkLogin();
        tokenUtil.waitAxios.push({
          config: config,
          resolve: resolve
        });
      })
    }
    return response;
  },
  error => {
    dealUtil.debounce(() => {
      const data = error.response.data;
      const config = error.response.config;
      if (data.message == '用户当前未在任何实验室或token已经过期') {
        return new Promise((resolve) => {
          tokenUtil.checkLogin();
          tokenUtil.waitAxios.push({
            config: config,
            resolve: resolve
          });
        })
      } else if (data.message) {
        Vue.prototype.$message.error(error.response.data.message);
      } else {
        Vue.prototype.$message.error("未知错误");
      }
    }, 500);
    return Promise.reject(error) // 返回接口返回的错误信息
  });


const tokenUtil = {
  onRefresh: false, // 正在刷新token
  waitAxios: [], // 等待重新请求的axios数组
  goLogin() { // 跳转登录
    let go = window.location.href;
    go = go.replace(/[&]/g, "@");
    let path = Vue.prototype.path.main + "login?go=" + go;
    window.location.href = path;
  },
  // 检察登录状态
  checkLogin() {
    if (this.onRefresh) return;
    let onetime = Vue.prototype.getCookie("onetime");
    let sevenday = Vue.prototype.getCookie("sevenday");
    let refresh_token = Vue.prototype.getCookie("refresh_token");
    if (onetime == "" || onetime < Date.now()) {
      // token失效
      if (sevenday != "" && sevenday < Date.now()) this.goLogin();
      if (sevenday != "" && sevenday > Date.now()) this.refreshToken();
      if (sevenday == "" && refresh_token == "") this.goLogin();
      if (sevenday == "" && refresh_token != "") this.refreshToken();
    }
  },
  // 刷新token
  refreshToken() {
    this.onRefresh = true;

    let access_token = Vue.prototype.getCookie("access_token");
    let refresh_token = Vue.prototype.getCookie("refresh_token");
    if (access_token == "" || refresh_token == "") return;

    let path = "/api/v1/oauth/refresh/";
    let data = {
      access_token: access_token,
      refresh_token: refresh_token,
    };

    axios.post(path, data)
      .then(res => {
        setTimeout(() => {
          this.onRefresh = false;
        }, 1000)

        if (res.data.data && res.data.data.access_token) {
          Vue.prototype.setCookie("access_token", res.data.data.access_token, 7);
          let onetime = Date.now() + 60 * 60 * 1000;
          Vue.prototype.setCookie("onetime", onetime + "", 7);

          this.waitAxios.forEach(item => {
            axios(item.config).then(res => {
              item.resolve(res);
            });
          })
          this.waitAxios = [];
        } else if (res.data.code == 40399) {
          this.getLogin();
        } else {
          setTimeout(() => {
            this.refreshToken();
          }, 2000);
        }
      });
  },
}

const dealUtil = {
  timeout: null,
  debounce(func, delay) {
    const fun = () => {
      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => func(), delay);
    };
    return fun()
  },
}