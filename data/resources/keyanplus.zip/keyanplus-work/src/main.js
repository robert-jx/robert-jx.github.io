import Vue from 'vue'
import App from './App.vue'
import './plugins/element.js'
import router from './router'
import store from './store'
import axios from 'axios'
// import XLSX from 'xlsx'
import './axios'
import './util'

Vue.config.productionTip = false
Vue.prototype.axios = axios
// require('./mock/index')
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
