import Vue from 'vue'
import { Button } from 'element-ui'
import { Input } from 'element-ui'
import { Autocomplete } from 'element-ui'
import { Divider } from 'element-ui'
import { Carousel } from 'element-ui'
import { CarouselItem } from 'element-ui'
import { Backtop } from 'element-ui'
import { Icon } from 'element-ui'
import { Popover } from 'element-ui'
import { Avatar } from 'element-ui'
import { Radio } from 'element-ui'
import { RadioGroup } from 'element-ui'
import { Checkbox } from 'element-ui'
import { CheckboxGroup } from 'element-ui'
import { Scrollbar } from 'element-ui'
import { Container } from 'element-ui'
import { Header } from 'element-ui'
import { Main } from 'element-ui'
import { Aside } from 'element-ui'
import { Menu } from 'element-ui'
import { Submenu } from 'element-ui'
import { MenuItem } from 'element-ui'
import { MenuItemGroup } from 'element-ui'
import { Drawer } from 'element-ui'
import { TabPane } from 'element-ui'
import { Tabs } from 'element-ui'
import { Dialog } from 'element-ui'
import { Form } from 'element-ui'
import { FormItem } from 'element-ui'
import { Row } from 'element-ui'
import { Col } from 'element-ui'
import { Select } from 'element-ui'
import { Option } from 'element-ui'
import { Table } from 'element-ui'
import { TableColumn } from 'element-ui'
import { Transfer } from 'element-ui'
import { Message } from 'element-ui'
import { RadioButton } from 'element-ui'
import { Pagination } from 'element-ui'
import { Dropdown } from 'element-ui'
import { DropdownMenu } from 'element-ui'
import { DropdownItem } from 'element-ui'
import { Tag } from 'element-ui'
import { Cascader } from 'element-ui'
// import { Select } from 'element-ui'
import { Link } from 'element-ui'
import { MessageBox } from 'element-ui'
import { Loading } from 'element-ui'
import { Steps } from 'element-ui'
import { Step } from 'element-ui'
import { DatePicker } from 'element-ui'
import { Upload } from 'element-ui'
import { Tree } from 'element-ui'
import { Breadcrumb } from 'element-ui'
import { BreadcrumbItem } from 'element-ui'
import { Tooltip } from 'element-ui'
import { InputNumber } from 'element-ui'

Vue.use(Button)
Vue.use(Input)
Vue.use(Autocomplete)
Vue.use(Divider)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(Backtop)
Vue.use(Icon)
Vue.use(Popover)
Vue.use(Avatar) 
Vue.use(Radio) 
Vue.use(RadioGroup) 
Vue.use(Checkbox) 
Vue.use(CheckboxGroup) 
Vue.use(Scrollbar)
Vue.use(Container)
Vue.use(Header)
Vue.use(Main)
Vue.use(Aside)
Vue.use(Menu)
Vue.use(Submenu)
Vue.use(MenuItem)
Vue.use(MenuItemGroup)
Vue.use(Drawer)
Vue.use(TabPane)
Vue.use(Tabs)
Vue.use(Dialog)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Row)
Vue.use(Col)
Vue.use(Select)
Vue.use(Option)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Transfer)
Vue.use(RadioButton)
Vue.use(Pagination)
Vue.use(Dropdown)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(Tag)
Vue.use(Cascader)
Vue.use(Link)
Vue.use(Loading.directive);
Vue.use(Steps);
Vue.use(Step);
Vue.use(DatePicker);
Vue.use(Upload);
Vue.use(Tree);
Vue.use(Breadcrumb);
Vue.use(BreadcrumbItem);
Vue.use(Tooltip);
Vue.use(InputNumber);


Vue.prototype.$message = Message;
Vue.prototype.$msgbox = MessageBox;
Vue.prototype.$confirm = MessageBox.confirm;
Vue.prototype.$loading = Loading.service;