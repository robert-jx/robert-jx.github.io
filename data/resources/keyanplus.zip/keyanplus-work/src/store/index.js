import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    login: false,
    avatarUrl: '',
    guide: {
      history: 'hidden',
      instru: {
        list: 'hidden',
        appoint: 'hidden',
      },
      drug: {
        list: 'hidden',
      },
      label: {
        type: 'hidden',
        label: 'hidden',
      },
      stor: {
        place: 'hidden',
      }
    },
  },
  mutations: {
    setLogin(state, val) {
      state.login = val;
    },
    setAvatarUrl(state, val) {
      state.avatarUrl = val;
    },
    setGuide(state, val) {
      state.guide = val;
    },
  },
  actions: {},
  modules: {}
})