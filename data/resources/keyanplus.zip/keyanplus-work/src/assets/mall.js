const brand = {
  mini: 'MINISO/名创优品',
  nome: 'NOME/诺米'
};
const mall = [{
    img: 'image/ceramicCup.png',
    brand: brand.mini,
    name: '漫威漫画系列陶瓷杯400ml/漫威漫画系列陶瓷杯500ml',
    point: 171
  },
  {
    img: 'image/ceramicCup1.png',
    brand: brand.mini,
    name: '漫威卡通系列带盖带勺陶瓷杯320ml',
    point: 185
  },
  {
    img: 'image/bag.png',
    brand:brand.mini,
    name: '漫威竖款斜挎包',
    point: 200
  },
  {
    img: 'image/juggle.png',
    brand:brand.mini,
    name: '积木 M4901',
    point: 169
  },
  {
    img: 'image/coinPurse.png',
    brand:brand.mini,
    name: '漫威零钱包（混色）',
    point: 180
  },
  {
    img: 'image/bucket.png',
    brand:brand.mini,
    name: 'My Melody迷你翻盖收纳桶（410ml',
    point: 190
  },
  {
    img: 'image/cosmeticBag.png',
    brand:brand.nome,
    name: '黄灰配双链中号化妆包(灰色)/黄灰配双链大号化妆包(灰色)',
    point: 170
  },
  {
    img: 'image/coinPurse1.png',
    brand:brand.nome,
    name: '简约大小折面零钱包',
    point: 169
  },
  {
    img: 'image/glass.png',
    brand:brand.mini,
    name: 'Sanrio Characters带盖高硼硅玻璃杯410mL(凯蒂猫)',
    point: 381
  },
  {
    img: 'image/toy.png',
    brand:brand.mini,
    name: '积木玩具(MC0720-1)',
    point: 350
  },
  {
    img: 'image/cleanSing.png',
    brand:brand.mini,
    name: '芦荟洁净去角质凝露',
    point: 399
  },
  {
    img: 'image/headset.png',
    brand:brand.mini,
    name: '经典音乐耳机',
    point: 360
  },
  {
    img: 'image/nightLight.png',
    brand:brand.mini,
    name: '小M小夜灯（白色）',
    point: 377
  },
  {
    img: 'image/ceramicCup2.png',
    brand:brand.mini,
    name: 'Sanrio Characters带勺陶瓷杯480mL(凯蒂猫)',
    point: 385
  },
  {
    img: 'image/freshBox.png',
    brand:brand.mini,
    name: '漫威卡通系列保鲜盒950ml',
    point: 300
  },
  {
    img: 'image/headset1.png',
    brand:brand.mini,
    name: '胶囊音乐耳机',
    point: 490
  },
  {
    img: 'image/teapot.png',
    brand:brand.mini,
    name: '丹莉茶壶700ML',
    point: 450
  },
  {
    img: 'image/storageBox.png',
    brand:brand.mini,
    name: '唐老鸭系列带盖收纳箱',
    point: 500
  },
  {
    img: 'image/headset2.png',
    brand:brand.mini,
    name: '经典半入耳式运动蓝牙耳机',
    point: 681
  },
  {
    img: 'image/vacuumCup.png',
    brand:brand.mini,
    name: '经典简约保温杯300ml',
    point: 600
  },
  {
    img: 'image/led.png',
    brand:brand.mini,
    name: '鹿小萌可充电LED灯',
    point: 700
  },
  {
    img: 'image/typeC.png',
    brand:brand.mini,
    name: '一拖三数据线（银白色）',
    point: 500
  },
  {
    img: 'image/pillow.png',
    brand:brand.mini,
    name: '面包粒子枕',
    point: 550
  },
  {
    img: 'image/pillow1.png',
    brand:brand.mini,
    name: '趣味阿柴系列-萌趣抱枕',
    point: 620
  },
  {
    img: 'image/u.png',
    brand:brand.mini,
    name: '小猪B-BO系列-趣味U枕',
    point: 599
  },
  {
    img: 'image/ledMirror.png',
    brand:brand.mini,
    name: '方形树枝LED化妆镜',
    point: 700
  },
  {
    img: 'image/bluetoothSpeaker.png',
    brand:brand.mini,
    name: '金属重低音蓝牙音箱 型号：A109(星光银)',
    point: 750
  },
  {
    img: 'image/source.png',
    brand:brand.mini,
    name: '国民经典mini10000mAh移动电源 型号：N88',
    point: 780
  },
  {
    img: 'image/source1.png',
    brand:brand.mini,
    name: '小巧便携10000毫安移动电源',
    point: 799
  },
  {
    img: 'image/headset3.png',
    brand:brand.mini,
    name: '无线挂脖运动蓝牙耳机 型号：B59',
    point: 740
  },
  {
    img: 'image/electricHeater.png',
    brand:brand.mini,
    name: '简约圆形电暖器',
    point: 780
  }
]
export default mall;