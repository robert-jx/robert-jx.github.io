<template>
  <div class="history">
    <!-- <div class="upper"></div> -->
    <div class="middle" v-loading="loading">
      <el-table :data="historyPage.list">
        <el-table-column label="序" type="index" :index="indexMethod"></el-table-column>
        <el-table-column prop="createTime" label="入库时间" width="150">
          <template slot-scope="scope">{{ scope.row.createTime | formatCreateTime }}</template>
        </el-table-column>
        <el-table-column prop="name" label="物品名称" width></el-table-column>
        <el-table-column prop="brand" label="品牌" width></el-table-column>
        <el-table-column prop="supplierName" label="供应商" width></el-table-column>
        <el-table-column prop="price" label="单价" width="100"></el-table-column>
        <el-table-column prop="total" label="数量" width="100"></el-table-column>
        <el-table-column label="总价" width="100">
          <template slot-scope="scope">{{ scope.row.price * scope.row.total }}</template>
        </el-table-column>
      </el-table>

      <el-pagination
        background
        :page-sizes="[10, 20, 30, 40]"
        :pager-count="5"
        :page-size="historyPage.pageSize"
        @size-change="pageSizeChange"
        :current-page="historyPage.index"
        @current-change="pageCurrentChange"
        layout="sizes, prev, pager, next"
        :total="historyPage.total"
      >
        <!-- hide-on-single-page -->
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      labInfo: null,
      historyPage: {
        index: 1, // 入库记录列表当前页数
        pageSize: 10, // 入库记录列表页面大小
        total: 0, // 入库记录列表大小
        list: [], // 入库记录列表数据
        search: null // 入库记录列表搜索
      },
      loading: false
    };
  },
  computed: {
    // 是否刷新页面
    refresh() {
      return this.$route.query.refresh;
    }
  },
  watch: {
    // 页面刷新
    refresh() {
      this.getHistoryList();
    }
  },
  mounted() {
    this.initLabInfo();
    this.getHistoryList();
    this.initPageScroll();
  },
  methods: {
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 初始化滚动位置
    initPageScroll(val) {
      val = val ? val : 0;

      let scroll = document.getElementById("main-scroll");
      if (scroll) scroll.scrollTo(0, val);

      // if (this.isMacBook()) {
      //   let scroll = document.getElementById("main-scroll");
      //   if (scroll) scroll.scrollTo(0, val);
      // } else {
      //   let scroll = this.$parent.$parent.$parent.$parent.$refs.wrap;
      //   if (scroll) scroll.scrollTop = val;
      // }
    },
    // 计算索引
    indexMethod(index) {
      return (
        (this.historyPage.index - 1) * this.historyPage.pageSize + index + 1
      );
    },
    // 列表显示数量变化调用
    pageSizeChange(val) {
      this.historyPage.pageSize = val;
      this.historyPage.index = 1;
      this.getHistoryList();
    },
    // 列表当前页数变化调用
    pageCurrentChange(val) {
      this.historyPage.index = val;
      this.getHistoryList();
      this.initPageScroll(140);
    },
    // 获取入库记录
    getHistoryList() {
      let path = "/api/v1/lab/getLogistics";
      let data = {
        isInLab: true,
        labId: this.labInfo.fkLabId,
        index: this.historyPage.index - 1,
        pageSize: this.historyPage.pageSize,
        ascProperties: [],
        descProperties: ["id"]
      };
      this.loading = true;
      this.axios.post(path, data).then(res => {
        this.loading = false;
        // console.info(res)
        if (res.data.code == 20000) {
          this.historyPage.list = res.data.data.data;
          this.historyPage.total = res.data.data.totalElements;
          // console.info(this.historyPage.list);
          return;
        }
        let object = {
          id: -100,
          name: "示例仪器",
          pid: -100,
          fkLabId: this.labInfo.fkLabId,
          createTime: Date.now() - 365 * 24 * 3600 * 1000,
          supplierName: "仪器供应商",
          brand: "示例品牌",
          total: 1,
          price: 2000,
          state: 1,
          properties: "INSTRUMENT",
          place: "示例存放位置"
        };
        this.historyPage.list = [object];
        this.historyPage.total = 1;
      });
    }
  },
  filters: {
    // 格式化入库时间
    formatCreateTime(val) {
      if (val == null) return "";
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      // let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "/" + M + "/" + D + " " + h + ":" + m;
    }
  }
};
</script>

<style scoped>
.history .middle {
  width: 100%;
  min-height: 640px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  /* border: 1px var(--border3) solid; */
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.history .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
</style>