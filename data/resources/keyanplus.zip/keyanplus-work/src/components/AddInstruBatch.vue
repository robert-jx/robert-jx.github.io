<template>
  <el-dialog
    width="500px"
    class="add-instru-batch"
    :visible.sync="iVisible"
    :close-on-click-modal="false"
    v-loading.fullscreen.lock="loading"
    element-loading-text="上传中"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(0, 0, 0, 0.8)"
  >
    <el-tabs v-model="activeTab">
      <el-tab-pane label="仪器入库" name="first">
        <a
          @click="downTemplate('仪器')"
          style="margin-bottom: 20px; display: inline-block"
        >
          <el-button style="width: 250px">下载仪器批量入库模版</el-button>
        </a>
        <el-upload
          action
          :limit="1"
          :auto-upload="false"
          :on-change="onFileChange"
          :on-remove="onFileRemove"
          accept=".xlsx"
          class="upload"
          ref="upload"
        >
          <el-button v-show="!uploadFile" style="width: 250px" type="primary"
            >点击上传数据文件</el-button
          >
        </el-upload>
      </el-tab-pane>

      <!-- 试剂耗材 -->
      <el-tab-pane label="试剂/耗材入库" name="second">
        <a
          @click="downTemplate('试剂/耗材')"
          style="margin-bottom: 20px; display: inline-block"
        >
          <el-button style="width: 250px">下载试剂与耗材批量入库模版</el-button>
        </a>
        <el-upload
          action
          :limit="1"
          :auto-upload="false"
          :on-change="onFileChange"
          :on-remove="onFileRemove"
          accept=".xlsx"
          class="upload"
          ref="upload2"
        >
          <el-button v-show="!uploadFile" style="width: 250px" type="primary"
            >点击上传数据文件</el-button
          >
        </el-upload>
      </el-tab-pane>

      <!-- <el-tab-pane label="保藏中心入库（未）" name="three"></el-tab-pane> -->
    </el-tabs>
    <span slot="footer" class="dialog-footer">
      <el-button size="medium" @click="close()">取 消</el-button>
      <el-button
        size="medium"
        type="primary"
        @click="submitForm"
        :disabled="!uploadFile"
        >确 定</el-button
      >
    </span>
  </el-dialog>
</template>

<script>
import xlsx from "xlsx";
import { Workbook } from "exceljs";

export default {
  props: {
    visible: {
      type: Boolean,
      default: false,
    },
    active: {
      type: String,
      default: "first",
    },
  },
  data() {
    return {
      labInfo: null, // 实验室信息
      typeObject: null, // 分类对象
      supplierList: null, // 供应商列表
      brandList: [], // 品牌列表
      placeList: [], // 存放点列表
      labelList: [], // 标签列表
      activeTab: this.active, // 选中标签页
      iVisible: this.visible, // 弹窗显示
      loading: false, // 加载动画
      instruList: [], // 仪器名称列表
      materList: [], // 试剂耗材名称列表
      uploadFile: null,
      typeAdmin: [],
    };
  },
  computed: {},
  watch: {
    // 同步iVisible跟visible
    iVisible(newV) {
      this.$emit("update:visible", newV);
    },
    visible(newV) {
      this.iVisible = newV;
    },
    activeTab() {
      this.uploadFile = null;
      this.$refs.upload.clearFiles();
      this.$refs.upload2.clearFiles();
    },
  },
  mounted() {
    this.initLabInfo();
    this.getTypeObject();
    this.getGoodsList();
    this.getSupplierList();
    this.getBrandList();
    this.getPlaceList();
    this.getLabelList();
  },
  methods: {
    downTemplate(type, file) {
      const workbook = new Workbook();
      const sheet1 = workbook.addWorksheet("sheet1");

      const downTemplate = async () => {
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], {
          type: "application/octet-stream",
        });
        const aLink = document.createElement("a");
        aLink.href = URL.createObjectURL(blob);
        aLink.download = type + "批量入库模板.xlsx";
        if (file) aLink.download = "无效数据-" + aLink.download;
        aLink.click();
      };

      const initTemplate = () => {
        if (type == "仪器") {
          sheet1.columns = [
            { header: "仪器名称", key: "name", width: 17 },
            { header: "分类名称", key: "type", width: 17 },
            { header: "标签名称", key: "label", width: 17 },
            { header: "品牌名称", key: "brand", width: 17 },
            { header: "供应商名称", key: "supplier", width: 17 },
            { header: "存放地址", key: "place", width: 17 },
            { header: "单位", key: "unit", width: 17 },
            { header: "附件地址", key: "attachment", width: 17 },
            { header: "备注", key: "remark", width: 17 },
            { header: "图片地址", key: "picture", width: 17 },
            { header: "规格", key: "spec", width: 17 },
            { header: "数量", key: "num", width: 17 },
          ];
        } else {
          sheet1.columns = [
            { header: "试剂/耗材名称", key: "name", width: 17 },
            { header: "CAS号", key: "cas", width: 17 },
            { header: "分类名称", key: "type", width: 17 },
            { header: "标签名称", key: "label", width: 17 },
            { header: "品牌名称", key: "brand", width: 17 },
            { header: "供应商名称", key: "supplier", width: 17 },
            { header: "存放地址", key: "place", width: 17 },
            { header: "单位", key: "unit", width: 17 },
            { header: "浓度", key: "conc", width: 17 },
            { header: "图片地址", key: "picture", width: 17 },
            { header: "规格", key: "spec", width: 17 },
            { header: "数量", key: "num", width: 17 },
          ];
        }
      };

      const formatTemplate = () => {
        const brandList = [];
        const placeList = [];
        const labelList = [];
        const supplierList = [];
        const instruList = [];
        const materList = [];
        const typeList = [];

        if (!this.instruList) this.instruList = [];
        if (!this.materList) this.materList = [];

        this.brandList.forEach((item) => brandList.push(item.name));
        this.placeList.forEach((item) => placeList.push(item.name));
        this.labelList.forEach((item) => labelList.push(item.typeName));
        this.supplierList.forEach((item) => supplierList.push(item.name));
        this.instruList.forEach((item) => instruList.push(item));
        this.materList.forEach((item) => materList.push(item));
        for (let key in this.typeObject) {
          typeList.push(this.typeObject[key].name.replace("* ", ""));
        }

        if (type == "仪器") {
          new Array(10).fill(0).forEach((item, index) => {
            const row = index + 2;
            // 名称
            sheet1.getCell(row, 1).dataValidation = {
              type: "list",
              formulae: ['"' + instruList.join(",") + '"'],
            };
            // 分类
            sheet1.getCell(row, 2).dataValidation = {
              type: "list",
              formulae: ['"' + typeList.join(",") + '"'],
            };
            // 标签
            sheet1.getCell(row, 3).dataValidation = {
              type: "list",
              formulae: ['"' + labelList.join(",") + '"'],
            };
            // 品牌
            sheet1.getCell(row, 4).dataValidation = {
              type: "list",
              formulae: ['"' + brandList.join(",") + '"'],
            };
            // 供应商
            sheet1.getCell(row, 5).dataValidation = {
              type: "list",
              formulae: ['"' + supplierList.join(",") + '"'],
            };
            // 位置
            sheet1.getCell(row, 6).dataValidation = {
              type: "list",
              formulae: ['"' + placeList.join(",") + '"'],
            };
          });
        } else {
          new Array(10).fill(0).forEach((item, index) => {
            const row = index + 2;
            // 名称
            sheet1.getCell(row, 1).dataValidation = {
              type: "list",
              formulae: ['"' + materList.join(",") + '"'],
            };
            // 分类
            sheet1.getCell(row, 3).dataValidation = {
              type: "list",
              formulae: ['"' + typeList.join(",") + '"'],
            };
            // 标签
            sheet1.getCell(row, 4).dataValidation = {
              type: "list",
              formulae: ['"' + labelList.join(",") + '"'],
            };
            // 品牌
            sheet1.getCell(row, 5).dataValidation = {
              type: "list",
              formulae: ['"' + brandList.join(",") + '"'],
            };
            // 供应商
            sheet1.getCell(row, 6).dataValidation = {
              type: "list",
              formulae: ['"' + supplierList.join(",") + '"'],
            };
            // 位置
            sheet1.getCell(row, 7).dataValidation = {
              type: "list",
              formulae: ['"' + placeList.join(",") + '"'],
            };
          });
        }
      };

      const readTemplate = () => {
        if (file) {
          let reader = new FileReader();
          reader.readAsBinaryString(file);
          reader.onload = (e) => {
            const workbook = xlsx.read(e.target.result, { type: "binary" });
            const sheetNames = workbook.SheetNames;
            sheetNames.forEach((item) => {
              const sheet = workbook.Sheets[item];
              const json = xlsx.utils.sheet_to_json(sheet);
              const sheet1_data = [];
              if (type == "仪器") {
                json.forEach((item) => {
                  sheet1_data.push({
                    name: item["仪器名称"],
                    type: item["分类名称"],
                    label: item["标签名称"],
                    brand: item["品牌名称"],
                    supplier: item["供应商名称"],
                    place: item["存放地址"],
                    unit: item["单位"],
                    attachment: item["附件地址"],
                    remark: item["备注"],
                    picture: item["图片地址"],
                    spec: item["规格"],
                    num: item["数量"],
                  });
                });
              } else {
                json.forEach((item) => {
                  // console.info(item);
                  sheet1_data.push({
                    name: item["name"],
                    cas: item["cas"],
                    type: item["tagName"],
                    label: item["typeName"],
                    brand: item["brand"],
                    supplier: item["supplierName"],
                    place: item["place"],
                    unit: item["unit"],
                    conc: item["concentration"],
                    picture: item["picture"],
                    spec: item["规格"],
                    num: item["数量"],
                  });
                });
              }
              sheet1.addRows(sheet1_data);
              formatTemplate();
              downTemplate();
            });
          };
        } else {
          formatTemplate();
          downTemplate();
        }
      };

      initTemplate();
      readTemplate();
    },
    onFileChange(file) {
      this.uploadFile = file;
    },
    onFileRemove() {
      this.uploadFile = null;
    },
    // 关闭弹窗
    close() {
      this.iVisible = false;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取供应商列表
    getSupplierList() {
      let path = "/api/v1/utils/SBPs/suppliers/" + this.labInfo.fkLabId;
      this.axios.get(path).then((res) => {
        this.supplierList = res.data;
      });
    },
    // 获取品牌列表
    getBrandList() {
      let path = "/api/v1/utils/SBPs/brands/" + this.labInfo.fkLabId;
      this.axios.get(path).then((res) => {
        this.brandList = res.data;
      });
    },
    // 判断品牌是否存在
    checkBrandExist(val) {
      if (!val) return;
      let brandExist = false;
      this.brandList.forEach((item) => {
        if (item.name == val) {
          brandExist = true;
          return;
        }
      });
      if (!brandExist) this.doAddBrand(val);
    },
    // 新增品牌
    doAddBrand(name) {
      let path = "/api/v1/utils/SBPs/brands";
      let data = {
        name: name,
        alias: [],
      };
      this.axios.post(path, data).then(() => {
        this.getBrandList();
      });
    },
    // 获取存放点列表
    getPlaceList() {
      let path = "/api/v1/lab/storages";
      let data = {
        params: { labId: this.labInfo.fkLabId },
      };
      this.axios.get(path, data).then((res) => {
        if (res.data.code == 20000) {
          this.placeList = res.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取标签列表
    getLabelList() {
      let path = "/api/v1/lab/getCategories";
      let data = {
        labId: this.labInfo.fkLabId,
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
      };
      this.axios.post(path, data).then((res) => {
        if (res.data.code == 20000) {
          this.labelList = res.data.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 判断标签是否存在
    checkLabelExist(val) {
      if (!val) return;
      let labelExist = false;
      this.labelList.forEach((item) => {
        if (item.typeName == val) {
          labelExist = true;
          return;
        }
      });
      if (!labelExist) this.doCreateLabel(val);
    },
    // 向后台提交新建标签
    doCreateLabel(val) {
      let path = "/api/v1/lab/category";
      let data = {
        name: val,
        labId: this.labInfo.fkLabId,
      };
      this.axios.post(path, data).then((res) => {
        if (res.data.code == 20000) {
          this.getLabelList();
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取分类对象列表
    getTypeObject() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
        labId: this.labInfo.fkLabId,
      };
      this.axios.post(path, data).then((res) => {
        let object = {};
        if (res.data.code == 20000) {
          let list = res.data.data.data;
          list.forEach((item) => {
            object[item.id] = {
              name: item.name,
              power: item.permission,
            };
            if (item.fkAdminIds == this.labInfo.id) {
              this.typeAdmin.push(item.fkAdminIds);
            }
          });
        } else {
          if (res.data.message != "没有相关数据")
            console.info(res.data.message);
        }
        // 添加默认分类
        object[1] = {
          name: "* 实验室公用",
          power: "01100",
        };
        object[2] = {
          name: "* 需申请预约",
          power: "11111",
        };
        object[3] = {
          name: "* 预约仪器",
          power: "11110",
        };
        object[4] = {
          name: "* 仅需申请",
          power: "11101",
        };
        this.typeObject = object;
      });
    },
    // 获取仪器试剂名称列表
    getGoodsList() {
      let path = "/api/v1/lab/goodsNames";
      let data = {
        params: { labId: this.labInfo.fkLabId },
      };
      this.axios.get(path, data).then((res) => {
        if (res.data.code == 20000) {
          this.instruList = res.data.data.instrumentList;
          this.materList = res.data.data.materialList;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取具体仪器试剂信息
    getGoodsInfo(name, type) {
      let path = "/api/v1/lab/goods";
      let data = {
        params: {
          labId: this.labInfo.fkLabId,
          type: type,
          name: name,
        },
      };
      this.axios.get(path, data).then((res) => {
        if (res.data.code == 20000) {
          if (type == "INSTRUMENT") {
            let data = res.data.data;
            this.instruForm.fkTagId = data.fkTagId;
            this.instruForm.typeName = data.typeName;
            this.instruForm.unit = data.unit;
            this.instruForm.brand = data.brand;
            this.instruForm.supplierName = data.supplierName;
          }
          if (type == "MATERIAL") {
            let data = res.data.data;
            this.materForm.fkTagId = data.fkTagId;
            this.materForm.typeName = data.typeName;
            this.materForm.unit = data.unit;
            this.materForm.brand = data.brand;
            this.materForm.supplierName = data.supplierName;
            // console.info(data);
          }
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 点击提交调用
    submitForm() {
      if (this.activeTab == "first") this.doAddInstru();
      if (this.activeTab == "second") this.doAddMater();
    },
    // 向后台提交仪器入库
    doAddInstru() {
      let path = "/api/v1/lab/addInstrumentList";
      let config = {
        params: { labId: this.labInfo.fkLabId },
        headers: { "Content-Type": "multipart/form-data" },
        responseType: "blob",
      };

      let forms = new FormData();
      forms.append("csv", this.uploadFile.raw);
      this.loading = true;

      this.axios.post(path, forms, config).then((res) => {
        this.loading = false;
        this.uploadFile = null;
        this.$refs.upload.clearFiles();
        this.close();
        if (res.data.type == "text/xml") {
          var reader = new FileReader();
          reader.readAsText(res.data);
          reader.onload = () => {
            // let result = JSON.parse(reader.result);
            // console.info(result);
            this.$message.success("仪器批量上传成功");
            this.goPath("/instrument?refresh=" + Date.now());
          };
        } else {
          this.downTemplate("仪器", res.data);
          this.goPath("/instrument?refresh=" + Date.now());
          setTimeout(() => {
            this.$msgbox("部分数据不符合要求，请修改后重新上传", "提示", {
              confirmButtonText: "确定",
            }).catch(() => {});
          }, 100);
        }
      });
    },
    // 向后台提交试剂耗材入库
    doAddMater() {
      let path = "/api/v1/lab/addMaterialList";
      let config = {
        params: { labId: this.labInfo.fkLabId },
        headers: { "Content-Type": "multipart/form-data" },
        responseType: "blob",
      };

      let forms = new FormData();
      forms.append("csv", this.uploadFile.raw);
      this.loading = true;

      this.axios.post(path, forms, config).then((res) => {
        this.loading = false;
        this.uploadFile = null;
        this.$refs.upload2.clearFiles();
        this.close();
        if (res.data.type == "text/xml") {
          this.$message.success("试剂与耗材批量上传成功");
          this.goPath("/drugs?refresh=" + Date.now());
        } else {
          this.downTemplate("试剂/耗材", res.data);
          this.goPath("/drugs?refresh=" + Date.now());
          setTimeout(() => {
            this.$msgbox("部分数据不符合要求，请修改后重新上传", "提示", {
              confirmButtonText: "确定",
            }).catch(() => {});
          }, 100);
        }
      });
    },
    // 时间戳转换
    timestampFormat(val) {
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
    },
  },
};
</script>

<style>
.add-instru-batch .el-dialog__body,
.add-instru-batch .el-dialog__footer {
  padding: 30px 50px;
}
.add-instru-batch .el-tabs {
  margin-top: -30px;
}
.add-instru-batch .el-tabs .el-tabs__header {
  user-select: none;
}
.add-instru-batch .el-tabs .el-tab-pane {
  text-align: center;
  padding: 20px;
}
.add-instru-batch .upload,
.add-instru-batch .upload .el-upload-list {
  width: 250px;
  margin: auto;
}
.add-instru-batch .upload .el-upload-list__item {
  outline: none;
  background: var(--border2);
  padding: 7.5px 0;
  margin-top: -17px;
}
.add-instru-batch .upload .el-icon-close {
  top: 13px;
}
</style>