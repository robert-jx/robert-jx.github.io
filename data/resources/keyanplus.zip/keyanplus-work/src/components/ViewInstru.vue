<template>
  <el-dialog
    width="720px"
    class="view-instru"
    :visible.sync="iVisible"
    :close-on-click-modal="false"
    :title="scope.name"
  >
    <el-tabs :value="activeTab">
      <el-tab-pane label="仪器入库" name="first">
        <el-row :gutter="20">
          <el-col :span="4">仪器名称</el-col>
          <el-col :span="8" class="no-up">
            <el-input :value="scope.name" placeholder="仪器名称" disabled></el-input>
          </el-col>
          <el-col :span="4">所属分类</el-col>
          <el-col :span="8">
            <el-input :value="scope.tagName" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">品牌名称</el-col>
          <el-col :span="8" class="no-up">
            <el-input :value="scope.brand" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">供应商</el-col>
          <el-col :span="8">
            <el-input :value="scope.supplierName" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">仪器价格</el-col>
          <el-col :span="8">
            <el-input :value="scope.price" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">仪器数量</el-col>
          <el-col :span="8">
            <el-input :value="scope.total" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">仪器规格</el-col>
          <el-col :span="8">
            <el-input :value="scope.unit" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">仪器标签</el-col>
          <el-col :span="8" class="no-up">
            <el-input disabled :value="scope.typeName" placeholder></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">存放位置</el-col>
          <el-col :span="20" class="no-up">
            <el-input :value="scope.place" placeholder style="width: 100%" disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">仪器备注</el-col>
          <el-col :span="20">
            <el-input type="textarea" :rows="4" placeholder :value="scope.remark" disabled></el-input>
          </el-col>
        </el-row>
      </el-tab-pane>

      <!-- 试剂耗材 -->
      <el-tab-pane label="试剂/耗材入库" name="second">
        <el-row :gutter="20">
          <el-col :span="4">名称</el-col>
          <el-col :span="8" class="no-up">
            <el-input :value="scope.name" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">CAS号</el-col>
          <el-col :span="8">
            <el-input :value="scope.cas" placeholder></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">分类</el-col>
          <el-col :span="8">
            <el-input :value="scope.tagName" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">品牌</el-col>
          <el-col :span="8" class="no-up">
            <el-input :value="scope.brand" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">供应商</el-col>
          <el-col :span="8">
            <el-input :value="scope.supplierName" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">标签</el-col>
          <el-col :span="8" class="no-up">
            <el-input :value="scope.typeName" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">浓度</el-col>
          <el-col :span="8">
            <el-input :value="scope.concentration" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">规格</el-col>
          <el-col :span="8">
            <el-input :value="scope.unit" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">单价</el-col>
          <el-col :span="8">
            <el-input :value="scope.price" placeholder disabled></el-input>
          </el-col>
          <el-col :span="4">数量</el-col>
          <el-col :span="8">
            <el-input :value="scope.total" placeholder disabled></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">位置</el-col>
          <el-col :span="20" class="no-up">
            <el-input :value="scope.place" placeholder disabled style="width: 100%"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">备注</el-col>
          <el-col :span="20">
            <el-input type="textarea" :rows="4" placeholder :value="scope.remark" disabled></el-input>
          </el-col>
        </el-row>
      </el-tab-pane>

      <el-tab-pane label="保藏中心入库（未）" name="three"></el-tab-pane>
    </el-tabs>
    <span slot="footer" class="dialog-footer">
      <el-button size="medium" type="primary" @click="close()">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    active: {
      type: String,
      default: "first"
    },
    scope: {
      type: Object,
      default: null
    }
  },
  data() {
    return {
      labInfo: null, // 实验室信息
      typeList: null, // 分类列表
      supplierList: null, // 供应商列表
      brandList: null, // 品牌列表
      placeList: null, // 存放点列表
      labelList: null, // 标签列表
      activeTab: this.active, // 选中标签页
      iVisible: this.visible, // 弹窗显示
      instruList: null, // 仪器名称列表
      materList: null // 试剂耗材名称列表
    };
  },
  watch: {
    // 同步iVisible跟visible
    iVisible(newV) {
      this.$emit("update:visible", newV);
    },
    visible(newV) {
      this.iVisible = newV;
    },
    scope() {
      // console.info(this.scope);
    }
  },
  mounted() {
    this.initLabInfo();
    this.getTypeList();
  },
  methods: {
    // 关闭弹窗
    close() {
      this.iVisible = false;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取分类列表
    getTypeList() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: []
      };
      data.labId = this.labInfo.fkLabId;
      this.axios.post(path, data).then(res => {
        this.typeList = [];
        if (res.data.code == 20000) {
          let list = res.data.data.data;
          list.forEach(item => {
            this.typeList.push({
              id: item.id,
              name: item.name,
              power: item.permission
            });
          });
        } else {
          if (res.data.message != "没有相关数据")
            console.info(res.data.message);
        }
        // 添加默认分类
        this.typeList.unshift(
          {
            id: 1,
            name: "* 实验室公用",
            power: "01100"
          },
          {
            id: 2,
            name: "* 需申请预约",
            power: "11111"
          },
          {
            id: 3,
            name: "* 预约仪器",
            power: "11110"
          },
          {
            id: 4,
            name: "* 仅需申请",
            power: "11101"
          }
        );
      });
    },
    // 时间戳转换
    timestampFormat(val) {
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
    }
  }
};
</script>

<style>
.view-instru .el-dialog__body,
.view-instru .el-dialog__footer {
  padding: 30px 50px;
}
.view-instru .el-tabs {
  margin-top: -25px;
}
.view-instru .el-tabs .el-tabs__header {
  user-select: none;
  display: none;
}
.view-instru .el-row {
  margin-top: 20px;
}
.view-instru .el-row .el-col {
  line-height: 40px;
}
.view-instru .el-row .el-col .el-input,
.view-instru .el-row .el-col .el-select {
  width: 100%;
}
.view-instru .el-row .el-col .el-input .el-input__inner,
.view-instru .el-row .el-col .el-textarea .el-textarea__inner,
.view-instru .el-row .el-col .el-select .el-input__inner {
  border: none;
  cursor: default;
  background: #f4f6f9;
  color: var(--text2);
}
.view-instru .el-row .el-col:nth-child(2n + 1) {
  text-align: right;
}
.view-instru .el-row .el-col i {
  margin-right: 3px;
}
.view-instru .el-upload {
  display: unset;
}
.view-instru .el-upload-list__item:first-child {
  margin-top: 7px;
}
.view-instru .el-upload-list__item.is-ready {
  outline: none;
}
.view-instru .no-up .el-icon-arrow-up::before {
  display: none;
}
</style>