<template>
  <el-dialog
    width="720px"
    class="add-instru"
    :visible.sync="iVisible"
    :close-on-click-modal="false"
    v-loading.fullscreen.lock="loading"
    element-loading-text="处理中"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(0, 0, 0, 0.8)"
  >
    <el-tabs v-model="activeTab">
      <el-tab-pane label="仪器入库" name="first">
        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>仪器名称
          </el-col>
          <el-col :span="8" class="no-up">
            <el-select
              clearable
              filterable
              allow-create
              v-model="instruForm.name"
              @change="goodsChange"
              @clear="goodsClear"
              placeholder="仪器名称"
            >
              <el-option v-for="item in instruList" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <i>*</i>所属分类
          </el-col>
          <el-col :span="8">
            <el-select v-model="instruForm.fkTagId" placeholder="请选择所属分类" :disabled="isExistGoods">
              <el-option
                v-for="item in typeList"
                :key="item.id"
                :value="item.id"
                :label="item.name"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">品牌名称</el-col>
          <el-col :span="8" class="no-up">
            <el-select
              v-model="instruForm.brand"
              placeholder="品牌名称"
              allow-create
              filterable
              clearable
            >
              <el-option
                v-for="item in brandList"
                :key="item._id"
                :value="item.name"
                :label="item.name"
              ></el-option>
            </el-select>
          </el-col>
          <el-col :span="4">供应商</el-col>
          <el-col :span="8">
            <el-select v-model="instruForm.supplierName" filterable placeholder="请选择供应商" clearable>
              <el-option
                v-for="item in supplierList"
                :key="item._id"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">仪器单价</el-col>
          <el-col :span="8">
            <el-input v-model="instruForm.price" placeholder="请输入单价（元）"></el-input>
          </el-col>
          <el-col :span="4">
            <i>*</i>仪器数量
          </el-col>
          <el-col :span="8">
            <el-input v-model="instruForm.total" placeholder="请输入数量"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>仪器单位
          </el-col>
          <el-col :span="8">
            <el-input v-model="instruForm.unit" :disabled="isExistGoods" placeholder="请输入仪器规格"></el-input>
          </el-col>
          <el-col :span="4">仪器标签</el-col>
          <el-col :span="8" class="no-up">
            <el-select
              :disabled="isExistGoods"
              v-model="instruForm.typeName"
              filterable
              placeholder="例如：固定资产"
              clearable
              allow-create
            >
              <el-option
                v-for="item in labelList"
                :key="item.id"
                :label="item.typeName"
                :value="item.typeName"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>存放位置
          </el-col>
          <el-col :span="20" class="no-up">
            <el-select
              v-model="instruForm.place"
              placeholder="存放位置"
              style="width: 100%"
              allow-create
              filterable
              clearable
            >
              <el-option
                v-for="item in placeList"
                :key="item.id"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">使用说明</el-col>
          <el-col :span="20">
            <el-upload
              :limit="1"
              ref="upload"
              :on-change="fileChange"
              :http-request="uploadFile"
              :auto-upload="false"
              action
            >
              <el-button
                v-if="!instruForm.upload.length"
                slot="trigger"
                size="small"
                type="primary"
              >选取文件( &lt; 50M )</el-button>
            </el-upload>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">仪器备注</el-col>
          <el-col :span="20">
            <el-input type="textarea" :rows="4" placeholder="备注内容" v-model="instruForm.remark"></el-input>
          </el-col>
        </el-row>
      </el-tab-pane>

      <!-- 试剂耗材 -->
      <el-tab-pane label="试剂/耗材入库" name="second">
        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>名称
          </el-col>
          <el-col :span="8" class="no-up">
            <el-select
              clearable
              filterable
              allow-create
              v-model="materForm.name"
              @change="goodsChange"
              @clear="goodsClear"
              placeholder="物品名称"
            >
              <el-option v-for="item in materList" :key="item" :label="item" :value="item"></el-option>
            </el-select>
          </el-col>
          <el-col :span="4">CAS号</el-col>
          <el-col :span="8">
            <el-input v-model="materForm.cas" placeholder="请输入CAS号"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>分类
          </el-col>
          <el-col :span="8">
            <el-select v-model="materForm.fkTagId" placeholder="请选择所属分类" :disabled="isExistGoods">
              <el-option
                v-for="item in typeList"
                :key="item.id"
                :value="item.id"
                :label="item.name"
              ></el-option>
            </el-select>
          </el-col>
          <el-col :span="4">品牌</el-col>
          <el-col :span="8" class="no-up">
            <el-select
              v-model="materForm.brand"
              placeholder="品牌名称"
              allow-create
              filterable
              clearable
            >
              <el-option
                v-for="item in brandList"
                :key="item._id"
                :value="item.name"
                :label="item.name"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">供应商</el-col>
          <el-col :span="8">
            <el-select v-model="materForm.supplierName" filterable placeholder="请选择供应商" clearable>
              <el-option
                v-for="item in supplierList"
                :key="item._id"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-col>
          <el-col :span="4">标签</el-col>
          <el-col :span="8" class="no-up">
            <el-select
              v-model="materForm.typeName"
              filterable
              placeholder="物品标签"
              clearable
              allow-create
            >
              <el-option
                v-for="item in labelList"
                :key="item.id"
                :label="item.typeName"
                :value="item.typeName"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">浓度</el-col>
          <el-col :span="8">
            <el-input v-model="materForm.concentration" placeholder="试剂属性"></el-input>
          </el-col>
          <el-col :span="4">
            <i>*</i>规格
          </el-col>
          <el-col :span="8">
            <el-input v-model="materForm.specifications" placeholder="请输入规格"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>单位
          </el-col>
          <el-col :span="8">
            <el-input v-model="materForm.unit" placeholder="请输入单位"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">单价</el-col>
          <el-col :span="8">
            <el-input v-model="materForm.price" placeholder="请输入单价（元）"></el-input>
          </el-col>
          <el-col :span="4">
            <i>*</i>数量
          </el-col>
          <el-col :span="8">
            <el-input v-model="materForm.total" placeholder="请输入试剂数量"></el-input>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">
            <i>*</i>位置
          </el-col>
          <el-col :span="20" class="no-up">
            <el-select
              v-model="materForm.place"
              placeholder="存放位置"
              style="width: 100%"
              allow-create
              filterable
              clearable
            >
              <el-option
                v-for="item in placeList"
                :key="item.id"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>

        <el-row :gutter="20">
          <el-col :span="4">备注</el-col>
          <el-col :span="20">
            <el-input type="textarea" :rows="4" placeholder="备注内容" v-model="materForm.remark"></el-input>
          </el-col>
        </el-row>
      </el-tab-pane>

      <!-- <el-tab-pane label="保藏中心入库（未）" name="three"></el-tab-pane> -->
    </el-tabs>
    <span slot="footer" class="dialog-footer">
      <el-button size="medium" @click="close()">取 消</el-button>
      <el-button size="medium" type="primary" @click="submitForm">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
const COS = require("cos-js-sdk-v5");
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    active: {
      type: String,
      default: "first"
    }
  },
  data() {
    return {
      instruForm: {
        // 仪器表单
        fkLabId: null, // 实验室ID
        name: null, // 名称
        fkTagId: null, // 分类ID
        brand: null, // 品牌
        supplierName: null, // 供应商
        price: null, // 价格
        total: null, // 数量
        place: null, // 存放位置
        typeName: null, // 标签
        properties: "INSTRUMENT", // 标志
        date: null, // 入库日期
        unit: "台", // 规格
        remark: null, // 备注
        picture: null, // 图片
        attachment: null, // 附件
        upload: []
      },
      materForm: {
        // 试剂/耗材表单
        fkLabId: null, // 实验室ID
        name: null, // 名称
        typeName: null, // 标签
        properties: "MATERIAL", // 标志
        total: null, // 数量
        fkTagId: null, // 分类ID
        date: null, // 入库时间
        unit: null, // 单位/规格
        remark: null, // 备注
        price: null, // 价格
        picture: null, // 图片
        supplierName: null, // 供应商
        brand: null, // 品牌
        cas: null, // CAS
        concentration: null, // 浓度
        place: null // 存放位置
      },
      labInfo: null, // 实验室信息
      typeList: null, // 分类列表
      supplierList: null, // 供应商列表
      brandList: null, // 品牌列表
      placeList: null, // 存放点列表
      labelList: null, // 标签列表
      activeTab: this.active, // 选中标签页
      iVisible: this.visible, // 弹窗显示
      loading: false, // 加载动画
      instruList: null, // 仪器名称列表
      materList: null, // 试剂耗材名称列表

      cos: null // 腾讯云对象存储
    };
  },
  computed: {
    // 判断当前goods是否已经存在
    isExistGoods() {
      if (this.activeTab == "first") {
        if (!this.instruList) return false;
        return this.instruList.includes(this.instruForm.name);
      }
      if (this.activeTab == "second") {
        if (!this.materList) return false;
        return this.materList.includes(this.materForm.name);
      }
      return false;
    },
    // 是否刷新页面
    refresh() {
      return this.$route.query.refresh;
    }
  },
  watch: {
    // 同步iVisible跟visible
    iVisible(newV) {
      this.$emit("update:visible", newV);
    },
    visible(newV) {
      this.iVisible = newV;
    },
    // 页面刷新
    refresh() {
      this.initLabInfo();
      this.initTencentCos();
      this.getTypeList();
      this.getGoodsList();
      this.getSupplierList();
      this.getBrandList();
      this.getPlaceList();
      this.getLabelList();
    },
    // 监听goods变化，为空时清空默认填充
    "instruForm.name"(newV) {
      if (this.activeTab == "first") {
        if (!this.instruList || !this.instruList.includes(newV))
          this.goodsClear(newV);
      }
    },
    "materForm.name"(newV) {
      if (this.activeTab == "second") {
        if (!this.materList || !this.materList.includes(newV))
          this.goodsClear(newV);
      }
    },
    // 限制价格是数值
    "instruForm.price"(newV, oldV) {
      if (!newV) return;
      if (parseFloat(newV + "") != newV) {
        this.$message.error("价格只能是数值");
        this.instruForm.price = oldV;
        return;
      }
    },
    "materForm.price"(newV, oldV) {
      if (!newV) return;
      if (parseFloat(newV + "") != newV) {
        this.$message.error("价格只能是数值");
        this.materForm.price = oldV;
        return;
      }
    },
    // 限制数量是正整数
    "instruForm.total"(newV, oldV) {
      if (!newV) return;
      if ((newV + "").indexOf(".") != -1) {
        this.$message.error("价格只能是正整数");
        this.instruForm.total = oldV;
        return;
      }
      if (parseInt(newV + "") != newV) {
        this.$message.error("价格只能是正整数");
        this.instruForm.total = oldV;
        return;
      }
    },
    "materForm.total"(newV, oldV) {
      if (!newV) return;
      if ((newV + "").indexOf(".") != -1) {
        this.$message.error("数量只能是正整数");
        this.materForm.total = oldV;
        return;
      }
      if (parseInt(newV + "") != newV) {
        this.$message.error("数量只能是正整数");
        this.materForm.total = oldV;
        return;
      }
    }
  },
  mounted() {
    this.initLabInfo();
    this.initTencentCos();
    this.getTypeList();
    this.getGoodsList();
    this.getSupplierList();
    this.getBrandList();
    this.getPlaceList();
    this.getLabelList();
  },
  methods: {
    // 头
    head(r) {
      return `x-cos-meta-${r.toLowerCase()}`;
    },
    // 关闭弹窗
    close() {
      this.iVisible = false;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 初始化腾讯云对象存储
    initTencentCos() {
      // 获取临时密钥
      let getAuthorization = (options, callback) => {
        let path = "/api/v1/utils/STS/labs";
        this.axios.get(path).then(({ data }) => {
          let credentials = data && data.credentials;
          if (!data || !credentials) {
            console.error("获取临时密钥失败");
            return;
          }
          callback({
            TmpSecretId: credentials.tmpSecretId,
            TmpSecretKey: credentials.tmpSecretKey,
            XCosSecurityToken: credentials.sessionToken,
            StartTime: data.startTime,
            ExpiredTime: data.expiredTime
          });
        });
      };

      // 根据临时密钥生成cos对象
      this.cos = new COS({
        getAuthorization: getAuthorization
      });
    },
    // 选择文件
    fileChange(file, fileList) {
      if (file.size / 1024 / 1024 > 50) {
        this.$message.error("文件大小超出50M");
        fileList.pop();
      }
      this.instruForm.upload = fileList;
    },
    // 上传文件
    uploadFile(file) {
      let auth = {
        Inner: "all",
        Group: { none: [], read: [], all: [] },
        Project: { none: [], read: [], all: [] },
        User: { none: [], read: [], all: [] }
      };
      this.cos.sliceUploadFile(
        {
          Bucket: "lab-files-1300972980", // 必须
          Region: "ap-shanghai", // 存储桶所在地域，必须
          Key: this.labInfo.fkLabId + "/仪器文档/" + file.file.name, // 必须
          [this.head("auth")]: JSON.stringify(auth),
          [this.head("authorName")]: this.encodeUnicode(this.labInfo.realName),
          [this.head("authorUsername")]: this.labInfo.id,
          [this.head("createTime")]: new Date().toJSON(),
          Body: file.file // 上传文件对象
          // onProgress: progressData => {
          //   console.log(JSON.stringify(progressData));
          // }
        },
        (err, data) => {
          if (err !== null) {
            this.$message.error("文件上传错误");
            console.log(err || data);
          } else {
            this.instruForm.attachment = data.Location;
          }
        }
      );
    },
    // 获取供应商列表
    getSupplierList() {
      let path = "/api/v1/utils/SBPs/suppliers/"+this.labInfo.fkLabId;
      this.axios.get(path).then(res => {
        this.supplierList = res.data;
      });
    },
    // 获取品牌列表
    getBrandList() {
      let path = "/api/v1/utils/SBPs/brands/"+this.labInfo.fkLabId;
      this.axios.get(path).then(res => {
        this.brandList = res.data;
      });
    },
    // 判断品牌是否存在
    checkBrandExist(val) {
      if (!val) return;
      let brandExist = false;
      this.brandList.forEach(item => {
        if (item.name == val) {
          brandExist = true;
          return;
        }
      });
      if (!brandExist) this.doAddBrand(val);
    },
    // 新增品牌
    doAddBrand(name) {
      let path = "/api/v1/utils/SBPs/brands";
      let data = {
        name: name,
        alias: []
      };
      this.axios.post(path, data).then(() => {
        this.getBrandList();
      });
    },
    // 获取存放点列表
    getPlaceList() {
      let path = "/api/v1/lab/storages";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.placeList = res.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取标签列表
    getLabelList() {
      let path = "/api/v1/lab/getCategories";
      let data = {
        labId: this.labInfo.fkLabId,
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: []
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.labelList = res.data.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 判断标签是否存在
    checkLabelExist(val) {
      if (!val) return;
      let labelExist = false;
      this.labelList.forEach(item => {
        if (item.typeName == val) {
          labelExist = true;
          return;
        }
      });
      if (!labelExist) this.doCreateLabel(val);
    },
    // 向后台提交新建标签
    doCreateLabel(val) {
      let path = "/api/v1/lab/category";
      let data = {
        name: val,
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.getLabelList();
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取分类列表
    getTypeList() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: []
      };
      data.labId = this.labInfo.fkLabId;
      this.axios.post(path, data).then(res => {
        this.typeList = [];
        if (res.data.code == 20000) {
          let list = res.data.data.data;
          list.forEach(item => {
            this.typeList.push({
              id: item.id,
              name: item.name,
              power: item.permission
            });
          });
        } else {
          if (res.data.message != "没有相关数据")
            console.info(res.data.message);
        }
        // 添加默认分类
        this.typeList.unshift(
          {
            id: 1,
            name: "* 实验室公用",
            power: "01100"
          },
          {
            id: 2,
            name: "* 需申请预约",
            power: "11111"
          },
          {
            id: 3,
            name: "* 预约仪器",
            power: "11110"
          },
          {
            id: 4,
            name: "* 仅需申请",
            power: "11101"
          }
        );
      });
    },
    // 获取仪器试剂名称列表
    getGoodsList() {
      let path = "/api/v1/lab/goodsNames";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.instruList = res.data.data.instrumentList;
          this.materList = res.data.data.materialList;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取具体仪器试剂信息
    getGoodsInfo(name, type) {
      let path = "/api/v1/lab/goods";
      let data = {
        params: {
          labId: this.labInfo.fkLabId,
          type: type,
          name: name
        }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          if (type == "INSTRUMENT") {
            let data = res.data.data;
            this.instruForm.fkTagId = data.fkTagId;
            this.instruForm.typeName = data.typeName;
            this.instruForm.unit = data.unit;
            this.instruForm.brand = data.brand;
            this.instruForm.supplierName = data.supplierName;
          }
          if (type == "MATERIAL") {
            let data = res.data.data;
            this.materForm.fkTagId = data.fkTagId;
            this.materForm.typeName = data.typeName;
            this.materForm.unit = data.unit;
            this.materForm.brand = data.brand;
            this.materForm.supplierName = data.supplierName;
            // console.info(data);
          }
        } else {
          console.info(res.data.message);
        }
      });
    },
    // goods改变时调用
    goodsChange(val) {
      if (this.activeTab == "first") {
        if (!this.instruList || !this.instruList.includes(this.instruForm.name))
          return;
        this.getGoodsInfo(val, "INSTRUMENT");
      }
      if (this.activeTab == "second") {
        if (!this.materList || !this.materList.includes(this.materForm.name))
          return;
        this.getGoodsInfo(val, "MATERIAL");
      }
    },
    // 清空goods时调用
    goodsClear(val) {
      this.instruForm = {
        fkLabId: null,
        name: null,
        fkTagId: null,
        brand: null,
        supplierName: null,
        price: null,
        total: null,
        place: null,
        typeName: null,
        properties: "INSTRUMENT",
        date: null,
        unit: "台",
        remark: null,
        picture: null,
        attachment: null,
        upload: []
      };
      if (val) this.instruForm.name = val;
    },
    // 点击提交调用
    submitForm() {
      if (this.activeTab == "first") this.doAddInstru();
      if (this.activeTab == "second") this.doAddMater();
    },
    // 向后台提交仪器入库
    doAddInstru() {
      let path = "/api/v1/lab/logistics";
      let data = JSON.parse(JSON.stringify(this.instruForm));
      delete data.upload;
      data.fkLabId = this.labInfo.fkLabId;
      data.properties = "INSTRUMENT";
      data.date = this.timestampFormat(Date.now());
      if (
        !data.name ||
        !data.total ||
        !data.fkTagId ||
        !data.unit ||
        !data.place
      ) {
        this.$message.error("请填写相关信息");
        return;
      }

      this.checkLabelExist(data.typeName);
      this.checkBrandExist(data.brand);

      this.loading = true;
      this.$refs.upload.submit();
      let interval = setInterval(() => {
        if (this.instruForm.attachment || !this.instruForm.upload.length) {
          clearInterval(interval);
          // console.info(data);
          this.axios.post(path, data).then(res => {
            if (res.data.code == 20000) {
              this.$message.success(res.data.message);
              this.loading = false;
              this.iVisible = false;
              this.$refs.upload.clearFiles();
              this.instruForm = {
                fkLabId: null,
                name: null,
                fkTagId: null,
                brand: null,
                supplierName: null,
                price: null,
                total: null,
                place: null,
                typeName: null,
                properties: "INSTRUMENT",
                date: null,
                unit: "台",
                remark: null,
                picture: null,
                attachment: null,
                upload: []
              };
              this.getGoodsList();
              this.goPath("/instrument?refresh=" + Date.now());
              // this.goPath(
              //   "/instrument?refresh=" + Date.now() + "&activeTab=four"
              // );
            } else {
              this.loading = false;
              this.$message.error(res.data.message);
            }
          });
        }
      }, 500);
    },
    // 向后台提交试剂耗材入库
    doAddMater() {
      let path = "/api/v1/lab/logistics";
      let data = this.materForm;
      data.fkLabId = this.labInfo.fkLabId;
      data.properties = "MATERIAL";
      data.date = this.timestampFormat(Date.now());
      if (
        !data.name ||
        !data.total ||
        !data.fkTagId ||
        !data.specifications ||
        !data.unit ||
        !data.place
      ) {
        this.$message.error("请填写必填信息");
        return;
      }

      this.checkLabelExist(data.typeName);
      this.checkBrandExist(data.brand);

      this.loading = true;
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.$message.success(res.data.message);
          this.loading = false;
          this.iVisible = false;
          this.materForm = {
            fkLabId: null,
            name: null,
            typeName: null,
            properties: "MATERIAL",
            total: null,
            fkTagId: null,
            date: null,
            unit: null,
            remark: null,
            price: null,
            picture: null,
            supplierName: null,
            brand: null,
            cas: null,
            concentration: null,
            place: null
          };
          this.getGoodsList();
          this.goPath("/drugs?refresh=" + Date.now());
          // this.goPath("/drugs?refresh=" + Date.now() + "&activeTab=four");
        } else {
          this.loading = false;
          this.$message.error(res.data.message);
        }
      });
    },
    // 时间戳转换
    timestampFormat(val) {
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
    }
  }
};
</script>

<style>
.add-instru .el-dialog__body,
.add-instru .el-dialog__footer {
  padding: 30px 50px;
}
.add-instru .el-tabs {
  margin-top: -30px;
}
.add-instru .el-tabs .el-tabs__header {
  user-select: none;
}
.add-instru .el-row {
  margin-top: 20px;
}
.add-instru .el-row .el-col {
  line-height: 40px;
}
.add-instru .el-row .el-col .el-input,
.add-instru .el-row .el-col .el-select {
  width: 100%;
}
.add-instru .el-row .el-col:nth-child(2n + 1) {
  text-align: right;
}
.add-instru .el-row .el-col i {
  margin-right: 3px;
}
.add-instru .el-upload {
  display: unset;
}
.add-instru .el-upload-list__item:first-child {
  margin-top: 7px;
}
.add-instru .el-upload-list__item.is-ready {
  outline: none;
}
.add-instru .no-up .el-icon-arrow-up::before {
  display: none;
}
</style>