<template>
  <div class="foo">

  </div>
</template>

<script>
export default {

}
</script>

<style>
.foo {
  width: 100vw;
  height: 420px;
  background: var(--back5);
}
</style>