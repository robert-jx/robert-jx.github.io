<template>
  <div class="nav">
    <div class="box">
      <!-- 图标 -->
      <div class="logo" @click="goIndex">
        <img src="/favicon.ico" />
        <span>
          科研家
          <sup>
            <strong>+</strong>
          </sup>
        </span>
      </div>

      <!-- 搜索 -->
      <!-- <div class="search">
        <input placeholder="用户/实验室" />
        <i class="iconfont icon-search"></i>
      </div>-->

      <!-- 帮助文档 -->
      <el-tooltip class="help" effect="dark" content="帮助中心" placement="bottom">
        <a href="https://help.keyanplus.com" target="_blank">?</a>
      </el-tooltip>

      <!-- 二维码 -->
      <div class="qrcode">
        <el-dropdown trigger="click" placement="bottom">
          <i class="iconfont icon-qrcode"></i>
          <el-dropdown-menu slot="dropdown" class="nav-qrcode">
            <el-dropdown-item>
              <div class="title">
                科研家
                <sup>+</sup>微信操作入口
              </div>
              <img src="image/qrcode.jpg" />
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>

      <!-- 消息 -->
      <!-- <div class="message">
        <i class="iconfont icon-bell"></i>
      </div>-->

      <!-- 用户 -->
      <div v-show="login" class="avatar">
        <el-dropdown trigger="click">
          <div style="margin-top: -2px">
            <el-avatar :size="22" :src="user.avatar"></el-avatar>
            <!-- <i class="iconfont icon-down"></i> -->
          </div>
          <el-dropdown-menu slot="dropdown" class="nav-user">
            <el-dropdown-item @click.native="goSetting()">个人设置</el-dropdown-item>
            <el-dropdown-item @click.native="doLogout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div v-show="!login" class="avatar">
        <div style="margin-top: -2px" @click="goLogin">
          <el-avatar :size="22"></el-avatar>
          <!-- <i class="iconfont icon-down"></i> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      user: {}
    };
  },
  computed: {
    login() {
      return this.$store.state.login;
    },
    work() {
      return this.$store.state.work;
    }
  },
  watch: {
    login() {
      if (this.login) this.getUserInfo();
    }
  },
  mounted() {
    if (this.login) this.getUserInfo();
  },
  methods: {
    // 获取用户信息
    getUserInfo() {
      let get1 = this.axios.get("/api/v1/user/getInfo");
      let get2 = this.axios.get("/api/v1/user/getWxInfo");
      Promise.all([get1, get2]).then(
        this.axios.spread((res1, res2) => {
          this.user = res1.data.data;
          this.user.password = null;
          if (res2.data.data) {
            this.user.nickname = res2.data.data.nickname;
            this.user.headImgUrl = res2.data.data.headImgUrl;
          }
          if (!this.user.avatar) this.user.avatar = this.user.headImgUrl;
          else this.user.avatar = "http://" + this.user.avatar;
          this.user.avatar += "?" + Date.now();
          this.userN = JSON.parse(JSON.stringify(this.user));
          this.$store.commit("setAvatarUrl", this.user.avatar);
          // console.info(this.user);
        })
      );
    },
    // 前往登录
    goLogin() {
      let href = window.location.href;
      let path = href.split("?")[0];
      let go = this.$route.query.go;
      if (path == this.path.main + "login") return;
      if (path == this.path.main + "regist") {
        this.goPath("/login?go=" + go);
        return;
      }

      href = href.replace(/[&]/g, "@");
      window.location.href = this.path.main + "login?go=" + href;
    },
    goIndex() {
      window.location.href = this.path.main;
    },
    goSetting() {
      window.location.href = this.path.main + "setting";
    },
    // 退出登录
    doLogout() {
      // 清空对应cookie
      this.setCookie("access_token", null, -1);
      this.setCookie("refresh_token", null, -1);
      this.setCookie("sevenday", null, -1);
      this.setCookie("onetime", null, -1);
      this.setCookie("currentlab", null, -1);

      this.$store.commit("setLogin", false);
      window.location.href = this.path.main;
    }
  }
};
</script>

<style scoped>
@font-face {
  font-family: logo;
  src: url("/font/logo.woff");
}
.nav {
  height: 50px;
  min-width: 1200px;
  user-select: none;
  position: relative;
  z-index: 1;
}
.nav .box {
  width: 100vw;
  height: 50px;
  padding: 0 30px;
  box-sizing: border-box;
  font-size: 16px;
  line-height: 50px;
  text-align: right;
  color: var(--back3);
  background: var(--back1);
  box-shadow: var(--shadow3);
  position: fixed;
  left: 0;
  top: 0;
}
.nav .box > div {
  margin-left: 28px;
  padding: 0 4px;
  display: inline-block;
  cursor: pointer;
}
.nav .box > div > i {
  font-size: 22px;
  line-height: 50px;
  display: inline-block;
}
.nav .logo {
  font-family: logo;
  font-size: 20px;
  margin-top: -0.33em;
  margin-left: 0 !important;
  cursor: default;
  float: left;
}
.nav .logo img {
  width: 25px;
  opacity: 0.8;
  margin: 20px 0;
  vertical-align: top;
}
.nav .search {
  height: 34px;
  background: rgba(240, 242, 245, 0.1);
  border-radius: 3px;
  vertical-align: top;
  margin-top: 7px;
  margin-right: 20px;
  text-align: left;
}
.nav .search input:focus {
  width: 250px;
  transition: ease-in-out 0.3;
}
.nav .search input {
  width: 200px;
  height: 100%;
  line-height: 34px;
  vertical-align: top;
  padding: 0 32px 0 12px;
  box-sizing: border-box;
  outline: none;
  background: none;
  border: none;
  color: var(--back3);
  display: inline-block;
  transition: ease-in-out 0.3;
}
.nav .search i {
  width: 32px;
  text-align: center;
  display: inline-block;
  margin-left: -32px;
  padding-left: 2px;
  vertical-align: top;
  font-size: 16px !important;
  line-height: 34px !important;
}
.nav .help {
  width: 30px;
  height: 30px;
  line-height: 30px;
  font-size: 20px;
  font-weight: 600;
  text-align: center;
  text-decoration: none;
  color: var(--back3);
  display: inline-block;
  box-sizing: border-box;
  margin: -8px -7px 0 0;
  border: 2px solid var(--back3);
  border-radius: 50%;
  vertical-align: middle;
  transform: scale(0.64);
  outline: none !important;
}
.nav .qrcode i {
  font-size: 22px;
  color: var(--back3);
}
.nav .avatar > * {
  display: inline-block;
  vertical-align: top;
}
.nav .avatar .el-avatar {
  margin-top: 12px;
  margin-right: 4px;
}
.nav .avatar i {
  font-size: 12px !important;
  vertical-align: top;
}

@media (max-width: 760px) {
  .nav .box {
    padding: 0 26px;
  }
  .nav .box .search,
  .nav .box .qrcode,
  .nav .box .message,
  .nav .box .desktop,
  .nav .box .avatar {
    display: none;
  }
}
</style>
<style>
.nav-user,
.nav-qrcode {
  margin-top: -6px !important;
  padding: 6px 0 !important;
  background: var(--back6) !important;
  color: var(--back3) !important;
  border: none;
}
.nav-user .el-dropdown-menu__item,
.nav-qrcode .el-dropdown-menu__item {
  background: var(--back6) !important;
  color: var(--back3) !important;
}
.nav-qrcode .el-dropdown-menu__item {
  height: 190px;
}
.nav-qrcode .el-dropdown-menu__item .title {
  line-height: 26px;
  margin-bottom: -3px;
  text-align: center;
}
.nav-user .el-dropdown-menu__item:hover {
  background: rgba(255, 255, 255, 0.08) !important;
  color: var(--back3) !important;
}
/* .nav-user .popper__arrow {
  margin-right: 12px !important;
} */
.nav-user .popper__arrow::after,
.nav-qrcode .popper__arrow::after {
  border-bottom-color: var(--back6) !important;
}
.nav-qrcode img {
  width: 140px;
  margin: 12px 0;
  border-radius: 2px;
}
</style>