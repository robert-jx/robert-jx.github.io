<template>
  <div class="preser">
    <div class="head">保藏中心</div>

    <div class="main">
      <div class="upper">
        <el-button type="primary" @click="dialog.addPreser = true">入库（未）</el-button>
        <!-- <el-button type="primary"> 批量导入 </el-button> -->
        <el-input placeholder="搜索保藏" v-model="preserPage.search" clearable>
          <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
        </el-input>
      </div>
      <div class="middle">
        <el-table :data="currentPageList">
          <el-table-column prop="name" label="物品名称" width="120"></el-table-column>
          <el-table-column prop="source" label="来源" width="120"></el-table-column>
          <el-table-column prop="typeName" label="标签" width="120">
            <template slot-scope="scope">
              <el-tag v-show="scope.row.typeName" size="medium">{{ scope.row.typeName }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="document" label="文档" width="120"></el-table-column>
          <el-table-column prop="createTime" label="添加时间">
            <template slot-scope="scope">
              {{ (scope.row.createTime+"").slice(0, 10) }}
            </template>
          </el-table-column>
          <!-- <el-table-column label="操作" :width="doingWidth">
            <template slot-scope>
              <el-button size="small" type="text">领取</el-button>
              <el-button size="small" type="text">详情</el-button>
              <el-button size="small" type="text" v-if="doingBool">管理</el-button>
            </template>
          </el-table-column>-->
        </el-table>
        <el-pagination
          background
          :page-sizes="[10, 20, 30, 40]"
          :pager-count="5"
          :page-size="preserPage.pageSize"
          @size-change="pageSizeChange"
          :current-page="preserPage.index"
          @current-change="pageCurrentChange"
          layout="sizes, prev, pager, next"
          :total="preserPage.total"
        >
          <!-- hide-on-single-page -->
        </el-pagination>
      </div>
    </div>

    <add-instru active="three" :visible.sync="dialog.addPreser"></add-instru>
  </div>
</template>

<script>
import AddInstru from "../../../components/AddInstru";

export default {
  components: {
    AddInstru
  },
  data() {
    return {
      labInfo: null, // 实验室信息
      preserPage: {
        index: 1, // 保藏列表当前页数
        pageSize: 10, // 保藏列表页面大小
        total: 0, // 保藏列表大小
        list: [], // 保藏列表数据
        search: null // 保藏列表搜索
      },
      dialog: {
        addPreser: false // 入库弹窗
      },
      typeObject: null
    };
  },
  computed: {
    // 判断用户是否有权限操作
    doingBool() {
      if (!this.labInfo) return false;
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN";
    },
    doingWidth() {
      if (!this.labInfo) return "90";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "120"
        : "90";
    },
    // 计算显示列表当前页
    currentPageList() {
      let list = this.preserPage.list;
      let search = this.preserPage.search;
      if (search) {
        list = list.filter(
          data =>
            !search || data.name.toLowerCase().includes(search.toLowerCase())
        );
      }
      let start = (this.preserPage.index - 1) * this.preserPage.pageSize;
      let end = start + this.preserPage.pageSize;
      return list.slice(start, end);
    },
    // 是否刷新页面
    refresh() {
      return this.$route.query.refresh;
    }
  },
  watch: {
    // 页面刷新
    refresh() {
      this.getPreserList();
    },
    // 监听分类搜索，更改页数
    "preserPage.search"() {
      this.preserPage.index = 1;
    }
  },
  mounted() {
    this.initLabInfo();
    this.getPreserList();
    this.getTypeObject();
  },
  methods: {
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取分类对象列表
    getTypeObject() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          let object = {};
          let list = res.data.data.data;
          list.forEach(item => {
            object[item.id] = {
              name: item.name,
              power: item.permission
            };
          });
          // 添加默认分类
          object[1] = {
            name: "* 实验室公用",
            power: "01100"
          };
          object[2] = {
            name: "* 需申请预约",
            power: "11111"
          };
          object[3] = {
            name: "* 预约仪器",
            power: "11110"
          };
          object[4] = {
            name: "* 仅需申请",
            power: "11101"
          };
          this.typeObject = object;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 列表显示数量变化调用
    pageSizeChange(val) {
      this.preserPage.pageSize = val;
    },
    // 列表当前页数变化调用
    pageCurrentChange(val) {
      this.preserPage.index = val;
    },
    // 获取保藏列表
    getPreserList() {
      let path = "/api/v1/lab/getPrizes";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.preserPage.total = res.data.data.totalElements;
          this.preserPage.list = res.data.data.data;
          console.info(this.preserPage);
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取保藏展开内容
    getPreserExpand(row) {
      let path = "/api/v1/lab/goodsByName";
      let data = {
        params: {
          labId: this.labInfo.fkLabId,
          name: row.name,
          type: "INSTRUMENT"
        }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          console.info(res.data.data);
          this.$set(this.preserPage.expand, row.id + "", res.data.data);
        } else {
          console.info(res.data.message);
        }
      });
    }
  }
};
</script>

<style scoped>
.preser {
  width: 100%;
  min-width: 1000px;
  height: 100%;
}
.preser .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.preser .main {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 23px;
  padding: 0 20px;
  box-sizing: border-box;
}
.preser .upper {
  width: 100%;
  height: 40px;
}
.preser .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.preser .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}
.preser .middle {
  width: 100%;
  min-height: 750px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  /* border: 1px var(--border3) solid; */
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.preser .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
</style>
<style>
.preser .middle .none .el-table__expand-column .cell {
  display: none !important;
}
.preser .middle .el-table__expanded-cell {
  padding-left: 25px;
  padding-right: 48px;
}
</style>