<template>
  <div class="stor">
    <div class="head">存储管理与设置</div>

    <el-tabs v-model="activeTab">
      <!-- 分类列表 -->
      <el-tab-pane label="存放位置" name="first">
        <!--  顶部操作 -->
        <div class="upper">
          <el-button v-show="doingBool" type="primary" @click="dialog.createPlace = true">新存放点</el-button>
          <span class="describle-stor">功能简介：管理员可以在此添加实验室常用的物品存储点</span>
          <el-input placeholder="搜索位置" clearable v-model="placePage.search">
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <!-- 中间列表 -->
        <div class="middle">
          <el-table :data="currentPlaceList">
            <el-table-column label="存放点" prop="name" width="180"></el-table-column>
            <el-table-column label="备注" prop="detail"></el-table-column>
            <el-table-column :label="doingBool?'操作':''" :width="placeDoingWidth">
              <template slot-scope="scope">
                <!-- <el-link type="primary">详情</el-link> -->
                <!-- <el-link type="primary">修改</el-link> -->
                <el-link v-show="doingBool"  type="danger" @click="onDeletePlace(scope.row)">删除</el-link>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页显示 -->
          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="placePage.pageSize"
            @size-change="placeSizeChange"
            :current-page="placePage.index"
            @current-change="placeCurrentChange"
            layout="sizes, prev, pager, next"
            :total="placePage.total"
          ></el-pagination>
        </div>
      </el-tab-pane>

      <!-- 标签列表 -->
      <!-- <el-tab-pane label="预警设置（未）" name="second"></el-tab-pane> -->
    </el-tabs>

    <!-- 存放点弹窗 -->
    <el-dialog
      :close-on-click-modal="false"
      title="新建项目"
      class="create-place"
      :visible.sync="dialog.createPlace"
      width="640px"
    >
      <el-form :model="placeForm" label-width="120px">
        <el-form-item
          :label="index?'存放点'+(index+1):'存放点'"
          v-for="(item, index) in placeForm.list"
          :key="index"
        >
          <el-row>
            <el-col :span="20">
              <el-input v-model="item.name" placeholder="存放地点"></el-input>
            </el-col>
            <el-col :span="3" :offset="1">
              <el-button v-if="!index" type="primary" plain @click="addPlaceItem">
                <i class="el-icon-plus"></i>
              </el-button>
              <el-button v-else type="danger" plain @click="delPlaceItem(item)">
                <i class="el-icon-minus"></i>
              </el-button>
            </el-col>
          </el-row>
          <el-row style="margin-top: 8px;">
            <el-col :span="24">
              <el-input
                type="textarea"
                v-model="item.detail"
                placeholder="备注"
                :autosize="{ minRows: 2, maxRows: 5}"
              ></el-input>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.createPlace = false">取 消</el-button>
        <el-button type="primary" size="medium" @click="doCreatePlace">确 定</el-button>
      </span>
    </el-dialog>

    <div class="guide guide-place" v-show="guide.stor.place=='show' && activeTab=='first'">
      <div class="one" v-show="doingBool">
        <div class="box"></div>
        <span class="desc">您可在此新建实验室存放点</span>
      </div>
      <div class="two">
        <div class="box"></div>
        <span class="desc">您可在此搜索相关存放点</span>
      </div>
      <div class="three">
        <div class="box"></div>
        <span v-show="doingBool" class="desc">您可在此浏览、删除相关存放点信息</span>
        <span v-show="!doingBool" class="desc">您可在此浏览相关存放点信息</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('stor', 'place')">关闭</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeTab: "first",
      labInfo: null,
      placePage: {
        index: 1, // 存放点列表当前页数
        pageSize: 10, // 存放点列表页面大小
        total: 0, // 存放点列表大小
        list: [], // 存放点列表数据
        search: null // 存放点列表搜索
      },
      placeForm: {
        list: [
          {
            name: null,
            detail: null
          }
        ]
      },
      dialog: {
        createPlace: false
      }
    };
  },
  watch: {
    // 监听存放点搜索，更改页数
    "placePage.search"() {
      this.placePage.index = 1;
    }
  },
  computed: {
    // 计算显示存放点列表当前页
    currentPlaceList() {
      let list = this.placePage.list;
      let search = this.placePage.search;
      if (search) {
        list = list.filter(
          data =>
            !search ||
            data.name.toLowerCase().includes(search.toLowerCase()) ||
            data.detail.toLowerCase().includes(search.toLowerCase())
        );
      }
      let start = (this.placePage.index - 1) * this.placePage.pageSize;
      let end = start + this.placePage.pageSize;
      return list.slice(start, end);
    },
    // 判断用户是否有权限操作
    doingBool() {
      if (!this.labInfo) return false;
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN";
    },
    placeDoingWidth() {
      if (!this.labInfo) return "1";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "50"
        : "1";
    },
    guide() {
      return this.$store.state.guide;
    }
  },
  mounted() {
    this.initLabInfo();
    this.getPlaceList();
  },
  methods: {
    closeGuide(val1, val2) {
      if (val1 == "stor") this.guide[val1][val2] = "hidden";

      let path = "/api/v1/utils/members/guide/" + this.labInfo.fkAccountName;
      let data = JSON.parse(JSON.stringify(this.$store.state.guide));
      delete data._id;
      this.axios.post(path, data);
    },
    // 存放点列表显示数量变化调用
    placeSizeChange(val) {
      this.placePage.pageSize = val;
    },
    // 存放点当前页数变化调用
    placeCurrentChange(val) {
      this.placePage.index = val;
    },
    // 添加存放点项
    addPlaceItem() {
      this.placeForm.list.push({
        name: null,
        detail: null
      });
    },
    // 移除存放点项
    delPlaceItem(val) {
      var index = this.placeForm.list.indexOf(val);
      if (index !== -1) {
        this.placeForm.list.splice(index, 1);
      }
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取存放点列表
    getPlaceList() {
      let path = "/api/v1/lab/storages";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.placePage.total = res.data.data.length;
          this.placePage.list = res.data.data;
          // console.info(this.placePage);
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 提交添加存放点
    doCreatePlace() {
      let path = "/api/v1/lab/storages";
      let list = [];
      this.placeForm.list.forEach(item => {
        list.push({
          labId: this.labInfo.fkLabId,
          name: item.name,
          detail: item.detail
        });
      });
      let data = list;
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.$message.success(res.data.message);
          this.dialog.createPlace = false;
          this.getPlaceList();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    onDeletePlace(row) {
      const doDeletePlace = () => {
        let path = "/api/v1/lab/storage";
        let data = {
          params: {
            id: row.id,
            labId: row.fkLabId
          }
        };
        this.axios.delete(path, data).then(res => {
          if (res.data.code == 20000) {
            this.$message.success(res.data.message);
            this.getPlaceList();
          } else {
            this.$message.error(res.data.message);
          }
        });
      };
      console.info(row);
      this.$confirm("此操作将删除该地址，是否继续？", "提示", {
        type: "warning",
        distinguishCancelAndClose: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(() => doDeletePlace())
        .catch(() => {
          this.$message.info("取消删除");
        });
    }
  },
  filters: {}
};
</script>

<style scoped>
.stor {
  width: 100%;
  min-width: 1000px;
  /* height: 100%; */
  position: relative;
}
.stor .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.stor .el-tab-pane {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 8px;
  padding: 0 20px;
  box-sizing: border-box;
}
.stor .upper {
  width: 100%;
  height: 40px;
}
.stor .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.stor .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}
.stor .upper > .el-button:first-child {
  margin-right: 16px;
}

.describle-stor {
  color: var(--text3);
  line-height: 20px;
  box-shadow: none;
  user-select: none;
  font-size: 12px;
  max-width: 360px;
  display: inline-block;
  vertical-align: middle;
  font-weight: 500;
}
.stor .middle {
  width: 100%;
  min-height: 650px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.stor .el-table .el-link {
  font-size: 12px;
  text-decoration: none;
  user-select: none;
}
.stor .el-table .el-link::after {
  display: none;
}
.stor .el-table .el-link + .el-link {
  margin-left: 12px;
}
.stor .el-table span {
  font-size: 12px;
  color: var(--text3);
  user-select: none;
}
.stor .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
.stor .create-place .el-form {
  padding-right: 70px;
  box-sizing: border-box;
}
.stor .create-place .el-form .el-select,
.stor .create-place .el-form .el-cascader {
  width: 100%;
}
</style>

<style scoped>
.stor .guide {
  background: rgba(0, 0, 0, 0.66);
  width: 100%;
  height: 100%;
  color: #cccccc;
  font-size: 14px;
  z-index: 10010;
  position: absolute;
  left: 0;
  top: 0;
}
.stor .guide .btn {
  width: 80px;
  margin: 0 -40px;
  position: absolute;
  right: 50%;
  top: 400px;
}
.stor .guide-place .one .box {
  width: 110px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  left: 14px;
  top: 116px;
}
.stor .guide-place .one .desc {
  width: 180px;
  position: absolute;
  left: 135px;
  top: 120px;
}
.stor .guide-place .two .box {
  width: 410px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 116px;
}
.stor .guide-place .two .desc {
  width: 180px;
  position: absolute;
  right: 246px;
  top: 92px;
}
.stor .guide-place .three .box {
  width: calc(100% - 30px);
  height: 120px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.stor .guide-place .three .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 320px;
}
</style>

<style>
.stor .el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 14px;
  line-height: 40px;
  user-select: none;
}
.stor .el-tabs__nav-scroll .el-tabs__item {
  padding: 0 16px;
}
.stor .el-tabs__nav-wrap::after {
  background-color: var(--border3);
}
/* .stor .el-table .system {
  color: var(--text3) !important;
} */
</style>