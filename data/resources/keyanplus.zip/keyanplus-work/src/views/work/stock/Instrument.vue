<template>
  <div class="instru">
    <div class="head">仪器与预约</div>

    <el-tabs v-model="activeTab">
      <!-- 仪器列表 -->
      <el-tab-pane label="仪器列表" name="first">
        <div class="upper">
          <el-button v-show="doingBool" type="primary" @click="dialog.addInstru = true">入库</el-button>
          <el-button v-show="doingBool" type="primary" @click="dialog.addInstruBatch = true">批量入库</el-button>
          <span class="describle-stock">功能简介：实验室所有仪器都可以在此查看/管理。</span>

          <!-- <el-button type="primary"> 批量入库 </el-button> -->
          <el-input placeholder="搜索仪器" v-model="instruPage.search" clearable>
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <div class="middle">
          <el-table
            :data="currentInstruList()"
            @expand-change="expandChange"
            @filter-change="filterChange"
            :row-class-name="pageRowClass"
          >
            <el-table-column prop="name" label="仪器名称" width="150"></el-table-column>

            <el-table-column prop="curCount" label="数量" width="70"></el-table-column>

            <el-table-column prop="unit" label="规格" width="100"></el-table-column>

            <el-table-column
              prop="tagName"
              label="所属分类"
              column-key="type"
              :filters="filter.type.list"
              width="150"
            >
              <template slot-scope="scope">{{ scope.row.tagName ? scope.row.tagName : "实验室公用" }}</template>
            </el-table-column>

            <!-- <el-table-column
              prop="brand"
              label="品牌"
              column-key="brand"
              :filters="filter.brand.list"
              width="150"
            >
            </el-table-column>-->

            <el-table-column
              prop="typeName"
              width="200"
              label="标签"
              column-key="tag"
              :filters="filter.tag.list"
            >
              <template slot-scope="scope">
                <el-tag v-show="scope.row.typeName" size="medium">{{ scope.row.typeName }}</el-tag>
              </template>
            </el-table-column>

            <el-table-column label="存放位置" prop="place">
              <template
                slot-scope="iscope"
              >{{ iscope.row.place?(iscope.row.place+'').replace(',undefined','').replace('undefined',' '):'' }}</template>
            </el-table-column>

            <!-- <el-table-column
              prop="supplierName"
              label="供应商"
              column-key="supplier"
              :filters="filter.supplier.list"
            >
            </el-table-column>-->

            <el-table-column label="操作" :width="doingWidth">
              <template slot-scope="scope">
                <el-link type="primary" @click="onViewInstru(scope.row)">详情</el-link>
                <el-link type="danger" v-if="doingBool" @click="onDeleteInstru(scope.row)">删除</el-link>
              </template>
            </el-table-column>
          </el-table>

          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="instruPage.pageSize"
            @size-change="pageSizeChange"
            :current-page="instruPage.index"
            @current-change="pageCurrentChange"
            layout="sizes, prev, pager, next"
            :total="instruPage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>

      <!-- 仪器预约 -->
      <el-tab-pane label="仪器预约" name="second">
        <div class="upper">
          <el-button v-show="doingBool" type="primary" @click="dialog.addInstru = true">入库</el-button>
          <el-button v-show="doingBool" type="primary" @click="dialog.addInstruBatch = true">批量入库</el-button>
          <span class="describle-stock">
            功能简介：实验室所有仪器都可以线上编号入库。
            <br />所有成员方便在网页端和微信移动端预约实验室仪器。
          </span>

          <!-- <el-button type="primary"> 批量入库 </el-button> -->
          <el-input placeholder="搜索仪器" v-model="instruPage.search" clearable>
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <div class="middle appoint">
          <div
            v-show="!Object.keys(instruPage.expand).length"
            style="line-height: 50px;text-align: center;font-size: 14px;"
          >暂无可预约仪器</div>
          <el-table
            empty-text="."
            v-for="(value, key, index) in instruPage.expand"
            :key="key"
            :data="
              value.filter(
                (data) =>
                  !instruPage.search ||
                  (data.alias+'')
                    .toLowerCase()
                    .includes(instruPage.search.toLowerCase())
              )
            "
            v-show="
              value.filter(
                (data) =>
                  !instruPage.search ||
                  (data.alias+'')
                    .toLowerCase()
                    .includes(instruPage.search.toLowerCase())
              ).length
            "
            :show-header="!index"
          >
            <el-table-column prop="alias" width="150" label="仪器名称"></el-table-column>

            <el-table-column label="预约状况">
              <div slot-scope="iscope" class="appoint-detail">
                <el-tooltip
                  effect="light"
                  placement="top"
                  v-for="(appoint, index) in instruPage.appoint[key][
                    iscope.row.fkPid + iscope.row.selfId
                  ]"
                  :key="appoint.id"
                >
                  <div slot="content" v-html="showAppointDetail(key, iscope.row, index)"></div>
                  <span
                    class="appoint-item"
                    :style="{
                      left: appoint.offset / 3.36 + '%',
                      width: appoint.span / 3.36 + '%',
                    }"
                  ></span>
                </el-tooltip>
                <div
                  class="appoint-driver"
                  v-for="driver in 6"
                  :key="driver"
                  :style="{
                    left: driver / 0.07 + '%',
                  }"
                ></div>
              </div>
            </el-table-column>

            <el-table-column :width="doingWidth" label="操作">
              <template slot-scope="iscope">
                <!-- <el-link type="primary">修改</el-link> -->
                <el-link type="primary" @click="onAppointInstru(key, iscope.row)">预约</el-link>
              </template>
            </el-table-column>
          </el-table>

          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="instruPage.pageSize"
            @size-change="pageSizeChange"
            :current-page="instruPage.index"
            @current-change="pageCurrentChange"
            layout="sizes, prev, pager, next"
            :total="instruPage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>

      <!-- 入库记录 -->
      <el-tab-pane v-if="doingBool" label="入库记录" name="four">
        <sto-history></sto-history>
      </el-tab-pane>
    </el-tabs>

    <!-- 入库弹窗 -->
    <add-instru active="first" :visible.sync="dialog.addInstru"></add-instru>

    <!-- 批量入库弹窗 -->
    <add-instru-batch active="first" :visible.sync="dialog.addInstruBatch"></add-instru-batch>

    <!-- 详情弹窗 -->
    <view-instru active="first" :visible.sync="dialog.viewInstru" :scope="detailForm"></view-instru>

    <!-- 预约弹窗 -->
    <el-dialog
      :title="appointForm.alias"
      :close-on-click-modal="false"
      width="100%"
      :visible.sync="dialog.addAppoint"
      class="add-appoint"
    >
      <div class="main">
        <div class="row">
          <span class="label"></span>
          <span
            class="item"
            :key="item"
            v-for="item in 24"
            style="background: none; text-align: left"
          >{{ ("0" + (item - 1)).slice(-2) }}</span>
        </div>
        <div class="row" v-for="(value, key) in appointForm.dayAppo" :key="key">
          <span class="label">{{ value.date }}</span>
          <span
            class="item"
            :key="index"
            v-for="(item, index) in value.days"
            :style="getAppoFormStyle(key, index, item)"
            @click="onSelectAppoTime(key, index, item)"
          ></span>
        </div>
      </div>
      <el-form label-width="80px" label-position="left">
        <el-form-item label="* 时间">
          <el-input v-model="appoTime" readonly class="appo-time"></el-input>
        </el-form-item>
        <el-form-item label="* 标题" v-if="appointForm.apply">
          <el-input v-model="appointForm.title" placeholder="请输入申请标题"></el-input>
        </el-form-item>
        <el-form-item label="* 审批" v-if="appointForm.apply">
          <el-select
            v-model="appointForm.manager"
            placeholder="请选择审批人"
            style="width: 50%"
            allow-create
            clearable
            multiple
          >
            <el-option v-for="item in adminList" :key="item[0]" :value="item[0]" :label="item[2]"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="* 内容" v-if="appointForm.apply">
          <el-input
            v-model="appointForm.content"
            type="textarea"
            placeholder="请输入申请内容"
            :autosize="{ minRows: 3 }"
          ></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.addAppoint = false">取消</el-button>
        <el-button type="primary" size="medium" @click="doCreateAppoint">确定</el-button>
      </span>
    </el-dialog>

    <div class="guide guide-list" v-show="guide.instru.list=='show' && activeTab=='first'">
      <div class="one" v-show="doingBool">
        <div class="box"></div>
        <span class="desc">您可在此对采购的仪器进行入库登记</span>
      </div>
      <div class="two">
        <div class="box"></div>
        <span class="desc">您可在此搜索相关仪器</span>
      </div>
      <div class="three">
        <div class="box"></div>
        <span v-show="doingBool" class="desc">您可在此浏览、删除实验室仪器</span>
        <span v-show="!doingBool" class="desc">您可在此浏览实验室仪器</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('instru', 'list')">关闭</el-button>
    </div>

    <div class="guide guide-appoint" v-show="guide.instru.appoint=='show' && activeTab=='second'">
      <div class="one">
        <div class="box"></div>
        <span class="desc">您可在此预约实验室仪器，预约状况是未来一周该仪器的预约情况</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('instru', 'appoint')">关闭</el-button>
    </div>

    <div class="guide guide-history" v-show="guide.history=='show' && activeTab=='four'">
      <div class="one">
        <div class="box"></div>
        <span class="desc">您可在此查看仪器跟试剂耗材的入库记录</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('history')">关闭</el-button>
    </div>
  </div>
</template>

<script>
import AddInstru from "../../../components/AddInstru";
import AddInstruBatch from "../../../components/AddInstruBatch";
import ViewInstru from "../../../components/ViewInstru";
import StoHistory from "../../../components/StoHistory";

export default {
  components: {
    AddInstru,
    AddInstruBatch,
    StoHistory,
    ViewInstru
  },
  data() {
    return {
      activeTab: "first",
      labInfo: null, // 实验室信息
      instruPage: {
        index: 1, // 仪器列表当前页数
        pageSize: 10, // 仪器列表页面大小
        total: 0, // 仪器列表大小
        list: [], // 仪器列表数据
        expand: {}, // 列表展开项
        loading: {}, // 展开项加载动画
        appoint: {}, // 展开项预约情况
        search: null, // 仪器列表搜索
        expandRow: [] // 当前展开行
      },
      appointForm: {
        appoint: {}, // 当前仪器的预约情况
        dayAppo: {}, // 处理后的预约情况
        dayAll: [], // 处理后的预约情况(全部)
        selTime: [], // 选择时间标记
        pid: null, // 仪器批号
        selfId: null, // 仪器私有ID
        name: null, // 仪器名称
        startTime: null, // 预约开始时间
        endTime: null, // 预约结束时间
        title: null, // 申请标题
        content: null, // 申请内容
        manager: [], // 审批人ID数组
        apply: false, // 是否需要审批
        row: null // 当前仪器类
      },
      detailForm: {},
      filter: {
        lock: false, // 避免更新筛选条件发生死循环
        first: "type", // 最先筛选
        type: {
          list: [], // 筛选所属分类
          value: []
        },
        tag: {
          list: [], // 筛选标签
          value: []
        },
        brand: {
          list: [], // 筛选品牌
          value: []
        },
        supplier: {
          list: [], // 筛选供应商
          value: []
        }
      },
      dialog: {
        addInstru: false, // 入库弹窗
        addInstruBatch: false, // 批量入库弹窗
        viewInstru: false, // 详情弹窗
        addAppoint: false // 预约弹窗
      },
      userList: null, // 用户列表
      adminList: null, // 管理原列表
      typeObject: null,
      typeAdmin: []
    };
  },
  computed: {
    // 判断用户是否有权限操作
    doingBool() {
      if (!this.labInfo) return false;
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN";
    },
    doingWidth() {
      if (!this.labInfo) return "50";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "90"
        : "50";
    },
    // 是否刷新页面
    refresh() {
      return this.$route.query.refresh;
    },
    // 计算显示预约弹窗预约时间
    appoTime() {
      let start = this.appointForm.startTime;
      let end = this.appointForm.endTime;
      let other = " （在上面点击选择一个时间范围） ";
      start = start ? start.slice(5, 16) : "开始时间";
      end = end ? end.slice(5, 16) : "结束时间";
      return start + "  至  " + end + other;
    },
    getActive() {
      return this.$route.query.activeTab;
    },
    guide() {
      return this.$store.state.guide;
    }
  },
  watch: {
    // 页面刷新
    refresh() {
      this.getInstruList();
    },
    // 监听搜索，更改页数
    "instruPage.search"() {
      this.instruPage.index = 1;
      this.filter.lock = false;
    },
    // 切换列表时索引置为1
    activeTab() {
      this.instruPage.index = 1;
      this.filter.lock = false;
    },
    getActive() {
      this.initActiveTab();
    }
  },
  mounted() {
    this.initLabInfo();
    this.initActiveTab();
    this.getInstruList();
    this.getTypeObject();
    this.getGroupUserInfo();
  },
  methods: {
    closeGuide(val1, val2) {
      if (val1 == "instru") this.guide[val1][val2] = "hidden";
      if (val1 == "history") this.guide[val1] = "hidden";

      let path = "/api/v1/utils/members/guide/" + this.labInfo.fkAccountName;
      let data = JSON.parse(JSON.stringify(this.$store.state.guide));
      delete data._id;
      this.axios.post(path, data);
    },
    initActiveTab() {
      let active = this.$route.query.activeTab;
      if (active) this.activeTab = active;
    },
    // 计算显示列表当前页
    currentInstruList() {
      let list = this.instruPage.list;
      // 筛选搜索内容
      let search = this.instruPage.search;
      if (search) {
        list = list.filter(
          data =>
            !search || data.name.toLowerCase().includes(search.toLowerCase())
        );
      }
      // 筛选visible
      list = list.filter(data => data.visible != "不可见");
      // 筛选分类
      let type = this.filter.type.value;
      list = list.filter(data => {
        if (type.length == 0) return true;
        if (type.includes(data.fkTagId + "")) return true;
        return false;
      });
      // 筛选标签
      let tag = this.filter.tag.value;
      list = list.filter(data => {
        if (tag.length == 0) return true;
        if (tag.includes(data.typeName + "")) return true;
        return false;
      });
      // 筛选品牌
      let brand = this.filter.brand.value;
      list = list.filter(data => {
        if (brand.length == 0) return true;
        if (brand.includes(data.brand + "")) return true;
        return false;
      });
      // 筛选供应商
      let supplier = this.filter.supplier.value;
      list = list.filter(data => {
        if (supplier.length == 0) return true;
        if (supplier.includes(data.supplierName + "")) return true;
        return false;
      });
      // 删选可以预约的仪器
      if (this.activeTab == "second") {
        list = list.filter(data => (data.power + "").slice(3, 4) == "1");
      }
      // 删选可以申请的仪器
      if (this.activeTab == "three") {
        list = list.filter(data => (data.power + "").slice(3, 5) == "01");
      }
      // 如果允许，更新筛选条件
      if (!this.filter.lock) this.formatInstrFilter(list);
      // 设置元素总数
      this.instruPage.total = list.length;
      // 截取当前页
      let start = (this.instruPage.index - 1) * this.instruPage.pageSize;
      let end = start + this.instruPage.pageSize;
      return list.slice(start, end);
    },
    // 表格行样式，控制拓展按钮
    pageRowClass({ row }) {
      return row.expand ? "" : "none";
    },
    // 筛选条件变化
    filterChange(filters) {
      if (filters.type) this.filter.type.value = filters.type;
      if (filters.tag) this.filter.tag.value = filters.tag;
      if (filters.brand) this.filter.brand.value = filters.brand;
      if (filters.supplier) this.filter.supplier.value = filters.supplier;
      this.instruPage.index = 1;
      // 允许更新筛选条件
      this.filter.lock = false;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取课题组跟用户相关信息
    getGroupUserInfo() {
      let path = "/api/v1/lab/researchGroupsAndDetails";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.userList = res.data.data.labDetails;
          let adminRole = ["ADMIN", "OWNER"];
          this.adminList = this.userList.filter(data =>
            adminRole.includes(data[1])
          );
        }
      });
    },
    // 获取分类对象列表
    getTypeObject() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        let object = {};
        if (res.data.code == 20000) {
          let list = res.data.data.data;
          list.forEach(item => {
            object[item.id] = {
              name: item.name,
              power: item.permission
            };
            if (item.fkAdminIds == this.labInfo.id) {
              this.typeAdmin.push(item.fkAdminIds);
            }
          });
        } else {
          if (res.data.message != "没有相关数据")
            console.info(res.data.message);
        }
        // 添加默认分类
        object[1] = {
          name: "* 实验室公用",
          power: "01100"
        };
        object[2] = {
          name: "* 需申请预约",
          power: "11111"
        };
        object[3] = {
          name: "* 预约仪器",
          power: "11110"
        };
        object[4] = {
          name: "* 仅需申请",
          power: "11101"
        };
        this.typeObject = object;
        this.formatInstruValue();
      });
    },
    // 获取某种仪器预约情况
    getAppointDetail(row) {
      let path = "/api/v1/lab/getAppointment";
      let zero = new Date(new Date().toLocaleDateString()).getTime();
      let data = {
        labId: this.labInfo.fkLabId,
        endTimeGT: this.timestampFormat(new Date(zero)),
        name: row.name
      };
      this.instruPage.appoint[row.id] = {};
      this.axios.post(path, data).then(res => {
        this.getInstruExpand(row);
        if (res.data.code == 20000) {
          let object = {};
          res.data.data.forEach(item => {
            let harfHour = 30 * 60 * 1000;
            item.offday = 0;
            if (item.startTime <= zero) {
              item.offset = 0;
              item.span = Number((item.endTime - zero) / harfHour);
            } else {
              item.offset = Number((item.startTime - zero) / harfHour);
              item.offday = Math.floor(item.offset / 48);
              item.span = Number((item.endTime - item.startTime) / harfHour);
            }
            if (!object[item.fkPid + item.selfId])
              object[item.fkPid + item.selfId] = [];
            object[item.fkPid + item.selfId].push(item);
          });
          this.$set(this.instruPage.appoint, row.id + "", object);
        }
      });
    },
    // 展示预约具体信息
    showAppointDetail(rowId, irow, id) {
      let row = this.getInstruItemById(rowId);
      let data = this.instruPage.appoint[row.id][irow.fkPid + irow.selfId][id];
      let sponsorName = "申请人：" + data.sponsorName + "<br>";
      let startTime = this.timestampFormat(data.startTime).slice(0, 16);
      let start = "开始时间：" + startTime + "<br>";
      let endTime = this.timestampFormat(data.endTime).slice(0, 16);
      let end = "结束时间：" + endTime + "<br>";
      return sponsorName + start + end;
    },
    // 列表展开调用
    expandChange(row) {
      if (!this.instruPage.expand[row.id]) {
        this.getAppointDetail(row);
      }
    },
    // 列表显示数量变化调用
    pageSizeChange(val) {
      this.instruPage.pageSize = val;
    },
    // 列表当前页数变化调用
    pageCurrentChange(val) {
      this.instruPage.index = val;
    },
    // 获取仪器列表
    getInstruList() {
      let path = "/api/v1/lab/getInstrumentSummary";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: ["id"],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.instruPage.total = res.data.data.totalElements;
          this.instruPage.list = res.data.data.data;
          this.formatInstruValue();
          this.formatInstrFilter(this.instruPage.list);
          // console.info(this.instruPage);
        } else {
          // console.info(res.data.message);
          this.instruPage.list = [];
          this.instruPage.list.push({
            id: -100,
            name: "示例仪器",
            curCount: 1,
            fkLabId: this.labInfo.fkLabId,
            typeName: "示例标签",
            fkTagId: 2,
            unit: "台",
            picture: null,
            brand: "AMEKO",
            supplierName: "仪器供应商",
            tagName: "需申请预约",
            remark: null,
            attachment: null,
            place: "示例存放位置",
            isDelete: false,
            power: "11111",
            expand: true,
            visible: "可用"
          });
        }
      });
    },
    // 格式化列表筛选
    formatInstrFilter(list) {
      if (!list) return;

      let typeObject = {};
      let tagObject = {};
      let brandObject = {};
      let supplierObject = {};
      // 用对象获取非重复数组
      list.forEach(item => {
        typeObject[item.fkTagId] = item.tagName;
        tagObject[item.typeName] = "1";
        brandObject[item.brand] = "1";
        supplierObject[item.supplierName] = "1";
      });

      let typeList = [];
      let tagList = [];
      let brandList = [];
      let supplierList = [];
      // 将对象转数组
      for (let key in typeObject) {
        typeList.push({
          text: typeObject[key],
          value: key
        });
      }
      for (let key in tagObject) {
        tagList.push({
          text: key,
          value: key
        });
      }
      for (let key in brandObject) {
        brandList.push({
          text: key,
          value: key
        });
      }
      for (let key in supplierObject) {
        supplierList.push({
          text: key,
          value: key
        });
      }
      // 禁止更新筛选条件，避免死循环
      this.filter.lock = true;
      // 将数值赋给filter
      this.filter.type.list = typeList;
      this.filter.tag.list = tagList;
      this.filter.brand.list = brandList;
      this.filter.supplier.list = supplierList;
    },
    // 格式化列表expand、visible、loading
    formatInstruValue() {
      if (!this.instruPage.list) return;
      if (!this.typeObject) return;
      this.instruPage.list.forEach(item => {
        let power = "01100";
        if (this.typeObject[item.fkTagId]) {
          power = this.typeObject[item.fkTagId].power;
        }
        item.power = power;

        // 获取可预约仪器信息
        if ((item.power + "").slice(3, 4) == "1") {
          this.getAppointDetail(item);
        }

        // 初始化loading
        this.instruPage.loading[item.id] = false;

        // 初始化expand
        if (power.slice(3, 4) == "0" && power.slice(4, 5) == "0")
          item.expand = false;
        else item.expand = true;

        // 初始化visible
        if (!this.typeAdmin) this.typeAdmin = [];
        if (!this.labInfo.tagIds) this.labInfo.tagIds = [];
        if (["ADMIN", "OWNER"].includes(this.labInfo.role))
          item.visible = "可用";
        else if (
          power.slice(1, 2) == "1" ||
          this.typeAdmin.includes(item.fkTagId) ||
          this.labInfo.tagIds.includes(item.fkTagId)
        )
          item.visible = "可用";
        else if (
          power.slice(2, 3) == "1" ||
          this.typeAdmin.includes(item.fkTagId) ||
          this.labInfo.tagIds.includes(item.fkTagId)
        )
          item.visible = "仅可见";
        else item.visible = "不可见";
      });
      this.instruPage.list = JSON.parse(JSON.stringify(this.instruPage.list));
    },
    // 获取仪器展开内容
    getInstruExpand(row) {
      if (row.id == -100) {
        let expand = {
          id: -100,
          name: "电子显微镜",
          fkPid: -100,
          selfId: -100,
          place: "示例存放位置",
          fkLabId: this.labInfo.fkLabId,
          remark: null,
          brand: "示例品牌",
          supplierName: "仪器供应商",
          createTime: Date.now() - 365 * 24 * 3600 * 1000,
          isApply: true,
          alias: "示例仪器-1",
          isDelete: false,
          power: "11111"
        };
        this.$set(this.instruPage.expand, "-100", [expand]);
        return;
      }
      let path = "/api/v1/lab/goodsByName";
      let data = {
        params: {
          labId: this.labInfo.fkLabId,
          name: row.name,
          type: "INSTRUMENT"
        }
      };
      this.instruPage.loading[row.id] = true;
      this.axios.get(path, data).then(res => {
        this.instruPage.loading[row.id] = false;
        if (res.data.code == 20000) {
          if (res.data.data)
            res.data.data.forEach(item => {
              let power = this.typeObject[row.fkTagId].power;
              item.power = power;
            });
          this.$set(this.instruPage.expand, row.id + "", res.data.data);
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取仪器详细信息
    getInstruDetailInfo() {
      // let path = "/api/v1/lab/instrument";
      // let data = {
      // }
    },
    // 根据ID获取仪器信息
    getInstruItemById(id) {
      let result = null;
      this.instruPage.list.forEach(item => {
        if (item.id == id) {
          result = item;
          return;
        }
      });
      return result;
    },
    // 仪器预约列表点击预约时调用
    onAppointInstru(id, irow) {
      let row = this.getInstruItemById(id);
      this.appointForm.name = row.name;
      this.appointForm.alias = irow.alias;
      this.appointForm.fkPid = irow.fkPid;
      this.appointForm.selfId = irow.selfId;
      this.appointForm.apply = row.power.slice(4, 5) == "1";
      this.appointForm.row = row;

      // 获取当前仪器是预约情况
      let list = this.instruPage.appoint[row.id][irow.fkPid + irow.selfId];
      if (!list) list = [];

      // 生成当前仪器7天内每半小时的默认预约数组
      let array = Array.from(Array(48 * 7), () => {
        return {
          id: -1,
          before: false,
          select: false
        };
      });

      // 将当前仪器的预约数据存到appoint对象，初始化array中的id属性
      this.appointForm.appoint = {};
      list.forEach(item => {
        this.appointForm.appoint[item.id] = item;
        for (let i = item.offset; i < item.span + item.offset; i++) {
          array[i].id = item.id;
        }
      });

      // 初始化array中的before，表示时间已经过去
      let zero = new Date(new Date().toLocaleDateString()).getTime();
      let harfHour = 30 * 60 * 1000;
      let beforeLen = Math.ceil((Date.now() - zero) / harfHour);
      for (let i = 0; i < beforeLen; i++) {
        array[i].before = true;
      }

      // 将array存到dayAll数组中
      this.appointForm.dayAll = array;

      // 将array分成7天存到dayAppo对象中
      this.appointForm.dayAppo = {};
      for (let i = 0; i < 7; i++) {
        this.appointForm.dayAppo[i] = {
          date: this.getNextDate(i),
          days: array.slice(i * 48, i * 48 + 48)
        };
      }

      // 打开预约弹窗
      this.dialog.addAppoint = true;
    },
    // 选择预约时间调用
    onSelectAppoTime(row, col, item) {
      const updateTime = () => {
        // 更新表单预约时间
        let zero = new Date(new Date().toLocaleDateString()).getTime();
        let harfHour = 30 * 60 * 1000;
        if (this.appointForm.selTime[0]) {
          let row0 = this.appointForm.selTime[0].row;
          let col0 = this.appointForm.selTime[0].col;
          let time = zero + (row0 * 48 + col0) * harfHour;
          this.appointForm.startTime = this.timestampFormat(time);
        }
        if (this.appointForm.selTime[1]) {
          let row1 = this.appointForm.selTime[1].row;
          let col1 = this.appointForm.selTime[1].col;
          let time = zero + (row1 * 48 + col1 + 1) * harfHour;
          this.appointForm.endTime = this.timestampFormat(time);
        }
      };
      // 过去时间跟被预约时间不能点击
      if (item.id > 0 || item.before) {
        return;
      }
      // 将row转成数字
      row = Number(row);
      // 第一次点击
      if (this.appointForm.selTime.length < 2) {
        let object = {
          row: row,
          col: col
        };
        this.appointForm.selTime = [object, object];
        this.appointForm.dayAppo[row].days[col].select = true;
      }
      // 第n次点击
      else {
        let row0 = this.appointForm.selTime[0].row;
        let col0 = this.appointForm.selTime[0].col;
        let row1 = this.appointForm.selTime[1].row;
        let col1 = this.appointForm.selTime[1].col;
        let offset = row * 48 + col;
        let offset0 = row0 * 48 + col0;
        let offset1 = row1 * 48 + col1;
        // 清掉之前的选择
        const clearSelect = () => {
          for (let i = 0; i < 7; i++) {
            this.appointForm.dayAppo[i].days.forEach(item => {
              item.select = false;
            });
          }
        };
        // 如果已选（多个时间段），取消选择
        if (offset0 < offset1) {
          this.appointForm.selTime = [];
          this.appointForm.startTime = null;
          this.appointForm.endTime = null;
          clearSelect();
          return;
        }
        // 只有单个时间段，第二次点击，取消选择
        if (offset == offset0) {
          this.appointForm.selTime = [];
          this.appointForm.startTime = null;
          this.appointForm.endTime = null;
          clearSelect();
          return;
        }
        // 只有单个时间段，更新起点终点
        if (offset < offset0) {
          offset0 = offset;
          row0 = row;
          col0 = col;
        }
        if (offset > offset0) {
          offset1 = offset;
          row1 = row;
          col1 = col;
        }
        // 如果时间段包含无效点，当成第一次点击
        for (let i = offset0; i < offset1; i++) {
          let day = this.appointForm.dayAll[i];
          if (day.id > 0 || day.before) {
            clearSelect();
            let object = {
              row: row,
              col: col
            };
            this.appointForm.selTime = [object, object];
            this.appointForm.dayAppo[row].days[col].select = true;
            updateTime();
            return;
          }
        }
        // 更新时间段
        this.appointForm.selTime = [
          {
            row: row0,
            col: col0
          },
          {
            row: row1,
            col: col1
          }
        ];
        // 更新select值
        for (let i = 0; i < 7; i++) {
          for (let j = 0; j < 48; j++) {
            if (i * 48 + j >= offset0 && i * 48 + j <= offset1) {
              this.appointForm.dayAppo[i].days[j].select = true;
            }
          }
        }
      }
      updateTime();
    },
    // 获取当前日期后n天的日期
    getNextDate(val) {
      val = val ? val : 0;
      let now = Date.now();
      let diff = val * 24 * 3600 * 1000;
      let date = new Date(now + diff);
      let M = date.getMonth() + 1;
      let D = date.getDate();
      return M + "月" + D + "日";
    },
    // 时间戳转换
    timestampFormat(val) {
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "-" + M + "-" + D + " " + h + ":" + m + ":" + s;
    },
    // 计算预约弹窗中的预期时间表单元样式
    getAppoFormStyle(row, col, item) {
      let background = "";
      if (item.id > 0) background = "var(--warning)";
      if (item.before) background = "#f9f9f9";
      if (item.select) background = "#75b2fa";
      return { background: background };
    },
    // 向后台提交预约
    doCreateAppoint() {
      console.info(this.appointForm);
      if (this.appointForm.selfId == -100) {
        return this.$message.info("示例仪器，添加仪器后自动移除");
      }
      if (!this.appointForm.startTime || !this.appointForm.endTime) {
        this.$message.error("请选择预约时间");
        return;
      }
      if (
        this.appointForm.apply &&
        (!this.appointForm.title ||
          !this.appointForm.content ||
          !this.appointForm.manager.length)
      ) {
        this.$message.error("请申请相关信息");
        return;
      }
      // 提交预约
      let path = "/api/v1//lab/instrumentAppoint";
      let data = {
        labId: this.labInfo.fkLabId,
        pid: this.appointForm.fkPid,
        selfId: this.appointForm.selfId,
        name: this.appointForm.name,
        startTime: this.appointForm.startTime,
        endTime: this.appointForm.endTime,
        title: this.appointForm.title,
        content: this.appointForm.content,
        manager_ids: this.appointForm.manager
      };
      // console.info(data);
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.addAppoint = false;
          this.$message.success("已成功提交");
          this.getAppointDetail(this.appointForm.row);
          this.appointForm = {
            appoint: {},
            dayAppo: {},
            dayAll: [],
            selTime: [],
            pid: null,
            selfId: null,
            name: null,
            startTime: null,
            endTime: null,
            title: null,
            content: null,
            manager: [],
            apply: false,
            row: null
          };
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 查看仪器详情调用
    onViewInstru(row) {
      this.detailForm = JSON.parse(JSON.stringify(row));
      if (!this.typeObject[this.detailForm.fkTagId]) {
        this.detailForm.tagName = "实验室公用";
      }
      this.dialog.viewInstru = true;
    },
    // 删除仪器总览
    onDeleteInstru(row) {
      if (row.id == -100) {
        return this.$message.info("示例仪器，添加仪器后自动移除");
      }
      const doDeletePlace = () => {
        let path = "/api/v1/lab/instrumentSummaryWithNames";
        let data = {
          params: {
            names: row.name,
            labId: this.labInfo.fkLabId
          }
        };
        this.axios.delete(path, data).then(res => {
          if (res.data.code == 20000) {
            this.$message.success(res.data.message);
            this.goPath("/instrument?refresh=" + Date.now());
          } else {
            this.$message.error(res.data.message);
          }
        });
      };
      this.$confirm("此操作将删除对应的所有仪器，是否继续？", "提示", {
        type: "warning",
        distinguishCancelAndClose: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(() => doDeletePlace())
        .catch(() => {
          this.$message.info("取消删除");
        });
    }
  }
};
</script>

<style scoped>
.instru {
  width: 100%;
  min-width: 1000px;
  position: relative;
  /* height: 100%; */
}
.instru .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.instru .el-tab-pane {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 8px;
  padding: 0 20px;
  box-sizing: border-box;
}
.instru .upper {
  width: 100%;
  height: 40px;
}
.instru .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.instru .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}
.instru .upper > .el-button:nth-child(2) {
  margin-right: 16px;
}
.instru .middle {
  width: 100%;
  min-height: 750px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  /* border: 1px var(--border3) solid; */
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.instru .el-table .el-link {
  font-size: 12px;
  text-decoration: none;
  user-select: none;
}
.instru .el-table .el-link::after {
  display: none;
}
.instru .el-table .el-link + .el-link {
  margin-left: 12px;
}
.instru .el-table .appoint-detail {
  height: 20px;
  position: relative;
  background: #f0f2f5;
}
.instru .el-table .appoint-detail .appoint-item {
  display: inline-block;
  height: 20px;
  position: absolute;
  background: var(--warning);
}
.instru .el-table .appoint-detail .appoint-driver {
  height: 100%;
  position: absolute;
  width: 2px;
  background: white;
  pointer-events: none;
}
.instru .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
</style>

<style scoped>
.instru .guide {
  background: rgba(0, 0, 0, 0.66);
  width: 100%;
  height: 100%;
  color: #cccccc;
  font-size: 14px;
  z-index: 10010;
  position: absolute;
  left: 0;
  top: 0;
}
.instru .guide .btn {
  width: 80px;
  margin: 0 -40px;
  position: absolute;
  right: 50%;
  top: 400px;
}
.instru .guide-list .one .box {
  width: 80px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  left: 14px;
  top: 116px;
}
.instru .guide-list .one .desc {
  width: 125px;
  position: absolute;
  left: 105px;
  top: 120px;
}
.instru .guide-list .two .box {
  width: 410px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 116px;
}
.instru .guide-list .two .desc {
  width: 150px;
  position: absolute;
  right: 276px;
  top: 92px;
}
.instru .guide-list .three .box {
  width: calc(100% - 30px);
  height: 130px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.instru .guide-list .three .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 330px;
}
.instru .guide-appoint .one .box {
  width: calc(100% - 30px);
  height: 120px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.instru .guide-appoint .one .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 160px;
}
.instru .guide-history .one .box {
  width: calc(100% - 30px);
  height: 130px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 140px;
}
.instru .guide-history .one .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 110px;
}
</style>

<style>
.instru .el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 14px;
  line-height: 40px;
  user-select: none;
}
.instru .el-tabs__nav-scroll .el-tabs__item {
  padding: 0 16px;
}
.instru .el-tabs__nav-wrap::after {
  background-color: var(--border3);
}
.describle-stock {
  color: var(--text3);
  line-height: 20px;
  box-shadow: none;
  user-select: none;
  font-size: 12px;
  max-width: 360px;
  display: inline-block;
  vertical-align: middle;
  font-weight: 500;
}
.instru .middle .none .el-table__expand-column .cell {
  display: none !important;
}
.instru .middle .el-table__expand-column.is-leaf > .cell {
  text-align: left !important;
}
.instru .middle .el-table__expand-column > .cell > * {
  margin-left: calc(-50% - 20px);
}
.instru .middle .el-table__expanded-cell {
  padding-left: 0px;
  padding-right: 0;
}
.instru .middle .el-table__expanded-cell .el-table::before {
  height: 0;
}
.instru .middle .el-table__expanded-cell .el-table__row > td {
  border-bottom: none;
}
.instru .middle .el-table__expanded-cell .el-table__row:hover > td {
  background: transparent;
}
.instru .add-appoint .el-dialog {
  max-width: 1000px;
  min-width: 900px;
}
.instru .add-appoint .el-dialog .el-dialog__header {
  border-bottom: 1px solid var(--border1);
}
.instru .add-appoint .el-dialog .el-dialog__body {
  padding-top: 20px;
}
.instru .add-appoint .main {
  width: 100%;
}
.instru .add-appoint .main .row {
  width: 100%;
  display: flex;
  margin: 10px 0;
  font-size: 12px;
  line-height: 20px;
}
.instru .add-appoint .main .row .label {
  user-select: none;
  width: 80px !important;
}
.instru .add-appoint .main .row .item {
  flex: 1 1 auto;
  text-align: center;
  display: inline-block;
  margin: 0 0 0 1px;
  border-radius: 1px 0px 0px 1px;
  background: #e0e2e5;
}
.instru .add-appoint .main .row .item:hover {
  background: #e1e1e1;
}
.instru .add-appoint .el-form .appo-time .el-input__inner:hover,
.instru .add-appoint .el-form .appo-time .el-input__inner:focus {
  border-color: var(--border2);
}
.instru .add-appoint .main .row .item:nth-child(2n - 1) {
  margin: 0;
  border-radius: 0px 1px 1px 0px;
  /* border-left: 1px solid rgba(255, 255, 255, 0.16); */
}
.el-tooltip__popper.is-light {
  border: none;
  box-shadow: 0 0 6px -1px rgba(140, 146, 163, 0.5);
}
.el-tooltip__popper.is-light .popper__arrow {
  border-top-color: rgba(140, 146, 163, 0.23) !important;
}
.instru .appoint .el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: #fff !important;
}
</style>