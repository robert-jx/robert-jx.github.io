<template>
  <div class="label">
    <div class="head">分类标签与策略设置</div>

    <el-tabs v-model="activeTab">
      <!-- 分类列表 -->
      <el-tab-pane label="分类列表" name="first">
        <!--  顶部操作 -->
        <div class="upper">
          <el-button type="primary" @click="onCreateType" v-if="doingBool">新建分类</el-button>
          <span class="describle-label">功能简介：管理者可以自定义不同类型的权限设置，方便对不同场景的分类和分级管理</span>
          <el-input placeholder="搜索分类" clearable v-model="typePage.search">
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <!-- 中间列表 -->
        <div class="middle">
          <el-table :data="currentTypeList" :row-class-name="typeRowClass">
            <el-table-column prop="name" label="分类名称" width="180"></el-table-column>
            <el-table-column prop="permission" label="分类权限" width="460">
              <template slot-scope="scope">{{ scope.row.power | powerFormat }}</template>
            </el-table-column>
            <el-table-column prop="name" label="管理员">
              <template slot-scope="scope">{{ scope.row.admin | typeAdminFormat }}</template>
            </el-table-column>
            <el-table-column label="操作" :width="typeDoingWidth">
              <template slot-scope="scope" class="doing">
                <el-link type="info" @click="onViewType(scope.row)">详情</el-link>
                <el-link
                  v-if="scope.row.id > 128 && doingBool"
                  type="primary"
                  @click="onEditType(scope.row)"
                >修改</el-link>
                <el-link
                  v-if="scope.row.id > 128 && doingBool"
                  type="danger"
                  @click="onDeleteType(scope.row)"
                >删除</el-link>
                <!-- <span v-else> 系统默认 </span> -->
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页显示 -->
          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="typePage.pageSize"
            @size-change="typeSizeChange"
            :current-page="typePage.index"
            @current-change="typeCurrentChange"
            layout="sizes, prev, pager, next"
            :total="typePage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>

      <!-- 标签列表 -->
      <el-tab-pane label="标签列表" name="second">
        <!-- 顶部操作 -->
        <div class="upper">
          <el-button type="primary" v-if="doingBool" @click="onCreateLabel">新建标签</el-button>
          <span class="describle-label">功能简介：管理者可以自定义不同的标签，方便对物品进行标记。</span>

          <el-input placeholder="搜索标签" clearable v-model="labelPage.search">
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <!-- 中间列表 -->
        <div class="middle">
          <el-table :data="currentLabelList">
            <el-table-column prop="typeName" label="标签名称"></el-table-column>
            <el-table-column label="操作" :width="labelDoingWidth">
              <template slot-scope="scope" class="doing" v-if="doingBool">
                <el-link type="primary" @click="onEditLabel(scope.row)">修改</el-link>
                <el-link type="danger" @click="onDeleteLabel(scope.row)">删除</el-link>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页显示 -->
          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="labelPage.pageSize"
            @size-change="labelSizeChange"
            :current-page="labelPage.index"
            @current-change="labelCurrentChange"
            layout="sizes, prev, pager, next"
            :total="labelPage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>
    </el-tabs>

    <!-- 分类弹窗 -->
    <el-dialog
      :close-on-click-modal="false"
      :title="typeForm.type"
      class="create-type"
      :visible.sync="dialog.editType"
      width="640px"
    >
      <el-form ref="typeForm" :model="typeForm" label-width="120px">
        <el-form-item label="分类名称">
          <el-input
            :disabled="typeForm.type == '分类详情'"
            v-model="typeForm.name"
            placeholder="请输入分类名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="管理员">
          <el-select
            v-model="typeForm.admin"
            multiple
            filterable
            :placeholder="
              typeForm.type == '分类详情' && !typeForm.admin.length
                ? '无管理员'
                : null
            "
            :disabled="typeForm.type == '分类详情'"
          >
            <el-option v-for="item in userList" :key="item[0]" :label="item[2]" :value="item[0]">
              <span style="float: left">{{ item[2] }}</span>
              <span
                style="float: right; color: #8492a6; font-size: 13px"
              >{{ item[1] | adminFormat }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="关联用户">
          <el-cascader
            :disabled="typeForm.type == '分类详情'"
            v-model="typeForm.user"
            :placeholder="
              typeForm.type == '分类详情' && !typeForm.user.length
                ? '无关联用户'
                : null
            "
            :options="groupList"
            :props="{ multiple: true }"
            :show-all-levels="false"
          ></el-cascader>
        </el-form-item>
        <el-form-item label="管理方式">
          <el-radio
            v-model="typeForm.power.granular"
            label="0"
            :disabled="
              typeForm.type == '分类详情' || typeForm.power.appoint == '1'
            "
            v-if="typeForm.type != '分类详情' || typeForm.power.usable == '0'"
          >普通管理</el-radio>
          <el-radio
            v-model="typeForm.power.granular"
            label="1"
            :disabled="
              typeForm.type == '分类详情' || typeForm.power.appoint == '1'
            "
            v-if="typeForm.type != '分类详情' || typeForm.power.usable == '1'"
          >精细管理</el-radio>
        </el-form-item>
        <el-form-item label="可用人员" style="margin-top: -12px">
          <el-radio
            v-model="typeForm.power.usable"
            label="0"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.usable == '0'"
          >关联用户可用</el-radio>
          <el-radio
            v-model="typeForm.power.usable"
            label="1"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.usable == '1'"
          >实验室内共用</el-radio>
        </el-form-item>
        <el-form-item label="可见人员" style="margin-top: -12px">
          <el-radio
            v-model="typeForm.power.visible"
            label="0"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.visible == '0'"
          >关联用户可见</el-radio>
          <el-radio
            v-model="typeForm.power.visible"
            label="1"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.visible == '1'"
          >实验室内可见</el-radio>
        </el-form-item>
        <el-form-item label="仪器预约" style="margin-top: -12px">
          <el-radio
            v-model="typeForm.power.appoint"
            label="0"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.appoint == '0'"
          >无需预约</el-radio>
          <el-radio
            v-model="typeForm.power.appoint"
            label="1"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.appoint == '1'"
          >需要预约</el-radio>
        </el-form-item>
        <el-form-item label="使用申请" style="margin-top: -12px">
          <el-radio
            v-model="typeForm.power.apply"
            label="0"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.apply == '0'"
          >无需申请</el-radio>
          <el-radio
            v-model="typeForm.power.apply"
            label="1"
            :disabled="typeForm.type == '分类详情'"
            v-if="typeForm.type != '分类详情' || typeForm.power.apply == '1'"
          >需要申请</el-radio>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button v-if="typeForm.type != '分类详情'" size="medium" @click="dialog.editType = false">取 消</el-button>
        <el-button type="primary" size="medium" @click="submitTypeForm">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 标签弹窗 -->
    <el-dialog
      :close-on-click-modal="false"
      :title="labelForm.type"
      class="create-label"
      :visible.sync="dialog.editLabel"
      width="640px"
    >
      <el-form :model="labelForm" label-width="120px">
        <el-form-item label="标签名称">
          <el-input v-model="labelForm.name" placeholder="请输入标签名称"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.editLabel = false">取 消</el-button>
        <el-button type="primary" size="medium" @click="submitLabelForm">确 定</el-button>
      </span>
    </el-dialog>

    <div class="guide guide-type" v-show="guide.label.type=='show' && activeTab=='first'">
      <div class="one" v-show="doingBool">
        <div class="box"></div>
        <span class="desc">您可在此建立分类，方便对不同场景的分类和分级管理</span>
      </div>
      <div class="two">
        <div class="box"></div>
        <span class="desc">您可在此搜索相关分类</span>
      </div>
      <div class="three">
        <div class="box"></div>
        <span v-show="doingBool" class="desc">您可在此浏览、修改和删除相关分类</span>
        <span v-show="!doingBool" class="desc">您可在此浏览相关分类</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('label', 'type')">关闭</el-button>
    </div>

    <div class="guide guide-label" v-show="guide.label.label=='show' && activeTab=='second'">
      <div class="one" v-show="doingBool">
        <div class="box"></div>
        <span class="desc">您可在此建立标签，方便对不同的物品做标记</span>
      </div>
      <div class="two">
        <div class="box"></div>
        <span class="desc">您可在此搜索相关标签</span>
      </div>
      <div class="three">
        <div class="box"></div>
        <span v-show="doingBool" class="desc">您可在此浏览、修改和删除相关标签</span>
        <span v-show="!doingBool" class="desc">您可在此浏览相关标签</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('label', 'label')">关闭</el-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      labInfo: null, // 基本信息
      activeTab: "first", // 标签页
      dialog: {
        editType: false, // 分类弹窗
        editLabel: false // 标签弹窗
      },
      typeForm: {
        type: "新建分类", // 分类弹窗标题
        id: "-1", // 分类ID
        name: "", // 分类名
        admin: [], // 管理员列表
        user: [], // 关联用户列表
        power: {
          // 分类权限
          granular: "0", // 粒度
          usable: "0", // 可用
          visible: "0", // 可见
          appoint: "0", // 预约
          apply: "0" // 申请
        }
      },
      labelForm: {
        type: "新建标签", // 标签弹窗标题
        id: "-1", // 标签ID
        name: null // 标签名
      },
      editType: null, // 修改前的分类信息
      userList: null, // 用户列表
      groupList: null, // 课题组列表
      typePage: {
        index: 1, // 分类列表当前页数
        pageSize: 10, // 分类列表页面大小
        total: 0, // 分类列表大小
        list: [], // 分类列表数据
        search: null // 分类列表搜索
      },
      labelPage: {
        index: 1, // 标签列表当前页数
        pageSize: 10, // 标签列表页面大小
        total: 0, // 标签列表大小
        list: [], // 标签列表数据
        search: null // 标签列表搜索
      }
    };
  },
  watch: {
    // 监听关联成员选择，避免重复选择
    "typeForm.user"(newV) {
      let object = {};
      newV.forEach(item => {
        object[item[1]] = item[0];
      });
      this.groupList.forEach(item => {
        item.children.forEach(item2 => {
          if (object[item2.value] && object[item2.value] != item2.parent) {
            item2.disabled = true;
          } else {
            item2.disabled = false;
          }
        });
      });
    },
    // 选择预约时默认选中精细管理
    "typeForm.power.appoint"(newV) {
      if (newV == "1") {
        this.typeForm.power.granular = "1";
      }
    },
    // 监听分类搜索，更改页数
    "typePage.search"() {
      this.typePage.index = 1;
    },
    // 监听标签搜索，更改页数
    "labelPage.search"() {
      this.labelPage.index = 1;
    }
  },
  computed: {
    // 计算显示分类列表当前页
    currentTypeList() {
      let list = this.typePage.list;
      let search = this.typePage.search;
      if (search) {
        list = list.filter(
          data =>
            !search || data.name.toLowerCase().includes(search.toLowerCase())
        );
      }
      let start = (this.typePage.index - 1) * this.typePage.pageSize;
      let end = start + this.typePage.pageSize;
      return list.slice(start, end);
    },
    // 计算显示标签列表当前页
    currentLabelList() {
      let list = this.labelPage.list;
      let search = this.labelPage.search;
      if (search) {
        list = list.filter(
          data =>
            !search ||
            data.typeName.toLowerCase().includes(search.toLowerCase())
        );
      }
      let start = (this.labelPage.index - 1) * this.labelPage.pageSize;
      let end = start + this.labelPage.pageSize;
      return list.slice(start, end);
    },
    // 判断用户是否有权限操作
    doingBool() {
      if (!this.labInfo) return false;
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN";
    },
    typeDoingWidth() {
      if (!this.labInfo) return "50";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "120"
        : "50";
    },
    labelDoingWidth() {
      if (!this.labInfo) return "1";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "90"
        : "1";
    },
    guide() {
      return this.$store.state.guide;
    }
  },
  mounted() {
    this.initLabInfo();
    this.getGroupUserInfo();
    this.getTypeUser();
    this.getLabelList();
  },
  methods: {
    closeGuide(val1, val2) {
      if (val1 == "label") this.guide[val1][val2] = "hidden";

      let path = "/api/v1/utils/members/guide/" + this.labInfo.fkAccountName;
      let data = JSON.parse(JSON.stringify(this.$store.state.guide));
      delete data._id;
      this.axios.post(path, data);
    },
    // 更改默认分类样式
    typeRowClass({ row }) {
      if (row.id <= 128) return "system";
      return "";
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 分类列表显示数量变化调用
    typeSizeChange(val) {
      this.typePage.pageSize = val;
    },
    // 标签列表显示数量变化调用
    labelSizeChange(val) {
      this.labelPage.pageSize = val;
    },
    // 分类列表当前页数变化调用
    typeCurrentChange(val) {
      this.typePage.index = val;
    },
    // 标签列表当前页数变化调用
    labelCurrentChange(val) {
      this.labelPage.index = val;
    },
    // 获取课题组跟用户相关信息
    getGroupUserInfo() {
      let path = "/api/v1/lab/researchGroupsAndDetails";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.userList = res.data.data.labDetails;
          // 将数组转化为对象数组（将相同课题组的数据项放在一起）
          let list = res.data.data.researchGroupDetails;
          if (!list) list = [];
          let onGroupObject = {};
          let object = {};
          list.forEach(item => {
            let key = item.groupName;
            if (!object[key]) object[key] = [];
            object[key].push({
              value: item.fkLabDetailId,
              label: item.detailName,
              parent: item.groupName
            });
            onGroupObject[item.fkLabDetailId] = 1;
          });
          // 将其他不在课题组的用户放入其他用户组
          object["其他实验室成员"] = [];
          this.userList.forEach(item => {
            if (onGroupObject[item[0]] == 1) return;
            object["其他实验室成员"].push({
              value: item[0],
              label: item[2],
              parent: "其他实验室成员"
            });
          });
          // 将对象数组转为二维数组（转为组件数据格式）
          this.groupList = [];
          for (let key in object) {
            this.groupList.push({
              value: key,
              label: key,
              children: object[key]
            });
          }
        }
      });
    },
    // 获取分类的管理员跟关联用户相关信息
    getTypeUser() {
      let path = "/api/v1/lab/init";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          let tagHash = res.data.data.tagHash ? res.data.data.tagHash : [];
          let labDetails = res.data.data.labDetails
            ? res.data.data.labDetails
            : [];
          // 将数组转对象，方便处理数据
          let object = {};
          tagHash.forEach(item => {
            let key = item.id;
            if (!object[key]) object[key] = {};
            object[key].name = item.name;
            object[key].power = item.permission;
            object[key].user = [];
            // 生成管理员数组
            object[key].admin = [];
            if (item.fkAdminIds) {
              let list = item.fkAdminIds.split(",");
              list.forEach(id => {
                if (id) {
                  let admin = {};
                  for (let user of labDetails) {
                    if (user.id == id) {
                      admin = {
                        id: user.id,
                        name: user.realName,
                        role: user.role
                      };
                      break;
                    }
                  }
                  object[key].admin.push(admin);
                }
              });
            }
          });
          // 生成关联用户数组
          labDetails.forEach(item => {
            if (item.tagIds) {
              let list = item.tagIds.split(",");
              list.forEach(id => {
                if (id && object[id]) {
                  object[id].user.push({
                    id: item.id,
                    name: item.realName,
                    role: item.role
                  });
                }
              });
            }
          });
          // 将对象转化成数组
          this.typePage.total = tagHash.length;
          this.typePage.list = [];
          for (let key in object) {
            this.typePage.list.push({
              id: key,
              name: object[key].name,
              power: object[key].power,
              admin: object[key].admin,
              user: object[key].user
            });
          }
          this.typePage.list.reverse();
          // 添加默认分类
          this.typePage.list.unshift(
            {
              id: 1,
              name: "* 实验室公用",
              power: "01100",
              admin: "——",
              user: "——"
            },
            {
              id: 2,
              name: "* 需申请预约",
              power: "11111",
              admin: "——",
              user: "——"
            },
            {
              id: 3,
              name: "* 预约仪器",
              power: "11110",
              admin: "——",
              user: "——"
            },
            {
              id: 4,
              name: "* 仅需申请",
              power: "11101",
              admin: "——",
              user: "——"
            }
          );
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取标签列表
    getLabelList() {
      let path = "/api/v1/lab/getCategories";
      let data = {
        labId: this.labInfo.fkLabId,
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: []
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.labelPage.total = res.data.data.totalElements;
          this.labelPage.list = res.data.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 分类弹窗点击提交调用
    submitTypeForm() {
      if (this.typeForm.type == "新建分类") this.doCreateType();
      if (this.typeForm.type == "修改分类") this.doEditType();
      if (this.typeForm.type == "分类详情") this.doViewType();
    },
    // 标签弹窗点击提交调用
    submitLabelForm() {
      if (this.labelForm.type == "新建标签") this.doCreateLabel();
      if (this.labelForm.type == "修改标签") this.doEditLabel();
    },
    // 向后台提交新建分类
    doCreateType() {
      let path = "/api/v1/lab/tag";
      let power = this.typeForm.power;
      let permission =
        power.granular +
        power.usable +
        power.visible +
        power.appoint +
        power.apply;
      let user = [];
      this.typeForm.user.forEach(item => {
        user.push(item[1]);
      });
      let data = {
        name: this.typeForm.name,
        permission: permission,
        fkAdminIds: this.typeForm.admin,
        fkLabDetailIds: user,
        fkLabId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.editType = false;
          this.$message.success(res.data.message);
          this.typeForm = {
            name: "",
            admin: [],
            user: [],
            power: {
              granular: "0",
              usable: "0",
              visible: "0",
              appoint: "0",
              apply: "0"
            }
          };
          this.getTypeUser();
          this.typePage.index = 1;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 向后台提交新建标签
    doCreateLabel() {
      let path = "/api/v1/lab/category";
      let data = {
        name: this.labelForm.name,
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.editLabel = false;
          this.labelForm = {
            type: "新建标签",
            id: "-1",
            name: ""
          };
          this.$message.success(res.data.message);
          this.getLabelList();
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 向后台提交修改分类
    doEditType() {
      let path = "/api/v1/lab/tag";
      let power = this.typeForm.power;
      let permission =
        power.granular +
        power.usable +
        power.visible +
        power.appoint +
        power.apply;

      let user1 = []; // 修改后
      let user2 = []; // 修改前
      let detailAdd = []; // 增加的
      let detailDel = []; // 减少的
      this.typeForm.user.forEach(item => {
        user1.push(item[1]);
      });
      this.editType.user.forEach(item => {
        user2.push(item[1]);
      });
      user1.forEach(id => {
        if (!user2.includes(id)) detailAdd.push(id);
      });
      user2.forEach(id => {
        if (!user1.includes(id)) detailDel.push(id);
      });

      let admin1 = this.typeForm.admin;
      let admin2 = this.editType.admin;
      let adminAdd = [];
      let adminDel = [];
      admin1.forEach(id => {
        if (!admin2.includes(id)) adminAdd.push(id);
      });
      admin2.forEach(id => {
        if (!admin1.includes(id)) adminDel.push(id);
      });

      let data = {
        id: this.typeForm.id,
        name: this.typeForm.name,
        permission: permission,
        labId: this.labInfo.fkLabId,
        detailAdd: detailAdd,
        detailDel: detailDel,
        adminAdd: adminAdd,
        adminDel: adminDel
      };
      console.info(data);
      this.axios.put(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.editType = false;
          this.$message.success(res.data.message);
          this.typeForm = {
            id: "-1",
            name: "",
            admin: [],
            user: [],
            power: {
              granular: "0",
              usable: "0",
              visible: "0",
              appoint: "0",
              apply: "0"
            }
          };
          this.getTypeUser();
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 向后台提交修改标签
    doEditLabel() {
      let path = "/api/v1/lab/category";
      let data = {
        id: this.labelForm.id,
        typeName: this.labelForm.name,
        fkLabId: this.labInfo.fkLabId
      };
      this.axios.put(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.editLabel = false;
          this.labelForm = {
            type: "修改标签",
            id: "-1",
            name: ""
          };
          this.$message.success(res.data.message);
          this.getLabelList();
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 关闭分类详情调用
    doViewType() {
      this.dialog.editType = false;
      this.typeForm = {
        name: "",
        admin: [],
        user: [],
        power: {
          usable: "0",
          visible: "0",
          appoint: "0",
          apply: "0"
        }
      };
    },
    // 向后台提交删除分类
    doDeleteType(val) {
      let path = "/api/v1/lab/tags";
      let data = {
        ids: [val.id],
        labId: this.labInfo.fkLabId
      };
      this.axios.delete(path, { data: data }).then(res => {
        if (res.data.code == 20000) {
          this.$message.success(res.data.message);
          this.getTypeUser();
          console.info(res.data);
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 向后台提交删除标签
    doDeleteLabel(val) {
      let path = "/api/v1/lab/category";
      let data = {
        id: val.id,
        typeName: val.typeName,
        fkLabId: this.labInfo.fkLabId
      };
      this.axios.delete(path, { data: data }).then(res => {
        if (res.data.code == 20000) {
          this.$message.success(res.data.message);
          this.getLabelList();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 点击新建分类调用
    onCreateType() {
      this.typeForm.type = "新建分类";
      this.dialog.editType = true;
    },
    // 点击新建标签调用
    onCreateLabel() {
      this.typeForm.type = "新建标签";
      this.dialog.editLabel = true;
    },
    // 点击修改分类调用
    onEditType(val) {
      let adminList = [];
      let userList = [];
      const getGroupName = id => {
        let result = "";
        this.groupList.forEach(item => {
          item.children.forEach(user => {
            if (user.value == id) result = user.parent;
          });
        });
        return result;
      };
      val.admin.forEach(user => {
        if (user.id) adminList.push(user.id);
      });
      val.user.forEach(user => {
        if (user.id) userList.push([getGroupName(user.id), user.id]);
      });
      this.typeForm.admin = adminList;
      this.typeForm.user = userList;
      this.typeForm.id = val.id;
      this.typeForm.name = val.name;
      this.typeForm.power = {
        granular: val.power.slice(0, 1),
        usable: val.power.slice(1, 2),
        visible: val.power.slice(2, 3),
        appoint: val.power.slice(3, 4),
        apply: val.power.slice(4, 5)
      };
      this.typeForm.type = "修改分类";
      this.editType = JSON.parse(JSON.stringify(this.typeForm));
      this.dialog.editType = true;
    },
    // 点击修改标签调用
    onEditLabel(val) {
      this.labelForm.type = "修改标签";
      this.labelForm.id = val.id;
      this.labelForm.name = val.typeName;
      this.dialog.editLabel = true;
    },
    // 点击分类详情调用
    onViewType(val) {
      let adminList = [];
      let userList = [];
      const getGroupName = id => {
        let result = "";
        this.groupList.forEach(item => {
          item.children.forEach(user => {
            if (user.value == id) result = user.parent;
          });
        });
        return result;
      };
      let buffList1 = val.admin != "——" ? val.admin : [];
      let buffList2 = val.user != "——" ? val.user : [];
      buffList1.forEach(user => {
        if (user.id) adminList.push(user.id);
      });
      buffList2.forEach(user => {
        if (user.id) userList.push([getGroupName(user.id), user.id]);
      });
      this.typeForm.admin = adminList;
      this.typeForm.user = userList;
      this.typeForm.id = val.id;
      this.typeForm.name = val.name;
      this.typeForm.power = {
        usable: val.power.slice(0, 1),
        visible: val.power.slice(1, 2),
        appoint: val.power.slice(2, 3),
        apply: val.power.slice(3, 4)
      };
      this.typeForm.type = "分类详情";
      this.dialog.editType = true;
    },
    // 点击删除分类调用
    onDeleteType(val) {
      this.$confirm(
        "此操作会将对应物品的分类更改为实验室公用，是否继续？",
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }
      )
        .then(() => {
          this.doDeleteType(val);
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    },
    // 点击删除标签调用
    onDeleteLabel(val) {
      this.$confirm("此操作将移除相关物品的对应标签，是否继续？", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.doDeleteLabel(val);
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    }
  },
  filters: {
    // 转换管理员显示
    adminFormat(val) {
      if (val == "OWNER") return "所有者";
      if (val == "ADMIN") return "管理员";
      if (val == "CATEGORY_ADMIN") return "分类管理员";
      if (val == "MEMBER") return "成员";
    },
    // 转换分类权限显示
    powerFormat(val) {
      val = val + "";
      let granular = val.slice(0, 1) == 1 ? "精细管理 · " : "普通管理 · ";
      let usable = val.slice(1, 2) == 1 ? "实验室内公用 · " : "关联用户可用 · ";
      let visible =
        val.slice(2, 3) == 1 ? "实验室内可见 · " : "关联用户可见 · ";
      let appoint = val.slice(3, 4) == 1 ? "需要预约 · " : "无需预约 · ";
      let apply = val.slice(4, 5) == 1 ? "需要申请" : "无需申请";
      return granular + usable + visible + appoint + apply;
    },
    // 转换管理员显示
    typeAdminFormat(val) {
      if (!val) return "无";
      if (val == "——") return "实验室管理员";
      let result = "";
      val.forEach(user => {
        result += user.name ? user.name + " / " : "";
      });
      result = result.slice(0, result.length - 3);
      if (!result) result = "无";
      return result;
    }
  }
};
</script>

<style scoped>
.label {
  width: 100%;
  min-width: 1000px;
  /* height: 100%; */
  position: relative;
}
.label .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.label .el-tab-pane {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 8px;
  padding: 0 20px;
  box-sizing: border-box;
}
.label .upper {
  width: 100%;
  height: 40px;
}
.label .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.label .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}
.label .upper > .el-button:first-child {
  margin-right: 16px;
}
.describle-label {
  color: var(--text3);
  line-height: 20px;
  box-shadow: none;
  user-select: none;
  font-size: 12px;
  max-width: 360px;
  display: inline-block;
  vertical-align: middle;
  font-weight: 500;
}
.label .middle {
  width: 100%;
  min-height: 650px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.label .el-table .el-link {
  font-size: 12px;
  text-decoration: none;
  user-select: none;
}
.label .el-table .el-link::after {
  display: none;
}
.label .el-table .el-link + .el-link {
  margin-left: 12px;
}
.label .el-table span {
  font-size: 12px;
  color: var(--text3);
  user-select: none;
}
.label .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
.label .create-type .el-form,
.label .create-label .el-form {
  padding-right: 70px;
  box-sizing: border-box;
}
.label .create-type .el-form .el-select,
.label .create-type .el-form .el-cascader {
  width: 100%;
}
</style>

<style scoped>
.label .guide {
  background: rgba(0, 0, 0, 0.66);
  width: 100%;
  height: 100%;
  color: #cccccc;
  font-size: 14px;
  z-index: 10010;
  position: absolute;
  left: 0;
  top: 0;
}
.label .guide .btn {
  width: 80px;
  margin: 0 -40px;
  position: absolute;
  right: 50%;
  top: 400px;
}
.label .guide-type .one .box {
  width: 110px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  left: 14px;
  top: 116px;
}
.label .guide-type .one .desc {
  width: 180px;
  position: absolute;
  left: 135px;
  top: 120px;
}
.label .guide-type .two .box {
  width: 410px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 116px;
}
.label .guide-type .two .desc {
  width: 150px;
  position: absolute;
  right: 276px;
  top: 92px;
}
.label .guide-type .three .box {
  width: calc(100% - 30px);
  height: 120px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.label .guide-type .three .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 320px;
}

.label .guide-label .one .box {
  width: 110px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  left: 14px;
  top: 116px;
}
.label .guide-label .one .desc {
  width: 140px;
  position: absolute;
  left: 135px;
  top: 120px;
}
.label .guide-label .two .box {
  width: 410px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 116px;
}
.label .guide-label .two .desc {
  width: 150px;
  position: absolute;
  right: 276px;
  top: 92px;
}
.label .guide-label .three .box {
  width: calc(100% - 30px);
  height: 130px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.label .guide-label .three .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 330px;
}
</style>

<style>
.label .el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 14px;
  line-height: 40px;
  user-select: none;
}
.label .el-tabs__nav-scroll .el-tabs__item {
  padding: 0 16px;
}
.label .el-tabs__nav-wrap::after {
  background-color: var(--border3);
}
/* .label .el-table .system {
  color: var(--text3) !important;
} */
</style>