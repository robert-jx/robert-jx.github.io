<template>
  <div class="drugs">
    <div class="head">试剂与耗材</div>

    <el-tabs v-model="activeTab">
      <!-- 试剂/耗材列表 -->
      <el-tab-pane label="物品列表" name="first">
        <div class="upper">
          <el-button v-show="doingBool" type="primary" @click="dialog.addDrugs = true">入库</el-button>
          <el-button v-show="doingBool" type="primary" @click="dialog.addDrugsBatch = true">批量入库</el-button>
          <span class="describle-stock">
            功能简介：物品按照贵重级别和安全系数具有分类入库功能。
            <br />记录来源、数量和存放位置，避免浪费和重复订购
          </span>
          <!-- <el-button type="primary"> 批量导入 </el-button> -->
          <el-input placeholder="搜索试剂/耗材" v-model="drugsPage.search" clearable>
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <div class="middle">
          <el-table :data="currentPageList">
            <el-table-column prop="name" label="名称" width="120"></el-table-column>

            <el-table-column prop="curCount" label="数量" width="70"></el-table-column>

            <el-table-column prop="unit" label="规格" width="100"></el-table-column>

            <el-table-column prop="tagName" label="所属分类" width="150">
              <template slot-scope="scope">{{ scope.row.tagName ? scope.row.tagName : "实验室公用" }}</template>
            </el-table-column>

            <el-table-column prop="typeName" label="标签" width="200">
              <template slot-scope="scope">
                <el-tag size="medium" v-show="scope.row.typeName">{{ scope.row.typeName }}</el-tag>
              </template>
            </el-table-column>

            <!-- <el-table-column prop="brand" label="品牌"></el-table-column> -->

            <el-table-column prop="place" label="存放位置">
              <template
                slot-scope="iscope"
              >{{ iscope.row.place?(iscope.row.place+'').replace(',undefined','').replace('undefined',' '):'' }}</template>
            </el-table-column>

            <el-table-column label="操作" :width="doingWidth">
              <template slot-scope="scope">
                <el-link
                  :disabled="scope.row.curCount <= 0"
                  type="primary"
                  @click="onReceDrugs(scope.row)"
                >领取</el-link>
                <el-link type="primary" @click="onViewDrugs(scope.row)">详情</el-link>
                <!-- <el-link type="primary" v-if="doingBool">管理</el-link> -->
                <el-link type="danger" v-if="doingBool" @click="onDeleteDrugs(scope.row)">删除</el-link>
              </template>
            </el-table-column>
          </el-table>

          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="drugsPage.pageSize"
            @size-change="pageSizeChange"
            :current-page="drugsPage.index"
            @current-change="pageCurrentChange"
            layout="sizes, prev, pager, next"
            :total="drugsPage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>

      <!-- 领取记录 -->
      <el-tab-pane label="领取记录" name="three">
        <!-- <div class="upper">
          <el-button v-show="doingBool" type="primary" @click="exportRece()">导出领取记录</el-button>
        </div>-->
        <div class="middle">
          <el-table :data="recePage.list">
            <el-table-column label="序" type="index" :index="indexMethod"></el-table-column>

            <el-table-column prop="goodsTime" label="时间" width="150">
              <template slot-scope="scope">{{ scope.row.goodsTime | formatReceTime }}</template>
            </el-table-column>

            <el-table-column prop="goodsName" label="物品" width="120"></el-table-column>

            <el-table-column prop="borrowerName" label="人员" width="100"></el-table-column>

            <el-table-column prop="goodsNumber" label="数量" width="70"></el-table-column>

            <el-table-column prop="goodsPlace" label="位置" width></el-table-column>
          </el-table>

          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="recePage.pageSize"
            @size-change="receSizeChange"
            :current-page="recePage.index"
            @current-change="receCurrentChange"
            layout="sizes, prev, pager, next"
            :total="recePage.total"
          >
            <!-- hide-on-single-page -->
          </el-pagination>
        </div>
      </el-tab-pane>

      <!-- 入库记录 -->
      <el-tab-pane v-if="doingBool" label="入库记录" name="second">
        <sto-history></sto-history>
      </el-tab-pane>
    </el-tabs>

    <!-- 入库弹窗 -->
    <add-instru active="second" :visible.sync="dialog.addDrugs"></add-instru>

    <!-- 批量入库弹窗 -->
    <add-instru-batch active="second" :visible.sync="dialog.addDrugsBatch"></add-instru-batch>

    <!-- 详情弹窗 -->
    <view-instru active="second" :visible.sync="dialog.viewDrugs" :scope="detailForm"></view-instru>

    <!-- 领取弹窗 -->
    <el-dialog
      width="640px"
      :title="'领取（'+receive.name+'）'"
      :close-on-click-modal="false"
      :visible.sync="dialog.receDrugs"
      class="rece-drugs"
    >
      <el-form :model="receForm" label-width="120px">
        <el-form-item label="领取物品">
          <el-input v-model="receForm.goodsName" readonly></el-input>
        </el-form-item>
        <el-form-item label="领取人员">
          <el-input v-model="receForm.borrowerName" readonly></el-input>
        </el-form-item>
        <el-form-item label="领取数量">
          <el-input-number
            style="width: 100%"
            v-model="receForm.goodsNumber"
            placeholder="请输入领取数量"
            controls-position="right"
            step-strictly
            :min="1"
            :max="receForm.max"
          ></el-input-number>
        </el-form-item>
        <el-form-item label="领取位置">
          <!-- <el-input v-model="receForm.goodsPlace" placeholder="请输入领取位置"></el-input> -->

          <el-select
            v-model="receForm.goodsPlace"
            placeholder="领取位置"
            style="width: 100%"
            allow-create
            filterable
            clearable
          >
            <el-option
              v-for="item in placeList"
              :key="item.id"
              :label="item.name"
              :value="item.name"
            ></el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="领取时间">
          <el-date-picker
            style="width: 100%"
            value-format="timestamp"
            v-model="receForm.goodsTime"
            type="datetime"
            placeholder="请选择领取时间"
          ></el-date-picker>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.receDrugs = false">取 消</el-button>
        <el-button type="primary" size="medium" @click="submitReceForm()">确 定</el-button>
      </span>
    </el-dialog>

    <div class="guide guide-list" v-show="guide.drug.list=='show' && activeTab=='first'">
      <div class="one" v-show="doingBool">
        <div class="box"></div>
        <span class="desc">您可在此对试剂与耗材进行入库登记</span>
      </div>
      <div class="two">
        <div class="box"></div>
        <span class="desc">您可在此搜索相关试剂与耗材</span>
      </div>
      <div class="three">
        <div class="box"></div>
        <span v-show="doingBool" class="desc">您可在此浏览、领取和管理实验室试剂与耗材</span>
        <span v-show="!doingBool" class="desc">您可在此浏览实验室试剂与耗材</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('drug', 'list')">关闭</el-button>
    </div>

    <div class="guide guide-history" v-show="guide.history=='show' && activeTab=='second'">
      <div class="one">
        <div class="box"></div>
        <span class="desc">您可在此查看仪器跟试剂耗材的入库记录</span>
      </div>
      <el-button class="btn" type="primary" @click="closeGuide('history')">关闭</el-button>
    </div>
  </div>
</template>

<script>
import AddInstru from "../../../components/AddInstru";
import AddInstruBatch from "../../../components/AddInstruBatch";
import ViewInstru from "../../../components/ViewInstru";
import StoHistory from "../../../components/StoHistory";

export default {
  components: {
    AddInstru,
    AddInstruBatch,
    ViewInstru,
    StoHistory
  },
  data() {
    return {
      activeTab: "first",
      labInfo: null, // 实验室信息
      drugsPage: {
        index: 1, // 试剂/耗材列表当前页数
        pageSize: 10, // 试剂/耗材列表页面大小
        total: 0, // 试剂/耗材列表大小
        list: [], // 试剂/耗材列表数据
        search: null // 试剂/耗材列表搜索
      },
      detailForm: {},
      dialog: {
        addDrugs: false, // 入库弹窗
        addDrugsBatch: false, // 批量入库弹窗
        viewDrugs: false,
        receDrugs: false
      },
      typeObject: null,
      receive: {},
      receForm: {
        borrowerName: null,
        goodsId: 1,
        goodsName: null,
        goodsNumber: 1,
        goodsPlace: null,
        goodsProperties: "MATERIAL",
        goodsTime: null,
        managerName: "default"
      },
      recePage: {
        index: 1, // 当前页数
        pageSize: 10, // 页面大小
        total: 0, // 大小
        list: [], // 数据
        search: null // 搜索
      },
      placeList: null
    };
  },
  computed: {
    // 判断用户是否有权限操作
    doingBool() {
      if (!this.labInfo) return false;
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN";
    },
    doingWidth() {
      if (!this.labInfo) return "90";
      return this.labInfo.role == "OWNER" || this.labInfo.role == "ADMIN"
        ? "120"
        : "90";
    },
    // 计算显示列表当前页
    currentPageList() {
      let list = this.drugsPage.list;
      let search = this.drugsPage.search;
      if (search) {
        list = list.filter(
          data =>
            !search || data.name.toLowerCase().includes(search.toLowerCase())
        );
      }
      let start = (this.drugsPage.index - 1) * this.drugsPage.pageSize;
      let end = start + this.drugsPage.pageSize;
      return list.slice(start, end);
    },
    // 是否刷新页面
    refresh() {
      return this.$route.query.refresh;
    },
    guide() {
      return this.$store.state.guide;
    }
  },
  watch: {
    // 页面刷新
    refresh() {
      this.getDrugsList();
    },
    // 监听分类搜索，更改页数
    "drugsPage.search"() {
      this.drugsPage.index = 1;
    }
  },
  mounted() {
    this.initLabInfo();
    this.getDrugsList();
    this.getTypeObject();
    this.getDrugsReceList();
    this.getPlaceList();
  },
  methods: {
    closeGuide(val1, val2) {
      if (val1 == "drug") this.guide[val1][val2] = "hidden";
      if (val1 == "history") this.guide[val1] = "hidden";

      let path = "/api/v1/utils/members/guide/" + this.labInfo.fkAccountName;
      let data = JSON.parse(JSON.stringify(this.$store.state.guide));
      delete data._id;
      this.axios.post(path, data);
    },
    // 计算索引
    indexMethod(index) {
      return (this.recePage.index - 1) * this.recePage.pageSize + index + 1;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取分类对象列表
    getTypeObject() {
      let path = "/api/v1/lab/getTags";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: [],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        let object = {};
        if (res.data.code == 20000) {
          let list = res.data.data.data;
          list.forEach(item => {
            object[item.id] = {
              name: item.name,
              power: item.permission
            };
          });
        } else {
          if (res.data.message != "没有相关数据")
            console.info(res.data.message);
        }
        // 添加默认分类
        object[1] = {
          name: "* 实验室公用",
          power: "01100"
        };
        object[2] = {
          name: "* 需申请预约",
          power: "11111"
        };
        object[3] = {
          name: "* 预约仪器",
          power: "11110"
        };
        object[4] = {
          name: "* 仅需申请",
          power: "11101"
        };
        this.typeObject = object;
      });
    },
    // 列表显示数量变化调用
    pageSizeChange(val) {
      this.drugsPage.pageSize = val;
    },
    // 列表当前页数变化调用
    pageCurrentChange(val) {
      this.drugsPage.index = val;
    },
    // 列表显示数量变化调用
    receSizeChange(val) {
      this.recePage.pageSize = val;
      this.getDrugsReceList();
    },
    // 列表当前页数变化调用
    receCurrentChange(val) {
      this.recePage.index = val;
      this.getDrugsReceList();
    },
    // 获取存放点列表
    getPlaceList() {
      let path = "/api/v1/lab/storages";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.placeList = res.data.data;
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取试剂/耗材列表
    getDrugsList() {
      let path = "/api/v1/lab/getMaterialsSummary";
      let data = {
        index: 0,
        pageSize: 5000,
        ascProperties: [],
        descProperties: ["id"],
        labId: this.labInfo.fkLabId
      };
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.drugsPage.total = res.data.data.totalElements;
          this.drugsPage.list = res.data.data.data;
          // console.info(this.drugsPage);
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 获取领取记录
    getDrugsReceList() {
      let path = "/api/v1/lab/getBorrowRecord";
      let data = {
        labId: this.labInfo.fkLabId,
        index: this.recePage.index - 1,
        pageSize: this.recePage.pageSize,
        goodsProperties: "MATERIAL",
        ascProperties: [],
        descProperties: ["id"]
      };
      if (!this.doingBool) data.borrowerName = this.labInfo.realName;

      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.recePage.list = res.data.data.content;
          this.recePage.total = res.data.data.totalElements;
        } else {
          console.info(res.data);
        }
      });
    },
    // 获取试剂/耗材展开内容
    getDrugsExpand(row) {
      let path = "/api/v1/lab/goodsByName";
      let data = {
        params: {
          labId: this.labInfo.fkLabId,
          name: row.name,
          type: "INSTRUMENT"
        }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          console.info(res.data.data);
          this.$set(this.drugsPage.expand, row.id + "", res.data.data);
        } else {
          console.info(res.data.message);
        }
      });
    },
    // 查看物品详情调用
    onViewDrugs(row) {
      this.detailForm = JSON.parse(JSON.stringify(row));
      if (!this.typeObject[this.detailForm.fkTagId]) {
        this.detailForm.tagName = "实验室公用";
      }
      this.dialog.viewDrugs = true;
    },
    onReceDrugs(row) {
      this.receive = row;
      this.receive.power = this.typeObject[row.fkTagId].power;
      this.receive.apply = this.receive.power.slice(4, 5) == "1";
      if (this.receive.apply) {
        return this.$confirm(
          "当前试剂耗材需要申请，点击确定前往申请界面？",
          "提示",
          {
            type: "warning",
            distinguishCancelAndClose: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消"
          }
        )
          .then(() => {
            this.$router.push("/apply");
          })
          .catch(() => {
            this.$message.info("取消操作");
          });
      }
      this.dialog.receDrugs = true;
      this.receForm.fkLabId = this.labInfo.fkLabId;
      this.receForm.borrowerName = this.labInfo.realName;
      this.receForm.goodsId = row.id;
      this.receForm.goodsName = row.name;
      this.receForm.goodsTime = Date.now();
      this.receForm.max = row.curCount;
    },
    submitReceForm() {
      let path = "/api/v1/lab/borrowRecord";
      let data = JSON.parse(JSON.stringify(this.receForm));
      delete data.max;

      if (!data.goodsPlace) data.goodsPlace = "无";
      if (!data.goodsNumber) return this.$message.error("领取数量不能为空");
      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.receDrugs = false;
          this.$message.success("领取成功");
          this.getDrugsReceList();
          this.getDrugsList();
          this.receForm = {
            borrowerName: null,
            goodsId: 1,
            goodsName: null,
            goodsNumber: 1,
            goodsPlace: null,
            goodsProperties: "MATERIAL",
            goodsTime: null,
            managerName: "default"
          };
        } else {
          console.info(res.data.message);
          this.$message.error(res.data.message);
        }
      });
    },
    // 删除仪器总览
    onDeleteDrugs(row) {
      if (row.id == -100) {
        return this.$message.info("示例仪器，添加仪器后自动移除");
      }
      const doDeleteDrugs = () => {
        let path = "/api/v1/lab/materialSummaryWithNames";
        let data = {
          params: {
            names: row.name,
            labId: this.labInfo.fkLabId
          }
        };
        this.axios.delete(path, data).then(res => {
          if (res.data.code == 20000) {
            this.$message.success(res.data.message);
            this.goPath("/drugs?refresh=" + Date.now());
          } else {
            this.$message.error(res.data.message);
          }
        });
      };
      this.$confirm("此操作将删除对应的所有试剂与耗材，是否继续？", "提示", {
        type: "warning",
        distinguishCancelAndClose: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(() => doDeleteDrugs())
        .catch(() => {
          this.$message.info("取消删除");
        });
    },
    exportRece() {
      let path = "/api/v1/lab/exportBorrowRecord";
      let data = {
        labId: this.labInfo.fkLabId
        // borrowerName: this.labInfo.realName,
        // descProperties: [],
        // endTimestamp: null,
        // goodsName: null,
        // goodsPlace: null,
        // goodsProperties: "MATERIAL",
        // index: 0,
        // managerName: null,
        // pageSize: 10,
        // startTimestamp: null,
        // ascProperties: [],
      };
      let config = {
        responseType: "blob"
      };
      this.axios.post(path, data, config).then(res => {
        console.info(res);
        let blob = new Blob([res], {
          type: "application/vnd.ms-excel"
        });
        let objectUrl = URL.createObjectURL(blob);

        let a = document.createElement("a");
        a.href = objectUrl;
        a.download = "客户.xlsx";
        a.click();
      });
    }
  },
  filters: {
    // 格式化入库时间
    formatReceTime(val) {
      if (val == null) return "";
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      let h = ("0" + time.getHours()).slice(-2);
      let m = ("0" + time.getMinutes()).slice(-2);
      // let s = ("0" + time.getSeconds()).slice(-2);
      return Y + "/" + M + "/" + D + " " + h + ":" + m;
    }
  }
};
</script>

<style scoped>
.drugs {
  width: 100%;
  min-width: 1000px;
  /* height: 100%; */
  position: relative;
}
.drugs .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.drugs .el-tab-pane {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 8px;
  padding: 0 20px;
  box-sizing: border-box;
}
.drugs .upper {
  width: 100%;
  height: 40px;
}
.drugs .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.drugs .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}
.drugs .upper > .el-button:nth-child(2) {
  margin-right: 16px;
}
.describle-stock {
  color: var(--text3);
  line-height: 20px;
  box-shadow: none;
  user-select: none;
  font-size: 12px;
  max-width: 360px;
  display: inline-block;
  vertical-align: middle;
  font-weight: 500;
}
.drugs .middle {
  width: 100%;
  min-height: 750px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  /* border: 1px var(--border3) solid; */
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.drugs .el-table .el-link {
  font-size: 12px;
  text-decoration: none;
  user-select: none;
}
.drugs .el-table .el-link::after {
  display: none;
}
.drugs .el-table .el-link + .el-link {
  margin-left: 12px;
}
.drugs .middle .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
</style>

<style scoped>
.drugs .guide {
  background: rgba(0, 0, 0, 0.66);
  width: 100%;
  height: 100%;
  color: #cccccc;
  font-size: 14px;
  z-index: 10010;
  position: absolute;
  left: 0;
  top: 0;
}
.drugs .guide .btn {
  width: 80px;
  margin: 0 -40px;
  position: absolute;
  right: 50%;
  top: 400px;
}
.drugs .guide-list .one .box {
  width: 80px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  left: 14px;
  top: 116px;
}
.drugs .guide-list .one .desc {
  width: 125px;
  position: absolute;
  left: 105px;
  top: 120px;
}
.drugs .guide-list .two .box {
  width: 410px;
  height: 50px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 116px;
}
.drugs .guide-list .two .desc {
  width: 190px;
  position: absolute;
  right: 236px;
  top: 92px;
}
.drugs .guide-list .three .box {
  width: calc(100% - 30px);
  height: 130px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.drugs .guide-list .three .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 330px;
}
.drugs .guide-appoint .one .box {
  width: calc(100% - 30px);
  height: 120px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 190px;
}
.drugs .guide-appoint .one .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 160px;
}
.drugs .guide-history .one .box {
  width: calc(100% - 30px);
  height: 130px;
  border: 1px solid #cccccc;
  border-radius: 4px;
  position: absolute;
  right: 13px;
  top: 140px;
}
.drugs .guide-history .one .desc {
  width: calc(100% - 30px);
  text-align: center;
  position: absolute;
  right: 13px;
  top: 110px;
}
</style>

<style>
.drugs .el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 14px;
  line-height: 40px;
  user-select: none;
}
.drugs .el-tabs__nav-scroll .el-tabs__item {
  padding: 0 16px;
}
.drugs .el-tabs__nav-wrap::after {
  background-color: var(--border3);
}
.drugs .middle .none .el-table__expand-column .cell {
  display: none !important;
}
.drugs .middle .el-table__expanded-cell {
  padding-left: 25px;
  padding-right: 48px;
}

.rece-drugs .el-dialog__body {
  padding-right: 70px;
  box-sizing: border-box;
}
.rece-drugs .el-input-number input {
  text-align: left;
}
</style>