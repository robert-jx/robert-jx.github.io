<template>
  <div class="work">
    <el-container>
      <el-scrollbar class="el-aside">
        <router-view name="sidebar"></router-view>
      </el-scrollbar>
      <el-main id="main-scroll">
        <router-view name="content"></router-view>
      </el-main>
      <!-- <el-main v-if="macBook" id="main-scroll">
        <router-view name="content"></router-view>
      </el-main>
      <el-scrollbar v-else class="el-main win">
        <router-view name="content"></router-view>
      </el-scrollbar>-->
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Work",
  data() {
    return {
      labId: "123",
      macBook: false,
      labInfo: null
    };
  },
  mounted() {
    this.initIsMacBook();
    this.initLabInfo();
    this.initGuideInfo();
  },
  methods: {
    // 判定是否 Mac
    initIsMacBook() {
      this.macBook = this.isMacBook();
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 初始化引导页信息
    initGuideInfo() {
      let path = "/api/v1/utils/members/guide/" + this.labInfo.fkAccountName;
      this.axios.get(path).then(res => {
        let guide = {
          history: "show",
          instru: {
            list: "show",
            appoint: "show"
          },
          drug: {
            list: "show",
          },
          label: {
            type: "show",
            label: "show"
          },
          stor: {
            place: "show"
          }
        };
        // if (res.data.data) Object.assign(guide, res.data.data.guide);
        if (!res.data.error) {
          // this.$store.commit("setGuide", guide);
          console.info(guide);
        }
      });
    }
  }
};
</script>

<style scoped>
.work {
  width: 100vw;
  height: calc(100vh - 50px);
  /* background-color: rebeccapurple; */
}
.work .el-container {
  width: 100vw;
  height: 100%;
  /* background-color: red; */
}
.work .el-aside {
  width: 250px !important;
  height: 100%;
  background-color: #1e2127;
  transition: ease-in-out 0.3;
}
.work .el-main {
  width: 100%;
  height: 100%;
  padding: 0 !important;
}

@media (max-width: 1280px) {
  .work .el-aside {
    width: 64px !important;
    height: 100%;
    background-color: #1e2127;
    overflow-x: hidden;
  }
}
</style>
<style>
.work .el-aside > .el-scrollbar__wrap,
.work .el-main > .el-scrollbar__wrap {
  overflow-x: hidden;
}
.work .el-main.win > .el-scrollbar__wrap {
  overflow-x: hidden;
  padding-right: 15px;
  padding-bottom: 15px;
  box-sizing: border-box;
}
.work .el-aside > .el-scrollbar__bar.is-vertical {
  width: 14px !important;
  border-radius: 0px !important;
  padding: 3px;
  box-sizing: border-box;
  right: 0;
  top: 0;
}
.work .el-main > .el-scrollbar__bar.is-vertical {
  width: 14px !important;
  border-radius: 0px !important;
  padding: 3px;
  box-sizing: border-box;
  border-left: 1px #e8e8e8 solid;
  background: #fafafa;
  right: 0;
  top: 0;
}
.work .el-aside > .el-scrollbar__bar.is-horizontal {
  display: none;
}
.work .el-main > .el-scrollbar__bar.is-horizontal {
  /* display: none; */
  height: 14px !important;
  border-radius: 0px !important;
  padding: 3px;
  box-sizing: border-box;
  border-top: 1px #e8e8e8 solid;
  background: #fafafa;
  bottom: 0;
  left: 0;
}
.work .el-aside > .el-scrollbar__bar .el-scrollbar__thumb,
.work .el-aside > .el-scrollbar__bar .el-scrollbar__thumb:hover {
  border-radius: 5px !important;
  background: rgba(144, 147, 153, 0.5);
}
.work .el-main > .el-scrollbar__bar .el-scrollbar__thumb,
.work .el-main > .el-scrollbar__bar .el-scrollbar__thumb:hover {
  border-radius: 5px !important;
  background: #c1c1c1;
}
</style>