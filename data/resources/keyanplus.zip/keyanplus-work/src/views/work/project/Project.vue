<template>
  <div class="proj">
    <div class="head">项目经费与报销</div>

    <el-tabs v-model="activeTab">
      <!-- 项目列表 -->
      <el-tab-pane label="项目列表" name="first">
        <!--  顶部操作 -->
        <div class="upper">
          <el-button type="primary" @click="onCreateProject">新建项目</el-button>
          <span class="describle">功能简介：管理员可以在此创建实验室项目，并对其进行管理</span>
          <el-input placeholder="搜索项目" v-model="projectPage.search" clearable>
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <!-- 中间列表 -->
        <div class="middle">
          <el-table
            v-loading="projectPage.loading"
            element-loading-spinner="el-icon-loading"
            empty-text="暂无匹配项"
            :data="projectPage.list"
            @sort-change="onProjectSortChange"
            @filter-change="onProjectFilterChange"
          >
            <el-table-column label="项目名称" prop="name" width="180"></el-table-column>

            <el-table-column
              label="类型"
              prop="type"
              width="100"
              column-key="type"
              :filters="[
                { text: '学生项目', value: '学生项目' },
                { text: '教师项目', value: '教师项目' },
              ]"
            ></el-table-column>

            <el-table-column
              label="级别"
              prop="level"
              width="80"
              column-key="level"
              :filters="[
                { text: '国家级', value: '国家级' },
                { text: '省级', value: '省级' },
                { text: '市级', value: '市级' },
                { text: '校级', value: '校级' },
                { text: '其他', value: '其他' },
              ]"
            ></el-table-column>

            <el-table-column
              label="添加时间"
              prop="createTime"
              sortable="custom"
              column-key="createTime"
              width="120"
            >
              <template slot-scope="scope">{{ timestampFormat(scope.row.createTime) }}</template>
            </el-table-column>

            <el-table-column label="负责人" prop="leaders" width="150">
              <template slot-scope="scope">
                <div class="leader" v-html="membersFormat(scope.row.leaders)"></div>
              </template>
            </el-table-column>

            <el-table-column label="成员" prop="members">
              <template slot-scope="scope">
                <div class="member" v-html="membersFormat(scope.row.members)"></div>
              </template>
            </el-table-column>

            <el-table-column label="操作" width="90">
              <template slot-scope="scope">
                <el-link type="primary" @click="onEditProject(scope.row)">管理</el-link>
                <el-link type="danger" @click="onDelProject(scope.row)">删除</el-link>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页显示 -->
          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="projectPage.pageSize"
            @size-change="projectSizeChange"
            :current-page="projectPage.index"
            @current-change="projectCurrentChange"
            layout="sizes, prev, pager, next"
            :total="projectPage.total"
          ></el-pagination>
        </div>
      </el-tab-pane>

      <!-- 经费管理 -->
      <el-tab-pane label="经费管理" name="second">
        <!-- 顶部操作 -->
        <div class="upper">
          <el-button type="primary" @click="onAddFunds()">添加经费</el-button>
          <span class="describle">功能简介：管理员可以对实验室项目进行添加经费的记录</span>
          <el-input placeholder="按项目名称搜索经费" clearable v-model="fundsPage.search">
            <el-button type="primary" slot="append" icon="el-icon-search">搜索</el-button>
          </el-input>
        </div>
        <!-- 中间列表 -->
        <div class="middle">
          <el-table
            v-loading="fundsPage.loading"
            element-loading-spinner="el-icon-loading"
            :data="fundsPage.list"
            @sort-change="onFundsSortChange"
            :row-class-name="fundsRowClass"
            empty-text="暂无匹配项"
          >
            <el-table-column label="项目名称" prop="projectName" width></el-table-column>

            <el-table-column label="经费名称" prop="name" width></el-table-column>

            <el-table-column label="余额" prop="curFee" width="100" align="right">
              <template slot-scope="{row}">
                {{ row.curFee }}元
              </template>
            </el-table-column>

            <el-table-column label="总额" prop="totalFee" width="100" align="right">
              <template slot-scope="{row}">
                {{ row.totalFee }}元
              </template>
            </el-table-column>

            <el-table-column label="有效时间" width="190">
              <template slot-scope="scope">
                {{ timestampFormat(scope.row.startTime) }}
                <span>-</span>
                {{ timestampFormat(scope.row.endTime) }}
              </template>
            </el-table-column>

            <el-table-column
              label="添加时间"
              prop="createTime"
              sortable="custom"
              column-key="createTime"
              width="120"
            >
              <template slot-scope="scope">{{ timestampFormat(scope.row.createTime) }}</template>
            </el-table-column>

            <!-- <el-table-column label="操作（未）" width="110"></el-table-column> -->
          </el-table>
          <!-- 分页显示 -->
          <el-pagination
            background
            :page-sizes="[10, 20, 30, 40]"
            :pager-count="5"
            :page-size="fundsPage.pageSize"
            @size-change="fundsSizeChange"
            :current-page="fundsPage.index"
            @current-change="fundsCurrentChange"
            layout="sizes, prev, pager, next"
            :total="fundsPage.total"
          ></el-pagination>
        </div>
      </el-tab-pane>
    </el-tabs>

    <!-- 项目弹窗 -->
    <el-dialog
      :close-on-click-modal="false"
      :title="projectForm.edit ? '项目管理' : '新建项目'"
      class="project"
      :visible.sync="dialog.project"
      width="640px"
    >
      <el-form :model="projectForm" label-width="120px">
        <el-form-item label="* 项目名称">
          <el-input v-model="projectForm.name" placeholder="请输入项目名称"></el-input>
        </el-form-item>

        <el-form-item label="* 项目负责人">
          <el-select v-model="projectForm.leaders" multiple filterable placeholder="请选择项目负责人（可搜索）">
            <el-option v-for="item in userList" :key="item[0]" :label="item[2]" :value="item[2]">
              <span style="float: left">{{ item[2] }}</span>
              <span
                style="float: right; color: #8492a6; font-size: 13px"
              >{{ item[1] | adminFormat }}</span>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item label="* 项目成员">
          <el-select v-model="projectForm.members" multiple filterable placeholder="请选择项目成员（可搜索）">
            <el-option v-for="item in userList" :key="item[0]" :label="item[2]" :value="item[2]">
              <span style="float: left">{{ item[2] }}</span>
              <span
                style="float: right; color: #8492a6; font-size: 13px"
              >{{ item[1] | adminFormat }}</span>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item
          :label="index ? '' : '项目经费'"
          v-for="(item, index) in projectForm.funds"
          :key="index"
        >
          <el-row>
            <el-col :span="11">
              <el-input v-model="item.name" placeholder="经费名称"></el-input>
            </el-col>
            <el-col :span="8" :offset="1">
              <el-input v-model="item.value" placeholder="经费数额（元）"></el-input>
            </el-col>
            <el-col :span="3" :offset="1">
              <el-button
                v-if="!index"
                plain
                type="primary"
                @click="addProjectFund()"
                style="padding: 12px 17px"
                icon="el-icon-plus"
              ></el-button>
              <el-button
                v-else
                plain
                type="danger"
                @click="delProjectFund(item)"
                style="padding: 12px 17px"
                icon="el-icon-minus"
              ></el-button>
            </el-col>
          </el-row>
          <el-row style="margin-top: 8px">
            <el-col :span="24">
              <el-date-picker
                v-model="item.date"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-col>
          </el-row>
        </el-form-item>

        <el-form-item label="项目级别">
          <el-radio v-model="projectForm.level" label="国家级">国家级</el-radio>
          <el-radio v-model="projectForm.level" label="省级">省级</el-radio>
          <el-radio v-model="projectForm.level" label="市级">市级</el-radio>
          <el-radio v-model="projectForm.level" label="校级">校级</el-radio>
          <el-radio v-model="projectForm.level" label="其他">其他</el-radio>
        </el-form-item>

        <el-form-item label="项目类型">
          <el-radio v-model="projectForm.type" label="教师项目">教师项目</el-radio>
          <el-radio v-model="projectForm.type" label="学生项目">学生项目</el-radio>
        </el-form-item>

        <el-form-item v-show="!projectForm.edit" label="创建文档">
          <el-radio v-model="projectForm.createDocument" :label="true">是</el-radio>
          <el-radio v-model="projectForm.createDocument" :label="false">否</el-radio>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.project = false">取消</el-button>
        <el-button
          v-if="!projectForm.edit"
          type="primary"
          size="medium"
          @click="doCreateProject()"
        >确定</el-button>
        <el-button v-if="projectForm.edit" type="primary" size="medium" @click="doEditProject()">确定</el-button>
      </span>
    </el-dialog>

    <!-- 经费弹窗 -->
    <el-dialog
      :close-on-click-modal="false"
      title="添加经费"
      class="add-funds"
      :visible.sync="dialog.addFunds"
      width="640px"
    >
      <el-form label-width="120px">
        <el-form-item label="* 所属项目">
          <el-select
            clearable
            filterable
            default-first-option
            v-model="fundsForm.project"
            placeholder="请选择所属项目名称（可搜索）"
            no-data-text="暂无匹配项目"
            v-loading="fundsForm.loading"
            element-loading-spinner="el-icon-loading"
          >
            <el-option
              v-for="item in fundsForm.options"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>

        <el-form-item
          :label="index ? '' : '* 项目经费'"
          v-for="(item, index) in fundsForm.funds"
          :key="index"
        >
          <el-row>
            <el-col :span="11">
              <el-input v-model="item.name" placeholder="经费名称"></el-input>
            </el-col>
            <el-col :span="8" :offset="1">
              <el-input v-model="item.value" placeholder="经费数额（元）"></el-input>
            </el-col>
            <el-col :span="3" :offset="1">
              <el-button
                v-if="!index"
                plain
                type="primary"
                @click="addFundItem()"
                style="padding: 12px 17px"
                icon="el-icon-plus"
              ></el-button>
              <el-button
                v-else
                plain
                type="danger"
                @click="delFundItem(item)"
                style="padding: 12px 17px"
                icon="el-icon-minus"
              ></el-button>
            </el-col>
          </el-row>
          <el-row style="margin-top: 8px">
            <el-col :span="24">
              <el-date-picker
                v-model="item.date"
                type="daterange"
                value-format="yyyy-MM-dd"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              ></el-date-picker>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button size="medium" @click="dialog.addFunds = false">取消</el-button>
        <el-button type="primary" size="medium" @click="doAddFunds()">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      labInfo: null, // 基本信息
      activeTab: "first", // 标签页
      projectPage: {
        index: 1, // 项目列表当前页数
        pageSize: 10, // 项目列表页面大小
        total: 0, // 项目列表大小
        list: [], // 项目列表数据
        asc: [], // 项目升序属性
        desc: ["id"], // 项目降序属性
        search: null, // 项目列表搜索
        level: [], // 项目等级筛选
        type: [], // 项目类型筛选
        loading: false // 加载动画
      },
      fundsPage: {
        index: 1, // 经费列表当前页数
        pageSize: 10, // 经费列表页面大小
        total: 0, // 经费列表大小
        list: [], // 经费列表数据
        asc: [], // 经费升序属性
        desc: ["id"], // 经费降序属性
        search: null, // 经费列表搜索
        loading: false // 加载动画
      },
      projectForm: {
        id: -1, // 编辑时的项目id
        edit: false, // 是否编辑
        name: null, // 项目名称
        level: "其他", // 项目级别
        type: "学生项目", // 项目类型
        createDocument: false, // 是否创建文档
        leaders: [], // 负责人列表
        members: [], // 成员列表
        funds: [
          {
            name: null, // 经费名称
            value: null, // 经费数额
            date: null // 经费有效期
          }
        ]
      },
      fundsForm: {
        project: null, // 所属项目
        loading: false, // 搜索项目动画
        funds: [
          {
            name: null, // 经费名称
            value: null, // 经费数额
            date: null // 经费有效期
          }
        ]
      },
      dialog: {
        project: false, // 项目弹窗
        addFunds: false // 经费弹窗
      },
      userList: null, // 用户列表
      groupList: null, // 课题组列表
      // 延迟操作，执行最新的
      dealUtil: {
        timeout: null,
        debounce(func, delay) {
          const fun = () => {
            clearTimeout(this.timeout);
            this.timeout = setTimeout(() => func(), delay);
          };
          return fun();
        }
      }
    };
  },
  watch: {
    // 监听项目搜索，更新数据
    "projectPage.search"() {
      this.projectPage.index = 1;
      this.dealUtil.debounce(this.getProjectList, 500);
    },
    // 监听标签搜索，更改页数
    "fundsPage.search"() {
      this.fundsPage.index = 1;
      this.dealUtil.debounce(this.getFundsList, 500);
    }
  },
  mounted() {
    this.initLabInfo();
    this.getProjectList();
    this.getFundsList();
    this.getGroupUserInfo();
  },
  methods: {
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 获取课题组跟用户相关信息
    getGroupUserInfo() {
      let path = "/api/v1/lab/researchGroupsAndDetails";
      let data = {
        params: { labId: this.labInfo.fkLabId }
      };
      this.axios.get(path, data).then(res => {
        if (res.data.code == 20000) {
          this.userList = res.data.data.labDetails;
          // 将数组转化为对象数组（将相同课题组的数据项放在一起）
          let list = res.data.data.researchGroupDetails;
          let onGroupObject = {};
          let object = {};
          list.forEach(item => {
            let key = item.groupName;
            if (!object[key]) object[key] = [];
            object[key].push({
              value: item.fkLabDetailId,
              label: item.detailName,
              parent: item.groupName
            });
            onGroupObject[item.fkLabDetailId] = 1;
          });
          // 将其他不在课题组的用户放入其他用户组
          object["其他实验室成员"] = [];
          this.userList.forEach(item => {
            if (onGroupObject[item[0]] == 1) return;
            object["其他实验室成员"].push({
              value: item[0],
              label: item[2],
              parent: "其他实验室成员"
            });
          });
          // 将对象数组转为二维数组（转为组件数据格式）
          this.groupList = [];
          for (let key in object) {
            this.groupList.push({
              value: key,
              label: key,
              children: object[key]
            });
          }
        }
      });
    },
    // 经费行样式，暂未设置
    fundsRowClass({ row }) {
      if (row.endTime < Date.now()) return "";
    },

    // 获取项目列表
    getProjectList() {
      let path = "/api/v1/lab/getProjects";
      let data = {
        labId: this.labInfo.fkLabId,
        index: this.projectPage.index - 1,
        pageSize: this.projectPage.pageSize,
        ascProperties: this.projectPage.asc,
        descProperties: this.projectPage.desc,
        name: this.projectPage.search,
        level: this.projectPage.level,
        type: this.projectPage.type
      };
      // this.projectPage.loading = true;
      this.axios.post(path, data).then(res => {
        this.projectPage.loading = false;
        if (res.data.code == 20000) {
          this.projectPage.total = res.data.data.totalElements;
          this.projectPage.list = res.data.data.data;
        } else {
          console.info(res.data.message);
          this.projectPage.list = null;
        }
      });
    },
    // 项目列表显示数量变化调用
    projectSizeChange(val) {
      this.projectPage.pageSize = val;
      this.getProjectList();
    },
    // 项目列表当前页数变化调用
    projectCurrentChange(val) {
      this.projectPage.index = val;
      this.getProjectList();
    },
    // 项目列表排序变化时调用
    onProjectSortChange(param) {
      if (param.order == "descending") {
        if (!this.projectPage.desc.includes(param.prop)) {
          this.projectPage.desc.push(param.prop);
        }
        if (this.projectPage.asc.includes(param.prop)) {
          let index = this.projectPage.asc.indexOf(param.prop);
          if (index !== -1) this.projectPage.asc.splice(index, 1);
        }
      }
      if (param.order == "ascending") {
        if (!this.projectPage.asc.includes(param.prop)) {
          this.projectPage.asc.push(param.prop);
        }
        if (this.projectPage.desc.includes(param.prop)) {
          let index = this.projectPage.desc.indexOf(param.prop);
          if (index !== -1) this.projectPage.desc.splice(index, 1);
        }
      }
      this.getProjectList();
    },
    // 项目列表筛选变化时调用
    onProjectFilterChange(param) {
      if (param.level) this.projectPage.level = param.level;
      if (param.type) this.projectPage.type = param.type;
      this.getProjectList();
    },
    onCreateProject() {
      this.projectForm = {
        edit: false,
        name: null,
        level: "其他",
        type: "学生项目",
        createDocument: false,
        leaders: [],
        members: [],
        funds: [
          {
            name: null,
            value: null,
            date: null
          }
        ]
      };
      this.dialog.project = true;
    },
    // 向后台提交创建项目
    doCreateProject() {
      if (!this.projectForm.name) {
        return this.$message.error("项目名称不能为空");
      }
      if (!this.projectForm.leaders.length) {
        return this.$message.error("项目负责人不能为空");
      }
      if (!this.projectForm.members.length) {
        return this.$message.error("项目成员不能为空");
      }
      let path = "/api/v1/lab/project";
      let feeInserts = [];
      let dataOk = true;
      this.projectForm.funds.forEach(item => {
        if (!item.name && !item.date && !item.value) return;
        if (!item.name || !item.date || !item.value) return (dataOk = false);
        feeInserts.push({
          name: item.name,
          totalFee: item.value,
          createTime: this.timestampFormat(Date.now()),
          fkLabId: this.labInfo.fkLabId,
          startTime: item.date[0],
          endTime: item.date[1]
        });
      });
      if (!dataOk) return this.$message.error("项目经费信息不完整");

      let data = {
        labId: this.labInfo.fkLabId,
        name: this.projectForm.name,
        level: this.projectForm.level,
        type: this.projectForm.type,
        createDocument: this.projectForm.createDocument,
        createTime: this.timestampFormat(Date.now()),
        leaders: this.projectForm.leaders,
        members: this.projectForm.members,
        feeInserts: feeInserts
      };

      this.axios.post(path, data).then(res => {
        if (res.data.code == 20000) {
          if (this.projectForm.createDocument) {
            this.doCreateProjectDir();
          }
          this.dialog.project = false;
          this.$message.success(res.data.message);
          this.projectForm = {
            name: null,
            level: "其他",
            type: "学生项目",
            createDocument: false,
            leaders: [],
            members: [],
            funds: []
          };
          this.getProjectList();
          this.getFundsList();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 创建项目文件夹
    doCreateProjectDir() {
      let path = "/api/v1/utils/COS/dirs";
      let data = {
        params: {
          path: "/项目文档/",
          dirName: this.projectForm.name
        }
      };
      let body = {
        Inner: "all"
      };
      this.axios.post(path, body, data);
    },
    // 点击项目列表管理时调用
    onEditProject(row) {
      this.projectForm = {
        id: row.id,
        edit: true,
        name: row.name,
        oldName: row.name,
        level: row.level,
        type: row.type,
        createDocument: null,
        leaders: row.leaders.split(",").slice(0, -1),
        members: row.members.split(",").slice(0, -1),
        funds: []
      };
      this.dialog.project = true;
    },
    // 向后台提交修改项目
    doEditProject() {
      if (!this.projectForm.name) {
        return this.$message.error("项目名称不能为空");
      }
      if (!this.projectForm.leaders.length) {
        return this.$message.error("项目负责人不能为空");
      }
      if (!this.projectForm.members.length) {
        return this.$message.error("项目成员不能为空");
      }
      let path = "/api/v1/lab/project";
      let name = this.projectForm.name;
      let oldName = this.projectForm.oldName;
      let data = {
        id: this.projectForm.id,
        name: name != oldName ? name : null,
        level: this.projectForm.level,
        type: this.projectForm.type,
        labId: this.labInfo.fkLabId,
        leaders: this.projectForm.leaders,
        members: this.projectForm.members,
        feeInserts: [],
        feeDeletes: []
      };
      this.axios.put(path, data).then(res => {
        if (res.data.code == 20000) {
          this.dialog.project = false;
          this.$message.success(res.data.message);
          this.projectForm = {
            id: -1,
            name: null,
            level: "其他",
            type: "学生项目",
            createDocument: false,
            leaders: [],
            members: [],
            funds: []
          };
          this.getProjectList();
          this.getFundsList();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 删除项目调用
    onDelProject(row) {
      const doDelProject = () => {
        let path = "/api/v1/lab/deleteProject";
        let data = {
          params: { id: row.id }
        };
        this.axios.delete(path, data).then(res => {
          if (res.data.code == 20000) {
            this.$message.success(res.data.message);
            this.getProjectList();
            this.getFundsList();
            this.getGroupUserInfo();
          } else {
            this.$message.error(res.data.message);
          }
        });
      };
      this.$confirm("此操作将永久删除该项目, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => doDelProject())
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 添加经费项 - 创建项目时
    addProjectFund() {
      this.projectForm.funds.push({
        name: null,
        value: null,
        date: null
      });
    },
    // 移除经费项 - 创建项目时
    delProjectFund(val) {
      var index = this.projectForm.funds.indexOf(val);
      if (index !== -1) {
        this.projectForm.funds.splice(index, 1);
      }
    },

    // 获取经费列表
    getFundsList() {
      let path = "/api/v1/lab/getFees";
      let data = {
        labId: this.labInfo.fkLabId,
        index: this.fundsPage.index - 1,
        pageSize: this.fundsPage.pageSize,
        ascProperties: this.fundsPage.asc,
        descProperties: this.fundsPage.desc,
        projectName: this.fundsPage.search
      };
      // this.fundsPage.loading = true;
      this.axios.post(path, data).then(res => {
        this.fundsPage.loading = false;
        if (res.data.code == 20000) {
          this.fundsPage.total = res.data.data.totalElements;
          this.fundsPage.list = res.data.data.data;
        } else {
          console.info(res.data.message);
          this.fundsPage.list = null;
        }
      });
    },
    // 添加经费项 - 添加经费时
    addFundItem() {
      this.fundsForm.funds.push({
        name: null,
        value: null,
        date: null
      });
    },
    // 移除经费项 - 添加经费时
    delFundItem(val) {
      var index = this.fundsForm.funds.indexOf(val);
      if (index !== -1) {
        this.fundsForm.funds.splice(index, 1);
      }
    },
    // 经费列表显示数量变化调用
    fundsSizeChange(val) {
      this.fundsPage.pageSize = val;
      this.getFundsList();
    },
    // 经费列表当前页数变化调用
    fundsCurrentChange(val) {
      this.fundsPage.index = val;
      this.getFundsList();
    },
    // 项目列表排序变化时调用
    onFundsSortChange(param) {
      if (param.order == "descending") {
        if (!this.fundsPage.desc.includes(param.prop)) {
          this.fundsPage.desc.push(param.prop);
        }
        if (this.fundsPage.asc.includes(param.prop)) {
          let index = this.fundsPage.asc.indexOf(param.prop);
          if (index !== -1) this.fundsPage.asc.splice(index, 1);
        }
      }
      if (param.order == "ascending") {
        if (!this.fundsPage.asc.includes(param.prop)) {
          this.fundsPage.asc.push(param.prop);
        }
        if (this.fundsPage.desc.includes(param.prop)) {
          let index = this.fundsPage.desc.indexOf(param.prop);
          if (index !== -1) this.fundsPage.desc.splice(index, 1);
        }
      }
      this.getFundsList();
    },
    // 点击添加经费调用
    onAddFunds() {
      this.dialog.addFunds = true;
      // this.fundsForm.loading = true;

      let path = "/api/v1/lab/getProjects";
      let data = {
        labId: this.labInfo.fkLabId,
        index: 0,
        pageSize: 1000,
        ascProperties: [],
        descProperties: [],
        name: null,
        level: [],
        type: []
      };
      this.axios.post(path, data).then(res => {
        this.fundsForm.loading = false;
        if (res.data.code == 20000) {
          this.$set(this.fundsForm, "options", res.data.data.data);
          // console.info(this.fundsForm.options);
        } else {
          this.fundsForm.options = [];
        }
      });
    },
    // 向后台提交添加经费
    doAddFunds() {
      if (!this.fundsForm.project) {
        this.$message.error("经费所属项目不能为空");
        return;
      }
      let path = "/api/v1/lab/fee";
      let list = JSON.parse(JSON.stringify(this.fundsForm.funds));
      let project = this.fundsForm.project;
      list.forEach(item => {
        let data = {
          name: item.name,
          totalFee: item.value,
          fkProjectId: project,
          fkLabId: this.labInfo.fkLabId,
          createTime: this.timestampFormat(Date.now()),
          startTime: item.date[0],
          endTime: item.date[1]
        };
        this.axios.post(path, data).then(res => {
          if (res.data.code == 20000) {
            let index = -1;
            for (let i in this.fundsForm.funds) {
              let fund = this.fundsForm.funds[i];
              if (
                fund.name == item.name &&
                fund.value == item.value &&
                fund.date[0] == item.date[0] &&
                fund.date[1] == item.date[1]
              ) {
                index = i;
              }
            }
            if (index > -1) this.fundsForm.funds.splice(index, 1);
            if (this.fundsForm.funds.length == 0) {
              this.$message.success(res.data.message);
              this.dialog.addFunds = false;
              this.fundsForm = {
                project: null,
                loading: false,
                funds: [
                  {
                    name: null,
                    value: null,
                    date: null
                  }
                ]
              };
              this.getFundsList();
            }
          } else {
            this.$message.error(item.name + " 添加失败");
            console.info(res.data.message);
          }
        });
      });
    },

    // 时间戳转YY-MM-DD
    timestampFormat(val) {
      let time = new Date(val);
      let Y = time.getFullYear();
      let M = ("0" + (time.getMonth() + 1)).slice(-2);
      let D = ("0" + time.getDate()).slice(-2);
      return Y + "-" + M + "-" + D;
    },
    // 根据用户ID获取姓名
    findUserNameByID(val) {
      let result = "";
      this.userList.forEach(item => {
        if (item[0] == val) {
          result = item[2];
          return;
        }
      });
      return result;
    },
    // 转换成员显示
    membersFormat(val) {
      val = val + "";
      val = val.slice(0, val.length - 1);
      let list = val.split(",");
      let result = "";
      list.forEach(item => {
        result += "<span>" + item + "</span>";
      });
      return result;
    }
  },
  filters: {
    // 转换管理员显示
    adminFormat(val) {
      if (val == "OWNER") return "所有者";
      if (val == "ADMIN") return "管理员";
      if (val == "CATEGORY_ADMIN") return "分类管理员";
      if (val == "MEMBER") return "成员";
    }
  }
};
</script>

<style scoped>
.proj {
  width: 100%;
  min-width: 1000px;
  height: 100%;
}
.proj .head {
  font-size: 18px;
  background: #ffffff;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 20px;
  box-sizing: border-box;
}
.proj .el-tab-pane {
  min-width: 1000px;
  max-width: 1240px;
  min-height: 600px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 8px;
  padding: 0 20px;
  box-sizing: border-box;
}
.proj .upper {
  width: 100%;
  height: 40px;
}
.proj .upper .el-input {
  float: right;
  width: 400px;
  box-shadow: var(--shadow3);
}
.proj .upper .el-input-group__append .el-button {
  color: white;
  border-radius: 0 2px 2px 0;
  margin-right: -22px;
  margin-left: -22px;
  border: 1px var(--primary) solid;
  background-color: var(--primary);
}

.describle {
  color: var(--text3);
  /* float: left; */
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.proj .middle {
  width: 100%;
  min-height: 650px;
  margin-top: 23px;
  padding: 20px;
  box-sizing: border-box;
  background-color: var(--back4);
  box-shadow: var(--shadow3);
  border-radius: 2px;
  text-align: left;
  padding-bottom: 90px;
  position: relative;
}
.proj .el-table .el-link {
  font-size: 12px;
  text-decoration: none;
  user-select: none;
}
.proj .el-table .el-link::after {
  display: none;
}
.proj .el-table .el-link + .el-link {
  margin-left: 12px;
}
.proj .el-pagination {
  position: absolute;
  bottom: 30px;
  right: 20px;
}
.proj .add-funds .el-form,
.proj .project .el-form {
  padding-right: 70px;
  box-sizing: border-box;
}
.proj .add-funds .el-form .el-select,
.proj .add-funds .el-form .el-date-editor,
.proj .add-funds .el-form .el-cascader,
.proj .project .el-form .el-select,
.proj .project .el-form .el-date-editor,
.proj .project .el-form .el-cascader {
  width: 100%;
}
</style>
<style>
.proj .el-table .leader span,
.proj .el-table .member span {
  margin-right: 8px;
}
.proj .el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 14px;
  line-height: 40px;
  user-select: none;
}
.proj .el-tabs__nav-scroll .el-tabs__item {
  padding: 0 16px;
}
.proj .el-tabs__nav-wrap::after {
  background-color: var(--border3);
}
</style>