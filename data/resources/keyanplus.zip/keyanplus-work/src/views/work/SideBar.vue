<template>
  <div class="sidebar" ref="sidebar">
    <el-menu
      router
      :default-active="$route.path"
      :collapse="collapse"
      background-color="#1E2127"
      text-color="#bcbfc4"
      active-text-color="#FFFFFF"
      @open="handleOpen"
      @close="handleClose"
    >
      <template v-for="item in sideMenu">
        <el-submenu v-if="item.children" :index="item.name" :key="item.name">
          <template slot="title">
            <i
              style="margin: -1px 5px 0 0;font-size:20px;"
              :class="'iconfont ' + item.icon"
            ></i>
            <span slot="title">{{ item.name }}</span>
          </template>
          <el-menu-item
            v-for="children in item.children"
            :index="children.path"
            :key="children.name"
          >
            <i
              style="margin: -1px 5px 0 0;font-size:20px;"
              :class="'iconfont ' + children.icon"
            ></i>
            <span slot="title">{{ children.name }}</span>
          </el-menu-item>
        </el-submenu>
        <el-menu-item v-else :index="item.path" :key="item.name">
          <i style="margin: -1px 5px 0 0;font-size:20px;" :class="'iconfont ' + item.icon"></i>
          <span slot="title">{{ item.name }}</span>
        </el-menu-item>
      </template>
    </el-menu>
  </div>
</template>

<script>
export default {
  name: "SideBar",
  data() {
    return {
      sideMenu: [
        {
          icon: "icon-cloud",
          name: "控制中心",
          path: "/",
        },

        {
          icon: "icon-team",
          name: "课题组与成员",
          children: [
            {
              icon: "icon-user",
              path: "/members",
              name: "成员管理",
            },
            {
              icon: "icon-solution",
              path: "/group",
              name: "小组管理",
            },
          ],
        },
        {
          icon: "icon-edit-square",
          name: "申请与审批",
          path: "/apply",
        },
        {
          icon: "icon-creditcard",
          name: "采购与供应商管理",
          children: [
            {
              icon: "icon-creditcard",
              name: "采购管理",
              path: "/buy",
            },
            {
              icon: "icon-shop",
              name: "供应商管理",
              path: "/supplier",
            },
          ],
        },

        {
          icon: "icon-antdesign",
          name: "库存管理",
          children: [
            {
              icon: "icon-experiment",
              path: "/instrument",
              name: "仪器与预约",
            },
            {
              icon: "icon-medicinebox",
              path: "/drugs",
              name: "试剂与耗材",
            },
            {
              icon: "icon-tag",
              path: "/label",
              name: "分类标签与策略设置",
            },
            {
              icon: "icon-slack",
              path: "/storage",
              name: "存储管理与设置",
            },
            // {
            //   icon: "icon-insurance",
            //   path: "/preserve",
            //   name: "保藏中心"
            // }
          ],
        },
        {
          icon: "icon-folder",
          name: "项目经费与报销",
          path: "/project",
        },
        {
          icon: "icon-cloud-server",
          name: "文档与知识库",
          path: "/document",
        },
        // {
        //   icon: "icon-setting",
        //   name: "设置",
        //   path: "/setting"
        // }
      ],
      collapse: false,
    };
  },
  mounted() {
    this.initSideBar();
  },
  methods: {
    initSideBar() {
      this.collapse = document.documentElement.clientWidth <= 1280;
      window.addEventListener("resize", () => {
        let newCollapse = document.documentElement.clientWidth <= 1280;
        if (this.collapse != newCollapse) {
          this.collapse = newCollapse;
          if (!this.$refs.sidebar) return;
          this.$refs.sidebar.style.opacity = 0;
          setTimeout(() => {
            this.$refs.sidebar.style.opacity = 1;
          }, 500);
        }
      });
      let timeout = document.documentElement.clientWidth <= 1280 ? 500 : 100;
      setTimeout(() => {
        this.$refs.sidebar.style.opacity = 1;
      }, timeout);
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
  },
};
</script>

<style scoped>
.sidebar {
  width: 100%;
  user-select: none;
  opacity: 0;
}
.el-menu {
  border-right: none;
}
.el-menu-item.is-active {
  background-color: rgba(255, 255, 255, 0.1) !important;
  background-color: #354053 !important;
}
.el-menu-item {
  font-size: 14px;
  vertical-align: middle !important;
  /* line-height: 52px!important; */
}
</style>