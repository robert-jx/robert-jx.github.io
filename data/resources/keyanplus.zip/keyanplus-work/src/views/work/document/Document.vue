<template>
  <div class="document">
    <!--  左侧目录树 -->
    <div class="left">
      <div class="head">文档与知识库</div>
      <div
        class="tree"
        :class="bread[0] && bread[0].label != '回收站' ? 'now' : ''"
      >
        <el-tree
          :data="tree"
          node-key="label"
          highlight-current
          :default-expanded-keys="expand"
          @node-click="onTreeClick"
        >
          <div slot-scope="{ data, node }">
            <span>
              <svg class="icon" aria-hidden="true">
                <use
                  v-if="data.label == '全部文档'"
                  xlink:href="#icon-yunpanlogo-3"
                ></use>
                <use
                  v-else-if="data.label == '我的收藏'"
                  xlink:href="#icon-yunpanlogo-1"
                ></use>
                <use
                  v-else-if="data.label == '我的上传'"
                  xlink:href="#icon-yunpanlogo-"
                ></use>
                <use v-else xlink:href="#icon-wenjianjia1"></use>
              </svg>
              {{ node.label }}
            </span>
          </div>
        </el-tree>
      </div>
      <div
        class="tree"
        :class="bread[0] && bread[0].label == '回收站' ? 'now' : ''"
      >
        <el-tree
          :data="tree2"
          node-key="label"
          highlight-current
          :default-expanded-keys="expand"
          @node-click="onTreeClick"
        >
          <div slot-scope="scope">
            <span>
              <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-yunpanlogo-2"></use>
              </svg>
              {{ scope.node.label }}
            </span>
          </div>
        </el-tree>
      </div>
    </div>
    <!-- 当前文件夹 -->
    <div class="right">
      <!-- 顶部操作按钮 -->
      <div class="head" style="text-align: right">
        <!-- 刷新 -->
        <el-button
          size="small"
          v-show="bread[1] && bread[0].label != '匹配到以下结果'"
          @click="doRefreshData(true)"
        >
          刷新
        </el-button>
        <!-- 新建文件夹 -->
        <el-button
          size="small"
          v-show="bread[1] && bread[0].label == '全部文档'"
          @click="onCreateDir()"
        >
          新建文件夹
        </el-button>
        <!-- 上传 -->
        <el-button
          size="small"
          type="primary"
          v-show="bread[1] && bread[0].label == '全部文档'"
          @click="onUploadFileTop()"
        >
          上传
        </el-button>
        <!-- 搜索 -->
        <el-input
          clearable
          size="small"
          v-model="search"
          placeholder="搜索文件，不支持特殊符号"
          @keydown.enter.native="doSearchFile()"
          style="float: left; width: 320px; margin-top: 14px"
        >
          <el-button
            slot="append"
            icon="el-icon-search"
            @click="doSearchFile()"
          ></el-button>
        </el-input>
      </div>

      <!-- 面包屑导航 -->
      <el-breadcrumb class="bread" separator-class="el-icon-arrow-right">
        <el-breadcrumb-item v-if="back.show">
          <span v-if="back.type == 'search'" @click="goBackBeforeList()">
            返回搜索结果
          </span>
          <!-- <span v-if="back.type == 'list'" @click="goBackBeforeList()">
            返回文件列表
          </span> -->
        </el-breadcrumb-item>

        <el-breadcrumb-item v-for="(item, index) in bread" :key="index">
          <span @click="onBreadClick(item, index)"> {{ item.label }} </span>
        </el-breadcrumb-item>
      </el-breadcrumb>

      <!-- 文件(夹)列表 - 全部文档 -->
      <div class="table" v-show="bread[0] && bread[0].label == '全部文档'">
        <el-table :data="current">
          <el-table-column label="名称" prop="name">
            <template slot-scope="scope">
              <svg class="icon" aria-hidden="true">
                <use
                  v-if="scope.row.label == '文件夹'"
                  xlink:href="#icon-wenjianjia1"
                ></use>
                <use v-else :xlink:href="getIconByName(scope.row.name)"></use>
              </svg>
              <span class="file-name" @click="onFileNameClick(scope.row)">
                {{ scope.row.name }}
              </span>
            </template>
          </el-table-column>

          <el-table-column label="类型" prop="label" width="80">
          </el-table-column>

          <el-table-column label="更新时间" prop="lastModified" width="152">
          </el-table-column>

          <el-table-column label="创建者" prop="authorName" width="100">
          </el-table-column>

          <el-table-column label="权限" prop="sign" width="120">
          </el-table-column>

          <el-table-column label="" width="50">
            <template slot-scope="scope">
              <el-dropdown trigger="click">
                <span class="el-dropdown-link">
                  <i class="el-icon-arrow-down el-icon-more"></i>
                </span>
                <el-dropdown-menu slot="dropdown" style="margin-top: 5px">
                  <el-dropdown-item
                    v-if="scope.row.create"
                    @click.native="onUploadFileList(scope.row)"
                  >
                    上传文件
                  </el-dropdown-item>

                  <el-dropdown-item
                    v-if="scope.row.authorName != 'system'"
                    @click.native="doCollectFile(scope.row)"
                  >
                    加入收藏夹
                  </el-dropdown-item>

                  <el-dropdown-item
                    v-if="scope.row.power == 'supper'"
                    @click.native="onOpenAuth(scope.row)"
                  >
                    设置权限
                  </el-dropdown-item>

                  <el-dropdown-item
                    v-if="scope.row.create"
                    @click.native="onRenameFile(scope.row)"
                  >
                    重命名
                  </el-dropdown-item>

                  <el-dropdown-item
                    v-if="scope.row.power == 'supper'"
                    @click.native="onRemoveTo(scope.row)"
                  >
                    移动到
                  </el-dropdown-item>

                  <el-dropdown-item
                    v-if="
                      scope.row.power == 'supper' &&
                      scope.row.authorName != 'system'
                    "
                    @click.native="doDeleteDocument(scope.row)"
                  >
                    删除
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 文件(夹)列表 - 我的收藏 -->
      <div class="table" v-show="bread[0] && bread[0].label == '我的收藏'">
        <el-table :data="current">
          <el-table-column label="名称" prop="name">
            <template slot-scope="scope">
              <svg class="icon" aria-hidden="true">
                <use
                  v-if="scope.row.label == '文件夹'"
                  xlink:href="#icon-wenjianjia1"
                ></use>
                <use v-else :xlink:href="getIconByName(scope.row.name)"></use>
              </svg>
              <span class="file-name" @click="onFileNameClick(scope.row)">
                {{ scope.row.name }}
              </span>
            </template>
          </el-table-column>

          <el-table-column label="类型" prop="label" width="80">
          </el-table-column>

          <el-table-column label="" width="50">
            <template slot-scope="scope">
              <el-dropdown trigger="click">
                <span class="el-dropdown-link">
                  <i class="el-icon-arrow-down el-icon-more"></i>
                </span>
                <el-dropdown-menu slot="dropdown" style="margin-top: 5px">
                  <el-dropdown-item
                    @click.native="goFromPathDir('收藏', scope.row)"
                  >
                    前往源位置
                  </el-dropdown-item>
                  <el-dropdown-item @click.native="doDeleteCollect(scope.row)">
                    移出收藏夹
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 文件(夹)列表 - 回收站 -->
      <div class="table" v-show="bread[0] && bread[0].label == '回收站'">
        <el-table :data="current">
          <el-table-column label="名称" prop="name">
            <template slot-scope="scope">
              <svg class="icon" aria-hidden="true">
                <use
                  v-if="scope.row.label == '文件夹'"
                  xlink:href="#icon-wenjianjia1"
                ></use>
                <use v-else :xlink:href="getIconByName(scope.row.name)"></use>
              </svg>
              <span class="file-name" @click="onFileNameClick(scope.row)">
                {{ scope.row.name }}
              </span>
            </template>
          </el-table-column>

          <el-table-column label="删除时间" prop="lastModified" width="152">
          </el-table-column>

          <el-table-column label="类型" prop="label" width="80">
          </el-table-column>

          <el-table-column label="" width="50">
            <template slot-scope="scope">
              <el-dropdown trigger="click">
                <span class="el-dropdown-link">
                  <i class="el-icon-arrow-down el-icon-more"></i>
                </span>
                <el-dropdown-menu slot="dropdown" style="margin-top: 5px">
                  <el-dropdown-item
                    @click.native="doDeleteDocumentComp(scope.row)"
                  >
                    彻底删除
                  </el-dropdown-item>
                  <el-dropdown-item @click.native="onRemoveTo(scope.row)">
                    移动到
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </template>
          </el-table-column>
        </el-table>
      </div>

      <!-- 搜索结果列表 -->
      <div
        class="table"
        v-show="bread[0] && bread[0].label == '匹配到以下结果'"
      >
        <div class="file" v-for="(item, index) in current" :key="index">
          <svg class="icon" aria-hidden="true">
            <use
              v-if="item.label == '文件夹'"
              xlink:href="#icon-wenjianjia1"
            ></use>
            <use v-else :xlink:href="getIconByName(item.name)"></use>
          </svg>
          <div class="content">
            <p @click="onFileNameClick(item)">
              {{ item.name }}
            </p>
            <p>
              {{ "创建于： " + item.createTime }}
              <span style="width: 20px; display: inline-block"></span>
              {{ "创建人： " + item.authorName }}
            </p>
          </div>
          <el-dropdown trigger="click">
            <span class="el-dropdown-link">
              <i class="el-icon-arrow-down el-icon-more"></i>
            </span>
            <el-dropdown-menu slot="dropdown" style="margin-top: 5px">
              <el-dropdown-item @click.native="goFromPathDir('搜索', item)">
                前往源位置
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>

    <!-- 上传文件弹窗 -->
    <el-dialog
      width="400px"
      title="上传文件"
      :visible.sync="dialog.upload"
      :close-on-click-modal="false"
      class="upload"
      ref="upload-dialog"
    >
      <el-upload
        drag
        action
        multiple
        ref="upload"
        :auto-upload="false"
        :on-change="fileChange"
        :http-request="uploadFile"
        :on-exceed="fileExceed"
        :limit="upload.limit"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或点击选择</div>
        <div class="el-upload__tip" slot="tip">
          单文件大小不超过 100 MB，可同时上传 5 个文件
        </div>
      </el-upload>

      <span slot="footer">
        <el-button size="small" @click="dialog.upload = false">
          取消
        </el-button>
        <el-button size="small" type="primary" @click="doUploadFile()">
          上传
        </el-button>
      </span>
    </el-dialog>

    <!-- 新建文件夹弹窗 -->
    <el-dialog
      width="400px"
      title="新建文件夹"
      :visible.sync="dialog.create"
      :close-on-click-modal="false"
      class="create"
    >
      <el-form :model="create">
        <el-form-item label="请输入文件夹名称">
          <el-input v-model="create.name"></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button size="small" @click="dialog.create = false">
          取消
        </el-button>
        <el-button size="small" type="primary" @click="doCreateDir()">
          创建
        </el-button>
      </span>
    </el-dialog>

    <!-- 设置权限弹窗 -->
    <el-dialog
      width="550px"
      title="设置权限"
      :visible.sync="dialog.auth"
      :close-on-click-modal="false"
      class="auth"
    >
      <el-form :model="auth" label-position="top">
        <el-form-item label="">
          <el-select
            v-model="auth.search"
            placeholder="请搜索成员、课题组设置权限"
            :remote-method="querySearch"
            no-data-text="无匹配结果"
            style="width: 100%"
            filterable
            clearable
            remote
          >
            <el-option
              v-for="item in auth.options"
              :key="item.value"
              :label="item.label"
              :value="item.id + '@' + item.type"
            >
              <i v-if="item.type == 'user'" class="iconfont icon-user"></i>
              <i v-if="item.type == 'group'" class="iconfont icon-solution"></i>
              <span style="margin-left: 2px; vertical-align: top">
                {{ item.value }}
              </span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="现有权限" class="auth-list">
          <!-- 实验室权限 -->
          <el-row :gutter="20">
            <el-col :span="10">
              <i class="el-icon-aim"></i>
              <span> 实验室成员 </span>
            </el-col>
            <el-col :span="14">
              <el-radio-group v-model="auth.Inner">
                <el-radio label="none">无权限</el-radio>
                <el-radio label="read">只读</el-radio>
                <el-radio label="all">读写</el-radio>
              </el-radio-group>
            </el-col>
          </el-row>
          <!-- 课题组权限 -->
          <el-row
            :gutter="20"
            v-for="(item, key) in auth.Group"
            :key="key"
            :class="item.new ? 'new' : ''"
          >
            <el-col :span="10">
              <i class="iconfont icon-solution"></i>
              <span> {{ item.label }} </span>
            </el-col>
            <el-col :span="13">
              <el-radio-group v-model="item.auth">
                <el-radio
                  label="none"
                  @click.native="onAuthChange('group', item.id, 'none')"
                  >无权限</el-radio
                >
                <el-radio
                  label="read"
                  @click.native="onAuthChange('group', item.id, 'read')"
                  >只读</el-radio
                >
                <el-radio
                  label="all"
                  @click.native="onAuthChange('group', item.id, 'all')"
                  >读写</el-radio
                >
              </el-radio-group>
            </el-col>
            <el-col :span="1">
              <i
                class="el-icon-delete"
                @click="onAuthDelete('group', item.id)"
              ></i>
            </el-col>
          </el-row>
          <!-- 用户权限 -->
          <el-row
            :gutter="20"
            v-for="(item, key) in auth.User"
            :key="key"
            :class="item.new ? 'new' : ''"
          >
            <el-col :span="10">
              <i class="el-icon-user"></i>
              <span> {{ item.name }} </span>
            </el-col>
            <el-col :span="13">
              <el-radio-group v-model="item.auth">
                <el-radio
                  label="none"
                  @click.native="onAuthChange('user', item.id, 'none')"
                  >无权限</el-radio
                >
                <el-radio
                  label="read"
                  @click.native="onAuthChange('user', item.id, 'read')"
                  >只读</el-radio
                >
                <el-radio
                  label="all"
                  @click.native="onAuthChange('user', item.id, 'all')"
                  >读写</el-radio
                >
              </el-radio-group>
            </el-col>
            <el-col :span="1">
              <i
                class="el-icon-delete"
                @click="onAuthDelete('user', item.id)"
              ></i>
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <div class="describle">
        <p>权限功能：</p>
        <p>通过搜索框内搜索成员姓名，可以对指定成员设置权限</p>
        <p>权限名词解读：</p>
        <p>*无权限</p>
        <p>使用场景：您上传的文件是仅供自己阅读整理，可以点击无权限</p>
        <p>*只读</p>
        <p>使用场景：您上传的文件可以让实验室成员阅读，但不能修改编辑</p>
        <p>*读写</p>
        <p>使用场景：您上传的文件既可以让实验室成员阅读，也可以修改编辑</p>
      </div>
      <span slot="footer">
        <el-button size="small" @click="dialog.auth = false"> 取消 </el-button>
        <el-button size="small" type="primary" @click="doEditFileAuth()">
          确定
        </el-button>
      </span>
    </el-dialog>

    <!-- 移动文件弹窗 -->
    <el-dialog
      width="400px"
      title="移动到"
      :visible.sync="dialog.move"
      :close-on-click-modal="false"
      class="move"
    >
      <el-tree
        lazy
        :load="getTargetDir"
        @node-click="onSelectTargetDir"
        :expand-on-click-node="false"
      ></el-tree>

      <span slot="footer">
        <el-button size="small" @click="dialog.move = false"> 取消 </el-button>
        <el-button size="small" type="primary" @click="doRemoveFile()">
          移动
        </el-button>
      </span>
    </el-dialog>

    <!-- 重命名文件（夹）弹窗 -->
    <el-dialog
      width="400px"
      title="重命名"
      :visible.sync="dialog.rename"
      :close-on-click-modal="false"
      class="rename"
    >
      <el-form :model="rename">
        <el-form-item label="请输入新的名称">
          <el-input
            v-model="rename.name2"
            :placeholder="rename.name"
          ></el-input>
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button size="small" @click="dialog.rename = false">
          取消
        </el-button>
        <el-button size="small" type="primary" @click="doRenameFile()">
          更改
        </el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
const COS = require("cos-js-sdk-v5");
export default {
  data() {
    return {
      tree: [], // 左侧目录树
      tree2: [], // 左侧目录树-回收站
      expand: ["全部文档"], // 默认展开
      back: {
        type: "search", // 返回类型
        list: null, // 之前的数据
        show: false, // 是否显示
      },
      current: [], // 当前文件夹
      userList: null, // 用户列表
      groupList: null, // 课题组列表
      search: null, // 顶部文件搜索
      loading: false, // 加载动画
      bread: [{ label: "全部文档" }], // 面包屑导航
      create: {
        name: null, // 新建文件夹名称
      },
      rename: {
        auth: null, // 文件（夹）权限
        name: null, // 文件（夹）名称
        path: null, // 文件（夹）路径
        name2: null, // 新文件（夹）名称
      },
      upload: {
        auth: null, // 目标文件夹权限
        name: null, // 目标文件夹名称
        count: null, // 正在上传的文件个数
        loading: null, // 上传等待动画
        status: {}, // 文件上传状态
        limit: 5, // 同时上传数量限制
      },
      auth: {
        search: null, // 查找用户/课题
        name: null, // 文件（夹）名
        label: null, // 文件或文件夹
        Inner: null, // 实验室权限
        Group: [], // 小组权限
        User: [], // 用户权限
      },
      move: {
        auth: null, // 文件（夹）权限
        name: null, // 文件（夹）名称
        path: null, // 文件（夹）路径
        target: null, // 移动路径
      },
      dialog: {
        upload: false, // 上传文件弹窗
        create: false, // 新建文件夹弹窗
        rename: false, // 重命名文弹窗
        auth: false, // 设置权限弹窗
        move: false, // 移动文件弹窗
      },
    };
  },
  watch: {
    search(newV) {
      newV += "";
      let array = ["*", "(", ")", "[", "]", "?", "\\"];
      for (let char of array) {
        if (newV.indexOf(char) != -1) {
          this.search = newV.replace(/\*|\(|\)|\[|\]|\?|\\/g, "");
          return;
        }
      }
      this.doSearchFile();
    },
    "auth.search"(newV) {
      if (newV) {
        let id = newV.split("@")[0];
        let type = newV.split("@")[1];
        if (type == "user") {
          if (this.auth.User[id]) {
            return this.$message.info("已在列表中");
          }
          this.auth.User[id] = this.getUserById(id);
          this.auth.User[id].auth = this.auth.Inner;
          this.auth.User[id].new = true;
        }
        if (type == "group") {
          if (this.auth.Group[id]) {
            return this.$message.info("已在列表中");
          }
          this.auth.Group[id] = this.getGroupById(id);
          this.auth.Group[id].auth = this.auth.Inner;
          this.auth.Group[id].new = true;
        }
      }
    },
    "create.name"(newV) {
      newV += "";
      if (newV && newV.slice(0, 1) == ".") {
        this.create.name = newV.slice(1);
        this.$message.warning('文件夹名称不能以"."开头');
      }
      if (newV.indexOf("/") != -1) {
        this.create.name = newV.replace(/\//g, "");
        this.$message.warning('文件夹名称不能包含"/"');
      }
      if (newV.indexOf("+") != -1) {
        this.create.name = newV.replace(/\+/g, "");
        this.$message.warning('文件夹名称不能包含"+"');
      }
    },
    "rename.name2"(newV) {
      newV += "";
      if (newV && newV.slice(0, 1) == ".") {
        this.rename.name2 = newV.slice(1);
        this.$message.warning('文件夹名称不能以"."开头');
      }
      if (newV.indexOf("/") != -1) {
        this.rename.name2 = newV.replace(/\//g, "");
        this.$message.warning('文件夹名称不能包含"/"');
      }
      if (newV.indexOf("+") != -1) {
        this.rename.name2 = newV.replace(/\+/g, "");
        this.$message.warning('文件夹名称不能包含"+"');
      }
    },
  },
  mounted() {
    this.initLabInfo();
    this.initLeftTree(true);
    this.getGroupUserInfo();
    this.getDocumentList("/实验室规范/");
  },
  methods: {
    // 头
    head(r) {
      return `x-cos-meta-${r.toLowerCase()}`;
    },
    // 初始化实验室信息
    initLabInfo() {
      this.labInfo = JSON.parse(this.getCookie("currentlab"));
    },
    // 初始化左侧目录树
    initLeftTree(def) {
      this.tree = [
        {
          label: "全部文档",
          children: [
            {
              label: "实验室规范",
              active: def,
            },
            {
              label: "会议与文献",
            },
            {
              label: "保藏知识库",
            },
            {
              label: "仪器文档",
            },
            {
              label: "项目文档",
            },
          ],
        },
        {
          label: "我的收藏",
        },
        // {
        //   label: "我的上传",
        // },
      ];
      this.tree2 = [
        {
          label: "回收站",
        },
      ];
    },
    // 刷新列表数据
    doRefreshData(show) {
      if (this.bread[0].label == "全部文档") {
        let paramPath = "/";
        for (let i in this.bread) {
          if (i > 0) paramPath += this.bread[i].label + "/";
        }
        this.getDocumentList(paramPath, show);
      }
      if (this.bread[0].label == "我的收藏") {
        this.getDocumentFav("/", show);
      }
      if (this.bread[0].label == "我的上传") {
        console.info("我的上传");
      }
      if (this.bread[0].label == "回收站") {
        this.getDocumentRec(show);
      }
    },
    // 搜索文件
    doSearchFile() {
      let path = "/api/v1/utils/COS/query";
      let data = {
        params: { keyword: this.search },
      };
      this.axios.get(path, data).then((res) => {
        // 处理数据并放到current
        const dealItem = (list, label) => {
          list.forEach((item) => {
            item.label = label;
            if (item.auth.Inner == "all") item.sign = "实验室内读写";
            if (item.auth.Inner == "read") item.sign = "实验室内只写";
            if (item.auth.Inner == "none") item.sign = "私有";
            item.authorName = this.decodeUnicode(
              item.authorName.replace(/[u]/g, "\\u")
            );
            item.power = this.dealFileAuth(item);
            item.create = false;
            if (label == "文件夹" && ["all", "supper"].includes(item.power)) {
              item.create = true;
            }

            this.current.push(item);
          });
        };

        // 初始化面包屑导航
        this.bread = [
          {
            label: "匹配到以下结果",
          },
        ];

        // 初始化current
        this.current = [];
        dealItem(res.data.dirs, "文件夹");
        dealItem(res.data.files, "文件");
      });
    },
    // 返回之前的列表
    goBackBeforeList() {
      this.back.show = false;
      this.current = this.back.list;
      this.bread = [
        {
          auth: null,
          label: "匹配到以下结果",
          power: null,
        },
      ];
    },
    // 获取课题组跟用户相关信息
    getGroupUserInfo() {
      let path = "/api/v1/lab/researchGroupsAndDetails";
      let data = {
        params: { labId: this.labInfo.fkLabId },
      };
      this.axios.get(path, data).then((res) => {
        if (res.data.code == 20000) {
          this.userList = res.data.data.labDetails;
          // 将数组转化为对象数组（将相同课题组的数据项放在一起）
          let list = res.data.data.researchGroupDetails;
          let onGroupObject = {}; // 用于记录在课题组中的用户
          let object = {};
          this.labInfo.group = []; // 用于记录用户所在的课题组
          list.forEach((item) => {
            // 将课题组ID添加到labInfo.group
            if (item.fkLabDetailId == this.labInfo.id) {
              this.labInfo.group.push(item.fkResearchGroupId);
            }
            let key = item.groupName;
            if (!object[key]) object[key] = [];
            object[key].push({
              value: item.fkLabDetailId,
              label: item.detailName,
              parent: item.groupName,
              groupId: item.fkResearchGroupId,
            });
            onGroupObject[item.fkLabDetailId] = 1;
          });
          // 将其他不在课题组的用户放入其他用户组
          object["其他实验室成员"] = [];
          this.userList.forEach((item) => {
            if (onGroupObject[item[0]] == 1) return;
            object["其他实验室成员"].push({
              value: item[0],
              label: item[2],
              parent: "其他实验室成员",
              groupId: "-1",
            });
          });
          // 将对象数组转为二维数组（转为组件数据格式）
          this.groupList = [];
          for (let key in object) {
            this.groupList.push({
              value: key,
              label: key,
              children: object[key],
              id: object[key][0] ? object[key][0].groupId : "-1",
            });
          }
        }
      });
    },
    // 获取文档列表
    getDocumentList(paramPath, refresh) {
      let path = "/api/v1/utils/COS/list";
      let data = {
        params: { path: paramPath },
      };
      this.loading = true;
      this.axios.get(path, data).then((res) => {
        this.loading = false;
        if (refresh) this.$message.success("刷新成功");

        // 处理数据并放到current
        const dealItem = (list, label) => {
          list.forEach((item) => {
            item.label = label;
            if (item.auth.Inner == "all") item.sign = "实验室内读写";
            if (item.auth.Inner == "read") item.sign = "实验室内只写";
            if (item.auth.Inner == "none") item.sign = "私有";
            item.authorName = this.decodeUnicode(
              item.authorName.replace(/[u]/g, "\\u")
            );
            item.power = this.dealFileAuth(item);
            item.create = false;
            if (label == "文件夹" && ["all", "supper"].includes(item.power)) {
              item.create = true;
            }

            this.current.push(item);
          });
        };

        // 初始化面包屑导航
        let bread = paramPath.split("/").slice(0, -1);
        this.bread = Array.from(bread, (item) => {
          return {
            label: item,
          };
        });
        this.bread[0].label = "全部文档";
        this.bread[this.bread.length - 1].auth = res.data.auth;
        this.bread[this.bread.length - 1].power = this.dealFileAuth({
          auth: res.data.auth,
        });

        // 初始化current
        this.current = [];
        dealItem(res.data.dirs, "文件夹");
        dealItem(res.data.files, "文件");
      });
    },
    // 获取收藏列表
    getDocumentFav(paramPath, refresh) {
      let path = "/api/v1/utils/COS/favorite";
      let data = {
        params: { path: paramPath },
      };
      this.loading = true;
      this.axios.get(path, data).then((res) => {
        this.loading = false;
        if (refresh) this.$message.success("刷新成功");
        // 处理数据并放到current
        const dealItem = (list, label) => {
          list.forEach((item) => {
            item.label = label;
            this.current.push(item);
          });
        };
        this.current = [];
        dealItem(res.data.data.dirs, "文件夹");
        dealItem(res.data.data.files, "文件");
      });
    },
    // 获取回收站列表
    getDocumentRec(refresh) {
      let path = "/api/v1/utils/COS/recycleBin";
      this.loading = true;
      this.axios.get(path).then((res) => {
        this.loading = false;
        if (refresh) this.$message.success("刷新成功");

        // 处理数据并放到current
        const dealItem = (list, label) => {
          list.forEach((item) => {
            item.label = label;
            if (item.auth.Inner == "all") item.sign = "实验室内读写";
            if (item.auth.Inner == "read") item.sign = "实验室内只写";
            if (item.auth.Inner == "none") item.sign = "私有";
            item.power = this.dealFileAuth(item);
            item.create = false;
            if (label == "文件夹" && ["all", "supper"].includes(item.power)) {
              item.create = true;
            }

            this.current.push(item);
          });
        };

        // 初始化面包屑导航
        this.bread = [{ label: "回收站" }];

        // 初始化current
        this.current = [];
        dealItem(res.data.dirs, "文件夹");
        dealItem(res.data.files, "文件");
      });
    },
    // 获取腾讯云cos临时密钥
    getAuthorization(options, callback) {
      let path = "/api/v1/utils/STS/labs";
      this.axios.get(path).then(({ data }) => {
        let credentials = data && data.credentials;
        if (!data || !credentials) {
          console.error("获取临时密钥失败");
          return;
        }
        callback({
          TmpSecretId: credentials.tmpSecretId,
          TmpSecretKey: credentials.tmpSecretKey,
          XCosSecurityToken: credentials.sessionToken,
          StartTime: data.startTime,
          ExpiredTime: data.expiredTime,
        });
      });
    },
    // 点击列表项上传文件调用
    onUploadFileList(item) {
      this.dialog.upload = true;
      this.upload.auth = item.auth;
      this.upload.name = item.name;
    },
    // 点击顶部上传文件调用
    onUploadFileTop() {
      this.dialog.upload = true;
      this.upload.auth = this.bread[this.bread.length - 1].auth;
      this.upload.name = null;
    },
    // 点击表单上传文件调用
    doUploadFile() {
      this.upload.count = 0;
      this.$refs.upload.submit();
    },
    // 选择文件时调用
    fileChange(file, fileList) {
      if (file.name) file.name = (file.name + "").replace(/\+/g, "-");
      // 判断大小是否符合要求
      if (file.size / 1024 / 1024 > 100) {
        this.$message.error(file.name + " 大小超出100M");
        fileList.pop();
      }
      // 判断是否重复选择
      for (let i = 0; i < fileList.length - 1; i++) {
        if (file.name == fileList[i].name && file.status == "ready") {
          this.$message.error(file.name + " 已经选择，请勿重复");
          fileList.pop();
          return;
        }
      }
      this.upload.status[file.name] = file.status;
      if (file.status != "ready") {
        // 去除加载动画
        let fileDomList = document.querySelectorAll(
          ".upload .el-upload-list__item"
        );
        fileDomList.forEach((dom) => {
          let name = dom.children[0].innerText;
          let target = dom.children[2];
          if (name == file.name) {
            target.classList.remove("el-icon-loading");
            target.classList.add("el-icon-close");
          }
        });
      }
    },
    // 文件数量超出时提示
    fileExceed() {
      this.$message.warning(`最多同时上传${this.upload.limit}个文件`);
    },
    // 上传文件
    uploadFile(param) {
      // 锁定上传文件弹窗
      if (this.upload.count == 0) {
        this.upload.loading = this.$loading({
          target: document.querySelector(".upload .el-dialog"),
          text: "",
          background: "rgba(0, 0, 0, 0.1)",
          spinner: "el-icon",
        });
      }
      // 添加加载动画
      let fileDomList = document.querySelectorAll(
        ".upload .el-upload-list__item"
      );
      fileDomList.forEach((dom) => {
        let name = dom.children[0].innerText;
        let target = dom.children[2];
        if (this.upload.status[name] == "ready") {
          target.classList.remove("el-icon-close");
          target.classList.add("el-icon-loading");
        }
      });

      // 统计正在上传的文件个数
      this.upload.count += 1;
      // 对文件（夹）进行授权
      let auth = this.upload.auth;
      if (!auth) {
        this.$message.error("未知错误，上传失败");
        return;
      }
      let paramPath = this.labInfo.fkLabId + "/";
      for (let i in this.bread) {
        if (i != 0) {
          paramPath += this.bread[i].label + "/";
        }
      }
      if (this.upload.name) paramPath += this.upload.name + "/";

      // 根据临时密钥生成cos对象并上传文件
      new COS({
        getAuthorization: this.getAuthorization,
      }).sliceUploadFile(
        {
          Bucket: "lab-files-1300972980", // 必须
          Region: "ap-shanghai", // 存储桶所在地域，必须
          Key: paramPath + param.file.name.replace(/\+/g, "-"), // 必须
          [this.head("auth")]: JSON.stringify(auth),
          [this.head("authorName")]: this.encodeUnicode(this.labInfo.realName),
          [this.head("authorUsername")]: this.labInfo.id,
          [this.head("createTime")]: new Date().toJSON(),
          Body: param.file, // 上传文件对象
          // onProgress: (progressData) => {
          //   console.log(JSON.stringify(progressData));
          // },
        },
        (err, data) => {
          this.upload.count--;
          if (err !== null) {
            param.onError();
            this.$message.error("文件上传错误");
            console.log(err || data);
          } else {
            param.onSuccess();
            if (this.upload.count == 0) {
              this.$message.success("文件上传成功");
              paramPath = paramPath.slice(paramPath.indexOf("/"));
              this.getDocumentList(paramPath);
              this.$refs.upload.clearFiles();
              this.dialog.upload = false;
              this.upload.loading.close();
            }
          }
        }
      );
    },
    // 下载文件
    doDownLoadFile(paramPath) {
      // 根据临时密钥生成cos对象并下载文件
      new COS({
        getAuthorization: this.getAuthorization,
      }).getObjectUrl(
        {
          Bucket: "lab-files-1300972980", // 必须
          Region: "ap-shanghai", // 存储桶所在地域，必须
          Key: paramPath, // 必须
          Sign: true,
          Expires: 30, // 单位秒
        },
        (err, data) => {
          if (err) return console.log(err);
          let urlParam = "response-content-disposition=attachment";
          // 补充强制下载的参数
          let downloadUrl =
            data.Url + (data.Url.indexOf("?") > -1 ? "&" : "?") + urlParam;
          // window.open(data.Url);

          let alink = document.createElement("a");
          alink.download = "teamplte"; // 文件名
          alink.href = downloadUrl; // 下载地址
          alink.click(); //自动点击
        }
      );
    },
    // 点击列表文件名时调用
    onFileNameClick(file) {
      if (this.bread[0].label == "回收站") {
        this.$message.warning(`回收站中不能打开`);
      }
      if (this.bread[0].label == "我的收藏") {
        if (file.label == "文件夹") this.getDocumentList(file.path);
      }
      if (this.bread[0].label == "全部文档") {
        let paramPath = "/";
        for (let i in this.bread) {
          if (i != 0) {
            paramPath += this.bread[i].label + "/";
          }
        }
        if (file.label == "文件夹") {
          paramPath += file.name + "/";
          this.getDocumentList(paramPath);
        } else {
          paramPath = "/" + this.labInfo.fkLabId + paramPath + file.name;
          this.doDownLoadFile(paramPath);
        }
      }
      if (this.bread[0].label == "匹配到以下结果") {
        this.back.list = JSON.parse(JSON.stringify(this.current));
        this.back.show = true;

        let paramPath = file.path;
        if (file.label == "文件夹") {
          this.getDocumentList(paramPath);
        } else {
          paramPath = "/" + this.labInfo.fkLabId + paramPath + file.name;
          this.doDownLoadFile(paramPath);
        }
      }
    },
    // 点击顶部新建文件夹调用
    onCreateDir() {
      this.dialog.create = true;
    },
    // 点击表单新建文件夹调用
    doCreateDir() {
      for (let item of this.current) {
        if (item.name == this.create.name) {
          this.$message.error("该文件夹已存在，请勿重复创建");
          return;
        }
      }
      let path = "/api/v1/utils/COS/dirs";
      let paramPath = "/";
      for (let i in this.bread) {
        if (i != 0) {
          paramPath += this.bread[i].label + "/";
        }
      }
      let data = {
        params: {
          path: paramPath,
          dirName: this.create.name,
        },
      };
      let body = this.bread[this.bread.length - 1].auth;
      this.axios.post(path, body, data).then((res) => {
        this.$message.success(res.data.message);
        this.dialog.create = false;
        this.create.name = null;
        this.getDocumentList(paramPath);
      });
    },
    // 点击列表收藏文件（夹）调用
    doCollectFile(file) {
      let path = "/api/v1/utils/COS/favorite";
      let paramPath = "/";
      for (let i in this.bread) {
        if (i != 0) {
          paramPath += this.bread[i].label + "/";
        }
      }
      if (file.label == "文件夹") paramPath += file.name + "/";
      if (file.label == "文件") paramPath += file.name;
      let data = {
        params: { path: paramPath },
      };
      this.axios.post(path, null, data).then((res) => {
        this.$message.success(res.data.message);
      });
    },
    // 点击列表移出收藏夹调用
    doDeleteCollect(file) {
      let path = "/api/v1/utils/COS/favorite";
      let data = { params: file };
      this.axios.delete(path, data).then((res) => {
        this.$message.success(res.data.message);
        this.getDocumentFav();
      });
    },
    // 点击前往源路径调用
    goFromPathDir(type, file) {
      let paramPath = "";
      if (type == "收藏") {
        if (file.label == "文件夹") {
          paramPath = file.path.slice(0, -(file.name.length + 1));
        }
        if (file.label == "文件") {
          paramPath = file.path.slice(0, -file.name.length);
        }
      }
      if (type == "搜索") {
        if (file.label == "文件夹") {
          paramPath = file.path.slice(0, -(file.name.length + 1));
        }
        if (file.label == "文件") {
          paramPath = file.path;
        }
        this.back.list = JSON.parse(JSON.stringify(this.current));
        this.back.show = true;
      }
      this.getDocumentList(paramPath);
    },
    // 点击列表删除文件（夹）调用
    doDeleteDocument(file) {
      let path = "/api/v1/utils/COS/";
      let paramPath = "/";
      for (let i in this.bread) {
        if (i != 0) {
          paramPath += this.bread[i].label + "/";
        }
      }
      if (file.label == "文件夹") paramPath += file.name + "/";
      if (file.label == "文件") paramPath += file.name;

      let data = {
        params: { path: paramPath },
      };

      // 删除文件（夹）
      const deleteDocument = () => {
        this.axios.delete(path, data).then((res) => {
          this.$message.success(res.data.message);
          if (file.label == "文件夹")
            paramPath = paramPath.slice(0, -(file.name.length + 1));
          if (file.label == "文件")
            paramPath = paramPath.slice(0, -file.name.length);
          this.getDocumentList(paramPath);
        });
      };

      // 删除前提醒
      let comfirmDesc = `此操作将删除「 ${file.name} 」${file.label}, 是否继续?`;
      let comfirmTitle = "提示";
      let comfirmBtn = {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      };
      this.$confirm(comfirmDesc, comfirmTitle, comfirmBtn)
        .then(() => {
          deleteDocument();
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    },
    // 点击回收站列表彻底删除调用
    doDeleteDocumentComp(file) {
      let path = "/api/v1/utils/COS/recycleBin";
      let paramPath = "/.回收站/";
      if (file.label == "文件夹") paramPath += file.name + "/";
      if (file.label == "文件") paramPath += file.name;
      let data = {
        params: { path: paramPath },
      };
      // 彻底删除回收站文件（夹）
      const deleteDocumentComp = () => {
        this.axios.delete(path, data).then((res) => {
          this.$message.success(res.data.message);
          this.getDocumentRec();
        });
      };

      // 删除前提醒
      let comfirmDesc = `此操作将彻底删除「 ${file.name} 」${file.label}, 是否继续?`;
      let comfirmTitle = "提示";
      let comfirmBtn = {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      };
      this.$confirm(comfirmDesc, comfirmTitle, comfirmBtn)
        .then(() => {
          deleteDocumentComp();
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    },
    // 点击列表重命名文件（夹）调用
    onRenameFile(file) {
      console.info(file);
      let paramPath = "/";
      for (let i in this.bread) {
        if (i > 0) paramPath += this.bread[i].label + "/";
      }
      if (file.label == "文件夹") paramPath += file.name + "/";
      if (file.label == "文件") paramPath += file.name;

      this.rename.auth = file.auth;
      this.rename.name = file.name;
      this.rename.path = paramPath;
      this.rename.label = file.label;
      this.dialog.rename = true;
    },
    // 向后台提交移动文件（夹）
    doRenameFile() {
      let path = "/api/v1/utils/COS/";
      let targetPath = "/";
      for (let i in this.bread) {
        if (i > 0) targetPath += this.bread[i].label + "/";
      }
      if (this.rename.label == "文件夹") targetPath += this.rename.name2 + "/";
      if (this.rename.label == "文件") targetPath += this.rename.name2;
      let data = {
        params: {
          path: this.rename.path,
          targetPath: targetPath,
        },
      };
      let body = this.move.auth;
      this.axios.put(path, body, data).then((res) => {
        this.$message.success(res.data.message);
        this.dialog.rename = false;
        this.doRefreshData(false);
      });
    },
    // 点击列表移动文件（夹）调用
    onRemoveTo(file) {
      let paramPath = "/";
      if (this.bread[0].label == "回收站") {
        paramPath = "/.回收站/";
      } else {
        for (let i in this.bread) {
          if (i > 0) paramPath += this.bread[i].label + "/";
        }
      }
      if (file.label == "文件夹") paramPath += file.name + "/";
      if (file.label == "文件") paramPath += file.name;

      this.move.auth = file.auth;
      this.move.name = file.name;
      this.move.path = paramPath;
      this.move.label = file.label;
      this.dialog.move = true;
    },
    // 获取文件目录调用
    getTargetDir(node, resolve) {
      if (node.level == 0) {
        resolve([
          {
            label: "实验室规范",
            parent: null,
          },
          {
            label: "会议与文献",
            parent: null,
          },
          {
            label: "保藏知识库",
            parent: null,
          },
          {
            label: "仪器文档",
            parent: null,
          },
          {
            label: "项目文档",
            parent: null,
          },
        ]);
      }
      if (node.level >= 1) {
        let paramPath = node.label ? "/" + node.label + "/" : "/";
        let parentData = node.data ? node.data.parent : null;
        while (parentData) {
          paramPath = "/" + parentData.label + paramPath;
          parentData = parentData.parent;
        }

        let path = "/api/v1/utils/COS/list";
        let data = {
          params: { path: paramPath },
        };
        this.axios.get(path, data).then((res) => {
          let result = [];
          res.data.dirs.forEach((item) => {
            if (["supper", "all"].includes(this.dealFileAuth(item))) {
              result.push({
                label: item.name,
                parent: node.data,
              });
            }
          });
          resolve(result);
        });
      }
    },
    // 选中文件夹调用
    onSelectTargetDir(data) {
      let paramPath = "/" + data.label + "/" + this.move.name;
      if (this.move.label == "文件夹") paramPath += "/";
      let parentData = data.parent;
      while (parentData) {
        paramPath = "/" + parentData.label + paramPath;
        parentData = parentData.parent;
      }
      this.move.target = paramPath;
    },
    // 向后台提交移动文件（夹）
    doRemoveFile() {
      let path = "/api/v1/utils/COS/";
      let data = {
        params: {
          path: this.move.path,
          targetPath: this.move.target,
        },
      };
      let body = this.move.auth;
      this.axios.put(path, body, data).then((res) => {
        this.$message.success(res.data.message);
        this.dialog.move = false;
        this.doRefreshData(false);
      });
    },
    // 点击列表设置权限调用
    onOpenAuth(file) {
      this.auth.name = file.name;
      this.auth.label = file.label;
      this.auth.User = {};
      this.auth.Group = {};
      this.auth.Inner = file.auth.Inner;
      const dealUserAuth = (list, auth) => {
        list.forEach((id) => {
          this.auth.User[id] = this.getUserById(id);
          this.auth.User[id].auth = auth;
        });
      };
      const dealUserGroup = (list, auth) => {
        list.forEach((id) => {
          this.auth.Group[id] = this.getGroupById(id);
          this.auth.Group[id].auth = auth;
        });
      };
      dealUserAuth(file.auth.User.none, "none");
      dealUserAuth(file.auth.User.read, "read");
      dealUserAuth(file.auth.User.all, "all");
      dealUserGroup(file.auth.Group.none, "none");
      dealUserGroup(file.auth.Group.read, "read");
      dealUserGroup(file.auth.Group.all, "all");
      this.dialog.auth = true;
    },
    // 刷新auth对应到视图
    refreshAuthView(type) {
      if (type == "user") {
        let item = JSON.parse(JSON.stringify(this.auth.User));
        this.$set(this.auth, "User", item);
      }
      if (type == "group") {
        let item = JSON.parse(JSON.stringify(this.auth.Group));
        this.$set(this.auth, "Group", item);
      }
    },
    // 权限弹窗更改权限调用
    onAuthChange(type, id, val) {
      if (type == "user") {
        this.auth.User[id].auth = val;
      }
      if (type == "group") {
        this.auth.Group[id].auth = val;
      }
      this.refreshAuthView(type);
    },
    // 权限弹窗删除权限调用
    onAuthDelete(type, id) {
      this.auth.search = null;
      this.auth.options = null;
      if (type == "user") {
        delete this.auth.User[id];
      }
      if (type == "group") {
        delete this.auth.Group[id];
      }
      this.refreshAuthView(type);
    },
    // 向后台提交更改后到权限
    doEditFileAuth() {
      let path = "/api/v1/utils/COS/";
      let paramPath = "/";
      for (let i in this.bread) {
        if (i > 0) {
          paramPath += this.bread[i].label + "/";
        }
      }
      let fileName = "";
      if (this.auth.label == "文件夹") fileName += this.auth.name + "/";
      if (this.auth.label == "文件") fileName += this.auth.name;
      let data = {
        params: {
          path: paramPath + fileName,
          targetPath: paramPath + fileName,
        },
      };

      let body = {};
      body.Inner = this.auth.Inner;

      const inAuthItem = (key) => {
        body[key] = {
          none: [],
          read: [],
          all: [],
        };
      };
      const dealAuthItem = (key) => {
        let list = this.auth[key];
        for (let i in list) {
          if (list[i].auth == "none") {
            body[key].none.push(i);
          }
          if (list[i].auth == "read") {
            body[key].read.push(i);
          }
          if (list[i].auth == "all") {
            body[key].all.push(i);
          }
        }
      };

      inAuthItem("User");
      inAuthItem("Group");
      inAuthItem("Project");
      dealAuthItem("User");
      dealAuthItem("Group");

      this.axios.put(path, body, data).then((res) => {
        this.$message.success(res.data.message);
        this.dialog.auth = false;
        this.getDocumentList(paramPath);
      });
    },
    // 点击左侧菜单调用
    onTreeClick(data) {
      this.back.show = false;

      if (data.label == "全部文档") {
        this.getDocumentList("/");
      } else if (data.label == "我的收藏") {
        this.getDocumentFav("/");
        this.bread = [
          {
            auth: null,
            label: "我的收藏",
            power: null,
          },
        ];
      } else if (data.label == "我的上传") {
        console.info("我的上传");
        this.bread = [
          {
            auth: null,
            label: "我的上传",
            power: null,
          },
        ];
      } else if (data.label == "回收站") {
        this.getDocumentRec();
        this.bread = [
          {
            auth: null,
            label: "回收站",
            power: null,
          },
        ];
      } else {
        let path = "/" + data.label + "/";
        this.getDocumentList(path);
        this.tree[0].children.forEach((node) => {
          if (node.label == data.label) node.active = true;
        });
      }
    },
    // 点击面包屑调用
    onBreadClick(item, index) {
      if (index == 0) {
        if (item.label == "全部文档") {
          this.getDocumentList("/");
        }
        return;
      }
      this.bread = this.bread.slice(0, index + 1);
      let paramPath = "/";
      for (let i in this.bread) {
        if (i > 0) paramPath += this.bread[i].label + "/";
      }
      this.getDocumentList(paramPath);
    },
    // 权限弹窗搜索时调用，返回搜索列表
    querySearch(search) {
      if (!search) {
        return this.$set(this.auth, "options", null);
      }
      let result = [];
      this.userList.forEach((user) => {
        if (user[2].toLowerCase().includes(search.toLowerCase())) {
          if (user[0] != this.labInfo.id) {
            result.push({
              id: user[0],
              role: user[1],
              label: user[2],
              value: user[2],
              type: "user",
            });
          }
        }
      });
      this.groupList.forEach((group) => {
        if (group.label.toLowerCase().includes(search.toLowerCase())) {
          group.type = "group";
          result.push(group);
        }
      });
      this.$set(this.auth, "options", result);
    },
    // 处理权限，read、all、super
    dealFileAuth(item) {
      // 默认实验室权限
      let auth = item.auth.Inner;
      // 判断是否有课题组权限
      this.labInfo.group.forEach((id) => {
        if (item.auth.Group.none.includes(id)) auth = "none";
        if (item.auth.Group.read.includes(id)) auth = "read";
        if (item.auth.Group.all.includes(id)) auth = "all";
      });
      // 判断是否有用户权限
      if (item.auth.User.none.includes(this.labInfo.id)) auth = "none";
      if (item.auth.User.read.includes(this.labInfo.id)) auth = "read";
      if (item.auth.User.all.includes(this.labInfo.id)) auth = "all";
      // 判断是否管理员权限
      let role = ["OWNER", "ADMIN"];
      if (role.includes(this.labInfo.role)) {
        auth = "supper";
      }
      // 判断是否创建者权限
      if (this.labInfo.id == item.authorUsername) {
        auth = "supper";
      }
      return auth;
    },
    // 根据id返回用户对象
    getUserById(id) {
      for (let user of this.userList) {
        if (user[0] == id) {
          return {
            id: user[0],
            role: user[1],
            name: user[2],
          };
        }
      }
    },
    // 根据id返回课题组对象
    getGroupById(id) {
      for (let group of this.groupList) {
        if (group.id == id) {
          return group;
        }
      }
    },
    // 根据文件名返回图标名
    getIconByName(name) {
      let array = ("" + name).split(".");
      if (array.length < 2) return "#icon-file_unknown";

      let type = array[array.length - 1];
      type = type ? type.toLowerCase() : "unknown";

      let image = ["jpg", "png", "jpeg", "gif"];
      let music = ["wav", "aif", "aiff", "au", "mid", "rmi"];
      let music2 = ["mp1", "mp2", "mp3", "ra", "rm", "ram"];
      let video = ["avi", "mov", "qt", "asf", "rm"];
      let video2 = ["navi", "divx", "mpeg", "mpg", "dat"];
      let word = ["doc", "docx"];

      if (type == "txt") return "#icon-file_txt";
      if (type == "css") return "#icon-file_css";
      if (type == "js") return "#icon-file_code";
      if (type == "pdf") return "#icon-file_pdf";
      if (type == "open") return "#icon-file_open";
      if (type == "zip") return "#icon-file_zip";
      if (type == "oa") return "#icon-file_oa";
      if (type == "rtf") return "#icon-file_rft";
      if (type == "dmg") return "#icon-file_dmg";
      if (type == "chm") return "#icon-file_chm";
      if (type == "csv") return "#icon-file_csv";
      if (type == "exe") return "#icon-file_exe";
      if (type == "ipa") return "#icon-file_Installation_pa";
      if (type == "ppt") return "#icon-file_ppt_office";
      if (type == "excel") return "#icon-file_excel_office";

      if (word.includes(type)) return "#icon-file_word_office";
      if (image.includes(type)) return "#icon-file_pic";
      if (music.includes(type)) return "#icon-file_music";
      if (music2.includes(type)) return "#icon-file_music";
      if (video.includes(type)) return "#icon-file_video";
      if (video2.includes(type)) return "#icon-file_video";

      return "#icon-file_unknown";
    },
  },
};
</script>

<style scoped>

.describle {
  width:100%;
  height: 300px;
  color: var(--text3);
  /* float: left; */
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
}
.document {
  width: 100%;
  min-height: 100%;
  background: white;
  position: relative;
}
.document .left {
  width: 210px;
  height: calc(100vh - 50px);
  background: #fafbfc;
  border-right: 1px #f0f2f5 solid;
  position: fixed;
  left: 250px;
  top: 50px;
}
.document .left .head {
  font-size: 18px;
  user-select: none;
  line-height: 60px;
  color: #1e2127;
  padding: 0 40px;
  box-sizing: border-box;
}
.document .left .tree {
  padding: 10px 12px;
  box-sizing: border-box;
}
.document .right {
  width: calc(100% - 210px);
  min-height: calc(100vh - 50px);
  padding: 0 20px 30px 20px;
  margin-left: 210px;
  box-sizing: border-box;
}
.document .right .head {
  height: 60px;
  line-height: 60px;
}
.document .right .bread {
  line-height: 60px;
  padding: 0 10px;
  box-sizing: border-box;
}
.document .right .table .file {
  min-height: 50px;
  padding: 8px 10px;
  border-bottom: 1px var(--border3) solid;
  position: relative;
}
.document .right .table .file:hover {
  background: #f9f9f9;
}
.document .right .table .file .icon {
  width: 42px;
  font-size: 40px;
  display: inline-block;
  opacity: 0.9;
  color: var(--info);
  vertical-align: top;
  margin-top: 7px;
}
.document .right .table .file > .content {
  width: calc(100% - 42px);
  padding-left: 5px;
  box-sizing: border-box;
  display: inline-block;
}
.document .right .table .file > .content > p {
  margin: 5px 0 0;
  font-size: 12px;
}
.document .right .table .file > .content > p:first-child {
  color: var(--primary);
  cursor: pointer;
  font-size: 14px;
}

@media (max-width: 1280px) {
  .document .left {
    left: 64px;
  }
}
</style>
<style>
.document .left .tree .el-tree {
  background: transparent;
  user-select: none;
}
.document .left .tree .el-tree span {
  font-size: 14px;
  line-height: 24px;
}
.document .left .tree .el-tree .icon {
  margin-right: 2px;
  opacity: 0.9;
  font-size: 20px;
  vertical-align: top;
}
.document .left .tree .el-tree-node__content {
  min-height: 40px;
  background: transparent;
  user-select: none;
}
.document .left .tree .el-tree-node__content:hover {
  min-height: 40px;
  background: #f3f5f8;
}
.document .left .tree.now .is-current > .el-tree-node__content {
  min-height: 40px;
  background: #f0f2f5;
}
.document .right .table .el-table__row > td {
  padding: 8px 0;
}
.document .right .table .el-table__row > td .icon {
  margin-right: 5px;
  opacity: 0.9;
  font-size: 15px;
}
.document .right .table .el-table__row > td .file-name {
  cursor: pointer;
}
.document .right .table .el-table__row > td .el-link::after {
  display: none;
}
.document .right .table .el-table__row > td .file-name:hover {
  color: var(--primary) !important;
}
.document .right .table .el-table__row > td .el-dropdown-link i {
  color: var(--text3);
  margin-right: 10px;
}
.document .right .table .file > .el-dropdown {
  width: 25px;
  position: absolute;
  right: 10px;
  top: 20px;
}
.document .right .bread .el-breadcrumb__inner {
  cursor: pointer;
  user-select: none;
}
.document .upload .el-dialog__body {
  padding-top: 10px;
}
.document .upload .el-upload-dragger {
  height: 125px;
  border-color: #d9d9d9 !important;
}
.document .upload .el-upload-dragger .el-upload__text {
  color: var(--text3);
  user-select: none;
  font-size: 13px;
}
.document .upload .el-upload-dragger .el-icon-upload {
  margin-top: 20px;
  font-size: 60px;
}
.document .upload .el-upload__tip {
  color: var(--text3);
}
.document .upload .el-upload-list__item {
  outline: none;
  line-height: 30px;
}
.document .upload .el-upload-list__item .el-icon-close {
  top: 8px;
}
.document .upload .el-upload-list__item .el-icon-loading {
  position: absolute;
  top: 8px;
  right: 5px;
}
.document .upload .el-upload-list__item.is-success:hover {
  background: white;
}
.document .create .el-dialog__body {
  padding-top: 16px;
}
.document .auth .el-dialog__body {
  padding-top: 16px;
  min-height: 300px;
}
.document .auth .el-dialog__body .auth-list .el-form-item__content {
  width: calc(100% - 20px);
  margin-left: 10px;
}
.document .auth .el-dialog__body .el-row {
  border-top: 1px var(--border2) solid;
  border-bottom: 1px var(--border2) solid;
  padding: 2px 0;
}
.document .auth .el-dialog__body .el-row.new {
  background: #fdf6ec;
}
.document .auth .el-dialog__body .el-row + .el-row {
  border-top: none;
  padding: 2px 0;
}
.document .auth .el-dialog__body .el-row i {
  margin-right: 2px;
  line-height: 40px;
  vertical-align: top;
}
.document .auth .el-dialog__body .el-row .el-radio__inner:hover {
  border-color: var(--border1);
}
.document .auth .el-dialog__body .el-row .el-radio__label {
  color: #808080 !important;
}
.document .auth .el-dialog__body .el-row .el-icon-delete {
  margin-left: -15px;
  margin-top: -1px;
  color: var(--info);
  font-size: 16px;
  cursor: pointer;
}
.document .move .el-dialog__body {
  padding-top: 16px;
}
.document .move .el-dialog__body .el-tree-node__content {
  user-select: none;
}

.el-message-box__wrapper {
  outline: none;
}
.el-dropdown-menu.el-popper {
  user-select: none;
}
</style>