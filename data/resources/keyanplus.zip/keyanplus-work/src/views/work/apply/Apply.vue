<template>
  <div class="apply">
    <el-container>
      <el-header>
        <span>申请与审批</span>
      </el-header>
      <el-main>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="使用申请" name="second">
            <div class="content">
              <div class="upper">
                <el-button
                  type="primary"
                  style="float: left"
                  @click="dialog.addGood = true"
                  >新建使用申请</el-button
                >
                <span class="describle"
                  >功能场景：当成员需要使用安全隐患的危险品和贵重试剂耗材时，管理员可以设置申请审批流程</span
                >
                <el-dialog
                  title="新建物品申请"
                  :visible.sync="dialog.addGood"
                  width="640px"
                  style="text-align: left"
                >
                  <el-form ref="form" :model="addGoodForm" label-width="110px">
                    <el-form-item label="物品类别：">
                      <el-row>
                        <el-col :span="8">
                          <el-select v-model="addGoodForm.type">
                            <el-option label="仪器" value="仪器"></el-option>
                            <el-option
                              label="试剂与耗材"
                              value="试剂与耗材"
                            ></el-option>
                          </el-select>
                        </el-col>
                        <el-col
                          :span="4"
                          style="box-sizing: border-box; padding-left: 14px"
                          >名称</el-col
                        >
                        <el-col :span="8">
                          <el-select
                            v-model="addGoodForm.name"
                            placeholder="请选择"
                          >
                            <el-option
                              v-for="item in options.productList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            >
                            </el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item v-if="addGoodForm.isShow" label="物品编号：">
                      <el-row>
                        <el-col :span="8">
                          <el-select v-model="addGoodForm.goodName">
                            <el-option
                              v-for="(item, index) in options.detailList"
                              :key="index"
                              :label="item.name"
                              :value="item.id"
                            ></el-option>
                          </el-select>
                        </el-col>
                        <el-col
                          :span="4"
                          style="box-sizing: border-box; padding-left: 14px"
                          >品牌</el-col
                        >
                        <el-col :span="8"
                          ><el-input
                            v-model="addGoodForm.brand"
                            readonly
                          ></el-input
                        ></el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item v-if="addGoodForm.isShow" label="存放位置：">
                      <el-row>
                        <el-col :span="8">
                          <el-input
                            v-model="addGoodForm.place"
                            readonly
                          ></el-input>
                        </el-col>
                        <el-col
                          :span="4"
                          style="box-sizing: border-box; padding-left: 14px"
                          >供应商</el-col
                        >
                        <el-col :span="8"
                          ><el-input
                            v-model="addGoodForm.supplierName"
                            readonly
                          ></el-input
                        ></el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="审批人：">
                      <el-row>
                        <el-col :span="8">
                          <el-select
                            v-model="addGoodForm.managerIds"
                            multiple
                            placeholder="请选择"
                          >
                            <el-option
                              v-for="item in options.memberList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            >
                            </el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="申请标题：">
                      <el-row>
                        <el-col :span="21">
                          <el-input v-model="addGoodForm.title"></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="申请内容：">
                      <el-row>
                        <el-col :span="21">
                          <el-input
                            v-model="addGoodForm.content"
                            type="textarea"
                            :rows="8"
                            placeholder="请输入物品使用情况，例如：数量、用途"
                          ></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="dialog.addGood = false">取 消</el-button>
                    <el-button type="primary" @click="addGood()"
                      >确 定</el-button
                    >
                  </span>
                </el-dialog>
              </div>
              <div class="middle">
                <div class="middle_head">
                  <el-table
                    ref="multipleTable"
                    :data="tableData.goods"
                    tooltip-effect="dark"
                    style="width: 100%"
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column type="selection" width="55">
                    </el-table-column>
                    <el-table-column
                      prop="_createTime"
                      label="申请时间"
                      width="150"
                    ></el-table-column>
                    <el-table-column
                      prop="name"
                      label="物品名称"
                      width="200"
                    ></el-table-column>
                    <el-table-column
                      prop="state"
                      label="事务状态"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="sponsorName"
                      label="发起人"
                      width="120"
                    ></el-table-column>
                    <!-- <el-table-column
                      prop="managerNames"
                      label="审批人"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="content"
                      label="理由"
                      show-overflow-tooltip
                    >
                    </el-table-column> -->
                    <el-table-column align="right">
                      <template slot="header" slot-scope="{}">
                        <el-select v-model="tableData.goodsType" size="mini">
                          <el-option
                            label="仪器列表"
                            value="仪器列表"
                          ></el-option>
                          <el-option
                            label="试剂与耗材列表"
                            value="试剂与耗材列表"
                          ></el-option
                        ></el-select>
                      </template>
                      <template slot-scope="scope">
                        <el-button
                          @click.native.prevent="openGood(scope.row)"
                          type="text"
                          size="small"
                        >
                          详情
                        </el-button>
                        <el-button
                          @click.native.prevent="openApprovalGood(scope.row)"
                          type="text"
                          size="small"
                          :disabled="
                            scope.row.state === '审批成功' ||
                            scope.row.state === '审批不通过' ||
                            myList.role == 'MEMBER'
                          "
                        >
                          审批
                        </el-button>
                        <el-button
                          @click.native.prevent="
                            deleteGood(scope.$index, tableData.goods, scope.row)
                          "
                          type="text"
                          size="small"
                          style="color: red"
                          :disabled="
                            scope.row.state === '审批成功' ||
                            scope.row.state === '审批不通过' ||
                            myList.role == 'MEMBER'
                          "
                        >
                          撤销
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                  <el-dialog
                    title="查看详情"
                    :visible.sync="dialog.openGood"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form
                      ref="form"
                      :model="openGoodForm"
                      label-width="90px"
                    >
                      <el-form-item label="*标题：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openGoodForm.title"
                              placeholder="请输入标题"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*申请物品：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openGoodForm.name"
                              placeholder="请输入物品"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*时间：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="openGoodForm._createTime"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>
                      <el-form-item label="*发起人：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="openGoodForm.sponsorName"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>

                      <el-form-item label="*申请内容">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="openGoodForm.content"
                              :rows="8"
                              resize="none"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button type="primary" @click="dialog.openGood = false"
                        >关 闭</el-button
                      >
                    </span>
                  </el-dialog>
                  <el-dialog
                    title="审批申请"
                    :visible.sync="dialog.approvalGood"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form
                      ref="form"
                      :model="approvalGoodForm"
                      label-width="90px"
                    >
                      <el-form-item label="*标题：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="approvalGoodForm.title"
                              placeholder="请输入标题"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*申请物品：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="approvalGoodForm.name"
                              placeholder="请输入物品"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*时间：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="approvalGoodForm._createTime"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>
                      <el-form-item label="*发起人：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="approvalGoodForm.sponsorName"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>

                      <el-form-item label="*申请内容">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="approvalGoodForm.content"
                              :rows="8"
                              resize="none"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>

                      <el-form-item label="*事务批示：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="approvalGoodForm.instruction"
                              :rows="4"
                              resize="none"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*审批结果：">
                        <el-select v-model="approvalGoodForm.applicationState">
                          <el-option label="同意" value="success"></el-option>
                          <el-option label="拒绝" value="fail"></el-option>
                        </el-select>
                      </el-form-item>
                    </el-form>

                    <span slot="footer" class="dialog-footer">
                      <el-button
                        type="primary"
                        @click="dialog.approvalGood = false"
                        >取 消</el-button
                      ><el-button type="primary" @click="approvalGood()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
                <div class="middle_foot">
                  <el-pagination
                    @size-change="handleSizeChange1"
                    @current-change="handleCurrentChange1"
                    :current-page="index"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalElements"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="事务申请" name="third">
            <div class="content">
              <div class="upper">
                <el-button
                  type="primary"
                  style="float: left"
                  @click="dialog.addBusiness = true"
                  >新建事务申请</el-button
                >
                <span class="describle"
                  >功能场景：当成员因事假/病假/其他原因时，需要在此申请请假，管理员可以再次进行审批</span
                >
                <el-dialog
                  title="新建事务申请"
                  :visible.sync="dialog.addBusiness"
                  width="640px"
                  style="text-align: left"
                >
                  <el-form
                    ref="form"
                    :model="addBusinessForm"
                    label-width="110px"
                  >
                    <el-form-item label="*事务标题：">
                      <el-row>
                        <el-col :span="8">
                          <el-input
                            v-model="addBusinessForm.title"
                            placeholder="请输入标题"
                          ></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="*事务类型：">
                      <el-radio v-model="addBusinessForm.type" label="事假"
                        >事假</el-radio
                      >
                      <el-radio v-model="addBusinessForm.type" label="病假"
                        >病假</el-radio
                      >
                      <el-radio v-model="addBusinessForm.type" label="其他"
                        >其他</el-radio
                      >
                    </el-form-item>
                    <el-form-item label="*发起人：">
                      <el-row>
                        <el-col>
                          <el-select
                            v-model="addBusinessForm.sponsor"
                            placeholder="请选择"
                          >
                            <el-option
                              v-for="item in options.memberList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            >
                            </el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="*审批人：">
                      <el-row>
                        <el-col>
                          <el-select
                            v-model="addBusinessForm.manager"
                            multiple
                            placeholder="请选择"
                          >
                            <el-option
                              v-for="item in options.memberList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            >
                            </el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="附件：">
                      <el-upload
                        class="upload-demo"
                        ref="upload"
                        :on-change="fileChange"
                        :http-request="uploadFile"
                        :auto-upload="false"
                        action
                      >
                        <el-button slot="trigger" size="small" type="primary"
                          >选取文件( &lt; 50M )</el-button
                        >
                        <div slot="tip" class="el-upload__tip">
                          只能上传50M以内的文件
                        </div>
                      </el-upload>
                    </el-form-item>
                    <el-form-item label="*申请内容">
                      <el-row>
                        <el-col :span="20">
                          <el-input
                            type="textarea"
                            placeholder="请输入申请理由/申请内容"
                            v-model="addBusinessForm.content"
                            :rows="8"
                            resize="none"
                          ></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="dialog.addBusiness = false"
                      >取 消</el-button
                    >
                    <el-button type="primary" @click="addBusiness()"
                      >确 定</el-button
                    >
                  </span>
                </el-dialog>
              </div>
              <div class="middle">
                <div class="middle_head">
                  <el-table
                    ref="multipleTable"
                    :data="tableData.business"
                    tooltip-effect="dark"
                    style="width: 100%"
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column type="selection" width="55">
                    </el-table-column>
                    <el-table-column
                      prop="_createTime"
                      label="创建时间"
                      width="160"
                    ></el-table-column>
                    <el-table-column
                      prop="title"
                      label="事务标题"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="type"
                      label="事务类型"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="state"
                      label="事务状态"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="sponsorName"
                      label="发起人"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="managerNames"
                      label="审批人"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="content"
                      label="理由"
                      show-overflow-tooltip
                    >
                    </el-table-column>
                    <el-table-column fixed="right" label="操作" width="120">
                      <template slot="header" slot-scope="{}">
                        <el-select v-model="tableData.businessType" size="mini">
                          <el-option label="事假" value="事假"></el-option>
                          <el-option label="病假" value="病假"></el-option>
                          <el-option label="其他" value="其他"></el-option>
                        </el-select>
                      </template>
                      <template slot-scope="scope">
                        <el-button
                          @click.native.prevent="openBusiness(scope.row)"
                          type="text"
                          size="small"
                        >
                          详情
                        </el-button>
                        <el-button
                          @click.native.prevent="
                            openApprovalBusiness(scope.row)
                          "
                          type="text"
                          size="small"
                          :disabled="
                            scope.row.state === '审批通过' ||
                            scope.row.state === '审批不通过' ||
                            myList.role == 'MEMBER'
                          "
                        >
                          审批
                        </el-button>
                        <el-button
                          @click.native.prevent="
                            deleteBusiness(
                              scope.$index,
                              tableData.business,
                              scope.row
                            )
                          "
                          type="text"
                          size="small"
                          style="color: red"
                          :disabled="
                            scope.row.state === '审批通过' ||
                            scope.row.state === '审批不通过' ||
                            myList.role == 'MEMBER'
                          "
                        >
                          撤销
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                  <el-dialog
                    title="查看详情"
                    :visible.sync="dialog.openBusiness"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form
                      ref="form"
                      :model="openBusinessForm"
                      label-width="90px"
                    >
                      <el-form-item label="*事务标题：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openBusinessForm.title"
                              placeholder="请输入标题"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*事务类型：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="openBusinessForm.type"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>
                      <el-form-item label="*事务状态：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="openBusinessForm.state"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>
                      <el-form-item label="*发起人：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              v-model="openBusinessForm.sponsorName"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*审批人：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              v-model="openBusinessForm.managerNames"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*申请内容">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="openBusinessForm.content"
                              :rows="8"
                              resize="none"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button
                        type="primary"
                        @click="dialog.openBusiness = false"
                        >关 闭</el-button
                      >
                    </span>
                  </el-dialog>
                  <el-dialog
                    title="审批事务"
                    :visible.sync="dialog.approvalBusiness"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form
                      ref="form"
                      :model="approvalBusinessForm"
                      label-width="90px"
                    >
                      <el-form-item label="*事务标题：">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="approvalBusinessForm.title"
                              placeholder="请输入标题"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*事务类型：">
                        <el-row
                          ><el-col :span="20">
                            <el-input
                              v-model="approvalBusinessForm.type"
                              readonly
                            ></el-input></el-col
                        ></el-row>
                      </el-form-item>
                      <el-form-item label="*发起人：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              v-model="approvalBusinessForm.sponsor"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*审批人：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              v-model="approvalBusinessForm.manager"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*申请内容：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="approvalBusinessForm.content"
                              :rows="4"
                              resize="none"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*事务批示：">
                        <el-row>
                          <el-col :span="20">
                            <el-input
                              type="textarea"
                              placeholder="请输入申请理由/申请内容"
                              v-model="approvalBusinessForm.instruction"
                              :rows="4"
                              resize="none"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*审批结果：">
                        <el-select
                          v-model="approvalBusinessForm.applicationState"
                        >
                          <el-option label="同意" value="success"></el-option>
                          <el-option label="拒绝" value="fail"></el-option>
                        </el-select>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialog.approvalBusiness = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="approvalBusiness()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
                <div class="middle_foot">
                  <el-pagination
                    @size-change="handleSizeChange2"
                    @current-change="handleCurrentChange2"
                    :current-page="index"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalElements"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="历史申请" name="first">
            <div class="displaySection">
              <div class="displaySection_head">
                <el-table
                  ref="multipleTable"
                  :data="tableData.all"
                  tooltip-effect="dark"
                  style="width: 100%"
                  @selection-change="handleSelectionChange"
                >
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column
                    prop="_createTime"
                    label="创建时间"
                    width="160"
                  ></el-table-column>
                  <el-table-column
                    prop="title"
                    label="事务标题"
                    width="120"
                  ></el-table-column>
                  <el-table-column
                    prop="type"
                    label="事务类型"
                    width="120"
                  ></el-table-column>
                  <el-table-column
                    prop="state"
                    label="事务状态"
                    width="120"
                  ></el-table-column>
                  <el-table-column
                    prop="sponsorName"
                    label="发起人"
                    width="120"
                  ></el-table-column>
                  <el-table-column
                    prop="managerNames"
                    label="审批人"
                    width="120"
                  ></el-table-column>
                  <el-table-column
                    prop="content"
                    label="理由"
                    show-overflow-tooltip
                  >
                  </el-table-column>
                </el-table>
              </div>
              <div class="displaySection_foot">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="index"
                  :page-sizes="[10, 20, 30]"
                  :page-size="pageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="totalElements"
                >
                </el-pagination>
              </div>
            </div>
          </el-tab-pane>
          <!-- <el-tab-pane label="试剂与耗材与耗材申请（未）" name="fourth">
          </el-tab-pane> -->
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>

<script>
const COS = require("cos-js-sdk-v5");
export default {
  name: "Apply",
  data() {
    return {
      labId: "",
      activeName: "second",
      // 多选框数组
      selection: [],
      myList: {},
      // select内容
      options: {
        memberList: [],
        instrumentList: [],
        materialList: [],
        productList: [],
        detailList: [
          {
            label: "test",
            value: 1,
          },
        ],
      },
      // 对话框标识
      dialog: {
        addGood: false,
        openGood: false,
        approvalGood: false,
        addBusiness: false,
        openBusiness: false,
        approvalBusiness: false,
      },
      addGoodForm: {
        name: "",
        type: "仪器",
        title: "",
        content: "",
        managerIds: [],
        selfId: "",
        pid: "",
        goodName: "",
        isShow: false,
        brand: "",
        place: "",
        supplierName: "",
      },
      openGoodForm: {
        name: "",
        type: "仪器",
        title: "",
        content: "",
        managerIds: [],
        managerName: "",
        managerNames: [],
      },
      approvalGoodForm: {
        id: "",
        applicationState: "",
        instruction: "",
        upload: [],
        type: "",
        manager: [],
        sponsor: "",
        urls: [],
        content: "",
        title: "",
      },

      addBusinessForm: {
        upload: [],
        type: "",
        manager: [],
        sponsor: "",
        urls: [],
        content: "",
        title: "",
      },

      openBusinessForm: {
        upload: [],
        type: "",
        manager: [],
        sponsor: "",
        urls: [],
        content: "",
        title: "",
      },
      approvalBusinessForm: {
        id: "",
        applicationState: "",
        instruction: "",
        upload: [],
        type: "",
        manager: [],
        sponsor: "",
        urls: [],
        content: "",
        title: "",
      },
      // 列表数据
      tableData: {
        all: [],
        goodsType: "仪器列表",
        goods: [
          {
            _createTime: "2021-03-11",
            name: "一号物品",
            state: "已审批",
            sponsorName: "程序猿",
          },
        ],
        businessType: "事假",
        business: [
          {
            _createTime: "2021-03-11",
            title: "请假",
            type: "事假",
            state: "审批通过",
            sponsorName: "程序猿",
            managerName: "程序猿",
            content: "临时有事需要请假数日",
          },
        ],
      },
      // 桶对象
      cos: null,

      // 分页
      index: 1,
      pageSize: 10,
      totalPages: 0,
      totalElements: 0,
    };
  },
  created() {
    this.getLabId();
  },
  watch: {
    "addGoodForm.type": {
      handler: function () {
        this.options.productList = [];
        if (this.addGoodForm.type === "仪器") {
          this.options.productList = this.options.instrumentList;
        } else {
          this.options.productList = this.options.materialList;
        }
      },
    },
    "addGoodForm.name": {
      handler: function () {
        this.options.detailList = [];
        this.addGoodForm.isShow = false;
        this.getDetail();
      },
    },
    "addGoodForm.goodName": {
      handler: function () {
        for (let i in this.options.detailList) {
          if (this.addGoodForm.goodName == this.options.detailList[i].id) {
            this.setAddForm(this.options.detailList[i]);
          }
        }
      },
    },
    "tableData.goodsType": {
      handler: function () {
        this.tableData.goods = [];
        this.index = 1;
        this.pageSize = 10;
        this.getGoods();
      },
    },
    "tableData.businessType": {
      handler: function () {
        this.tableData.business = [];
        this.index = 1;
        this.pageSize = 10;
        this.getBusiness();
      },
    },
  },
  components: {},
  mounted() {
    this.initTencentCos();
  },
  methods: {
    handleClick(tab) {
      // console.log(tab);
      if (tab.index === "0") {
        this.index = 1;
        this.pageSize = 10;
        this.getAll();
      } else if (tab.index === "1") {
        this.index = 1;
        this.pageSize = 10;
        this.getGoods();
      } else if (tab.index === "2") {
        this.index = 1;
        this.pageSize = 10;
        this.getBusiness();
      }
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.selection = val;
    },

    handleSizeChange(val) {
      this.pageSize = val;
      this.tableData.all.length = 0;
      // console.log(this.pageSize);
      this.getAll();
    },
    handleCurrentChange(val) {
      this.index = val;
      // console.log(this.index);
      this.tableData.all.length = 0;
      this.getAll();
    },
    handleSizeChange1(val) {
      this.pageSize = val;
      // this.tableData.length = 0;
      // console.log(this.pageSize);
      this.getGoods();
    },
    handleCurrentChange1(val) {
      this.index = val;
      // console.log(this.index);
      // this.tableData.length = 0;
      this.getGoods();
    },
    handleSizeChange2(val) {
      this.pageSize = val;
      // this.tableData.length = 0;
      // console.log(this.pageSize);
      this.getBusiness();
    },
    handleCurrentChange2(val) {
      this.index = val;
      // console.log(this.index);
      // this.tableData.length = 0;
      this.getBusiness();
    },
    // 获取实验室labId
    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;
      this.getMember();
      this.getProduct();
      this.getAll();
      this.getBusiness();
      this.getGoods();
      this.getMyRole();
    },
    getMyRole() {
      this.axios
        .get("/api/v1/lab/self", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.myList = res.data.data;
            // console.log(this.myList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getMember() {
      this.axios
        .get("/api/v1/lab/getMemberNames?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            list.forEach((v) => {
              let i = new Object();
              i.label = v[2];
              i.value = v[0];
              this.options.memberList.push(i);
            });
          }
          // console.log(this.memberList);
        })
        .catch((error) => {
          console.info(error);
        });
    },
    getProduct() {
      this.axios
        .get("/api/v1/lab/goodsNames?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list1 = res.data.data.instrumentList;
            let list2 = res.data.data.materialList;
            if (list1 != null) {
              list1.forEach((v) => {
                let i = new Object();
                i.label = v;
                i.value = v;
                this.options.instrumentList.push(i);
              });
              if (list2 != null) {
                list2.forEach((v) => {
                  let i = new Object();
                  i.label = v;
                  i.value = v;
                  this.options.materialList.push(i);
                });
              } else {
                this.options.materialList = [];
              }
            } else {
              this.options.instrumentList = [];
              if (list2 != null) {
                list2.forEach((v) => {
                  let i = new Object();
                  i.label = v;
                  i.value = v;
                  this.options.materialList.push(i);
                });
              } else {
                this.options.materialList = [];
              }
            }
          }
          this.options.productList = this.options.instrumentList;
          // console.log(this.options.instrumentList);
          // console.log(this.options.materialList);
        })
        .catch((error) => {
          console.info(error);
        });
    },
    getAll() {
      this.tableData.all.length = 0;
      this.axios
        .post("/api/v1/lab/getApplication", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
          type: "",
          managerName: "",
        })
        .then((res) => {
          // console.log("查询所有事务:");
          // console.log(res.data);
          this.tableData.all = [];
          this.totalElements = 0;
          if (res.data.code === 20000) {
            let list = res.data.data;
            this.pageSize = list.size;
            // this.totalElements = list.totalElements;
            this.totalPages = list.totalPages;
            for (let i of list.data) {
              if (i.isCancel != true) {
                // let str = i.createTime;
                let result = this.getLocalTime(i.createTime);
                i._createTime = result;
                this.totalElements++;
                this.tableData.all.push(i);
              }
            }
          }
        })
        .catch((error) => {
          console.info(error);
        });
    },
    getGoods() {
      if (this.tableData.goodsType === "仪器列表") {
        this.axios
          .post("/api/v1/lab/getInstrumentApplication", {
            labId: this.labId,
            index: this.index - 1,
            pageSize: this.pageSize,
            ascProperties: ["fkLabId"],
            descProperties: ["id"],
          })
          .then((res) => {
            // console.log("查询所有仪器申请：");
            // console.log(res.data);

            if (res.data.code === 20000) {
              let list = res.data.data;
              this.tableData.goods.length = 0;
              this.pageSize = list.size;
              this.totalPages = list.totalPages;
              this.totalElements = 0;
              for (let i of list.data) {
                if (i.isCancel != true) {
                  i.state = i.isSuccess ? "审批成功" : "未审批";
                  if (i.isFail) i.state = "审批不通过";
                  let result = this.getLocalTime(i.createTime);
                  i._createTime = result;
                  this.totalElements++;
                  this.tableData.goods.push(i);
                }
              }
              this.getManagerName("仪器申请");
            }
            // console.log(this.tableData.goods);
          })
          .catch((error) => {
            console.info(error);
          });
      } else {
        this.axios
          .post("/api/v1/lab/getMaterialApplication", {
            labId: this.labId,
            index: this.index - 1,
            pageSize: this.pageSize,
            ascProperties: ["fkLabId"],
            descProperties: ["id"],
          })
          .then((res) => {
            // console.log("查询所有试剂与耗材列表：");
            // console.log(res.data);
            if (res.data.code === 20000) {
              let list = res.data.data;

              this.tableData.goods.length = 0;
              this.pageSize = list.size;
              this.totalPages = list.totalPages;
              this.totalElements = 0;
              for (let i of list.data) {
                if (i.isCancel != true) {
                  i.state = i.isSuccess ? "审批成功" : "未审批";
                  if (i.isFail) i.state = "审批不通过";
                  let result = this.getLocalTime(i.createTime);
                  i._createTime = result;
                  this.totalElements++;
                  this.tableData.goods.push(i);
                }
              }

              this.getManagerName("药剂申请");
              // console.log(this.tableData.goods);
            }
          })
          .catch((error) => {
            console.info(error);
          });
      }
    },
    getManagerName(index) {
      this.axios
        .post("/api/v1/lab/getApplication", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
          type: index,
          managerName: "",
        })
        .then((res) => {
          // console.log(res.data.data);
          let list = res.data.data.data;
          // console.log(list);

          list.forEach((v) => {
            for (let key in this.tableData.goods) {
              if (v.id == this.tableData.goods[key].fkApplicationId) {
                this.tableData.goods[key].managerName = v.managerNames;
                this.tableData.goods[key].managerNames = v.managerNames.split(
                  ","
                );
                this.tableData.goods[key].title = v.title;
                this.tableData.goods[key].type = v.type;
                this.tableData.goods[key].content = v.content;
              }
            }
          });
        });
    },
    getDetail() {
      if (this.addGoodForm.type == "仪器") {
        this.axios
          .get(
            "/api/v1/lab/goodsByName?labId=" +
              this.labId +
              "&name=" +
              this.addGoodForm.name +
              "&type=INSTRUMENT"
          )
          .then((res) => {
            // console.log(res.data);
            if (res.data.code == 20000) {
              if (res.data.data[0] != "") {
                this.addGoodForm.isShow = true;
                this.options.detailList = [];
                this.options.detailList = res.data.data;
                this.addGoodForm.selfId = "";
                this.addGoodForm.pid = "";
              }
            } else {
              this.addGoodForm.selfId = "";
              this.addGoodForm.pid = "";
            }
          });
      } else {
        this.axios
          .get(
            "/api/v1/lab/goodsByName?labId=" +
              this.labId +
              "&name=" +
              this.addGoodForm.name +
              "&type=MATERIAL"
          )
          .then((res) => {
            // console.log(res.data);
            if (res.data.code == 20000) {
              if (res.data.data[0] != null) {
                this.addGoodForm.isShow = true;
                this.options.detailList = [];
                this.options.detailList = res.data.data;
                this.addGoodForm.selfId = "";
                this.addGoodForm.pid = "";
              } else {
                this.addGoodForm.isShow = false;
              }
            } else {
              this.addGoodForm.selfId = "";
              this.addGoodForm.pid = "";
            }
          });
      }
    },
    setAddForm(item) {
      this.addGoodForm.selfId = "";
      this.addGoodForm.pid = "";
      this.addGoodForm.brand = item.brand;
      this.addGoodForm.place = item.place;
      this.addGoodForm.supplierName = item.supplierName;

      this.addGoodForm.selfId = item.selfId;
      this.addGoodForm.pid = item.fkPid;
      // console.log(this.addGoodForm.selfId);
      // console.log(this.addGoodForm.pid);
    },
    getBusiness() {
      this.tableData.business.length = 0;
      this.axios
        .post("/api/v1/lab/getApplication", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
          type: this.tableData.businessType,
          managerName: "",
        })
        .then((res) => {
          // console.log("查询所有事务:");
          // console.log(res.data);
          this.tableData.business = [];
          this.totalElements = 0;
          if (res.data.code === 20000) {
            let list = res.data.data;
            this.pageSize = list.size;
            // this.totalElements = list.totalElements;
            this.totalPages = list.totalPages;
            for (let i of list.data) {
              if (i.isCancel != true) {
                // let str = i.createTime;
                let result = this.getLocalTime(i.createTime);
                i._createTime = result;
                this.totalElements++;
                this.tableData.business.push(i);
              }
            }
          }
        })
        .catch((error) => {
          console.info(error);
        });
    },
    addGood() {
      if (
        this.addGoodForm.type == "" ||
        this.addGoodForm.title == "" ||
        this.addGoodForm.content == "" ||
        this.addGoodForm.managerIds[0] == ""
      ) {
        this.Fail("信息不全，请填写完信息");
      } else {
        // console.info({
        //   name: this.addGoodForm.name,
        //   labId: this.labId,
        //   title: this.addGoodForm.title,
        //   content: this.addGoodForm.content,
        //   managerIds: this.addGoodForm.managerIds,
        // });
        if (this.addGoodForm.type === "仪器") {
          if (this.addGoodForm.pid != "") {
            this.axios
              .post("/api/v1/lab/addInstrumentApplication", {
                name: this.addGoodForm.name,
                labId: this.labId,
                title: this.addGoodForm.title,
                content: this.addGoodForm.content,
                managerIds: this.addGoodForm.managerIds,
                selfId: this.addGoodForm.selfId,
                pid: this.addGoodForm.pid,
              })
              .then((res) => {
                // console.log(res.data);
                if (res.data.code === 20000) {
                  this.Success("添加成功");
                  this.dialog.addGood = false;
                  this.index = 1;
                  this.pageSize = 10;
                  this.getGoods();
                  this.tableData.goodsType = "仪器列表";
                } else if (res.data.code === 20021) this.Fail("当前分类不可见");
                else if (res.data.code === 20023) this.Fail("当前分类需预约");
                else if (res.data.code === 20024) this.Fail("当前分类无需申请");
                else if (res.data.code == 40380) {
                  this.Fail("权限不足，无法执行操作");
                } else this.Fail("服务器发生错误，请联系客服");
              });
          } else {
            this.axios
              .post("/api/v1/lab/addInstrumentApplication", {
                name: this.addGoodForm.name,
                labId: this.labId,
                title: this.addGoodForm.title,
                content: this.addGoodForm.content,
                managerIds: this.addGoodForm.managerIds,
              })
              .then((res) => {
                // console.log(res.data);
                if (res.data.code === 20000) {
                  this.Success("添加成功");
                  this.dialog.addGood = false;
                  this.index = 1;
                  this.pageSize = 10;
                  this.getGoods();
                  this.tableData.goodsType = "仪器列表";
                } else if (res.data.code === 20021) this.Fail("当前分类不可见");
                else if (res.data.code === 20023) this.Fail("当前分类需预约");
                else if (res.data.code === 20024) this.Fail("当前分类无需申请");
                else if (res.data.code == 40380) {
                  this.Fail("权限不足，无法执行操作");
                } else this.Fail("服务器发生错误，请联系客服");
              });
          }
        } else {
          if(this.addGoodForm.pid!=''){
            this.axios
            .post("/api/v1/lab/addMaterialApplication", {
              name: this.addGoodForm.name,
              labId: this.labId,
              title: this.addGoodForm.title,
              content: this.addGoodForm.content,
              managerIds: this.addGoodForm.managerIds,
              selfId:this.addGoodForm.selfId,
              pid:this.addGoodForm.pid
            })
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                this.Success("添加成功");
                this.dialog.addGood = false;
                this.index = 1;
                this.pageSize = 10;
                this.getGoods();
                this.tableData.goodsType = "试剂与耗材列表";
              } else if (res.data.code === 20021) this.Fail("当前分类不可见");
              else if (res.data.code === 20023) this.Fail("当前分类需预约");
              else if (res.data.code === 20024) this.Fail("当前分类无需申请");
              else if (res.data.code == 40380) {
                this.Fail("权限不足，无法执行操作");
              } else this.Fail("服务器发生错误，请联系客服");
            });
          }
          else{
            this.axios
            .post("/api/v1/lab/addMaterialApplication", {
              name: this.addGoodForm.name,
              labId: this.labId,
              title: this.addGoodForm.title,
              content: this.addGoodForm.content,
              managerIds: this.addGoodForm.managerIds,
            })
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                this.Success("添加成功");
                this.dialog.addGood = false;
                this.index = 1;
                this.pageSize = 10;
                this.getGoods();
                this.tableData.goodsType = "试剂与耗材列表";
              } else if (res.data.code === 20021) this.Fail("当前分类不可见");
              else if (res.data.code === 20023) this.Fail("当前分类需预约");
              else if (res.data.code === 20024) this.Fail("当前分类无需申请");
              else if (res.data.code == 40380) {
                this.Fail("权限不足，无法执行操作");
              } else this.Fail("服务器发生错误，请联系客服");
            });
          }
        }
      }
    },

    openGood(row) {
      this.openGoodForm = row;
      this.dialog.openGood = true;
      // console.log(this.openBusinessForm);
    },
    openApprovalGood(row) {
      // console.log(row);
      // this.approvalGoodForm.id = row.id;
      this.approvalGoodForm = row;
      this.approvalGoodForm.content = row.content;
      this.approvalGoodForm.managerName = row.managerName;
      this.approvalGoodForm.managerNames = row.managerNames;
      this.approvalGoodForm.sponsor = row.sponsorName;
      this.approvalGoodForm.title = row.title;
      this.approvalGoodForm.type = row.type;
      this.approvalGoodForm.id = row.id;
      this.dialog.approvalGood = true;
    },
    approvalGood() {
      // console.log(this.approvalGoodForm);
      if (
        this.approvalGoodForm.instruction === "" ||
        this.approvalGoodForm.applicationState === ""
      ) {
        this.Fail("请填写全信息");
      } else {
        for (let i in this.approvalGoodForm.managerNames) {
          if (this.approvalGoodForm.managerNames[i] == this.myList.realName) {
            this.axios
              .get(
                "/api/v1/lab/approvalApplication?applicationState=" +
                  this.approvalGoodForm.applicationState +
                  "&applicationId=" +
                  this.approvalGoodForm.fkApplicationId +
                  "&instruction=" +
                  this.approvalGoodForm.instruction
              )
              .then((res) => {
                // console.log(res.data);
                if (res.data.code === 20000) {
                  this.dialog.approvalGood = false;
                  this.Success("审批成功");
                  this.index = 1;
                  this.pageSize = 10;
                  this.getGoods();
                  this.approvalGoodForm = {};
                } else if (res.data.code == 40380) {
                  this.Fail("权限不足，无法执行操作");
                } else this.Fail("服务器发生错误，请联系客服");
              })
              .catch((error) => {
                console.info(error);
              });
          }
        }
      }
    },

    deleteGood(index, rows, row) {
      this.$confirm("此操作将永久撤销该申请, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // console.log(row.id);
          this.axios
            .get(
              "/api/v1/lab/application/cancel?labId=" +
                this.labId +
                "&applicationId=" +
                row.fkApplicationId
            )
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                this.Success("删除成功");
                this.totalElements--;
                rows.splice(index, 1);
                // this.addBusinessForm = row;
              } else if (res.data.code == 40380) {
                this.Fail("权限不足，无法执行操作");
              } else this.Fail("服务器发生错误，请联系客服");
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    // 初始化桶
    initTencentCos() {
      // 获取临时密钥
      let getAuthorization = (options, callback) => {
        let path = "/api/v1/utils/STS/labs/" + this.labInfo.fkLabId;
        this.axios.get(path).then(({ data }) => {
          let credentials = data && data.credentials;
          if (!data || !credentials) {
            console.error("获取临时密钥失败");
            return;
          }
          callback({
            TmpSecretId: credentials.tmpSecretId,
            TmpSecretKey: credentials.tmpSecretKey,
            XCosSecurityToken: credentials.sessionToken,
            StartTime: data.startTime,
            ExpiredTime: data.expiredTime,
          });
        });
      };

      // 根据临时密钥生成cos对象
      this.cos = new COS({
        getAuthorization: getAuthorization,
      });
    },

    // 选择文件
    fileChange(file, fileList) {
      if (file.size / 1024 / 1024 > 50) {
        this.$message.error("文件大小超出50M");
        fileList.pop();
      }
      this.addBusinessForm.upload = fileList;
    },

    // 上传文件
    uploadFile(file) {
      // console.info(file.file)
      this.cos.sliceUploadFile(
        {
          Bucket: "lab-files-1300972980", // 必须
          Region: "ap-shanghai", // 存储桶所在地域，必须
          Key: this.labId + "/事务文档/" + file.file.name, // 必须
          Body: file.file, // 上传文件对象
          // onProgress: progressData => {
          //   console.log(JSON.stringify(progressData));
          // }
        },
        (err, data) => {
          if (err !== null) {
            this.$message.error("文件上传错误");
            // console.log(err || data);
          } else {
            this.addBusinessForm.urls = data.Location;
          }
        }
      );
    },
    addBusiness() {
      // console.log(this.addBusinessForm);
      if (
        this.addBusinessForm.type === "" ||
        this.addBusinessForm.manager[0] === "" ||
        this.addBusinessForm.sponsor === "" ||
        this.addBusinessForm.title === "" ||
        this.addBusinessForm.content === ""
      ) {
        this.Fail("请填写完必选信息");
      } else {
        this.axios
          .post("/api/v1/lab/application", {
            type: this.addBusinessForm.type,
            fkManagerIds: this.addBusinessForm.manager,
            sponsorId: this.addBusinessForm.sponsor,
            fkLabId: this.labId,
            title: this.addBusinessForm.title,
            content: this.addBusinessForm.content,
            urls: this.addBusinessForm.urls,
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.dialog.addBusiness = false;
              this.index = 1;
              this.pageSize = 10;
              this.getBusiness();
              this.addBusinessForm = {};
              this.Success("新建事务申请成功");
            } else if (res.data.code === 40300) {
              this.Fail("只能选取管理员或者实验室拥有者为审批人");
            } else if (res.data.code == 40380) {
              this.Fail("权限不足，无法执行操作");
            } else this.Fail("服务器发生错误，请联系客服");
          })
          .catch((error) => {
            console.info(error);
          });
      }
    },
    openBusiness(row) {
      this.openBusinessForm = row;
      this.dialog.openBusiness = true;
      // console.log(this.openBusinessForm);
    },
    openApprovalBusiness(row) {
      // console.log(row);
      this.approvalBusinessForm.id = row.id;
      this.approvalBusinessForm.content = row.content;
      this.approvalBusinessForm.manager = row.managerNames;
      this.approvalBusinessForm.sponsor = row.sponsorName;
      this.approvalBusinessForm.title = row.title;
      this.approvalBusinessForm.type = row.type;
      this.approvalBusinessForm.id = row.id;
      this.dialog.approvalBusiness = true;
    },
    approvalBusiness() {
      // console.log(this.approvalBusinessForm);
      if (
        this.approvalBusinessForm.instruction === "" ||
        this.approvalBusinessForm.applicationState === ""
      ) {
        this.Fail("请填写全信息");
      } else {
        this.axios
          .get(
            "/api/v1/lab/approvalApplication?applicationState=" +
              this.approvalBusinessForm.applicationState +
              "&applicationId=" +
              this.approvalBusinessForm.id +
              "&instruction=" +
              this.approvalBusinessForm.instruction
          )
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.dialog.approvalBusiness = false;
              this.Success("审批成功");
              this.index = 1;
              this.pageSize = 10;
              this.getBusiness();
              this.approvalBusinessForm = {};
            } else if (res.data.code == 40380) {
              this.Fail("权限不足，无法执行操作");
            } else this.Fail("服务器发生错误，请联系客服");
          })
          .catch((error) => {
            console.info(error);
          });
      }
    },
    deleteBusiness(index, rows, row) {
      this.$confirm("此操作将永久撤销该事务, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // console.log(row.id);
          this.axios
            .get(
              "/api/v1/lab/application/cancel?labId=" +
                this.labId +
                "&applicationId=" +
                row.id
            )
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                this.Success("删除成功");
                this.totalElements--;
                rows.splice(index, 1);
                // this.addBusinessForm = row;
              } else if (res.data.code == 40380) {
                this.Fail("权限不足，无法执行操作");
              } else this.Fail("服务器发生错误，请联系客服");
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    add0(m) {
      return m < 10 ? "0" + m : m;
    },
    getLocalTime(nS) {
      //shijianchuo是整数，否则要parseInt转换
      let time = new Date(nS);
      let y = time.getFullYear();
      let m = time.getMonth() + 1;
      let d = time.getDate();
      let h = time.getHours();
      let mm = time.getMinutes();
      let s = time.getSeconds();
      return (
        y +
        "-" +
        this.add0(m) +
        "-" +
        this.add0(d) +
        " " +
        this.add0(h) +
        ":" +
        this.add0(mm) +
        ":" +
        this.add0(s)
      );
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.apply {
  width: 100%;
  height: 100%;
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  box-shadow: var(--shadow2);
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}

.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* background-color: #E9EEF3; */
  color: #333;
  text-align: right;
}

.displaySection {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;

  padding: 20px;
  box-sizing: border-box;
  background-color: white;
  box-shadow: var(--shadow2);
  border-radius: 4px;
}

.displaySection_head {
  width: 100%;
  height: calc(700px - 105px);
  background-color: white;
  overflow-x: hidden;
}
.displaySection_head ::-webkit-scrollbar {
  display: none;
}
.displaySection_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}

.content {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 53px;
  /* background-color: red; */
}
.upper > * {
  box-shadow: var(--shadow2);
}
.upper .el-input-group__append .el-button {
  transform: translateY(1px);
  background-color: var(--primary);
  color: white;
  border-radius: 0 2px 2px 0;
}
.describle {
  color: var(--text3);
  float: left;
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.middle {
  width: 100%;
  min-height: calc(700px - 66px);
  margin-top: 13px;
  padding: 20px;
  background-color: white;
  border-radius: 4px;

  box-shadow: var(--shadow2);
  box-sizing: border-box;
}
.middle_head {
  width: 100%;
  height: calc(700px - 145px);
  background-color: white;
  overflow-x: hidden;
}
.middle_head ::-webkit-scrollbar {
  display: none;
}
.middle_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}

/* 适配 */
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
  .displaySection {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;

    padding: 20px;
    box-sizing: border-box;
    background-color: white;
    box-shadow: var(--shadow2);
    border-radius: 4px;
  }
}
@media screen and (max-width: 500px) {
  .content {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
  .displaySection {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;

    padding: 20px;
    box-sizing: border-box;
    background-color: white;
    box-shadow: var(--shadow2);
    border-radius: 4px;
  }
}
</style>
<style>
.el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
}
</style>