<template>
  <div class="center">
    <el-container>
      <el-header>
        <span>控制中心</span>
      </el-header>
      <el-main>
        <div class="content">
          <div class="upper">
            <div class="upper_left">
              <div class="headImage">
                <el-avatar :size="110" :src="avatarUrl"></el-avatar>
              </div>
              <div class="userInfo">
                <h1>
                  {{ userInformation.realName }} {{ labInformation.name }}
                  {{ userInformation._role }}
                </h1>
                <h2>{{ userInformation.record }}</h2>
              </div>
              <div style="line-height: 110px">
                <el-button type="warning" @click="openChangeName()" size="mini"
                  >改 名</el-button
                >
                <el-button type="warning" @click="punch()" size="mini"
                  >签 到</el-button
                >
                <el-button type="warning" @click="openMall()" size="mini"
                  >积分商城</el-button
                >
              </div>
            </div>
            <el-dialog
              title="实验室改名"
              :visible.sync="dialogVisible"
              width="400px"
              style="text-align: left"
            >
              <el-form ref="form" :model="changeForm" label-width="110px">
                <el-form-item label="名称">
                  <el-row>
                    <el-col>
                      <el-input v-model="changeForm.name"></el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-form>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="changeName()"
                  >确 定</el-button
                >
              </span>
            </el-dialog>
            <el-dialog
              title="积分商城"
              :visible.sync="dialogVisible6"
              width="780px"
              style="text-align: left"
            >
              <div>
                <div style="float: left; width: 520px; height: 300px">
                  <p>尊敬的科研用户：</p>
                  <p>积分商城是对科研家用户的使用福利。</p>
                  <p>
                    您的积分只要满足任意商品，请您联系客服进行兑换，一般3个工作日内免费邮寄到您的地址。
                  </p>
                  <p>积分规则介绍：</p>
                  <p>- 您首次注册签到即可以得到100积分</p>
                  <p>- 之后您每天登陆可以领取T+10积分,T指您连续登陆的天数。</p>
                  <p>领取方式：</p>
                  <p>
                    微信扫码联系您的专属客服（任何吐槽或者技术问题都可以联系），欢迎打扰。
                  </p>
                </div>
                <div style="float: left; width: 220px; height: 300px">
                  <img
                    src="image/service.jpeg"
                    alt=""
                    style="width: 200px; height: 300px"
                  />
                </div>
              </div>
              <div class="clearfix">
                <div
                  v-for="(item, index) in mallList"
                  :key="index"
                  class="mall"
                  @click="openService(item)"
                >
                  <img
                    :src="item.img"
                    alt=""
                    style="
                      width: 150px;
                      height: 180px;
                      margin-left: 35px;
                      margin-top: 20px;
                    "
                  />
                  <h1 style="padding-left: 14px">{{ item.brand }}</h1>
                  <div style="height: 100px; width: 220px">
                    <div
                      style="
                        float: left;
                        width: 146px;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        overflow: hidden;
                        padding-left: 14px;
                      "
                    >
                      {{ item.name }}
                    </div>
                    <div style="float: left; width: 60px; font-weight: 600">
                      {{ item.point }}积分
                    </div>
                  </div>
                </div>
              </div>
              <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="dialogVisible6 = false"
                  >关 闭</el-button
                >
              </span>
            </el-dialog>
            <el-dialog
              title="积分商城"
              :visible.sync="dialogVisible7"
              width="400px"
              style="text-align: left"
            >
              <img
                src="image/service.jpeg"
                alt=""
                style="width: 150px; margin-left: 115px"
              />
              <h3 style="text-align: center">请扫码联系客服兑换物品</h3>
            </el-dialog>
            <div class="upper_right">
              <div class="upper_right_item">
                <h1>积分</h1>
                <h2>{{ point }}</h2>
              </div>
              <div class="upper_right_item">
                <h1>项目数</h1>
                <h2>{{ projectCount }}</h2>
              </div>
              <div class="upper_right_item">
                <h1>成员数</h1>
                <h2>{{ memberCount }}</h2>
              </div>
            </div>
          </div>
          <div class="middle">
            <div class="left">
              <div class="left_upper">
                <div class="left_upper_upper">
                  <div style="float: left; width: 30%; margin-left: 28px">
                    <h1>快捷操作</h1>
                  </div>
                  <div style="float: right; margin-right: 28px">
                    <el-button type="text" size="small" @click="edit()"
                      >编辑</el-button
                    >
                  </div>
                  <el-dialog
                    title="设置快捷操作"
                    :visible.sync="dialogVisible1"
                    width="540px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="menuForm" label-width="10px">
                      <p
                        style="
                          font-size: 14px;
                          line-height: 20px;
                          height: 20px;
                          margin-top: -20px;
                        "
                      >
                        固定至控制中心首页
                      </p>
                      <el-form-item>
                        <el-checkbox-group
                          v-model="menuForm.menuList"
                          :min="1"
                          :max="6"
                        >
                          <el-checkbox
                            v-for="(item, index) in menuList"
                            :label="item.name"
                            :key="index"
                            >{{ item.name }}</el-checkbox
                          >
                        </el-checkbox-group>
                      </el-form-item>
                    </el-form>

                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialogVisible1 = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="setOperation()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
                <div class="left_upper_content">
                  <div
                    v-for="item in menuSelectionList"
                    :key="item.name"
                    class="left_upper_content_item"
                    @click="jump(item.path)"
                  >
                    <p>
                      <i
                        style="font-size: 18px"
                        :class="'iconfont ' + item.icon"
                      ></i>
                      {{ item.name }}
                    </p>
                  </div>
                </div>
              </div>
              <div class="left_bottom">
                <div class="left_bottom_upper">
                  <div style="float: left; width: 30%; margin-left: 28px">
                    <h1>实验室项目</h1>
                  </div>
                  <div style="float: right; margin-right: 28px">
                    <el-button
                      type="text"
                      size="small"
                      @click="jump('/project')"
                      v-show="userInformation.role != 'MEMBER'"
                      >全部项目</el-button
                    >
                  </div>
                </div>
                <div class="left_bottom_content">
                  <div
                    v-for="item in projectList"
                    :key="item.id"
                    class="left_bottom_content_item"
                  >
                    <p>
                      {{ item.name }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="right">
              <div class="right_upper">
                <div style="float: left; width: 30%; margin-left: 28px">
                  <h1>公告</h1>
                </div>
                <div style="float: right; margin-right: 28px">
                  <el-button
                    type="text"
                    size="small"
                    @click="dialogVisible3 = true"
                    v-show="userInformation._role != '普通成员'"
                    >发布公告</el-button
                  >
                  <el-button type="text" size="small" @click="open()"
                    >全部公告</el-button
                  >
                  <el-dialog
                    title="全部公告"
                    :visible.sync="dialogVisible2"
                    width="700px"
                    style="text-align: left"
                  >
                    <el-table
                      ref="multipleTable"
                      :data="tableData"
                      tooltip-effect="dark"
                      style="width: 100%"
                    >
                      <el-table-column
                        prop="_createTime"
                        label="发布时间"
                        width="150"
                      ></el-table-column>
                      <el-table-column
                        prop="title"
                        label="标题"
                        width="150"
                      ></el-table-column>
                      <el-table-column
                        prop="sponsorName"
                        label="发布人"
                        width="120"
                      ></el-table-column>
                      <el-table-column align="right">
                        <template slot="header" slot-scope="{}">
                          <el-button
                            type="text"
                            size="small"
                            @click="dialogVisible3 = true"
                            v-show="userInformation._role != '普通成员'"
                            >添加公告</el-button
                          >
                        </template>
                        <template slot-scope="scope">
                          <el-button
                            @click.native.prevent="openNotice(scope.row)"
                            type="text"
                            size="small"
                          >
                            详情
                          </el-button>
                          <el-button
                            @click.native.prevent="openEditNotice(scope.row)"
                            type="text"
                            size="small"
                            v-show="
                              userInformation._role != '普通成员' &&
                              userInformation.realName == scope.row.sponsorName
                            "
                          >
                            编辑
                          </el-button>
                          <el-button
                            @click.native.prevent="
                              deleteNotice(scope.$index, tableData, scope.row)
                            "
                            type="text"
                            size="small"
                            style="color: red"
                            v-show="userInformation._role != '普通成员'"
                          >
                            删除
                          </el-button>
                        </template>
                      </el-table-column>
                    </el-table>

                    <span slot="footer" class="dialog-footer">
                      <!-- <el-button @click="dialogVisible1 = false"
                        >取 消</el-button
                      > -->
                      <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="index"
                        :page-sizes="[10, 20, 30]"
                        :page-size="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalElements"
                      >
                      </el-pagination>
                      <el-button type="primary" @click="dialogVisible2 = false"
                        >关 闭</el-button
                      >
                    </span>
                  </el-dialog>

                  <el-dialog
                    title="添加公告"
                    :visible.sync="dialogVisible3"
                    width="700px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="addForm" label-width="110px">
                      <el-form-item label="*标题">
                        <el-row>
                          <el-col :span="8">
                            <el-input v-model="addForm.title"></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*优先级">
                        <el-row>
                          <el-col :span="4">
                            <el-select v-model="addForm.priority">
                              <el-option label="一般" value="0"></el-option>
                              <el-option label="较高" value="3"></el-option>
                              <el-option label="最高" value="5"></el-option>
                            </el-select>
                            <!-- <el-input v-model="addForm.priority"></el-input> -->
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*内容">
                        <el-row>
                          <el-col :span="16">
                            <el-input
                              v-model="addForm.content"
                              type="textarea"
                              :rows="3"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialogVisible3 = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="addNotice()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>

                  <el-dialog
                    title="公告详情"
                    :visible.sync="dialogVisible4"
                    width="700px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="openForm" label-width="110px">
                      <el-form-item label="*标题">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openForm.title"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*优先级">
                        <el-row>
                          <el-col :span="4">
                            <el-select v-model="openForm.priority" disabled>
                              <el-option label="一般" value="0"></el-option>
                              <el-option label="较高" value="3"></el-option>
                              <el-option label="最高" value="5"></el-option>
                            </el-select>
                            <!-- <el-input v-model="addForm.priority"></el-input> -->
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*发布时间">
                        <el-row>
                          <el-col :span="6">
                            <el-input
                              v-model="openForm._createTime"
                              readonly
                            ></el-input>
                            <!-- <el-input v-model="addForm.priority"></el-input> -->
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*发布者">
                        <el-row>
                          <el-col :span="6">
                            <el-input
                              v-model="openForm.sponsorName"
                              readonly
                            ></el-input>
                            <!-- <el-input v-model="addForm.priority"></el-input> -->
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*内容">
                        <el-row>
                          <el-col :span="16">
                            <el-input
                              v-model="openForm.content"
                              type="textarea"
                              :rows="3"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button type="primary" @click="dialogVisible4 = false"
                        >关 闭</el-button
                      >
                    </span>
                  </el-dialog>

                  <el-dialog
                    title="公告修改"
                    :visible.sync="dialogVisible5"
                    width="700px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="editForm" label-width="110px">
                      <el-form-item label="*标题">
                        <el-row>
                          <el-col :span="8">
                            <el-input v-model="editForm.title"></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*优先级">
                        <el-row>
                          <el-col :span="4">
                            <el-select v-model="editForm.priority">
                              <el-option label="一般" value="0"></el-option>
                              <el-option label="较高" value="3"></el-option>
                              <el-option label="最高" value="5"></el-option>
                            </el-select>
                            <!-- <el-input v-model="addForm.priority"></el-input> -->
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*内容">
                        <el-row>
                          <el-col :span="16">
                            <el-input
                              v-model="editForm.content"
                              type="textarea"
                              :rows="3"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialogVisible5 = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="editNotice()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
              </div>
              <div class="right_content">
                <div
                  v-for="(item, index) in noticeList"
                  :key="item.id"
                  class="right_content_item"
                >
                  <div v-if="item">
                    <div @click="openNotice(item)">
                      <p class="right_content_item_title">
                        {{ item.sponsorName }} 发布公告：{{ item.title }}
                      </p>
                      <!-- <h2>{{item.content}}</h2> -->
                      <p class="right_content_item_content">
                        {{ item.content }}
                      </p>
                    </div>

                    <span
                      style="
                        line-height: 20px;
                        font-size: 12px;
                        box-sizing: border-box;
                      "
                      >{{ item._createTime
                      }}<el-button
                        style="margin-left: 14px"
                        type="primary"
                        size="mini"
                        v-show="
                          userInformation._role != '普通成员' &&
                          userInformation.realName == item.sponsorName
                        "
                        @click="openEditNotice(item)"
                        >编辑</el-button
                      >
                      <el-button
                        @click.native.prevent="
                          deleteNotice(index, noticeList, item)
                        "
                        type="danger"
                        size="mini"
                        v-show="userInformation._role != '普通成员'"
                      >
                        删除
                      </el-button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="service">
          客 服

          <div class="service_more">
            <img
              src="image/service.png"
              alt=""
              style="width: 130px; border-radius: 10px"
            />
            <p>扫码联系您的使用小助手，欢迎吐槽和咨询使用当中的问题！</p>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import mall from "../../../assets/mall";
export default {
  name: "Center",
  data() {
    return {
      labId: "",
      // 打开改名
      dialogVisible: false,
      // 打开快捷操作
      dialogVisible1: false,
      // 打开全部公告
      dialogVisible2: false,
      // 添加公告
      dialogVisible3: false,
      // 打开公告详情
      dialogVisible4: false,
      // 编辑公告详情
      dialogVisible5: false,
      // 积分商城
      dialogVisible6: false,
      // 打开二维码
      dialogVisible7: false,
      mallList: [],
      userInformation: {
        id: "",
        fkAccountName: "",
        realName: "",
        record: "",
        role: "",
        _role: "",
        work: "",
        tags: "",
        tagIds: "",
        createTime: "",
        fkLabId: "",
        isDelete: "",
      },
      labInformation: {
        id: "",
        count: "",
        createTime: "",
        info: "",
        isDelete: "",
        name: "",
      },

      projectCount: "",
      memberCount: "",
      menuList: [
        {
          icon: "icon-creditcard",
          name: "采购管理",
          path: "/buy",
        },
        {
          icon: "icon-experiment",
          path: "/instrument",
          name: "仪器与预约",
        },
        {
          icon: "icon-medicinebox",
          path: "/drugs",
          name: "试剂与耗材",
        },
        {
          icon: "icon-tag",
          path: "/label",
          name: "分类标签与策略设置",
        },
        {
          icon: "icon-slack",
          path: "/storage",
          name: "存储管理与设置",
        },
        // {
        //   icon: "icon-insurance",
        //   path: "/preserve",
        //   name: "保藏中心",
        // },
        {
          icon: "icon-solution",
          path: "/group",
          name: "小组管理",
        },
        {
          icon: "icon-user",
          path: "/members",
          name: "成员管理",
        },
        {
          icon: "icon-edit-square",
          name: "申请与审批",
          path: "/apply",
        },
        {
          icon: "icon-shop",
          name: "供应商管理",
          path: "/supplier",
        },
        {
          icon: "icon-folder",
          name: "项目经费与报销",
          path: "/project",
        },
        {
          icon: "icon-cloud-server",
          name: "文档与知识库",
          path: "/document",
        },
        // {
        //   icon: "icon-setting",
        //   name: "设置",
        //   path: "/setting",
        // },
      ],
      menuList1: [
        {
          icon: "icon-creditcard",
          name: "采购管理",
          path: "/buy",
        },
        {
          icon: "icon-experiment",
          path: "/instrument",
          name: "仪器与预约",
        },
        {
          icon: "icon-medicinebox",
          path: "/drugs",
          name: "试剂与耗材",
        },
        {
          icon: "icon-tag",
          path: "/label",
          name: "分类标签与策略设置",
        },
        {
          icon: "icon-slack",
          path: "/storage",
          name: "存储管理与设置",
        },
        // {
        //   icon: "icon-insurance",
        //   path: "/preserve",
        //   name: "保藏中心",
        // },
        {
          icon: "icon-solution",
          path: "/group",
          name: "小组管理",
        },
        {
          icon: "icon-user",
          path: "/members",
          name: "成员管理",
        },
        {
          icon: "icon-edit-square",
          name: "申请与审批",
          path: "/apply",
        },
        {
          icon: "icon-shop",
          name: "供应商管理",
          path: "/supplier",
        },
        {
          icon: "icon-cloud-server",
          name: "文档与知识库",
          path: "/document",
        },
        // {
        //   icon: "icon-setting",
        //   name: "设置",
        //   path: "/setting",
        // },
      ],
      menuSelectionList: [
        {
          icon: "icon-creditcard",
          name: "采购管理",
          path: "/buy",
        },
        {
          icon: "icon-experiment",
          path: "/instrument",
          name: "仪器与预约",
        },
        {
          icon: "icon-medicinebox",
          path: "/drugs",
          name: "试剂与耗材",
        },
        {
          icon: "icon-tag",
          path: "/label",
          name: "分类标签与策略设置",
        },
        {
          icon: "icon-slack",
          path: "/storage",
          name: "存储管理与设置",
        },
        {
          icon: "icon-insurance",
          path: "/preserve",
          name: "保藏中心",
        },
      ],
      menuForm: {
        menuList: [],
      },
      projectList: [],
      projectOption: [
        {
          id: "1",
          name: "暂无项目",
        },
      ],
      point: 0,
      isCheckIn: false,
      noticeList: [],
      tableData: [],
      addForm: {
        title: "",
        content: "",
        priority: "",
      },
      openForm: {
        id: "",
        title: "",
        content: "",
        priority: "",
        createTime: "",
        _createTime: "",
        sponsorName: "",
      },
      editForm: {
        id: "",
        title: "",
        content: "",
        priority: "",
        createTime: "",
        _createTime: "",
        sponsorName: "",
      },
      changeForm: {
        name: "",
      },
      index: 1,
      pageSize: 10,
      totalElements: 10,
      totalPages: 1,
    };
  },
  created() {
    this.getLabId();
    this.mallList = mall;
    // console.log(this.mallList);
  },
  components: {},
  mounted() {},
  computed: {
    avatarUrl() {
      return this.$store.state.avatarUrl;
    },
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val;
      // console.log(this.pageSize);
      this.getNotice();
    },
    handleCurrentChange(val) {
      this.index = val;
      // console.log(this.index);
      this.getNotice();
    },
    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;

      // this.avatarUrl =
      this.getUserInformation();
      this.getProjectCount();
      this.getLabInformation();
      this.getMemberCount();
      this.getOperation();
      this.index = 1;
      this.pageSize = 10;
      this.getNotice();
      // console.log(this.labId);
    },
    getUserInformation() {
      this.axios
        .get("/api/v1/lab/self?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          let list = res.data.data;
          if (list.role === "OWNER") {
            list._role = "创建者";
          } else if (list.role === "ADMIN") list._role = "管理员";
          else if (list.role === "CATEGORY_ADMIN") list._role = "分类管理员";
          else {
            this.menuList = this.menuList1;
            list._role = "普通成员";
          }
          this.userInformation = list;
          // this.getIsCheck();
          this.getPoint();
          // console.log('userInformation:');
          // console.log(this.userInformation);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getLabInformation() {
      this.axios
        .get("/api/v1/lab", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.labInformation = res.data.data;
            // console.log('labInformation:');
            // console.log(this.labInformation);
          }
        });
    },
    getProjectCount() {
      this.axios
        .get("/api/v1/lab/getAllProject?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            let bufferList = [];
            this.projectList.length = 0;
            this.projectCount = list.length;
            list.forEach((v) => {
              let i = new Object();
              i.name = v.name;
              i.level = v.level;
              i.type = v.type;
              i.id = v.id;
              bufferList.push(i);
            });
            this.projectList = bufferList.splice(0, 6);

            // console.log(this.projectList);
          } else {
            this.projectList = this.projectOption;
            this.projectCount = 0;
          }
          // this.projectList = res.data.data;
          // console.log(this.projectList);
        });
    },
    getMemberCount() {
      this.axios
        .get("api/v1/lab/getMemberNames?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.memberCount = res.data.data.length;
          } else {
            this.memberCount = 0;
          }
          // console.log(this.memberCount);
        });
    },
    getOperation() {
      this.axios.get("/api/v1/lab/getRecentOperation").then((res) => {
        // console.log(res.data);
        if (res.data.code === 20000) {
          // console.log(res.data.data);
          let data = res.data.data;
          let list = data.split("-");
          let choice = this.menuList;
          let bufferList = [];

          this.menuSelectionList = [];
          // console.log(list);
          for (let key in list) {
            for (let i in choice) {
              if (list[key] == choice[i].name) {
                // console.log(choice[i]);
                let m = new Object();
                m.name = choice[i].name;
                m.path = choice[i].path;
                m.icon = choice[i].icon;
                bufferList.push(m);
              }
            }
          }
          // let bufferList = [];

          this.menuSelectionList = bufferList;
          // console.log(this.menuSelectionList);
        }
      });
    },
    getPoint() {
      this.axios
        .get(
          "/api/v1/utils//members/points/" + this.userInformation.fkAccountName
        )
        .then((res) => {
          // console.log(res.data);
          this.point = res.data.points;
        });
    },
    getIsCheck() {
      this.axios
        .get(
          "/api/v1/utils//members/checkin/" + this.userInformation.fkAccountName
        )
        .then((res) => {
          // console.log(res.data);
          this.isCheckIn = res.data.isCheckIn;
          // if
        });
    },

    getNotice() {
      this.tableData = [];
      this.noticeList = [];
      this.axios
        .post("/api/v1/lab/getNotice", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["priority"],
          descProperties: ["id"],
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data.data;
            list.forEach((v) => {
              v._createTime = this.getLocalTime(v.createTime);
            });
            // console.log(list);
            this.tableData = list;
            let bufferList = list;
            this.noticeList = bufferList.slice(0, 3);
            this.totalElements = res.data.totalElements;
            this.totalPages = res.data.totalPages;
            // console.log(this.noticeList);
          }
        });
    },
    punch() {
      this.axios
        .post(
          "/api/v1/utils//members/checkin/" + this.userInformation.fkAccountName
        )
        .then((res) => {
          // console.log(res.data);
          this.Success(res.data.message);
          this.point = res.data.points;
        });
    },
    openMall() {
      this.dialogVisible6 = true;
    },
    edit() {
      this.dialogVisible1 = true;
      // this.menuSelectionList
    },
    // 设置快捷操作
    setOperation() {
      if (this.menuForm.menuList.length == 0) {
        this.Fail("请至少选择一个快捷操作");
      } else {
        this.dialogVisible1 = false;
        let list = this.menuForm.menuList;
        let quickString = "";
        for (let key in list) {
          if (key == 0) {
            quickString = list[0];
          } else {
            quickString = quickString + "-" + list[key];
          }
        }
        // let quickString = list[0]+'-'+list[1]+'-'+list[2]+'-'+list[3]+'-'+list[4]+'-'+list[5];
        // console.log(quickString);
        this.axios
          .get("/api/v1/lab/setRecentOperation?operations=" + quickString)
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.Success("添加成功");
              this.getOperation();
            }
          });
      }
    },
    // 跳转至全部项目
    jump(index) {
      this.$router.push(index);
    },
    open() {
      this.dialogVisible2 = true;
    },
    addNotice() {
      // console.log(this.addForm);
      if (
        this.addForm.title == "" ||
        this.addForm.content == "" ||
        this.addForm.priority == ""
      ) {
        this.Fail("请输入全部信息");
      } else {
        this.axios
          .post("/api/v1/lab/notice", {
            title: this.addForm.title,
            content: this.addForm.content,
            priority: this.addForm.priority,
            labId: this.labId,
            sponsorName: this.userInformation.realName,
          })
          .then((res) => {
            if (res.data.code === 20000) {
              this.dialogVisible3 = false;
              this.Success("添加成功");
              this.index = 1;
              this.pageSize = 10;
              this.getNotice();
            } else if (res.data.code == 40380)
              this.Fail("权限不足，无法执行操作");
            else this.Fail("发布公告失败");
          });
      }
    },
    openNotice(row) {
      // console.log(row);
      this.openForm = row;
      this.dialogVisible4 = true;
    },

    openEditNotice(row) {
      this.editForm = row;
      this.dialogVisible5 = true;
    },
    editNotice() {
      if (
        this.editForm.title == "" ||
        this.editForm.content == "" ||
        this.editForm.priority == ""
      ) {
        this.Fail("请输入全部信息");
      } else {
        this.axios
          .put("/api/v1/lab/notice", {
            id: this.editForm.id,
            fkLabId: this.labId,
            title: this.editForm.title,
            content: this.editForm.content,
            priority: this.editForm.priority,
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.code == 20000) {
              this.dialogVisible5 = false;
              this.Success("修改成功");
              this.index = 1;
              this.pageSize = 10;
              this.getNotice();
            } else if (res.data.code == 40380)
              this.Fail("权限不足，无法执行操作");
            else this.Fail("编辑失败");
          });
      }
    },
    deleteNotice(index, rows, row) {
      // console.log(index, rows, row);
      let list = [];
      list.push(row.id);
      this.$confirm("此操作将永久删除该公告, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // console.log({
          //   fkLabId: this.labId,
          //   researchGroups: result,
          // });
          this.axios
            .delete("/api/v1/lab/notice", {
              data: {
                labId: this.labId,
                ids: list,
              },
            })
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                rows.splice(index, 1);
                this.Success("删除成功");
                this.index = 1;
                this.pageSize = 10;
                this.getNotice();
              } else if (res.data.code === 40380) {
                this.Fail("权限不足，无法执行操作");
              }
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },

    openService(item) {
      if (this.point < item.point) {
        this.Fail("积分不足");
        // this.dialogVisible7 = true;
      } else {
        this.dialogVisible7 = true;
      }
    },
    openChangeName() {
      this.dialogVisible = true;
      this.changeForm.name = this.labInformation.name;
    },
    changeName() {
      this.axios
        .put(
          "/api/v1/lab/fixLabName?id=" +
            this.labId +
            "&name=" +
            this.changeForm.name
        )
        .then((res) => {
          // console.log(res);
          if (res.data.code == 20000) {
            this.dialogVisible = false;
            this.Success("修改成功");
            this.getLabInformation();
          }
        });
    },

    add0(m) {
      return m < 10 ? "0" + m : m;
    },
    getLocalTime(nS) {
      //shijianchuo是整数，否则要parseInt转换
      let time = new Date(nS);
      let y = time.getFullYear();
      let m = time.getMonth() + 1;
      let d = time.getDate();
      return y + "-" + this.add0(m) + "-" + this.add0(d) + " ";
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.center {
  width: 100%;
  height: 100%;
  /* background-color: blue; */
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  box-shadow: var(--shadow2);
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}
.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* background-color: red; */
  color: #333;
  /* text-align: right; */
}
.content {
  min-width: 1000px;
  max-width: 1200px;
  /* height: 80%; */
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 150px;
  border-radius: 4px;
  box-shadow: var(--shadow2);
  background-color: white;
}
.upper_left {
  float: left;
  width: 60%;
  height: 150px;
  padding: 20px;
}

.headImage {
  float: left;
  width: 110px;
  height: 110px;
  border-radius: 50%;
  background-color: cadetblue;
  user-select: none;
}
.userInfo {
  float: left;
  width: 40%;
  height: 110px;
  padding-left: 16px;
  user-select: none;
  /* background-color: cadetblue; */
}
.userInfo h1 {
  font-size: 18px;
  line-height: 20px;
  user-select: none;
}
.userInfo h2 {
  font-size: 16px;
  line-height: 20px;
  user-select: none;
  color: rgb(99, 99, 99);
}
.upper_right {
  float: right;
  width: 30%;
  height: 150px;
  padding: 20px;
  user-select: none;
}
.upper_right_item {
  float: left;
  width: 30%;
  height: 150px;
}

.upper_right_item h1 {
  font-size: 18px;
  line-height: 20px;
  text-align: center;
  user-select: none;
}
.upper_right_item h2 {
  font-size: 16px;
  line-height: 20px;
  text-align: center;
  user-select: none;
  color: rgb(99, 99, 99);
}

.middle {
  width: 100%;
  height: 500px;
  margin-top: 30px;
  border-radius: 4px;
  /* box-shadow: var(--shadow2); */
}
.left {
  float: left;
  width: 60%;
  height: 100%;
}
.left_upper {
  width: 100%;
  height: 40%;
  background-color: white;
  border-radius: 4px;
  box-shadow: var(--shadow2);
}
.left_upper_upper {
  width: 100%;
  height: 60px;
  /* background-color: #333; */
  line-height: 60px;
  /* border-bottom: rgb(194, 194, 194);
  border-bottom-width: 1px;
  border-bottom-style: solid; */
}
.left_upper_upper h1 {
  margin: 0;
  font-size: 16px;
  line-height: 60px;
}
.left_upper_content {
  width: 100%;
  height: 140px;
  /* background-color: #333; */

  box-sizing: border-box;
}
.left_upper_content_item {
  float: left;
  width: 30%;
  height: 40%;
  margin-left: 2.11%;
  margin-top: 0.5%;
  /* padding-left: 28px; */
  user-select: none;
  background-color: #f1f3f8;
  /* border: 1px solid rgb(194, 194, 194); */

  /* background-color: #333; */
}
.left_upper_content_item p {
  margin: 0;
  font-size: 14px;
  line-height: 56px;
  padding-left: 18px;
  color: #3d4043;
}
.left_upper_content_item :hover {
  box-shadow: var(--shadow2);
}
.left_bottom {
  width: 100%;
  height: 250px;
  margin-top: 5%;
  background-color: white;
  border-radius: 4px;
  box-shadow: var(--shadow2);
}
.left_bottom_upper {
  width: 100%;
  height: 60px;
  line-height: 60px;
  /* border-bottom: rgb(194, 194, 194);
  border-bottom-width: 1px;
  border-bottom-style: solid; */
}
.left_bottom_upper h1 {
  margin: 0;
  font-size: 16px;
  line-height: 60px;
}

.left_bottom_content {
  width: 100%;
  height: 190px;
  /* background-color: #333; */

  box-sizing: border-box;
}
.left_bottom_content_item {
  float: left;
  width: 30%;
  height: 40%;
  margin-left: 2.11%;
  margin-top: 0.5%;
  background-color: #f1f3f8;
  /* padding-left: 28px; */
  user-select: none;
  /* border: 1px solid rgb(194, 194, 194); */

  /* background-color: #333; */
}

.left_bottom_content_item p {
  margin: 0;
  font-size: 14px;
  line-height: 76px;
  padding-left: 28px;
  color: #3d4043;
}
.right {
  float: left;
  width: 35%;
  height: 100%;
  margin-left: 5%;
  background-color: white;
  border-radius: 4px;
  box-shadow: var(--shadow2);
}
.right_upper {
  width: 100%;
  height: 10%;

  line-height: 50px;
  border-bottom: rgb(194, 194, 194);
  border-bottom-width: 1px;
  border-bottom-style: solid;
}
.right_upper h1 {
  font-size: 18px;
  line-height: 20px;
  user-select: none;
}
.right_content {
  width: 100%;
  height: 90%;
  /* background-color: #333; */
  padding: 20px;
  box-sizing: border-box;
  overflow-x: hidden;
}
.right_content::-webkit-scrollbar {
  display: none;
}
.right_content_item {
  width: 100%;
  height: 120px;
  /* background-color: antiquewhite; */
  border-bottom: rgb(194, 194, 194);
  border-bottom-width: 1px;
  border-bottom-style: solid;
}
.right_content_item_title {
  font-size: 16px;
  line-height: 20px;
  font-weight: 600;
  white-space: nowrap; /*强制在一行显示*/
  text-overflow: ellipsis; /*设置超出内容显示...*/
  overflow: hidden; /*一定不能少 超出的内容进行隐藏*/
}
.right_content_item_content {
  font-size: 14px;
  line-height: 30px;
  font-weight: 300;
  white-space: nowrap; /*强制在一行显示*/
  text-overflow: ellipsis; /*设置超出内容显示...*/
  overflow: hidden; /*一定不能少 超出的内容进行隐藏*/
}
.right_content_item h3 {
  font-size: 12px;
  line-height: 20px;
  font-weight: 300;
}
.clearfix {
  margin-top: 50px;
}
.clearfix:before,
.clearfix:after {
  content: "\0020";
  display: block;
  height: 0;
  overflow: hidden;
  clear: both;
}

.mall {
  padding: 2px;
  float: left;
  width: 220px;
  height: 300px;
  margin-left: 20px;
  margin-top: 20px;
  box-sizing: border-box;
  background-color: white;
}
.mall:hover {
  box-shadow: var(--shadow2);
}
.service {
  width: 80px;
  height: 60px;
  z-index: 999;
  position: fixed;
  right: 0;
  top: 100px;
  /* float:right; */
  margin-top: 100px;
  border-radius: 30px 0 0 30px;
  background-color: #559efa;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
  font-size: 18px;
}
.service:hover .service_more {
  display: inline-block;
}
.service_more {
  display: none;
  width: 170px;
  height: 250px;
  z-index: 999;
  position: fixed;
  padding: 20px;
  box-sizing: border-box;
  right: 0;
  top: 100px;
  /* float:right; */
  margin-top: 100px;
  border-radius: 10px 0 0 10px;
  background-color: #559efa;
  color: white;
  font-size: 14px;
  line-height: 20px;
  font-weight: 600;
}
.el-dialog__header {
  padding: 20px 20px 10px;
}
.el-dialog__body {
  padding: 10px 20px;
  color: #606266;
  font-size: 14px;
  word-break: break-all;
}
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    /* height: 80%; */
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
</style>