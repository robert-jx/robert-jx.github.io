<template>
  <div class="members">
    <el-container>
      <el-header>成员管理</el-header>
      <el-main>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="成员列表" name="first">
            <div class="content">
              <div class="upper">
                <el-button
                  type="primary"
                  style="float: left"
                  @click="inviteMember()"
                  :disabled="myList.role == 'MEMBER'"
                  >邀请成员</el-button
                >
                <!-- <el-button
                  type="warning"
                  style="float: left"
                  @click="openRoleList()"
                  >批量设置角色</el-button
                > -->
                <el-button
                  type="danger  "
                  style="float: left"
                  @click="openMemberList()"
                  :disabled="myList.role != 'OWNER'"
                  >批量删除</el-button
                >
                <span class="describle"
                  >功能简介：管理员可以对实验室成员设置不同角色，协同参与实验室日常运行</span
                >
                <!-- <el-input
                  style="float: right; width: 400px"
                  placeholder="搜索成员名称"
                >
                  <el-button type="primary" slot="append" icon="el-icon-search"
                    >搜索</el-button
                  >
                </el-input> -->
                <el-dialog
                  title="邀请成员"
                  :visible.sync="dialogVisible"
                  width="500px"
                  style="text-align: left"
                >
                  <el-form ref="form" :model="form" label-width="90px">
                    <el-form-item label="邀请链接">
                      <el-row>
                        <el-col :span="15">
                          <el-input
                            v-model="form.address"
                            placeholder="请复制该链接"
                            disabled
                          ></el-input>
                        </el-col>
                        <el-col :span="5" style="margin-left: 28px">
                          <el-button type="primary" @click="copyText()"
                            >一键复制</el-button
                          >
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="有效期限">
                      <el-row>
                        <el-col>
                          <el-select
                            v-model="hour"
                            placeholder="请选择有限期限"
                          >
                            <el-option label="一天" value="24">一天</el-option>
                            <el-option label="三天" value="72">三天</el-option>
                            <el-option label="七天" value="148">七天</el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <!-- <el-button @click="dialogVisible = false">取 消</el-button> -->
                    <el-button @click="dialogVisible = false">关 闭</el-button>
                  </span>
                </el-dialog>
                <!-- <el-dialog
                  title="批量设置角色"
                  :visible.sync="dialogVisible2"
                  width="500px"
                  style="text-align: left"
                >
                  <el-form ref="form" :model="roleFormList" label-width="90px">
                    <el-form-item label="实验室角色">
                      <el-row>
                        <el-col :span="19">
                          <el-select v-model="roleFormList.role">
                            <el-option
                              v-for="item in optionList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="dialogVisible2 = false">取 消</el-button>
                    <el-button
                      type="primary"
                      @click="this.dialogVisible2 = false"
                      >确 定</el-button
                    >
                  </span>
                </el-dialog> -->
                <el-dialog
                  title="选择您要进行的操作"
                  :visible.sync="dialogVisible3"
                  width="30%"
                >
                  <span slot="footer" class="dialog-footer">
                    <el-button type="danger" @click="deleteMemberList()"
                      >删除</el-button
                    >
                    <el-button type="primary" @click="historyMemberList()"
                      >移至历史实验室</el-button
                    >
                    <el-button @click="dialogVisible3 = false">取 消</el-button>
                  </span>
                </el-dialog>
              </div>
              <div class="middle">
                <div class="middle_head">
                  <el-table
                    ref="multipleTable"
                    :data="tableData"
                    tooltip-effect="dark"
                    style="width: 100%"
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column type="selection" width="55">
                    </el-table-column>
                    <el-table-column
                      prop="_createTime"
                      label="创建时间"
                      width="160"
                    ></el-table-column>
                    <el-table-column
                      prop="realName"
                      label="姓名"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="_role"
                      label="角色"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="record"
                      label="学历"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="isHere"
                      label="成员状态"
                      show-overflow-tooltip
                    >
                    </el-table-column>
                    <el-table-column fixed="right" label="操作" width="120">
                      <template slot-scope="scope">
                        <el-button
                          @click.native.prevent="setRoleForm(scope.row)"
                          type="text"
                          size="small"
                          :disabled="
                            myList.role != 'OWNER' || scope.row.role == 'OWNER'
                          "
                        >
                          设置角色
                        </el-button>
                        <el-button
                          @click.native.prevent="
                            deleteMember(scope.$index, tableData, scope.row)
                          "
                          type="text"
                          size="small"
                          :disabled="
                            myList.role != 'OWNER' || scope.row.role == 'OWNER'
                          "
                        >
                          移除
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                  <el-dialog
                    title="设置角色"
                    :visible.sync="dialogVisible1"
                    width="500px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="roleForm" label-width="90px">
                      <el-form-item label="实验室角色">
                        <el-row>
                          <el-col :span="19">
                            <el-select v-model="roleForm.role">
                              <el-option
                                v-for="item in optionList"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                              ></el-option>
                            </el-select>
                          </el-col>
                        </el-row>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialogVisible1 = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="setRole()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
                <div class="middle_foot">
                  <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="index"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalElements"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <!-- <el-tab-pane label="申请列表" name="second">
            <div class="content">
              <div class="middle">
                <el-table
                  ref="multipleTable"
                  :data="applyData"
                  tooltip-effect="dark"
                  style="width: 100%"
                  @selection-change="handleSelectionChange"
                >
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column label="日期" width="120">
                    <template slot-scope="scope">{{ scope.row.date }}</template>
                  </el-table-column>
                  <el-table-column
                    prop="name"
                    label="姓名"
                    width="120"
                  ></el-table-column>

                  <el-table-column
                    prop="reason"
                    label="申请理由"
                    show-overflow-tooltip
                  >
                  </el-table-column>
                  <el-table-column fixed="right" label="操作" width="120">
                    <template slot-scope="scope">
                      <el-button
                        @click.native.prevent="
                          deleteMember(scope.$index, tableData, scope.row)
                        "
                        type="text"
                        size="small"
                      >
                        移除
                      </el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </div>
          </el-tab-pane> -->
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Members",
  data() {
    return {
      labId: "",
      hour: "24",
      activeName: "first",
      dialogVisible: false,
      dialogVisible1: false,
      dialogVisible2: false,
      dialogVisible3: false,
      form: {
        address: "https://invite.keyanplus.com/",
      },
      tableData: [
        {
          _createTime: "2021-03-11",
          realName: "程序猿",
          _role: "管理员",
          record: "硕士生",
          isHere: "当前成员",
        },
      ],
      myList: {},
      optionList: [
        {
          label: "管理员",
          value: "ADMIN",
        },
        // {
        //   label: "分类管理员",
        //   value: "CATEGORY_ADMIN",
        // },
        {
          label: "普通成员",
          value: "MEMBER",
        },
      ],
      roleForm: {
        id: "",
        role: "",
        userName: "",
      },
      roleFormList: {
        id: "",
        role: "",
      },
      selection: [],
      applyData: [],
      //分页
      index: 1,
      pageSize: 10,
      totalPages: 0,
      totalElements: 0,
    };
  },
  created() {
    this.getLabId();
  },
  watch: {
    dialogVisible(newName) {
      if (newName == false) {
        this.form.address = "https://invite.keyanplus.com/";
        // console.log(this.form.address);
      }
    },
    hour(newName) {
      this.hour = newName;
      this.inviteMember();
    },
  },
  components: {},
  mounted() {},
  methods: {
    // 点击事件
    handleClick(tab, event) {
      console.log(tab, event);
    },
    // 多选框函数
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.selection = val;
    },
    deleteRow(index, rows) {
      rows.splice(index, 1);
    },
    handleSizeChange(val) {
      this.pageSize = val;
      // console.log(this.pageSize);
      this.getMember();
    },
    handleCurrentChange(val) {
      this.index = val;
      // console.log(this.index);
      this.getMember();
    },
    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;
      // console.log(this.labId);

      this.getMember();
      this.getMyRole();
    },
    getMember() {
      // console.log({
      //     labId: this.labId,
      //     index: this.index - 1,
      //     pageSize: this.pageSize,
      //     ascProperties: ["fkLabId"],
      //     descProperties: ["id"],
      //   })
      this.axios
        .post("/api/v1/lab/members", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let result = res.data.data;
            this.pageSize = result.pageSize;
            this.totalElements = result.totalElements;
            this.totalPages = result.totalPages;
            for (let i of result.data) {
              let result = this.getLocalTime(i.createTime);
              i._createTime = result;

              i.isHere = i.work ? "当前成员" : "历史成员";
              if (i.role === "OWNER") i._role = "所有者";
              else if (i.role === "ADMIN") i._role = "管理员";
              else if (i.role === "CATEGORY_ADMIN") i._role = "分类管理员";
              else i._role = "普通成员";
            }
            this.tableData = result.data;
            // console.log(this.tableData);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getMyRole() {
      this.axios
        .get("/api/v1/lab/self", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.myList = res.data.data;
            // console.log(this.myList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 邀请成员
    inviteMember() {
      // this.dialogVisible = true;
      // this.axios.post('/api/invite').then(res =>{
      //   // console.log(res.data);
      //   this.form.address = this.form.address + res.data.data;
      // })

      this.form.address = "https://invite.keyanplus.com/";
      this.axios
        .post("/api/v1/lab/inviteUrl", null, {
          params: {
            labId: this.labId,
            hour: parseInt(this.hour),
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.dialogVisible = true;
            this.form.address = this.form.address + res.data.data;
          } else {
            this.Fail("获取邀请链接失败");
            this.dialogVisible = false;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    copyText() {
      let input = document.createElement("input");
      input.value = this.form.address;
      document.body.appendChild(input);
      input.select();
      document.execCommand("Copy");
      document.body.removeChild(input);
      this.Success("复制成功");
    },
    // 打开设置角色弹窗
    setRoleForm(obj) {
      // console.log(obj);
      this.dialogVisible1 = true;
      this.roleForm.role = obj.role;
      this.roleForm.id = obj.id;
      this.roleForm.userName = obj.fkAccountName;
    },
    // 单个设置角色
    setRole() {
      if (this.myList.role === "OWNER") {
        let result = [];
        result.push(this.roleForm.id);
        // console.log({
        //   role: this.roleForm.role,
        //   targetIds: result,
        // });
        this.axios
          .put("/api/v1/lab/host/roles", {
            role: this.roleForm.role,
            targetIds: result,
          })
          .then((res) => {
            this.dialogVisible1 = false;
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.Success("设置角色成功");
              this.index = 1;
              this.pageSize = 10;
              // this.getMember();
              this.selection = [];
              this.roleForm.id = "";
              this.roleForm.role = "";
              this.getMember();
              this.axios
                .post(
                  "/api/v1/utils/members/guide/" + this.roleForm.userName,
                  {}
                )
                .then();
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
      // else if (this.myList.role === "ADMIN") {
      //   let result = [];
      //   result.push(this.roleForm.id);
      //   this.axios
      //     .put("/api/v1/lab/admin/roles", {
      //       role: this.roleForm.role,
      //       targetIds: result,
      //     })
      //     .then((res) => {
      //       this.dialogVisible1 = false;
      //       // console.log(res.data);
      //       if (res.data.code === 20000) {
      //         this.Success("设置角色成功");
      //         this.index = 1;
      //         this.pageSize = 10;
      //         // this.getMember();
      //         this.selection = [];
      //         this.roleForm.id = "";
      //         this.roleForm.role = "";
      //         this.getMember();
      //       }
      //     })
      //     .catch((error) => {
      //       console.log(error);
      //     });
      // }
    },
    // 点击批量设置角色按钮
    openRoleList() {
      if (this.selection.length >= 1) {
        this.dialogVisible2 = true;
      } else {
        this.Fail("请选择操作对象");
      }
    },
    // 点击批量删除成员按钮
    openMemberList() {
      // console.log(this.selection);
      if (this.selection.length >= 1) {
        let isMember = false;
        for (let i of this.selection) {
          if (i.role != "MEMBER") {
            isMember = true;
          }
        }
        if (isMember) {
          this.Fail("请先将用户角色修改为普通成员");
        } else {
          this.dialogVisible3 = true;
        }
      } else {
        this.Fail("请选择操作对象");
      }
    },
    deleteMember(index, rows, obj) {
      if (obj.role != "MEMBER") {
        this.Fail("请先将用户角色修改为普通成员");
      } else {
        let member = [];

        this.$confirm("是否将该用户删除?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(() => {
            let i = new Object();
            let str = this.getLocalTime(obj.createTime);
            i.id = obj.id + "";
            i.fkAccountName = obj.fkAccountName;
            i.fkLabId = obj.fkLabId + "";
            i.role = obj.role;
            i.work = obj.work;
            i.createTime = str;
            member.push(i);
            // console.log(member);
            this.axios
              .delete("/api/v1/lab/members", {
                data: {
                  labId: this.labId,
                  labDetails: member,
                },
              })
              .then((res) => {
                // console.log(res.data);
                this.selection = [];
                if (res.data.code === 20000) {
                  this.Success("删除成功");
                }

                rows.splice(index, 1);
                // console.log("删除成功");
              })
              .catch((error) => {
                console.log(error);
                this.Fail("删除失败");
              });
          })
          .catch(() => {});
      }
    },
    // 删除成员
    deleteMemberList() {
      // console.log('10000');
      this.dialogVisible3 = false;
      let list = this.selection;
      // console.log(list);
      let bufferList = [];
      let result = [];
      for (let key in list) {
        let i = new Object();
        let str = this.getLocalTime(list[key].createTime);
        i.id = list[key].id + "";
        i.fkAccountName = list[key].fkAccountName;
        i.fkLabId = list[key].fkLabId + "";
        i.role = list[key].role;
        i.work = list[key].work;
        i.createTime = str;
        bufferList.push(i);
      }
      // console.log(bufferList);
      result = bufferList;
      // console.log({
      //   data: {
      //     labId: 5,
      //     labDetails: result,
      //   },
      // });
      this.axios
        .delete("/api/v1/lab/members", {
          data: {
            labId: this.labId,
            labDetails: result,
          },
        })
        .then((res) => {
          // console.log(res.data);
          this.selection = [];
          if (res.data.code === 20000) {
            this.Success("删除成功");
          }
          this.index = 1;
          this.pageSize = 10;
          this.getMember();
          // console.log("删除成功");
        })
        .catch((error) => {
          console.log(error);
          this.Fail("删除失败");
        });
    },
    historyMemberList() {
      this.axios
        .put("/api/v1/lab/member/state", {
          ids: this.selection,
          state: true,
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.dialogVisible3 = false;
            this.index = 1;
            this.pageSize = 10;
            this.getMember();
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    add0(m) {
      return m < 10 ? "0" + m : m;
    },
    getLocalTime(nS) {
      //shijianchuo是整数，否则要parseInt转换
      let time = new Date(nS);
      let y = time.getFullYear();
      let m = time.getMonth() + 1;
      let d = time.getDate();
      return y + "-" + this.add0(m) + "-" + this.add0(d) + " ";
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.members {
  width: 100%;
  height: 100%;
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  /* box-shadow: var(--shadow2); */
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}

.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* padding: 0 20px; */
  /* background-color: #ffffff; */
  color: #333;
  font-size: 12px;
}

.content {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 53px;
  /* background-color: red; */
}
.upper > * {
  box-shadow: var(--shadow2);
}
.upper .el-input-group__append .el-button {
  transform: translateY(1px);
  background-color: var(--primary);
  color: white;
  border-radius: 0 2px 2px 0;
}

.describle {
  color: var(--text3);
  float: left;
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.middle {
  width: 100%;
  height: calc(700px - 66px);
  margin-top: 13px;
  padding: 20px;
  background-color: white;
  border-radius: 4px;

  box-shadow: var(--shadow2);
  box-sizing: border-box;
}
.middle_head {
  width: 100%;
  height: calc(634px - 75px);
  background-color: white;
  overflow-x: hidden;
}
.middle_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}

/* 适配 */
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
@media screen and (max-width: 500px) {
  .content {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
</style>
<style>
.el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
  font-size: 12px;
  line-height: 40px;
}
</style>