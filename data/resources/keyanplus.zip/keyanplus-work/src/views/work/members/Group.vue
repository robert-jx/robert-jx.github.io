<template>
  <div class="group">
    <el-container>
      <el-header>
        <span>小组管理</span>
      </el-header>
      <el-main>
        <div class="content">
          <div class="upper">
            <el-button
              type="primary"
              style="float: left"
              @click="dialogVisible = true"
              :disabled="myList.role == 'MEMBER'"
              >新建小组</el-button
            >
            <span class="describle"
              >功能简介：课题组内部可以设置不同研究方向的项目小组，对于不同的项目小组可以任意添加实验室成员加入</span
            >
            <!-- <el-input
              style="float: right; width: 400px"
              placeholder="搜索小组名称"
            >
              <el-button type="primary" slot="append" icon="el-icon-search"
                >搜索</el-button
              >
            </el-input> -->
            <el-dialog
              title="新建小组"
              :visible.sync="dialogVisible"
              width="640px"
              style="text-align: left"
            >
              <el-form ref="form" :model="form" label-width="90px">
                <el-form-item label="*小组名称">
                  <el-row>
                    <el-col :span="8">
                      <el-input
                        v-model="form.name"
                        placeholder="xx课题组/xx项目组/xx研究方向"
                      ></el-input>
                    </el-col>
                    <el-col :span="6" style="margin-left: 28px">
                      *小组负责人</el-col
                    >
                    <el-col :span="8">
                      <el-select
                        v-model="form.leader"
                        placeholder="请选择负责人"
                      >
                        <el-option
                          v-for="item in memberCList"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        ></el-option>
                      </el-select>
                    </el-col>
                  </el-row>
                </el-form-item>
                <el-form-item label="*小组成员">
                  <el-row>
                    <el-col>
                      <el-select
                        v-model="form.members"
                        multiple
                        placeholder="请选择"
                      >
                        <el-option
                          v-for="item in memberList"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value"
                        >
                        </el-option>
                      </el-select>
                    </el-col>
                  </el-row>
                </el-form-item>
                <el-form-item label="*是否公开">
                  <el-row>
                    <el-col
                      ><el-radio v-model="form.isShow" label="true"
                        >是</el-radio
                      >
                      <el-radio v-model="form.isShow" label="false"
                        >否</el-radio
                      >
                    </el-col>
                  </el-row>
                </el-form-item>
                <el-form-item label="*小组简介">
                  <el-input
                    v-model="form.remarks"
                    placeholder="请输入备注"
                    type="textarea"
                    :rows="8"
                    resize="none"
                  ></el-input>
                </el-form-item>
              </el-form>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="addGroup()">确 定</el-button>
              </span>
            </el-dialog>
          </div>
          <div class="middle">
            <div class="middle_head">
              <el-table
                ref="multipleTable"
                :data="tableData"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"> </el-table-column>
                <el-table-column
                  prop="_createTime"
                  label="创建日期"
                  width="160"
                ></el-table-column>
                <el-table-column
                  prop="name"
                  label="小组名称"
                  width="120"
                ></el-table-column>
                <el-table-column
                  prop="leaderName"
                  label="负责人"
                  width="120"
                ></el-table-column>
                <el-table-column
                  prop="_showForAll"
                  label="是否公开"
                  width="120"
                ></el-table-column>
                <el-table-column
                  prop="introduce"
                  label="简介"
                  show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column fixed="right" label="操作" width="120">
                  <template slot-scope="scope">
                    <el-button
                      @click.native.prevent="openMore(scope.row)"
                      type="text"
                      size="small"
                    >
                      详情
                    </el-button>
                    <el-button
                      @click.native.prevent="openEdit(scope.row)"
                      type="text"
                      size="small"
                      :disabled="myList.role == 'MEMBER'"
                    >
                      编辑
                    </el-button>
                    <el-button
                      @click.native.prevent="
                        deleteGroup(scope.$index, tableData, scope.row)
                      "
                      type="text"
                      size="small"
                      style="color: red"
                      :disabled="myList.role == 'MEMBER'"
                    >
                      删除
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
              <el-dialog
                title="查看详情"
                :visible.sync="dialogVisible1"
                width="640px"
                style="text-align: left"
              >
                <el-form ref="form" :model="openForm" label-width="90px">
                  <el-form-item label="小组名称">
                    <el-row>
                      <el-col :span="8">
                        <el-input v-model="openForm.name" readonly></el-input>
                      </el-col>
                      <el-col :span="4" style="margin-left: 28px"
                        >创建日期</el-col
                      >
                      <el-col :span="8">
                        <el-input
                          v-model="openForm._createTime"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="负责人">
                    <el-row>
                      <el-col :span="8">
                        <el-input
                          v-model="openForm.leaderName"
                          readonly
                        ></el-input>
                      </el-col>
                      <el-col :span="4" style="margin-left: 28px"
                        >是否公开</el-col
                      >
                      <el-col :span="8">
                        <el-select
                          v-model="openForm.showForAll"
                          placeholder="请选择"
                          disabled
                        >
                          <el-option
                            v-for="item in optionsList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          >
                          </el-option>
                        </el-select>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="小组成员">
                    <el-row>
                      <el-col>
                        <el-select
                          v-model="openForm.members"
                          multiple
                          placeholder="请选择"
                          disabled
                        >
                          <el-option
                            v-for="item in memberList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          >
                          </el-option>
                        </el-select>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <!-- <el-form-item label="是否公开">
                  <el-row>
                    <el-col
                      ><el-radio v-model="openForm.isShow" label=true
                        >是</el-radio
                      >
                      <el-radio v-model="openForm.isShow" label=false
                        >否</el-radio
                      >
                    </el-col>
                  </el-row>
                </el-form-item> -->
                  <el-form-item label="简介">
                    <el-row>
                      <el-col :span="21">
                        <el-input
                          type="textarea"
                          v-model="openForm.introduce"
                          resize="none"
                          :rows="8"
                          disabled
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                  <!-- <el-button @click="dialogVisible1 = false">取 消</el-button> -->
                  <el-button type="primary" @click="dialogVisible1 = false"
                    >关 闭</el-button
                  >
                </span>
              </el-dialog>
              <el-dialog
                title="编辑小组"
                :visible.sync="dialogVisible2"
                width="640px"
                style="text-align: left"
              >
                <el-form ref="form" :model="editForm" label-width="90px">
                  <el-form-item label="*小组名称">
                    <el-row>
                      <el-col :span="8">
                        <el-input v-model="editForm.name"></el-input>
                      </el-col>
                      <el-col :span="4" style="margin-left: 28px"
                        >*创建日期</el-col
                      >
                      <el-col :span="8">
                        <el-input
                          v-model="editForm._createTime"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="*负责人">
                    <el-row>
                      <el-col :span="8">
                        <el-select
                          v-model="editForm.leaderName"
                          placeholder="请选择负责人"
                        >
                          <el-option
                            v-for="item in memberList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          ></el-option>
                        </el-select>
                      </el-col>
                      <el-col :span="4" style="margin-left: 28px"
                        >*是否公开</el-col
                      >
                      <el-col :span="8">
                        <el-select
                          v-model="editForm.showForAll"
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in optionsList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          >
                          </el-option>
                        </el-select>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="*小组成员">
                    <el-row>
                      <el-col>
                        <el-select
                          v-model="groupMemberList"
                          multiple
                          placeholder="请选择"
                        >
                          <el-option
                            v-for="item in memberList1"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          >
                          </el-option>
                        </el-select>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="*简介">
                    <el-row>
                      <el-col :span="21">
                        <el-input
                          type="textarea"
                          v-model="editForm.introduce"
                          resize="none"
                          :rows="8"
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                  <el-button @click="dialogVisible2 = false">取 消</el-button>
                  <el-button type="primary" @click="editGroup()"
                    >确 定</el-button
                  >
                </span>
              </el-dialog>
            </div>
            <div class="middle_foot">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="index"
                :page-sizes="[10, 20, 30]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalElements"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Group",
  data() {
    return {
      labId: "",
      dialogVisible: false,
      dialogVisible1: false,
      dialogVisible2: false,
      myList: {},
      optionsList: [
        {
          value: true,
          label: "是",
        },
        {
          value: false,
          label: "否",
        },
      ],
      memberList: [],
      memberList1: [],
      memberCList: [],
      groupList: [],
      groupMemberList: [],
      form: {
        name: "",
        leader: "",
        members: [],
        // describe: "",
        isShow: false,
        remarks: "",
      },
      tableData: [
        {
          _createTime: "2021-03-11",
          name: "小组一号",
          leaderName: "程序猿",
          _showForAll: "是",
          introduce: "此小组仅为展示用",
        },
      ],
      selection: [],
      openForm: {
        members: [],
      },
      editForm: {},
      // 分页
      index: 1,
      pageSize: 10,
      totalPages: 0,
      totalElements: 0,
    };
  },
  created() {
    this.getLabId();
  },
  components: {},
  mounted() {},
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.selection = val;
    },

    handleSizeChange(val) {
      this.pageSize = val;
      // console.log(this.pageSize);
      this.getGroups();
    },
    handleCurrentChange(val) {
      this.index = val;
      // console.log(this.index);
      this.getGroups();
    },
    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;
      this.getGroups();
      this.getMemberList();
      this.getMyRole();
    },
    getMyRole() {
      this.axios
        .get("/api/v1/lab/self", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.myList = res.data.data;
            // console.log(this.myList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getGroups() {
      this.axios
        .post("/api/v1/lab/researchGroups", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            for (let i of list.data) {
              let result = this.getLocalTime(i.createTime);
              i._createTime = result;
              // i._createTime = result.toString();
              i._showForAll = i.showForAll ? "是" : "否";
            }
            this.tableData = list.data;
            this.pageSize = list.size;
            this.totalPages = list.totalPages;
            this.totalElements = list.totalElements;
            // console.log(this.tableData);
          }
        })
        .catch(() => {
          console.log("网络环境不佳，请稍后再试");
        });
    },
    getMemberList() {
      this.axios
        .get("/api/v1/lab/researchGroupsAndDetails?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            // console.log('1');
            let list = res.data.data;
            let bufferList = [];
            let bufferList1 = [];
            // console.log(list);
            for (let key in list.labDetails) {
              let i = new Object();
              i.label = list.labDetails[key][2];
              i.value = list.labDetails[key][0];
              // i.key = list.labDetails[key][0];
              // i.role = list.labDetails[key][1];
              bufferList.push(i);
            }
            this.memberList = bufferList;
            this.memberList1 = bufferList;
            this.groupList = list.researchGroupDetails;
            for (let key in list.labDetails) {
              let i = new Object();
              i.label = list.labDetails[key][2];
              i.value = list.labDetails[key][2];
              // i.key = list.labDetails[key][0];
              // i.role = list.labDetails[key][1];
              bufferList1.push(i);
            }
            this.memberCList = bufferList1;
            // console.log(this.memberList);
            // console.log(this.groupList);
          }
        })
        .catch(() => {
          console.log("网络环境不佳，请稍后再试");
        });
    },
    openMore(row) {
      row._createTime = row._createTime.toString();
      this.openForm = row;
      for (let key in this.groupList) {
        if (this.groupList[key].fkResearchGroupId == row.id) {
          this.groupMemberList.push(this.groupList[key].fkLabDetailId);
        }
      }
      // console.log(this.groupMemberList);
      this.openForm.members = this.groupMemberList;
      this.groupMemberList = [];
      // console.log(this.openForm);

      this.dialogVisible1 = true;
    },
    openEdit(row) {
      row._createTime = row._createTime.toString();
      let list = [];
      for (let key in this.groupList) {
        // let i = new Object();
        if (this.groupList[key].fkResearchGroupId == row.id) {
          // i.label = this.groupList[key].detailName;
          // i.key = this.groupList[key].fkLabDetailId;
          // i.value = this.groupList[key].fkLabDetailId;
          list.push(this.groupList[key].fkLabDetailId);
          // this.groupMemberList.push(i);
        }
      }
      // console.log(list);
      // row.members = list;
      this.groupMemberList = list;

      this.editForm = row;
      // console.log(this.editForm.members);

      this.dialogVisible2 = true;
    },
    addGroup() {
      // console.log(this.form);
      if (this.form.isShow === "true") {
        this.form.isShow = true;
      } else {
        this.form.isShow = false;
      }
      let list = [];
      let groupId = "";
      let groupName = "";
      for (let key in this.form.members) {
        for (let k in this.memberList) {
          if (this.form.members[key] === this.memberList[k].value) {
            let i = new Object();
            i.id = this.memberList[k].value;
            i.name = this.memberList[k].label;
            list.push(i);
          }
        }
      }
      // console.log({
      //   name:this.form.name,
      //   leaderName:this.form.leader,
      //   fkLabId:this.labId.toString(),
      //   showForAll:this.form.isShow,
      //   introduce:this.form.remarks
      // });
      this.axios
        .post("/api/v1/lab/researchGroup", {
          name: this.form.name,
          leaderName: this.form.leader,
          fkLabId: this.labId.toString(),
          showForAll: this.form.isShow,
          introduce: this.form.remarks,
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            groupId = res.data.data.id;
            groupName = res.data.data.name;
            this.axios
              .post("/api/v1/lab/joinResearchGroup", {
                labId: this.labId,
                groupId: groupId,
                groupName: groupName,
                detailInserts: list,
              })
              .then((res) => {
                // console.log(res.data);
                if (res.data.code === 20000) {
                  this.Success("添加成功");
                  this.dialogVisible = false;
                  this.index = 1;
                  this.pageSize = 10;
                  this.getGroups();
                }
              });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    editGroup() {
      // console.log(this.editForm);
      // console.log(this.groupMemberList);
      let list = [];
      for (let key in this.groupMemberList) {
        for (let k in this.memberList) {
          if (this.groupMemberList[key] === this.memberList[k].value) {
            let i = new Object();
            i.id = this.memberList[k].value;
            i.name = this.memberList[k].label;
            list.push(i);
          }
        }
      }
      // console.log(list);
      if (
        this.editForm.id === "" ||
        this.editForm.name === "" ||
        this.editForm.showForAll === "" ||
        this.editForm.introduce === "" ||
        this.editForm.leaderName === ""
      ) {
        this.Fail("信息不全");
      } else {
        this.dialogVisible2 = false;
        // console.log({
        //   id: this.editForm.id,
        //   fkLabId: this.labId,
        //   name: this.editForm.name,
        //   leaderName: this.editForm.leaderName,
        //   showForAll: this.editForm.showForAll,
        //   introduce: this.editForm.introduce,
        // });
        this.axios
          .put("/api/v1/lab/researchGroup", {
            id: this.editForm.id,
            fkLabId: this.labId,
            name: this.editForm.name,
            leaderName: this.editForm.leaderName,
            showForAll: this.editForm.showForAll,
            introduce: this.editForm.introduce,
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.axios
                .put("/api/v1/lab/researchGroupDetails", {
                  labId: this.labId,
                  researchGroupId: this.editForm.id,
                  researchDetailUpdates: list,
                })
                .then((res) => {
                  // console.log(res.data);
                  if (res.data.code === 20000) {
                    this.Success("修改成功");
                    this.getGroups();
                  } else if (res.data.code === 40380) {
                    this.Fail("权限不足，无法执行操作");
                  }
                })
                .catch((error) => {
                  console.log(error);
                });
            } else if (res.data.code === 40380) {
              this.Fail("权限不足，无法执行操作");
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    deleteGroup(index, rows, row) {
      let list = row;
      let result = [];
      // console.log(list);
      let i = new Object();
      i.id = list.id;
      i.fkLabId = this.labId;
      i.name = list.name;
      i.leaderName = list.leaderName;
      i.showForAll = list.showForAll;
      i.introduce = list.introduce;
      result.push(i);
      // console.log(result);
      this.$confirm("此操作将永久删除该课题组, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // console.log({
          //   fkLabId: this.labId,
          //   researchGroups: result,
          // });
          this.axios
            .delete("/api/v1/lab/researchGroups", {
              data: {
                fkLabId: this.labId,
                researchGroups: result,
              },
            })
            .then((res) => {
              // console.log(res.data);
              if (res.data.code === 20000) {
                rows.splice(index, 1);
                this.Success("删除成功");
                this.index = 1;
                this.pageSize = 10;
                this.getGroups();
              } else if (res.data.code === 40380) {
                this.Fail("权限不足，无法执行操作");
              }
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },

    add0(m) {
      return m < 10 ? "0" + m : m;
    },
    getLocalTime(nS) {
      //shijianchuo是整数，否则要parseInt转换
      let time = new Date(nS);
      let y = time.getFullYear();
      let m = time.getMonth() + 1;
      let d = time.getDate();
      return y + "-" + this.add0(m) + "-" + this.add0(d) + " ";
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.group {
  width: 100%;
  height: 100%;
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  box-shadow: var(--shadow2);
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}

.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* background-color: #E9EEF3; */
  color: #333;
  text-align: right;
}
.content {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 53px;
  /* background-color: red; */
}
.upper > * {
  box-shadow: var(--shadow2);
}
.upper .el-input-group__append .el-button {
  transform: translateY(1px);
  background-color: var(--primary);
  color: white;
  border-radius: 0 2px 2px 0;
}
.describle {
  color: var(--text3);
  float: left;
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.middle {
  width: 100%;
  min-height: calc(700px - 66px);
  margin-top: 13px;
  padding: 20px;
  background-color: white;
  border-radius: 4px;

  box-shadow: var(--shadow2);
  box-sizing: border-box;
}
.middle_head {
  width: 100%;
  height: calc(634px - 75px);
  background-color: white;
  overflow-x: hidden;
}
.middle_head ::-webkit-scrollbar {
  display: none;
}
.middle_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}
/* 适配 */
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
@media screen and (max-width: 500px) {
  .content {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
</style>