<template>
  <div class="buy">
    <el-container>
      <el-header>
        <span>采购管理</span>
      </el-header>
      <el-main>
        <div class="content">
          <div class="upper">
            <el-button
              type="primary"
              style="float: left"
              @click="dialogVisible = true"
              >新订单</el-button
            >
            <span class="describle"
              >功能简介：线上管理课题组成员在实验室使用的所有的科研物资采购事项</span
            >
            <el-dialog
              title="新订单"
              :visible.sync="dialogVisible"
              width="640px"
              style="text-align: left"
            >
              <el-steps
                :active="active"
                finish-status="success"
                space="70%"
                align-center
              >
                <el-step title="步骤 1"></el-step>
                <el-step title="步骤 2"></el-step>
              </el-steps>

              <div v-show="active == 0" style="margin-top: 28px">
                <div>
                  <span>*经费来源：</span>
                  <el-select v-model="form.fee" placeholder="请选择">
                    <el-option
                      v-for="item in feeList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>

                  <!-- <el-select v-model="form.project" placeholder="请选择">
                  <el-option
                    v-for="item in projectList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select> -->
                  <span style="margin-left: 28px">所用项目：</span>
                  <span>{{ form.project }}</span>
                </div>
                <div class="form_item">
                  <span>剩余经费：</span>
                  <el-input
                    style="width: 120px"
                    v-model="form.curFee"
                    readonly
                  ></el-input>
                  元
                </div>
                <div class="form_item">
                  <span>*申 购 人：</span>
                  <el-select v-model="form.member" placeholder="请选择">
                    <el-option
                      v-for="item in memberList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                  <span style="margin-left: 28px">*供 应 商：</span>
                  <el-select v-model="form.supplier" placeholder="请选择">
                    <el-option
                      v-for="item in supplierList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </div>
              </div>

              <div v-show="active == 1" style="margin-top: 28px">
                <div>
                  <span>*产品名称：</span>
                  <el-select
                    v-model="form.name"
                    filterable
                    allow-create
                    default-first-option
                    placeholder="请输入内容"
                    style="width: 178px"
                  >
                    <el-option
                      v-for="item in this.productList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                  <!-- <el-autocomplete
                    v-model="form.name"
                    :fetch-suggestions="querySearchAsync"
                    placeholder="请输入内容"
                    @select="handleSelect"
                  ></el-autocomplete> -->
                  <span style="margin-left: 28px">*物品分类：</span>
                  <el-select
                    v-model="form.tagId"
                    placeholder="请选择"
                    style="width: 178px"
                  >
                    <el-option
                      v-for="item in tagList"
                      :key="item.key"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </div>
                <div class="form_item">
                  <span>*物品品牌：</span>
                  <el-input
                    v-model="form.brand"
                    placeholder="请输入品牌"
                  ></el-input>
                  <span style="margin-left: 28px">*采购单价：</span>
                  <el-input
                    type="number"
                    v-model="form.price"
                    style="width: 178px"
                    placeholder="请填写单价"
                    oninput="if(isNaN(value)) { value = parseFloat(value) } if(value.indexOf('.')>0){value=value.slice(0,value.indexOf('.')+2)}"
                  ></el-input>
                  元
                </div>
                <div class="form_item">
                  <span>*采购数量：</span>
                  <el-input
                    type="number"
                    v-model="form.total"
                    style="width: 178px"
                    placeholder="请填写数量"
                    oninput="if(isNaN(value)) { value = parseFloat(value) } if(value.indexOf('.')>0){value=value.slice(0,value.indexOf('.')+2)}"
                  ></el-input>
                  <span style="margin-left: 28px">*单 位：</span>
                  <el-input
                    v-model="form.unit"
                    placeholder="例：台/个/管"
                  ></el-input>
                </div>
                <div class="form_item">
                  <span>*物品类型：</span>
                  <el-radio v-model="form.properties" label="INSTRUMENT"
                    >仪器</el-radio
                  >
                  <el-radio v-model="form.properties" label="MATERIAL"
                    >试剂与耗材</el-radio
                  >
                </div>

                <div class="form_item">
                  <span>物品标签：</span>
                  <el-select v-model="form.typeName" placeholder="请选择">
                    <el-option
                      v-for="item in tabList"
                      :key="item.key"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>

                  <!-- <el-select v-model="form.brand" placeholder="请选择">
                    <el-option
                      v-for="item in brandList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select> -->
                  <br />
                  <div
                    v-show="form.properties === 'INSTRUMENT'"
                    class="form_longItem"
                  >
                    <span>附件地址：</span>
                    <el-input v-model="form.attachment"></el-input>
                  </div>
                  <div
                    v-show="form.properties === 'MATERIAL'"
                    class="form_item"
                  >
                    <span>物品浓度：</span>
                    <el-input v-model="form.concentration" placeholder="例：96%"></el-input>
                    <span style="margin-left: 28px">cas号：</span>
                    <el-input v-model="form.cas"></el-input>
                  </div>
                  <div
                    v-show="form.properties === 'MATERIAL'"
                    class="form_item"
                  >
                    <span>物品规格：</span>
                    <el-input v-model="form.specifications" placeholder="例：500mg/L"></el-input>
                  </div>
                </div>
                <div class="form_longItem">
                  <span>存放地点：</span>
                  <el-input v-model="form.place"></el-input>
                  <br />
                  <span style="margin-top: 28px">物品备注：</span>
                  <el-input
                    v-model="form.remark"
                    style="margin-top: 28px"
                  ></el-input>
                </div>
              </div>

              <span slot="footer" class="dialog-footer">
                <el-button @click="cancel()">取 消</el-button>
                <el-button v-show="active === 1" @click="preItem()"
                  >上一步</el-button
                >
                <el-button
                  v-show="active === 0"
                  type="primary"
                  @click.native.prevent="nextItem()"
                  >下一步</el-button
                >
                <el-button v-show="active == 1" type="primary" @click="addBuy()"
                  >确 定</el-button
                >
              </span>
            </el-dialog>
          </div>
          <div class="middle">
            <div class="middle_head">
              <el-table
                ref="multipleTable"
                :data="tableData"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="55"> </el-table-column>
                <el-table-column
                  prop="_createTime"
                  label="创建日期"
                  width="160"
                ></el-table-column>
                <el-table-column
                  prop="goodsName"
                  label="产品名称"
                  width="150"
                  show-overflow-tooltip
                ></el-table-column>
                <el-table-column
                  prop="goodsNum"
                  label="采购量"
                  width="120"
                ></el-table-column>
                <el-table-column
                  prop="goodsPrice"
                  label="采购价格"
                  width="120"
                ></el-table-column>
                <el-table-column
                  prop="managerName"
                  label="申购人"
                  show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column fixed="right" label="操作" width="120">
                  <template slot-scope="scope">
                    <el-button
                      @click.native.prevent="openMore(scope.row)"
                      type="text"
                      size="small"
                    >
                      详情
                    </el-button>
                    <el-button
                      @click.native.prevent="openEdit(scope.row)"
                      type="text"
                      size="small"
                      :disabled="scope.row.isInLab == true||myList.role=='MEMBER'"
                    >
                      入库
                    </el-button>
                    <!-- <el-button
                      @click.native.prevent="
                        deleteGroup(scope.$index, tableData)
                      "
                      type="text"
                      size="small"
                      style="color: red"
                    >
                      删除
                    </el-button> -->
                  </template>
                </el-table-column>
              </el-table>
              <el-dialog
                title="查看详情"
                :visible.sync="dialogVisible1"
                width="640px"
                style="text-align: left"
              >
                <el-form ref="form" :model="openForm" label-width="90px">
                  <el-form-item label="产品名称">
                    <el-row>
                      <el-col :span="8">
                        <el-input
                          v-model="openForm.goodsName"
                          readonly
                        ></el-input>
                      </el-col>
                      <el-col :span="3" style="margin-left: 14px">
                        创建时间</el-col
                      >
                      <el-col :span="8">
                        <el-input
                          v-model="openForm._createTime"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="采购数量">
                    <el-row>
                      <el-col :span="8">
                        <el-input
                          v-model="openForm.goodsNum"
                          readonly
                        ></el-input>
                      </el-col>
                      <el-col :span="3" style="margin-left: 14px">
                        采购耗费
                      </el-col>
                      <el-col :span="8">
                        <el-input
                          v-model="openForm.goodsPrice"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="经费来源">
                    <el-row>
                      <el-col :span="20">
                        <el-input
                          v-model="openForm.feeName"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <!-- <el-form-item label="地址">
                        <el-input
                          v-model="openForm.address"
                          placeholder="请输入地址"
                          readonly
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="备注">
                        <el-input
                          v-model="openForm.remark"
                          placeholder="请输入备注"
                          type="textarea"
                          :rows="8"
                          resize="none"
                          readonly
                        ></el-input>
                      </el-form-item> -->
                </el-form>
                <span slot="footer" class="dialog-footer">
                  <!-- <el-button @click="dialogVisible1 = false">取 消</el-button> -->
                  <el-button type="primary" @click="dialogVisible1 = false"
                    >关 闭</el-button
                  >
                </span>
              </el-dialog>
              <el-dialog
                title="入库"
                :visible.sync="dialogVisible2"
                width="640px"
                style="text-align: left"
              >
                <el-form ref="form" :model="editForm" label-width="90px">
                  <el-form-item label="产品名称">
                    <el-row>
                      <el-col :span="8">
                        <el-input
                          v-model="editForm.goodsName"
                          readonly
                        ></el-input>
                      </el-col>
                      <el-col :span="3" style="margin-left: 14px">
                        创建时间</el-col
                      >
                      <el-col :span="8">
                        <el-input
                          v-model="editForm._createTime"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="采购数量">
                    <el-row>
                      <el-col :span="8">
                        <el-input
                          v-model="editForm.goodsNum"
                          readonly
                        ></el-input>
                      </el-col>
                      <el-col :span="3" style="margin-left: 14px">
                        采购耗费
                      </el-col>
                      <el-col :span="8">
                        <el-input
                          v-model="editForm.goodsPrice"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="经费来源">
                    <el-row>
                      <el-col :span="20">
                        <el-input
                          v-model="editForm.feeName"
                          readonly
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="地址">
                    <el-row>
                      <el-col :span="20">
                        <el-input
                          v-model="editForm.address"
                          placeholder="请输入地址"
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                  <el-form-item label="备注">
                    <el-row>
                      <el-col :span="20">
                        <el-input
                          v-model="editForm.remark"
                          placeholder="请输入备注"
                          type="textarea"
                          :rows="8"
                          resize="none"
                        ></el-input>
                      </el-col>
                    </el-row>
                  </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                  <el-button @click="dialogVisible2 = false">取 消</el-button>
                  <el-button type="primary" @click="putIn()">入 库</el-button>
                </span>
              </el-dialog>
            </div>
            <div class="middle_foot">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="index"
                :page-sizes="[10, 20, 30]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalElements"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Buy",
  data() {
    return {
      labId: "",
      dialogVisible: false,
      dialogVisible1: false,
      dialogVisible2: false,
      myList:{},
      // 选择项
      memberList: [],
      projectFeeList: [],
      productList: [],
      instrumentList: [],
      materialList: [],
      brandList: [],
      supplierList: [],
      tabList: [],
      tagList: [],
      feeList: [],

      active: 0,
      form: {
        fee: "",
        member: "",
        supplier: "",
        name: "",
        total: "",
        tagId: "",
        price: "",
        unit: "",
        properties: "INSTRUMENT",
        typeName: "",
        brand: "",
        place: "",
        remark: "",
        attachment: "",
        concentration: "",
        specifications:'',
        cas: "",
      },
      editForm: {
        fee: "",
        member: "",
        supplier: "",
        name: "",
        total: "",
        tagId: "",
        price: "",
        unit: "",
        properties: "INSTRUMENT",
        typeName: "",
        brand: "",
        place: "",
        remark: "",
        attachment: "",
        concentration: "",
        cas: "",
        address: " ",
      },
      tableData: [
        {
          _createTime: "2021-03-11",
          goodsName: "一号物品",
          goodsNum: "100",
          goodsPrice: "100",
          managerName: "程序猿",
        },
      ],
      selection: [],

      openForm: {},
      // 表单分页
      pageIndex: 1,

      //分页
      index: 1,
      pageSize: 10,
      totalPages: 0,
      totalElements: 0,
    };
  },
  created() {
    this.getLabId();
  },
  watch: {
    "form.fee": {
      handler: function () {
        for (let key in this.projectFeeList) {
          if (this.form.fee === this.projectFeeList[key].id) {
            this.form.curFee = this.projectFeeList[key].curFee;
            this.form.project = this.projectFeeList[key].projectName;
          }
        }
      },
    },
    "form.name": {
      handler: function () {
        for (let key in this.instrumentList) {
          if (this.form.name === this.instrumentList[key].label) {
            this.form.properties = "INSTRUMENT";
            break;
          } else {
            this.form.properties = "MATERIAL";
          }
        }
      },
    },
  },
  components: {},
  mounted() {},
  methods: {
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.selection = val;
    },
    // 分页功能
    handleSizeChange(val) {
      this.pageSize = val;
      this.getBuy();
      // console.log(this.pageSize);
      // this.getMember();
    },
    handleCurrentChange(val) {
      this.index = val;
      this.getBuy();
      // console.log(this.index);
      // this.getMember();
    },

    // 步骤条
    cancel() {
      this.dialogVisible = false;
      this.active = 0;
    },
    preItem() {
      if (this.active == 1) {
        this.active--;
      }
    },
    nextItem() {
      // console.log(this.form.fee);
      if (this.active === 0) {
        if (
          this.form.fee != "" &&
          this.form.supplier != "" &&
          this.form.member != ""
        ) {
          this.active++;
        } else {
          this.Fail("请检查是否填写完毕");
        }
      }
    },

    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;

      this.getMember();
      this.getBuy();
      // this.getProject();
      this.getTab();
      this.getBrand();
      this.getProduct();
      this.getSupplier();
      this.getTag();
      this.getProjectFee();
      this.getMyRole();
      // this.getPlace();
      // console.log(this.labId);
    },

    getMyRole() {
      this.axios
        .get("/api/v1/lab/self", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.myList = res.data.data;
            // console.log(this.myList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getMember() {
      this.axios
        .get("/api/v1/lab/getMemberNames?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            list.forEach((v) => {
              let i = new Object();
              i.label = v[2];
              i.value = v[2];
              this.memberList.push(i);
            });
          }
          // console.log(this.memberList);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 获取标签
    getTab() {
      this.axios
        .get("/api/v1/lab/getAllCategoriesName?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            list.forEach((v) => {
              let i = new Object();
              i.label = v;
              i.value = v;
              i.key = v.index;
              this.tabList.push(i);
            });
            // console.log(this.tabList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 获取品牌
    getBrand() {
      this.axios
        .get("/api/v1/utils/SBPs/brands/*")
        .then((res) => {
          // console.log("brand");
          // console.log(res.data);
          if (res.data === "") {
            this.brandList = [];
          } else {
            let list = res.data;
            list.forEach((v) => {
              let i = new Object();
              i.label = v.name;
              i.value = v.name;
              this.brandList.push(i);
            });
            // console.log(this.brandList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 获取物品名称
    getProduct() {
      this.productList = [];
      this.axios
        .get("/api/v1/lab/goodsNames?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          let list1 = res.data.data.instrumentList;
          let list2 = res.data.data.materialList;
          if(list1!=null){

          list1.forEach((v) => {
            let i = new Object();
            i.label = v;
            i.value = v;
            this.instrumentList.push(i);
            this.productList.push(i);
          });
          }
          else if(list2!=null){

          list2.forEach((v) => {
            let i = new Object();
            i.label = v;
            i.value = v;
            this.materialList.push(i);
            this.productList.push(i);
          });
          }
          else{
            this.instrumentList = [];
            this.materialList = [];
            this.productList = [];
          }
          // this.productList.push(this.instrumentList);
          // this.productList.push(this.materialList);
          // console.log(this.productList);
          // console.log(this.instrumentList);
          // console.log(this.materialList);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 获取供应商
    getSupplier() {
      this.axios
        .get("/api/v1/utils/SBPs/suppliers/" + this.labId)
        .then((res) => {
          // console.log(res.data);
          let list = res.data;
          if (list!=null) {
            list.forEach((v) => {
              if(v.isUsed){
              let i = new Object();
              i.label = v.name;
              i.value = v.name;
              this.supplierList.push(i);

              }
            });
          }
          // console.log(this.supplierList);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 获取分类
    getTag() {
      let object = [
        {
          label: "* 实验室公用",
          value: 1,
          key: 1,
        },
        {
          label: "* 需申请预约",
          value: 2,
          key: 2,
        },
        {
          label: "* 预约仪器",
          value: 3,
          key: 3,
        },
        {
          label: "* 仅需申请",
          value: 4,
          key: 4,
        },
      ];
      this.tagList = object;
      this.axios
        .get("/api/v1/lab/init?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data.tagHash;
            if(list!=null){

            list.forEach((v) => {
              let i = new Object();
              i.label = v.name;
              i.value = v.id;
              i.key = v.id;
              this.tagList.push(i);
            });
            }
          }
          // console.log(this.tagList);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getProjectFee() {
      this.axios
        .get("/api/v1/lab/getAllFees?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            // console.log(list);
            list.forEach((v) => {
              let i = new Object();
              i.label = v.name;
              i.value = v.id;
              i.key = v.id;
              v.curFee = v.curFee.toFixed(2);
              this.feeList.push(i);
            });

            this.projectFeeList = list;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getPlace() {
      this.axios
        .get("/api/v1/lab/storages?labId=" + this.labId)
        .then((res) => {
          console.log(res.data);
        })
        .catch((error) => {
          console.info(error);
        });
    },
    // 获取采购单列表
    getBuy() {
      this.axios
        .post("/api/v1/lab/getProcurement", {
          labId: this.labId,
          index: this.index - 1,
          pageSize: this.pageSize,
          ascProperties: ["fkLabId"],
          descProperties: ["id"],
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            let list = res.data.data;
            this.pageSize = list.size;
            this.totalElements = list.totalElements;
            this.totalPages = list.totalPages;

            list.data.forEach((v) => {
              let result = this.getLocalTime(v.createTime);
              v._createTime = result;
            });

            this.tableData = list.data;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // 添加采购单
    addBuy() {
      if (
        this.form.fee === "" ||
        this.form.member === "" ||
        this.form.supplier === "" ||
        this.form.name === "" ||
        this.form.total === "" ||
        this.form.tagId === "" ||
        this.form.price === "" ||
        this.form.unit === "" ||
        this.form.properties === "" ||
        this.form.brand === ""
      ) {
        this.Fail("信息不全");
        // console.info("信息不全");
      } else {
        // console.log(this.form);
        let day = this.getFormatDate();
        // console.log({
        //     fkFeeId: this.form.fee,
        //     managerName: this.form.member,
        //     create_time: day,
        //     logisticsInsert: {
        //       fkLabId: this.labId,
        //       name: this.form.name,
        //       typeName: this.form.typeName,
        //       properties: this.form.properties,
        //       total: parseInt(this.form.total),
        //       fkTagId: this.form.tagId,
        //       date: day,
        //       unit: this.form.unit,
        //       remark: this.form.remark,
        //       price: parseInt(this.form.price),
        //       picture: "",
        //       supplierName: this.form.supplier,
        //       brand: this.form.brand,
        //       place: this.form.place,
        //       attachment: this.form.attachment,
        //       cas: this.form.cas,
        //       concentration: this.form.concentration,
        //     },
        //   });
        this.axios
          .post("/api/v1/lab/procurement", {
            fkFeeId: this.form.fee,
            managerName: this.form.member,
            create_time: day,
            logisticsInsert: {
              fkLabId: this.labId,
              name: this.form.name,
              typeName: this.form.typeName,
              properties: this.form.properties,
              total: parseInt(this.form.total),
              fkTagId: this.form.tagId,
              date: day,
              unit: this.form.unit,
              remark: this.form.remark,
              price: parseInt(this.form.price),
              picture: "",
              supplierName: this.form.supplier,
              brand: this.form.brand,
              place: this.form.place,
              attachment: this.form.attachment,
              cas: this.form.cas,
              concentration: this.form.concentration,
              specifications:this.form.specifications
            },
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.Success("添加成功");
              this.dialogVisible = false;
              this.index = 1;
              this.pageSize = 10;
              this.getBuy();
            } else if (res.data.code === 40380) {
              this.Fail("权限不足，无法执行操作");
            }
          })
          .catch((error) => {
            console.info(error);
          });
      }
    },
    openMore(row) {
      // console.log(row);
      this.openForm = row;
      this.dialogVisible1 = true;
    },
    openEdit(row) {
      this.dialogVisible2 = true;
      this.editForm = row;
      // console.log(row);
    },
    putIn() {
      // console.log(this.editForm);
      if (this.editForm.address === "" || this.editForm.remark === "") {
        this.Fail("请填写全部信息");
      } else {
        if(!this.editForm.address){
          this.editForm.address = ' ';
        }
        this.dialogVisible2 = false;
        // console.log(
        //   "/api/v1/lab/procurementLoad?id=" +
        //     this.editForm.id +
        //     "&labId=" +
        //     this.labId +
        //     "&properties=" +
        //     this.editForm.properties +
        //     "&place=" +
        //     this.editForm.address
        // );
        this.axios
          .get(
            "/api/v1/lab/procurementLoad?id=" +
              this.editForm.id +
              "&labId=" +
              this.labId +
              "&properties=" +
              this.editForm.properties +
              "&place=" +
              this.editForm.address
          )
          .then((res) => {
            // console.log(res.data);
            if (res.data.code === 20000) {
              this.Success("入库成功");
              this.index = 1;
              this.pageSize = 10;
              this.getBuy();
            } else if (res.data.code === 40380) {
              this.Fail("权限不足，无法执行操作");
            }
          });
      }
    },

    getFormatDate() {
      let date = new Date();
      let seperator = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let nowDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (nowDate >= 0 && nowDate <= 9) {
        nowDate = "0" + nowDate;
      }
      let newDate = year + seperator + month + seperator + nowDate;
      return newDate;
    },
    add0(m) {
      return m < 10 ? "0" + m : m;
    },
    getLocalTime(nS) {
      //shijianchuo是整数，否则要parseInt转换
      let time = new Date(nS);
      let y = time.getFullYear();
      let m = time.getMonth() + 1;
      let d = time.getDate();
      let h = time.getHours();
      let mm = time.getMinutes();
      let s = time.getSeconds();
      return (
        y +
        "-" +
        this.add0(m) +
        "-" +
        this.add0(d) +
        " " +
        this.add0(h) +
        ":" +
        this.add0(mm) +
        ":" +
        this.add0(s)
      );
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.buy {
  width: 100%;
  height: 100%;
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  box-shadow: var(--shadow2);
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}

.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* background-color: #E9EEF3; */
  color: #333;
  text-align: right;
}

.content {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 53px;
  /* background-color: red; */
}

.upper > * {
  box-shadow: var(--shadow2);
}
.upper .el-input-group__append .el-button {
  transform: translateY(1px);
  background-color: var(--primary);
  color: white;
  border-radius: 0 2px 2px 0;
}
.describle {
  color: var(--text3);
  float: left;
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.middle {
  width: 100%;
  min-height: calc(700px - 66px);
  margin-top: 13px;
  padding: 20px;
  background-color: white;
  border-radius: 4px;

  box-shadow: var(--shadow2);
  box-sizing: border-box;
}

.middle_head {
  width: 100%;
  height: calc(634px - 75px);
  background-color: white;
  overflow-x: hidden;
}
.middle_head ::-webkit-scrollbar {
  display: none;
}
.middle_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}
.form_item {
  margin-top: 28px;
  width: 100%;
}
.form_item .el-input {
  width: 178px;
}
.form_longItem {
  margin-top: 28px;
  width: 100%;
}
.form_longItem .el-input {
  width: 500px;
}

/* 适配 */
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
@media screen and (max-width: 500px) {
  .content {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
</style>