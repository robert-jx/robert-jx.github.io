<template>
  <div class='setting'></div>
</template>

<script>
export default {
  name: 'Setting',
  data () {
    return {
      
    };
  },
  components: {},
  mounted () {},
  methods: {}
}
</script>

<style scoped>
.setting{
  width: 100%;
  height: 100%;
}
</style>