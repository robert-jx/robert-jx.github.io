<template>
  <div class="supplier">
    <el-container>
      <el-header>
        <span>供应商管理</span>
      </el-header>
      <el-main>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="供应商列表" name="first">
            <div class="content">
              <div class="upper">
                <el-button
                  type="primary"
                  style="float: left"
                  @click="dialogVisible = true"
                  :disabled="myList.role == 'MEMBER'"
                  >新增供应商</el-button
                >
                <span class="describle"
                  >功能简介：管理员可在此查看、添加、修改以及删除与实验室合作的供应商信息</span
                >

                <!-- <el-button type="primary" style="float: left"
                  >招商/防骚扰</el-button
                > -->
                <!-- <el-input
                  v-model="keyword"
                  style="float: right; width: 400px"
                  placeholder="搜索供应商"
                  @keydown="selectSupplier()"
                >
                  <el-button
                    type="primary"
                    slot="append"
                    icon="el-icon-search"
                    @click="selectSupplier()"
                    >搜索</el-button
                  >
                </el-input> -->
                <el-dialog
                  title="新增供应商"
                  :visible.sync="dialogVisible"
                  width="640px"
                  style="text-align: left"
                >
                  <el-form ref="form" :model="form" label-width="110px">
                    <el-form-item label="*公司名称">
                      <el-row>
                        <el-col :span="8">
                          <el-input
                            v-model="form.name"
                            placeholder="请输入供应商名称"
                          ></el-input>
                        </el-col>
                        <el-col :span="4" style="margin-left: 14px">
                          *公司联系人</el-col
                        >
                        <el-col :span="8">
                          <el-input
                            v-model="form.contact_person"
                            placeholder="请输入联系人名称"
                          ></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="*实验室联络人">
                      <el-row>
                        <el-col>
                          <el-select
                            v-model="form.contact_member"
                            placeholder="请选择联络人"
                          >
                            <el-option
                              v-for="item in contactList"
                              :key="item.value"
                              :label="item.label"
                              :value="item.value"
                            ></el-option>
                          </el-select>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="*手机号码">
                      <el-row>
                        <el-col :span="8">
                          <el-input
                            v-model="form.mobile"
                            placeholder="请输入联系人手机号码"
                            oninput="if(value.length>11)value=value.slice(0,11)"
                          ></el-input>
                        </el-col>
                        <el-col :span="3" style="margin-left: 14px">
                          座机
                        </el-col>
                        <el-col :span="8">
                          <el-input
                            v-model="form.phone"
                            placeholder="请输入座机号码"
                          ></el-input>
                        </el-col>
                      </el-row>
                    </el-form-item>
                    <el-form-item label="邮箱">
                      <el-input
                        v-model="form.email"
                        placeholder="请输入邮箱,例:********@163.com"
                        type="email"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="地址">
                      <el-input
                        v-model="form.address"
                        placeholder="请输入地址"
                      ></el-input>
                    </el-form-item>
                    <el-form-item label="备注">
                      <el-input
                        v-model="form.remark"
                        placeholder="请输入备注"
                        type="textarea"
                        :rows="8"
                        resize="none"
                      ></el-input>
                    </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="dialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="addSupplier()"
                      >确 定</el-button
                    >
                  </span>
                </el-dialog>
              </div>
              <div class="middle">
                <div class="middle_head">
                  <el-table
                    ref="multipleTable"
                    tooltip-effect="dark"
                    style="width: 100%"
                    @selection-change="handleSelectionChange"
                    :data="
                      tableData.filter(
                        (data) =>
                          !search ||
                          data.name
                            .toLowerCase()
                            .includes(search.toLowerCase()) ||
                          data.contact_person
                            .toLowerCase()
                            .includes(search.toLowerCase()) ||
                          data.contact_member
                            .toLowerCase()
                            .includes(search.toLowerCase()) ||
                          data.address
                            .toLowerCase()
                            .includes(search.toLowerCase()) ||
                          data.phone
                            .toLowerCase()
                            .includes(search.toLowerCase())
                      )
                    "
                  >
                    <el-table-column type="selection" width="55">
                    </el-table-column>
                    <el-table-column
                      prop="name"
                      label="供应商名称"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="contact_person"
                      label="供应商联系人"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="contact_member"
                      label="实验室联络人"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="phone"
                      label="手机"
                      width="120"
                    ></el-table-column>
                    <el-table-column
                      prop="address"
                      label="地址"
                      show-overflow-tooltip
                    >
                    </el-table-column>
                    <el-table-column fixed="right" label="操作" width="180">
                      <template slot="header">
                        <el-input
                          v-model="search"
                          size="mini"
                          placeholder="输入关键字搜索"
                        />
                      </template>
                      <template slot-scope="scope">
                        <el-button
                          @click.native.prevent="openMore(scope.row)"
                          type="text"
                          size="small"
                        >
                          详情
                        </el-button>
                        <el-button
                          @click.native.prevent="openEdit(scope.row)"
                          type="text"
                          size="small"
                          :disabled="
                            myList.role != 'ADMIN' && myList.role != 'OWNER'
                          "
                        >
                          编辑
                        </el-button>
                        <el-button
                          @click.native.prevent="
                            deleteSupplier(scope.$index, scope.row, tableData)
                          "
                          type="text"
                          size="small"
                          style="color: red"
                          :disabled="
                            myList.role != 'ADMIN' && myList.role != 'OWNER'
                          "
                        >
                          删除
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                  <el-dialog
                    title="查看详情"
                    :visible.sync="dialogVisible1"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="openForm" label-width="110px">
                      <el-form-item label="公司名称">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openForm.name"
                              placeholder="请输入供应商名称"
                              readonly
                            ></el-input>
                          </el-col>
                          <el-col :span="4" style="margin-left: 14px">
                            公司联系人</el-col
                          >
                          <el-col :span="8">
                            <el-input
                              v-model="openForm.contact_person"
                              placeholder="请输入联系人名称"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="实验室联络人">
                        <el-row>
                          <el-col>
                            <el-select
                              v-model="openForm.contact_member"
                              placeholder="请选择联络人"
                              disabled
                            >
                              <el-option
                                v-for="item in contactList"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                              ></el-option>
                            </el-select>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="手机号码">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="openForm.mobile"
                              placeholder="请输入联系人手机号码"
                              readonly
                            ></el-input>
                          </el-col>
                          <el-col :span="3" style="margin-left: 14px">
                            座机
                          </el-col>
                          <el-col :span="8">
                            <el-input
                              v-model="openForm.phone"
                              placeholder="请输入座机号码"
                              readonly
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="邮箱">
                        <el-input
                          v-model="openForm.email"
                          placeholder="请输入邮箱,例:********@163.com"
                          type="email"
                          readonly
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="地址">
                        <el-input
                          v-model="openForm.address"
                          placeholder="请输入地址"
                          readonly
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="备注">
                        <el-input
                          v-model="openForm.remark"
                          placeholder="请输入备注"
                          type="textarea"
                          :rows="8"
                          resize="none"
                          readonly
                        ></el-input>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <!-- <el-button @click="dialogVisible1 = false">取 消</el-button> -->
                      <el-button type="primary" @click="dialogVisible1 = false"
                        >关 闭</el-button
                      >
                    </span>
                  </el-dialog>
                  <el-dialog
                    title="编辑供应商"
                    :visible.sync="dialogVisible2"
                    width="640px"
                    style="text-align: left"
                  >
                    <el-form ref="form" :model="editForm" label-width="90px">
                      <el-form-item label="*公司名称">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="editForm.name"
                              placeholder="请输入供应商名称"
                            ></el-input>
                          </el-col>
                          <el-col :span="3" style="margin-left: 14px">
                            *联系人</el-col
                          >
                          <el-col :span="8">
                            <el-input
                              v-model="editForm.contact_person"
                              placeholder="请输入联系人名称"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*联络人">
                        <el-row>
                          <el-col>
                            <el-select
                              v-model="editForm.contact_member"
                              placeholder="请选择联络人"
                            >
                              <el-option
                                v-for="item in contactList"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                              ></el-option>
                            </el-select>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="*手机号码">
                        <el-row>
                          <el-col :span="8">
                            <el-input
                              v-model="editForm.mobile"
                              placeholder="请输入联系人手机号码"
                            ></el-input>
                          </el-col>
                          <el-col :span="3" style="margin-left: 14px">
                            座机
                          </el-col>
                          <el-col :span="8">
                            <el-input
                              v-model="editForm.phone"
                              placeholder="请输入座机号码"
                            ></el-input>
                          </el-col>
                        </el-row>
                      </el-form-item>
                      <el-form-item label="邮箱">
                        <el-input
                          v-model="editForm.email"
                          placeholder="请输入邮箱,例:********@163.com"
                          type="email"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="地址">
                        <el-input
                          v-model="editForm.address"
                          placeholder="请输入地址"
                        ></el-input>
                      </el-form-item>
                      <el-form-item label="备注">
                        <el-input
                          v-model="editForm.remark"
                          placeholder="请输入备注"
                          type="textarea"
                          :rows="8"
                          resize="none"
                        ></el-input>
                      </el-form-item>
                    </el-form>
                    <span slot="footer" class="dialog-footer">
                      <el-button @click="dialogVisible2 = false"
                        >取 消</el-button
                      >
                      <el-button type="primary" @click="editSupplier()"
                        >确 定</el-button
                      >
                    </span>
                  </el-dialog>
                </div>
                <div class="middle_foot">
                  <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="index"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalElements"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <!-- <el-tab-pane label="申请列表" name="second"> apply </el-tab-pane> -->
        </el-tabs>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Supplier",
  data() {
    return {
      labId: "",
      activeName: "first",

      myList: {},
      dialogVisible: false,
      dialogVisible1: false,
      dialogVisible2: false,
      contactList: [],
      groupList: [],
      keyword: "",
      search: "",
      form: {
        name: "",
        contact_person: "",
        contact_member: "",
        phone: "",
        mobile: "",
        email: "",
        address: "",
        remark: "",
      },
      openForm: {},
      editForm: {},
      list: [],
      tableData: [
        {
          name: "程序猿公司",
          contact_person: "程序猿一号",
          contact_member: "程序猿",
          phone: "169********",
          address: "深圳市**区**大道**号",
        },
      ],
      selection: [],

      // 分页
      index: 1,
      pageSize: 10,
      totalPages: 0,
      totalElements: 0,
    };
  },
  created() {
    this.getLabId();
  },
  components: {},
  mounted() {},
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.selection = val;
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.tableData.length = 0;
      // console.log(this.pageSize);
      this.getSupplier();
    },
    handleCurrentChange(val) {
      this.index = val;
      // console.log(this.index);
      this.tableData.length = 0;
      this.getSupplier();
    },
    getLabId() {
      this.labId = JSON.parse(this.getCookie("currentlab")).fkLabId;
      this.getContactList();
      this.getSupplier();
      this.getMyRole();
    },
    getMyRole() {
      this.axios
        .get("/api/v1/lab/self", {
          params: {
            labId: this.labId,
          },
        })
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            this.myList = res.data.data;
            // console.log(this.myList);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    getContactList() {
      this.axios
        .get("/api/v1/lab/researchGroupsAndDetails?labId=" + this.labId)
        .then((res) => {
          // console.log(res.data);
          if (res.data.code === 20000) {
            // console.log('1');
            let list = res.data.data;
            let bufferList = [];
            // console.log(list);
            for (let key in list.labDetails) {
              let i = new Object();
              i.label = list.labDetails[key][2];
              i.value = list.labDetails[key][2];
              // i.key = list.labDetails[key][0];
              // i.role = list.labDetails[key][1];
              bufferList.push(i);
            }
            this.contactList = bufferList;
            // this.memberList1 = bufferList;
            // this.groupList = list.researchGroupDetails;
            // console.log(this.contactList);
            // console.log(this.groupList);
          }
        })
        .catch(() => {
          console.log("网络环境不佳，请稍后再试");
        });
    },
    getSupplier() {
      // console.log(this.labId);
      this.axios
        .get("/api/v1/utils/SBPs/suppliers/" + this.labId)
        .then((res) => {
          // console.log(res);
          // console.log(res.data);
          if (res.data != null) {
            res.data.forEach((v) => {
              // console.log(v);
              if (v.isUsed != false) {
                this.list.push(v);
              }
            });
            // console.log(this.list);
            this.tableData.length = 0;
            let bufferList = [];
            this.totalElements = 0;
            this.totalPages = 0;
            this.totalElements = this.list.length;
            if (this.totalElements > this.pageSize) {
              this.totalPages = this.totalElements / this.pageSize;
            } else {
              this.totalPages = 1;
            }
            for (
              let key = (this.index - 1) * 10;
              key < (this.index - 1) * 10 + this.pageSize;
              key++
            ) {
              if (this.list[key]) {
                bufferList.push(this.list[key]);
              } else break;
            }
            this.tableData = bufferList;
            this.list.length = 0;
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },
    // form: {
    //     name: "",
    //     supplier: "",
    //     contact: "",
    //     phone: "",
    //     landline: "",
    //     email: "",
    //     address: "",
    //     remarks: "",
    //   },
    addSupplier() {
      if (
        this.form.name == "" ||
        this.form.contact_person == "" ||
        this.form.contact_member == "" ||
        this.form.mobile == ""
      ) {
        this.Fail("请填写完必选信息");
      } else {
        this.dialogVisible = false;
        this.axios
          .post("/api/v1/utils/SBPs/suppliers", {
            lab_id: this.labId.toString(),
            name: this.form.name,
            contact_person: this.form.contact_person,
            contact_member: this.form.contact_member,
            phone: this.form.phone,
            mobile: this.form.mobile,
            email: this.form.email,
            address: this.form.address,
            remark: this.form.remark,
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.id) {
              this.Success("添加成功");
              // this.tableData = [];

              this.index = 1;
              this.pageSize = 10;
              this.totalElements++;

              // setTimeout(function () {
              //   window.location.reload();
              // }, 1300);
              this.getSupplier();
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    selectSupplier() {
      if (this.keyword == "") {
        this.Fail("请输入要搜索的信息");
      } else {
        this.axios
          .get("/api/v1/utils/SBPs/suppliers/" + this.keyword)
          .then((res) => {
            // console.log(res.data);
            if (res.data != null) {
              res.data.forEach((v) => {
                // console.log(v);
                if (v.isUsed != false) {
                  this.list.push(v);
                }
              });
              // console.log(this.list);
              this.tableData.length = 0;
              let bufferList = [];
              this.totalElements = 0;
              this.totalPages = 0;
              this.totalElements = this.list.length;
              if (this.totalElements > this.pageSize) {
                this.totalPages = this.totalElements / this.pageSize;
              } else {
                this.totalPages = 1;
              }
              for (
                let key = (this.index - 1) * 10;
                key < (this.index - 1) * 10 + this.pageSize;
                key++
              ) {
                if (this.list[key]) {
                  bufferList.push(this.list[key]);
                } else break;
              }
              this.tableData = bufferList;
              this.list.length = 0;
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    openMore(row) {
      // console.log(row);
      this.openForm = row;
      this.dialogVisible1 = true;
    },
    openEdit(row) {
      // console.log(row);
      this.editForm = row;
      this.dialogVisible2 = true;
    },

    editSupplier() {
      if (
        this.editForm.name == "" ||
        this.editForm.contact_person == "" ||
        this.editForm.contact_member == "" ||
        this.editForm.mobile == ""
      ) {
        this.Fail("信息不全");
      } else {
        this.dialogVisible2 = false;
        this.axios
          .put("/api/v1/utils/SBPs/suppliers/" + this.editForm._id, {
            name: this.editForm.name,
            contact_person: this.editForm.contact_person,
            contact_member: this.editForm.contact_member,
            phone: this.editForm.phone,
            mobile: this.editForm.mobile,
            email: this.editForm.email,
            address: this.editForm.address,
            remark: this.editForm.remark,
          })
          .then((res) => {
            // console.log(res.data);
            if (res.data.requestId) {
              this.Success("修改成功");
              this.index = 1;
              this.pageSize = 10;
              this.getSupplier();

              // setTimeout(function () {
              //   window.location.reload();
              // }, 1300);
            }
          })
          .catch((error) => {
            console.log(error);
          });
      }
    },
    deleteSupplier(index, rows, tableData) {
      this.$confirm("此操作将永久删除该供应商, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // console.log({
          //   name: rows.name,
          //   contact_person: rows.contact_person,
          //   contact_member: rows.contact_member,
          //   phone: rows.phone,
          //   mobile: rows.mobile,
          //   email: rows.email,
          //   address: rows.address,
          //   remark: rows.remark,
          //   isUsed: false,
          // });
          this.axios
            .put("/api/v1/utils/SBPs/suppliers/" + rows._id, {
              name: rows.name,
              contact_person: rows.contact_person,
              contact_member: rows.contact_member,
              phone: rows.phone,
              mobile: rows.mobile,
              email: rows.email,
              address: rows.address,
              remark: rows.remark,
              isUsed: false,
            })
            .then((res) => {
              // console.log(res.data);
              if (res.data.requestId) {
                this.Success("删除成功");
                this.totalElements--;
                tableData.splice(index, 1);
                this.index = 1;
                this.pageSize = 10;

                // setTimeout(function () {
                //   window.location.reload();
                // }, 1300);
                this.getSupplier();
              }
            })
            .catch((error) => {
              console.log(error);
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
      // this.dialogVisible2 = false;
    },
    Success(index) {
      this.$message({
        message: index,
        type: "success",
      });
    },
    Fail(index) {
      this.$message({
        message: index,
        type: "warning",
      });
    },
  },
};
</script>

<style scoped>
.supplier {
  width: 100%;
  height: 100%;
}
.el-container {
  width: 100%;
  height: 100%;
}
.el-header {
  background-color: #ffffff;
  box-shadow: var(--shadow2);
  color: #1e2127;
  font-size: 18px;
  line-height: 60px;
  user-select: none;
}

.el-main {
  width: 100%;
  height: 100%;
  padding: 0;
  /* background-color: #E9EEF3; */
  color: #333;
  text-align: right;
}
.content {
  min-width: 1000px;
  max-width: 1200px;
  min-height: 700px;
  margin-left: auto;
  margin-right: auto;
  margin-top: 24px;
  /* background-color: white; */
  /* box-shadow: var(--shadow2);
    border-radius: 4px; */
}
.upper {
  width: 100%;
  height: 53px;
  /* background-color: red; */
}
.upper > * {
  box-shadow: var(--shadow2);
}
.upper .el-input-group__append .el-button {
  transform: translateY(1px);
  background-color: var(--primary);
  color: white;
  border-radius: 0 2px 2px 0;
}

.describle {
  color: var(--text3);
  float: left;
  margin-left: 16px;
  line-height: 40px;
  box-shadow: none;
  user-select: none;
  font-weight: 600;
  font-size: 14px;
}
.middle {
  width: 100%;
  min-height: calc(700px - 66px);
  margin-top: 13px;
  padding: 20px;
  background-color: white;
  border-radius: 4px;

  box-shadow: var(--shadow2);
  box-sizing: border-box;
}
.middle_head {
  width: 100%;
  height: calc(700px - 145px);
  background-color: white;
  overflow-x: hidden;
}
.middle_head ::-webkit-scrollbar {
  display: none;
}
.middle_foot {
  width: 100%;
  height: 35px;
  text-align: right;
  background-color: white;
}
/* 适配 */
@media screen and (max-width: 1366px) {
  .content {
    min-width: 700px;
    max-width: 1000px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
@media screen and (max-width: 500px) {
  .content {
    min-width: 200px;
    max-width: 300px;
    min-height: 700px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 24px;
    /* background-color: white; */
    /* box-shadow: var(--shadow2);
    border-radius: 4px; */
  }
}
</style>
<style>
.el-tabs__nav-scroll {
  padding-left: 20px;
  background-color: white;
}
</style>