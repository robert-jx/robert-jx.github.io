import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const nav = {
  Nav: () => import('../views/nav/Nav'),
  Foo: () => import('../views/nav/Foo'),
}
const work = {
  Work: () => import('../views/work/Work'),
  SideBar: () => import('../views/work/SideBar'),

  Center: () => import('../views/work/center/Center.vue'),
  Buy: () => import('../views/work/buy/Buy.vue'),

  Instrument: () => import('../views/work/stock/Instrument.vue'),
  Drugs: () => import('../views/work/stock/Drugs.vue'),
  Label: () => import('../views/work/stock/Label.vue'),
  Preserve: () => import('../views/work/stock/Preserve.vue'),
  Storage: () => import('../views/work/stock/Storage.vue'),

  Group: () => import('../views/work/members/Group.vue'),
  Members: () => import('../views/work/members/Members.vue'),

  Apply: () => import('../views/work/apply/Apply.vue'),
  Supplier: () => import('../views/work/supplier/Supplier.vue'),
  Project: () => import('../views/work/project/Project.vue'),
  Document: () => import('../views/work/document/Document.vue'),
  Setting: () => import('../views/work/setting/Setting.vue'),
}



const routes = [
  // 工作台
  {
    path: '/',
    components: {
      nav: nav.Nav,
      main: work.Work
    },
    children: [
      // 控制中心
      {
        path: '',
        components: {

          sidebar: work.SideBar,
          content: work.Center
        }
      },
      // 采购管理
      {
        path: 'buy',
        components: {

          sidebar: work.SideBar,
          content: work.Buy
        }
      },
      // 仪器与预约
      {
        path: 'instrument',
        components: {
          sidebar: work.SideBar,
          content: work.Instrument
        }
      },
      // 试剂与耗材
      {
        path: 'drugs',
        components: {
          sidebar: work.SideBar,
          content: work.Drugs
        }
      },
      // 保藏中心
      {
        path: 'preserve',
        components: {
          sidebar: work.SideBar,
          content: work.Preserve
        }
      },
      // 分类标签与策略设置
      {
        path: 'label',
        components: {
          sidebar: work.SideBar,
          content: work.Label
        }
      },
      // 存储管理与设置
      {
        path: 'storage',
        components: {
          sidebar: work.SideBar,
          content: work.Storage
        }
      },
      // 成员
      {
        path: 'members',
        components: {

          sidebar: work.SideBar,
          content: work.Members
        }
      },
      // 课题组
      {
        path: 'group',
        components: {

          sidebar: work.SideBar,
          content: work.Group
        }
      },
      // 申请与审批
      {
        path: 'apply',
        components: {

          sidebar: work.SideBar,
          content: work.Apply
        }
      },
      // 供应商管理
      {
        path: 'supplier',
        components: {

          sidebar: work.SideBar,
          content: work.Supplier
        }
      },
      // 项目经费与报销
      {
        path: 'project',
        components: {

          sidebar: work.SideBar,
          content: work.Project
        }
      },
      // 项目经费与报销
      {
        path: 'document',
        components: {
          sidebar: work.SideBar,
          content: work.Document
        }
      },
      // 设置
      {
        path: 'setting',
        components: {

          sidebar: work.SideBar,
          content: work.Setting
        }
      },

    ]
  },

]

const router = new VueRouter({
  mode: 'history',
  routes: routes
})

export default router