const Mock = require('mockjs')

const Random = Mock.Random

Mock.mock('/api/memberList','get',function(){
  return Mock.mock({
    'list|2-20':{
      'name':Random.cnmae,
      'actor':Random.cname,
      'describle':Random.cparagraph()
    }
  })
})

Mock.mock('/api/invite','post',function(){
  return Mock.mock({
    'data':'sdaklfjklajweio'
  })
})