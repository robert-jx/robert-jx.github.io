import Vue from 'vue'

const util = {
  // 判定是否Mac
  isMacBook() {
    let agent = navigator.userAgent;
    let reg = /macintosh|mac os x/i;
    return reg.test(agent);
  },
  // 跳转路径
  goPath(path, query = {}) {
    if (!path) return;
    if (this.$route.path == path) return;
    this.$router.push({
      path,
      query
    });
  },
  // 设置cookie
  setCookie(name, val, exdays) {
    val = encodeURI(val);
    let data = name + "=" + val + "; "
    let time = Date.now() + (exdays * 24 * 60 * 60 * 1000);
    let expires = "expires=" + new Date(time).toGMTString() + '; ';
    let path = "path=/; ";
    // let domain = "domain=" + ".keyanplus.com"; 
    let domain = "domain=" + document.domain;
    if (domain.indexOf('keyanplus') != -1) domain = "domain=" + ".keyanplus.com";
    
    document.cookie = data + expires + path + domain;
  },
  // 获取cookie
  getCookie(name) {
    let list = document.cookie.split(';');
    for (let i = 0; i < list.length; i++) {
      let item = list[i].trim();
      if (item.indexOf(name + '=') == 0) {
        let result = item.substring(name.length + 1, item.length);
        return decodeURI(result);
      }
    }
    return "";
  },
  // 检察手机号
  checkPhone(val) {
    val += "";
    let reg = /^1[0-9]{10}$/;
    if (!reg.test(val)) return false;
    return true;
  },
  // 检察邮箱
  checkEmail(val) {
    val += "";
    if (val.indexOf('@') == -1) return false;
    return true;
  },
  // 转为unicode 编码
  encodeUnicode(str) {
    var res = []
    for (var i = 0; i < str.length; i++) {
      res[i] = ('00' + str.charCodeAt(i).toString(16)).slice(-4)
    }
    return '\\u' + res.join('\\u')
  },
  // 解码  
  decodeUnicode(str) {
    str = str.replace(/\\/g, '%')
    //转换中文
    str = unescape(str)
    //将其他受影响的转换回原来
    str = str.replace(/%/g, '\\')
    //对网址的链接进行处理
    str = str.replace(/\\/g, '')
    return str
  },

}

Vue.prototype.isMacBook = util.isMacBook
Vue.prototype.goPath = util.goPath
Vue.prototype.setCookie = util.setCookie
Vue.prototype.getCookie = util.getCookie
Vue.prototype.checkPhone = util.checkPhone
Vue.prototype.checkEmail = util.checkEmail
Vue.prototype.encodeUnicode = util.encodeUnicode
Vue.prototype.decodeUnicode = util.decodeUnicode

Vue.prototype.path = {
  main: 'https://keyanplus.com/',
  // main: 'http://localhost:8200/',
  work: 'https://console.keyanplus.com/'
}