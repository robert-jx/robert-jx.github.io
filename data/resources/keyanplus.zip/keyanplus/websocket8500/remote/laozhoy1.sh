
#cd ..
#
#mvn clean package

#
#scp /Users/wujinglun/IdeaProjects/keyanplus/websocket8500/target/websocket8500-0.0.1-SNAPSHOT.jar root@www.laozhoy1.club:/root/javaee
scp /Users/wujinglun/IdeaProjects/keyanplus/websocket8500/target/websocket8500-0.0.1-SNAPSHOT.jar root@keyanplus:/root/kyp/kyp-jar/third
