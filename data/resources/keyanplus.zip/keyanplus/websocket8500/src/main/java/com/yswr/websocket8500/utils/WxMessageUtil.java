package com.yswr.websocket8500.utils;

import com.thoughtworks.xstream.XStream;
import com.yswr.websocket8500.wx_message_handlers.AbstractWxHttpMessageHandler;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class WxMessageUtil {
    public static final Map<String, AbstractWxHttpMessageHandler> wxMessageUtilMap = new ConcurrentHashMap<>();

    private static final XStream xStream =new XStream();
    public static Map<String, String> parseXml(HttpServletRequest request)  {
        Map<String, String> map = new HashMap<String, String>();
        try (InputStream inputStream = request.getInputStream()){
            SAXReader reader = new SAXReader();
            Document document = reader.read(inputStream);
            Element root = document.getRootElement();
            List<Element> elementList = root.elements();
            for (Element e : elementList) {
                map.put(e.getName(), e.getText());
            }
            return map;
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static String objectToXml(Object object,Class<?> clazz) {
        xStream.alias("xml", clazz);
        return xStream.toXML(object);
    }

}
