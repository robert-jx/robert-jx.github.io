//package com.yswr.websocket8500.configuration;
//
//import com.yswr.websocket8500.utils.MQConsumeMsgListenerProcessor;
//import lombok.Data;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
//import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
//import org.apache.rocketmq.client.exception.MQClientException;
//import org.apache.rocketmq.common.consumer.ConsumeFromWhere;
//import org.apache.rocketmq.common.message.MessageExt;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.annotation.PostConstruct;
//import javax.annotation.Resource;
//import java.util.List;
//
//@Configuration
//@Slf4j
//@Data
//@ConfigurationProperties(prefix = "rocketmq.wx-message-consumer")
//public class RocketMqConsumerConfiguration {
//
//    //labprovider8003
//    private String labGroupName;
//    private String nameSrvAddr;
//    //wxTM~*
//    private String topics;
//    private Integer     consumeThreadMin;
//    private Integer consumeThreadMax;
//    private Integer consumeMessageBatchMaxSize;
//
//    @Resource
//    private MQConsumeMsgListenerProcessor consumeMsgListenerProcessor;
//    /**
//     * mq 消费者配置
//     * @return
//     * @throws MQClientException
//     */
//    @PostConstruct//spring初始化注解，只会调用一次
//    @ConditionalOnProperty(prefix = "rocketmq.wx-message-consumer", value = "isOnOff", havingValue = "on")
//    public DefaultMQPushConsumer defaultConsumer() throws MQClientException {
//        log.info("defaultConsumer 正在创建---------------------------------------");
////        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(labGroupName);
//        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("labprovider8003");
////        consumer.setNamesrvAddr(nameSrvAddr);
//        consumer.setNamesrvAddr("keyanplus.com:9876");
//        consumer.setConsumeThreadMin(consumeThreadMin);
//        consumer.setConsumeThreadMax(consumeThreadMax);
////        consumer.setConsumeMessageBatchMaxSize(consumeMessageBatchMaxSize);
//        // 设置监听
//        consumer.registerMessageListener(consumeMsgListenerProcessor);
//
//        /**
//         * 设置consumer第一次启动是从队列头部开始还是队列尾部开始
//         * 如果不是第一次启动，那么按照上次消费的位置继续消费
//         */
//        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
//        /**
//         * 设置消费模型，集群还是广播，默认为集群
//         */
////        consumer.setMessageModel(MessageModel.CLUSTERING);
//        log.info("{}",this);
//        try {
//            // 设置该消费者订阅的主题和tag，如果订阅该主题下的所有tag，则使用*,
////            String[] topicArr = topics.split(";");
////            if (topicArr!=null){
////
////                for (String tag : topicArr) {
////                    String[] tagArr = tag.split("~");
////                    consumer.subscribe(tagArr[0], tagArr[1]);
////                }
////            }
//            consumer.subscribe("wxTM","*");
//            consumer.start();
//            log.info("consumer 创建成功 groupName={}, topics={}, namesrvAddr={}",labGroupName,topics,nameSrvAddr);
//        } catch (MQClientException e) {
//            log.error("consumer 创建失败!");
//        }
//        return consumer;
//    }
//}
