package com.yswr.websocket8500.wx_message_handlers;


import org.springframework.beans.factory.InitializingBean;

import java.util.Map;

public interface WxMessageHandler extends InitializingBean {
    public Object Handle(Map<String,String> params) ;
}
