package com.yswr.websocket8500.utils;

import com.yswr.websocket8500.constant.BaseMessage;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtil {

    @Resource
    RedisTemplate<String,Object> redisTemplate ;

    public static final String WX_TOKEN_KEY = "SYSTEM_WX_ACCESS_TOKEN";


    public void setWxAccessToken(String token,Integer time){
        redisTemplate.opsForValue().set(WX_TOKEN_KEY,token,time, TimeUnit.SECONDS);
    }

    public String getWxAccessToken(){
        Object o =redisTemplate.opsForValue().get(WX_TOKEN_KEY);
        return o==null?null:o.toString();
    }

    public void setLoginStatus(String ticket,Integer time,String status){
        redisTemplate.opsForValue().set(ticket.substring(2,6),status,time,TimeUnit.SECONDS);
    }
    @Deprecated
    public void setLoginBaseMessage(String state, String baseMessage,Integer time){
        redisTemplate.opsForValue().set(state,baseMessage,time,TimeUnit.SECONDS);
    }



    public String  getLoginStatus(String ticket){
        Object o  = redisTemplate.opsForValue().get(ticket.substring(2,6));
        return o==null?null:o.toString();
    }


}
