package com.yswr.websocket8500.constant;

import com.yswr.websocket8500.utils.RedisUtil;
import com.yswr.websocket8500.utils.RestUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Slf4j
@Component
public class WxTokenHolder {

    @Resource
    RedisUtil redisUtil;

    @Resource
    RestUtil restUtil;
    private String accessToken = null;

    private Long outTime = System.currentTimeMillis();

    public Long getOutTime() {
        return outTime;
    }

    public void setOutTime(Long outTime) {
        this.outTime = outTime;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getToken(){

//          服务重启时
        if (StringUtils.isEmpty(accessToken)){
            accessToken = redisUtil.getWxAccessToken();
            if (StringUtils.isEmpty(accessToken)){
                WxTokenMessage wxTokenMessage = restUtil.getWxTokenMessage();
                log.info("{}",wxTokenMessage);
                accessToken = wxTokenMessage.getAccess_token();
                redisUtil.setWxAccessToken(wxTokenMessage.getAccess_token(),wxTokenMessage.getExpires_in());
                setOutTime(System.currentTimeMillis()+wxTokenMessage.getExpires_in()*1000-60000L);
                setAccessToken(accessToken);
                log.info("getToken : ===> AccessToken :{} Expired In {}, outTime :{}",accessToken,wxTokenMessage.getExpires_in(),outTime);
            }
        }
//            token即将过期时，重置redis 与 本地时间（7200 -100）
        else if (outTime-System.currentTimeMillis()<100*1000){
            WxTokenMessage wxTokenMessage = restUtil.getWxTokenMessage();
            log.info("{}",wxTokenMessage);
            accessToken = wxTokenMessage.getAccess_token();
            redisUtil.setWxAccessToken(accessToken,wxTokenMessage.getExpires_in());
            setOutTime(System.currentTimeMillis()+wxTokenMessage.getExpires_in()*1000-60000L);
            setAccessToken(accessToken);
            log.info("getToken : ===> AccessToken :{} Expired In {}, outTime :{}",accessToken,wxTokenMessage.getExpires_in(),outTime);

        }else {
            log.info("getToken : ===> AccessToken :{}, outTime :{}",accessToken,outTime);
        }
        return accessToken;
    }

    public void reloadToken(){
        accessToken = redisUtil.getWxAccessToken();
        WxTokenMessage wxTokenMessage = restUtil.getWxTokenMessage();
        log.info("{}",wxTokenMessage);
        accessToken = wxTokenMessage.getAccess_token();
        redisUtil.setWxAccessToken(wxTokenMessage.getAccess_token(),wxTokenMessage.getExpires_in());
        setOutTime(wxTokenMessage.getExpires_in()-60L*1000);
        log.info("reloadToken : ===> AccessToken :{} , outTime :{}",accessToken,outTime);
    }
}
