package com.yswr.websocket8500;

import com.alibaba.fastjson.JSONObject;
import com.yswr.websocket8500.constant.*;
import com.yswr.websocket8500.utils.RedisUtil;
import com.yswr.websocket8500.utils.RestUtil;
import com.yswr.websocket8500.utils.WxMessageUtil;
import com.yswr.websocket8500.wx_message_handlers.AbstractWxHttpMessageHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.tomcat.util.http.LegacyCookieProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@SpringBootApplication
@EnableDiscoveryClient
@RefreshScope
@Slf4j

@EnableScheduling
public class Websocket8500Application {

    public static void main(String[] args) {
        SpringApplication.run(Websocket8500Application.class, args);
    }


    @Bean
    public ServerEndpointExporter serverEndpointExporter() {
        return new ServerEndpointExporter();
    }
    @Bean
    public WebServerFactoryCustomizer<TomcatServletWebServerFactory> cookieProcessorCustomizer() {
        return (factory) -> factory.addContextCustomizers(
                (context) -> context.setCookieProcessor(new LegacyCookieProcessor()));
    }

    @RestController
    @RequestMapping("/third")
    public static class BasicController{

        @Resource
        RestUtil restUtil;
        @Resource
        WxTokenHolder wxTokenHolder;
        @Resource
        RedisUtil redisUtil;

        private static final String WX_MP_APPROVAL_APPLICATION_URL= "keyanplus.com";
        private static final String TM_APPLICATION_NEED_APPROVAL = "j64TIk_KRFVfZN72SaTlwjygthTOANeC32n5LhZADbs";
        private static  final  String token ="qgS3jn";




        @PostMapping(value = "/wx/public",consumes = {"text/xml;charset=UTF-8"},produces={"application/xml; charset=UTF-8"})
        public Object getMessage(HttpServletRequest request){
            try {
                Map<String,String> types =  WxMessageUtil.parseXml(request);
                if (types==null){
                    return "Analysis fail";
                }
                AbstractWxHttpMessageHandler w= WxMessageUtil.wxMessageUtilMap.get(types.get("MsgType").trim());
                if (w==null){
                    return "fail";
                }
                return  w.Handle(types);
            }catch (Exception e){
                e.printStackTrace();
                return "fail";
            }
        }


        public static final int WX_QRCODE_EXPIRED_SECONDS = 600;

        /**
        * str 为 scene 值 在用户
        * */
        @GetMapping(value = "/wx/public/qrcodeLogin")
        public MvcResult<Object> qrcodeLogin(){
            try {
                String str = get12UUID();
                JSONObject json = new JSONObject();
                JSONObject innerJson = new JSONObject();
                JSONObject inner2Json = new JSONObject();
                inner2Json.put("scene_str",restUtil.getEVENT_LOGIN_PREFIX()+str);
                innerJson.put("scene",inner2Json);
                json.put("action_name", "QR_STR_SCENE");
                json.put("action_info",innerJson );
                HttpHeaders headers = new HttpHeaders();
                MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
                headers.setContentType(type);
                headers.add("Accept", MediaType.APPLICATION_JSON.toString());
                HttpEntity<String> formEntity = new HttpEntity<>(json.toString(), headers);
//                log.info("qrcodeLogin AccessToken : {}",token);
                TicketMessage s = restUtil.getTicketMessage(formEntity);
//                log.info("TicketMessage : {}",s);
                if (StringUtils.isEmpty(s.getTicket())){
                    return MvcResult.DATA_NULL;
                }
                return MvcResult.<Object>builder().code(20000).data(s).build();
            }catch (Exception e){
                e.printStackTrace();
                return MvcResult.ERROR;
            }
        }

        @GetMapping(value = "/showAccessToken")
        public void showAccessToken(){
            log.info("Access token is {}",wxTokenHolder.getToken());

        }

        @GetMapping(value = "/wx/public/tagAccount")
        public String wxTagAccount(String openId){
            try {
                return restUtil.tagAccount(openId);
            }catch (Exception e){
                e.printStackTrace();
                return "fail";
            }
        }


        @Deprecated
        @GetMapping(value = "/wx/public/untagAccount")
        public String wxUntagAccount(String openId){
            try {
                return restUtil.untagAccount(openId);
            }catch (Exception e){
                e.printStackTrace();
                return "fail";
            }
        }

        /**
         * str 为 scene 值
         * */
        @GetMapping(value = "/wx/public/qrcodeBind")
        public MvcResult<Object> qrcodeBind(String username){
            try {
                JSONObject json = new JSONObject();
                JSONObject innerJson = new JSONObject();
                JSONObject inner2Json = new JSONObject();
                inner2Json.put("scene_str",restUtil.getEVENT_BIND_PREFIX()+username);
                innerJson.put("scene",inner2Json);
                json.put("expire_seconds", WX_QRCODE_EXPIRED_SECONDS);
                json.put("action_name", "QR_LIMIT_STR_SCENE");
                json.put("action_info",innerJson );
                HttpHeaders headers = new HttpHeaders();
                MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
                headers.setContentType(type);
                headers.add("Accept", MediaType.APPLICATION_JSON.toString());
                HttpEntity<String> formEntity = new HttpEntity<>(json.toString(), headers);
                TicketMessage s = restUtil.getTicketMessage(formEntity);
                if (StringUtils.isEmpty(s.getTicket())){
                    return MvcResult.DATA_NULL;
                }
                redisUtil.setLoginStatus(s.getTicket(),WX_QRCODE_EXPIRED_SECONDS,"0");
                return MvcResult.<Object>builder().code(20000).data(s).build();
            }catch (Exception e){
                e.printStackTrace();
                return MvcResult.ERROR;
            }
        }


//     UNIONID o2-Y4wxBGHaULmpV9G-7QPS6_olg
        @GetMapping("/wx/public/isRLogin")
        public MvcResult<Object> isLoginWithPublic(String ticket){
            try {
                if(StringUtils.isEmpty(ticket)){
                    return MvcResult.NO_ARGS;
                }
//                获取5分钟的值
                Object o = redisUtil.getLoginStatus(ticket);
                if(o==null){
                    return MvcResult.LOGIN_FAIL;
                }
                String openId = o.toString();
                if(StringUtils.isEmpty(openId)|| "0".equals(openId)){
                    return MvcResult.builder().code(40300).message("用户未扫码").build();
                }
                log.info(openId);
                String w  = restUtil.getUnionId(openId);
                if (StringUtils.isEmpty(w)){
                    return MvcResult.DATA_NULL;
                }
                log.info("is LoginWithPublic {}",w);

//                JSONObject json = new JSONObject();
//                json.put("ticket",ticket);
//                json.put("unionId",w.getUnionid());
//                HttpHeaders headers = new HttpHeaders();
//                MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
//                headers.setContentType(type);
//                headers.add("Accept", MediaType.APPLICATION_JSON.toString());
                return restUtil.getJwt(ticket, w);
            }catch (Exception e){
                e.printStackTrace();
                return MvcResult.ERROR;
            }
        }


        @GetMapping("/wx/callback")
        public void wxCallBack(String code , String state, HttpServletResponse response) throws IOException {
            if (StringUtils.isEmpty(code)||StringUtils.isEmpty(state)){
                return ;
            }
            String b = restUtil.getBaseMessage(code);
            BaseMessage baseMessage  = JSONObject.parseObject(b,BaseMessage.class);
            String openId = baseMessage.getOpenid().trim();
            log.info(openId);
            String result = restUtil.loginWithOpenId(openId);
            MvcResult<Object> mvcResult = JSONObject.parseObject(result,MvcResult.class);
            log.info("{}",mvcResult);

            if (mvcResult.getCode()==20000){
                TokenResult tokenResult  = JSONObject.parseObject(mvcResult.getData().toString(),TokenResult.class);
                if ("center".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("goodapply".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("instrumentbook".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("matterapply".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("mall".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("notice".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else if ("apply".equals(state)){
                    response.sendRedirect("https://keyanplus.com/"+state+"?token="+tokenResult.getAccess_token());
                }else {
                    response.sendRedirect("https://keyanplus.com");
                }
            }else {
                response.sendRedirect("https://keyanplus.com");
            }
        }




        @GetMapping("/hello")
        public String hello(){
            return "hello";
        }

        //        https://blog.csdn.net/m0_37355951/article/details/75670866
        @GetMapping("/wx/public")
        public String check(@RequestParam String signature,@RequestParam String timestamp,@RequestParam String nonce,@RequestParam String echostr){
            if (checkSignature(signature,timestamp,nonce)){
                return echostr;
            }else {
                return "error";
            }
        }


        /**
         * 获得12个长度的十六进制的UUID
         * @return UUID
         */
        private static String get12UUID(){
            UUID id=UUID.randomUUID();
            String[] idd=id.toString().split("-");
            return idd[0]+idd[1];
        }

        public static boolean checkSignature(String signature,String timestamp, String nonce){

            String checktext = null;
            if(null != signature){
                List<String> list = Arrays.asList(token,timestamp,nonce);
                list.sort(String::compareTo);
                log.info("list: {}" , list);
//           将三个参数字符串拼接成一个字符串进行sha1加密
                StringBuilder stringBuilder = new StringBuilder("");
                for (String s:list
                ) {
                    stringBuilder.append(s);
                }
                String target = stringBuilder.toString();
                log.info("target : {}",target);
                //                    MessageDigest md = MessageDigest.getInstance("SHA-1");
//                    //对接后的字符串进行sha1加密
//                    byte[] digest = md.digest(content.toString().getBytes());
                byte[] digest =  DigestUtils.sha1(target);
                checktext = byteToStr(digest);
            }
            //将加密后的字符串与signature进行对比
            return checktext != null && checktext.equals(signature.toUpperCase());
        }

        /**
         * 将字节数组转化为16进制字符串
         * @return 字符串
         */
        private static String byteToStr(byte[] byteArrays) {
            StringBuilder str=new StringBuilder("");
            for (byte byteArray : byteArrays) {
                str.append(byteToHexStr(byteArray));
            }
            return str.toString();
        }

        /**
         * 将字节转化为十六进制字符串
         * @param myByte 字节
         * @return 字符串
         */
        private static String byteToHexStr(byte myByte) {

            char[] Digit = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
            char[] tempArr = new char[2];
            tempArr[0] = Digit[(myByte >>> 4)&0X0F];
            tempArr[1] = Digit[myByte & 0x0F];
            String str = new String(tempArr);
            return str;
        }
    }

}
