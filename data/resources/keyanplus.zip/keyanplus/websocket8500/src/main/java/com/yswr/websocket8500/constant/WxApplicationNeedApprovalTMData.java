package com.yswr.websocket8500.constant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WxApplicationNeedApprovalTMData {
    private WxTMDataUnit first;
    private WxTMDataUnit keyword1;
    private WxTMDataUnit keyword2;
    private WxTMDataUnit keyword3;
    private WxTMDataUnit remark;
}
