package com.yswr.websocket8500.wx_message_handlers.event;

import com.yswr.websocket8500.Websocket8500Application;
import com.yswr.websocket8500.constant.DailySign;
import com.yswr.websocket8500.constant.ThirdWx;
import com.yswr.websocket8500.constant.WxUnion;
import com.yswr.websocket8500.utils.RedisUtil;
import com.yswr.websocket8500.utils.RestUtil;
import com.yswr.websocket8500.utils.WxMessageUtil;
import com.yswr.websocket8500.wx_message_handlers.AbstractWxHttpMessageHandler;
import com.yswr.websocket8500.wx_message_handlers.text.WxTextResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Map;
import java.util.UUID;

@Component
@Slf4j
public class WxEventHandler extends AbstractWxHttpMessageHandler {

    @Resource
    RedisUtil redisUtil;
    @Resource
    RestUtil restUtil;

    public static final String EVENT_SEPARATOR = "_";

    /**
     * 获得12个长度的十六进制的UUID
     * @return UUID
     */
    private static String get12UUID(){
        UUID id=UUID.randomUUID();
        String[] idd=id.toString().split("-");
        return idd[0]+idd[1];
    }

    @Override
    public Object Handle(Map<String,String> params) {
        try {
            log.info("params :{}",params);
            String event = params.get("Event").trim();
            String openId = params.get("FromUserName").trim();
            Integer createTime =Integer.parseInt(params.get("CreateTime").trim());
            String self = params.get("ToUserName").trim();
            switch (event) {
                case "subscribe":
                {
//                    单纯的关注动作 ， 获取用户的unionWX 信息 在数据库中保存
                    String ticket = params.get("Ticket");

                    if (StringUtils.isEmpty(ticket)) {
                        //            用户自关注
                        //            添加数据库记录 如果用户已存在则发送duplicate
                        WxUnion wxUnion = restUtil.getWxUserInfo(openId);
                        if (wxUnion != null) {
                            ThirdWx thirdWx = ThirdWx.builder().headImgUrl(wxUnion.getHeadimgurl())
                                    .nickname(wxUnion.getNickname())
                                    .publicOpenId(wxUnion.getOpenid())
                                    .unionId(wxUnion.getUnionid())
                                    .build();
                            String result = restUtil.setUnionWx(thirdWx);
                            log.info("subscribe result : {}", result);
                            if ("unbind".equals(result)){
                                return WxMessageUtil.objectToXml(WxTextResponse.builder().Content("当前账户未绑定账号，请前往<a href='https://keyanplus.com/login?unionId="+wxUnion.getUnionid()+"&state="+get12UUID()+"'>这里</a>-->绑定账号")
                                        .CreateTime(createTime)
                                        .FromUserName(self)
                                        .ToUserName(openId)
                                        .MsgType("text")
                                        .build(), WxTextResponse.class);
                            }
                        }
                        return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                .MsgType("text")
                                .ToUserName(openId)
                                .FromUserName(self)
                                .CreateTime(createTime)
                                .Content("您好，欢迎关注科研家+！").build(), WxTextResponse.class);
                    }
//                用户未关注并且扫我们生成的码进入到这里， 有可能是绑定的 也有可能是登录的
                    else {
                        /*
                         * Thread : Thread[https-jsse-nio-8500-exec-6,5,main],
                         * WxQCodeSubscribe WxQCodeSubscribe(ToUserName=gh_d34ceffcd306,
                         * FromUserName=ogD616FoKr7U33dQs_rGwy_1Vlus, CreateTime=1609726742, MsgType=event,
                         *  Event=subscribe, EventKey=qrscene_2aa10f88bfc9,
                         *  Ticket=gQHx7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyU2FnUDlEMC1lUkUxUjZaT2h2Y0EAAgTuevJfAwRYAgAA)
                         * */
                        ticket = ticket.trim();
                        String EventKey = params.get("EventKey").trim();
                        String[] strings = EventKey.split(EVENT_SEPARATOR);
                        String prefix = strings[1];
                        WxUnion wxUnion = restUtil.getWxUserInfo(openId);
                        if (wxUnion == null) {
                            log.info("No WxUnion");
                            return "";
                        }
//                    用户未关注，扫码到登录事件
                        if (restUtil.getEVENT_LOGIN_PARAMS().equals(prefix)) {
//                            用户没有绑定账号
                            String name  = restUtil.findNameByUnionId(wxUnion.getUnionid());
                            if (StringUtils.isEmpty(name)){
                                return WxMessageUtil.objectToXml(WxTextResponse.builder().Content("当前账户未绑定账号，请前往<a href='https://keyanplus.com/login?unionId="+wxUnion.getUnionid()+"&state="+get12UUID()+"'>这里</a>-->绑定账号")
                                        .CreateTime(createTime)
                                        .FromUserName(self)
                                        .ToUserName(openId)
                                        .MsgType("text")
                                        .build(), WxTextResponse.class);
                            }
//                            设置登陆态
                            redisUtil.setLoginStatus(ticket, Websocket8500Application.BasicController.WX_QRCODE_EXPIRED_SECONDS, openId);
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("登录成功").build(), WxTextResponse.class);
                        }
//                        用户未关注，但是扫码到 绑定事件
                        else if (restUtil.getEVENT_BIND_PARAMS().equals(prefix)) {
//                            String username = strings[2] + EVENT_SEPARATOR + strings[3];
//                            String bindResult = restUtil.bindUnionId(username, wxUnion.getUnionid());
//                            if ("success".equals(bindResult)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("绑定成功").build(), WxTextResponse.class);
//                            }else if ("no register".equals(bindResult)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("用户未注册").build(), WxTextResponse.class);
//                            }else if ("duplicate".equals(bindResult)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("请勿重复绑定当前账号").build(), WxTextResponse.class);
//                            }else if ("unionIdBound".equals(bindResult)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("您已经绑定了当前账号，无法绑定其他账号，请先解除绑定当前账号").build(), WxTextResponse.class);
//                            }else if ("no mark".equals(bindResult)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("用户未关注公众号").build(), WxTextResponse.class);
//                            }else {
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("绑定失败").build(), WxTextResponse.class);
//                            }
//                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                    .MsgType("text")
//                                    .ToUserName(openId)
//                                    .FromUserName(self)
//                                    .CreateTime(createTime)
//                                    .Content("请点击下方按钮进行绑定").build(), WxTextResponse.class);
                        }else {
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("不合法的关注事件").build(), WxTextResponse.class);
                        }
                    }
                    break;
                }
//                    单纯的取消关注动作 ， 获取用户的unionId 信息 在数据库中删除unionWx记录和绑定的账号信息
                case "unsubscribe":
                {
                    /*
                     * {CreateTime=1609726689, EventKey=, Event=unsubscribe,
                     * ToUserName=gh_d34ceffcd306, FromUserName=ogD616FoKr7U33dQs_rGwy_1Vlus,
                     * MsgType=event}
                     * */
//                    String unionId = restUtil.getUnionId(openId);
//                    String result = restUtil.removeUnionWx(unionId);
                    log.info("unsubscribe result : 用户 {} 取消了关注",openId);
                    break;
                }
//              用户已经关注的推送   也有可能是绑定和 登录
                case "SCAN":
                {
                    /*
                     * Thread : Thread[https-jsse-nio-8500-exec-9,5,main],
                     * SCAN WxQCodeSubscribe(ToUserName=gh_d34ceffcd306, FromUserName=ogD616FoKr7U33dQs_rGwy_1Vlus, CreateTime=1609726358, MsgType=event, Event=SCAN,
                     * EventKey=a85d2e4c65d8, Ticket=gQEH7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyWVc3VzhZMC1lUkUxVG1YT3h2Y24AAgR_efJfAwRYAgAA)
                     * */
                    String EventKey = params.get("EventKey").trim();
                    String[] strings = EventKey.split(EVENT_SEPARATOR);
                    String prefix = strings[0];
                    String ticket = params.get("Ticket").trim();
                    log.info(prefix);
                    String unionId = restUtil.getUnionId(openId);
                    if (unionId==null){
                        log.info("unionId null");
                        return "";
                    }
                    if (restUtil.getEVENT_LOGIN_PARAMS().equals(prefix)) {
                        log.info("login QCode start");
                        String name  = restUtil.findNameByUnionId(unionId);
                        if (StringUtils.isEmpty(name)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder().Content("当前账户未绑定账号，请前往<a href='https://keyanplus.com/login?unionId="+unionId+"&state="+get12UUID()+"'>这里</a>绑定账号")
                                    .CreateTime(createTime)
                                    .FromUserName(self)
                                    .ToUserName(openId)
                                    .MsgType("text")
                                    .build(), WxTextResponse.class);
                        }
                        redisUtil.setLoginStatus(ticket, Websocket8500Application.BasicController.WX_QRCODE_EXPIRED_SECONDS, openId);
                        return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                .MsgType("text")
                                .ToUserName(openId)
                                .FromUserName(self)
                                .CreateTime(createTime)
                                .Content("登录成功").build(), WxTextResponse.class);
                    } else if (restUtil.getEVENT_BIND_PARAMS().equals(prefix)) {
                        log.info("bind start");
                        String username = strings[1] + EVENT_SEPARATOR + strings[2];
                        log.info("{}_{}_{}",strings[0],strings[1],strings[2]);
                        if (StringUtils.isEmpty(unionId)) {
                            log.info("No unionId");
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("绑定失败").build(), WxTextResponse.class);
                        }
                        log.info("bind unionId :{}", unionId);
                        String result = restUtil.tagAccount(openId);
                        log.info("BIND result :{}",result);
                        if (!"success".equals(result)){
                            WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("绑定失败").build(), WxTextResponse.class);
                        }
                        result = restUtil.bindUnionId(username, unionId);
                        log.info("BIND result :{}",result);
                        if ("success".equals(result)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("绑定成功").build(), WxTextResponse.class);
                        }else if ("no register".equals(result)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("用户未注册").build(), WxTextResponse.class);
                        }else if ("duplicate".equals(result)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("请勿重复绑定当前账号").build(), WxTextResponse.class);
                        }else if ("unionIdBound".equals(result)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("您已经绑定了当前账号，无法绑定其他账号，请先解除绑定当前账号").build(), WxTextResponse.class);
                        }else if ("no mark".equals(result)){
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("用户未关注公众号").build(), WxTextResponse.class);
                        }else {
                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                    .MsgType("text")
                                    .ToUserName(openId)
                                    .FromUserName(self)
                                    .CreateTime(createTime)
                                    .Content("绑定失败").build(), WxTextResponse.class);
                        }

                    }else {
                        return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                .MsgType("text")
                                .ToUserName(openId)
                                .FromUserName(self)
                                .CreateTime(createTime)
                                .Content("不合法的扫码事件").build(), WxTextResponse.class);
                    }
                }
                case "CLICK":
                {
                    String unionId = restUtil.getUnionId(openId);
                    String eventKey = params.get("EventKey").trim();
                    if (unionId==null){
                        log.info("没有找到用户信息");
                        return "success";
                    }
                    if ("DAILY_SIGN".equals(eventKey)) {
                        log.info("unionId :{}", unionId);
                        DailySign dailySign = restUtil.dailySign(unionId);
                        log.info("daily Sign :{}", dailySign);
                        if (dailySign != null) {
//                        DailySign(id=21ded5cb5ff56d0603f717c37b739f06, requestId=176d6b1e27f_5,
//                        message=签到成功！首次签到加100积分, points=100, continuousRecord=1)
                            log.info("DAILY_SIGN : {}",dailySign);
                            return WxMessageUtil.objectToXml(WxTextResponse.builder().Content(dailySign.getMessage() +
                                    "\n当前已经连续签到" + dailySign.getContinuousRecord() + "天，总积分为："
                                    + dailySign.getPoints())
                                    .CreateTime(createTime)
                                    .FromUserName(self)
                                    .ToUserName(openId)
                                    .MsgType("text")
                                    .build(), WxTextResponse.class);
                        } else {
                            return WxMessageUtil.objectToXml(WxTextResponse.builder().Content("签到失败")
                                    .CreateTime(createTime)
                                    .FromUserName(self)
                                    .ToUserName(openId)
                                    .MsgType("text")
                                    .build(), WxTextResponse.class);
                        }
                    } else if ("BIND".equals(eventKey)) {
                        return WxMessageUtil.objectToXml(WxTextResponse.builder().Content("请点击<a href='https://keyanplus.com/login?unionId="+unionId+"&state="+get12UUID()+"'>这里</a>绑定账号")
                                .CreateTime(createTime)
                                .FromUserName(self)
                                .ToUserName(openId)
                                .MsgType("text")
                                .build(), WxTextResponse.class);
                    }else if ("UNBIND".equals(eventKey)){
//                        if (StringUtils.isEmpty(unionId)) {
//                            log.info("No unionId");
//                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                    .MsgType("text")
//                                    .ToUserName(openId)
//                                    .FromUserName(self)
//                                    .CreateTime(createTime)
//                                    .Content("解除绑定失败").build() , WxTextResponse.class);
//                        }
//                        String result = restUtil.untagAccount(openId);
//                        if ("success".equals(result)){
//                            result = restUtil.unbindUnionIdByUnionId(unionId);
//                            if ("success".equals(result)){
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("解除绑定成功").build() , WxTextResponse.class);
//                            }else {
//                                return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                        .MsgType("text")
//                                        .ToUserName(openId)
//                                        .FromUserName(self)
//                                        .CreateTime(createTime)
//                                        .Content("解除绑定失败").build() , WxTextResponse.class);
//                            }
//                        }else {
//                            return WxMessageUtil.objectToXml(WxTextResponse.builder()
//                                    .MsgType("text")
//                                    .ToUserName(openId)
//                                    .FromUserName(self)
//                                    .CreateTime(createTime)
//                                    .Content("解除绑定失败").build() , WxTextResponse.class);
//                        }
                    }
                    else {
                        return WxMessageUtil.objectToXml(WxTextResponse.builder()
                                .MsgType("text")
                                .ToUserName(openId)
                                .FromUserName(self)
                                .CreateTime(createTime)
                                .Content("不合法的点击事件").build(), WxTextResponse.class);
                    }

                }
                default:
                    return WxMessageUtil.objectToXml(WxTextResponse.builder()
                            .MsgType("text")
                            .ToUserName(openId)
                            .FromUserName(self)
                            .CreateTime(createTime)
                            .Content("该功能尚未开发").build(), WxTextResponse.class);
            }
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        WxMessageUtil.wxMessageUtilMap.put("event",this);
    }
}