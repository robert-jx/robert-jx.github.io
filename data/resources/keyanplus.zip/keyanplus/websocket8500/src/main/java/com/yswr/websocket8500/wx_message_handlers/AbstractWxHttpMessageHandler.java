package com.yswr.websocket8500.wx_message_handlers;

public abstract class AbstractWxHttpMessageHandler implements WxMessageHandler {



}
