package com.yswr.websocket8500.constant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WxTMDataUnit {
    private String value;
    private String color ="#173177" ;
}
