package com.yswr.websocket8500.constant;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ThirdWx {
    private Long id;
    private String publicOpenId;
    private String nickname;
    private String headImgUrl;
    private String unionId;
}
