package com.yswr.websocket8500.wx_message_handlers.text;

import com.yswr.websocket8500.utils.WxMessageUtil;
import com.yswr.websocket8500.wx_message_handlers.AbstractWxHttpMessageHandler;
import com.yswr.websocket8500.wx_message_handlers.text.WxText;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Slf4j
public class WxTextHandler extends AbstractWxHttpMessageHandler {


    @Override
    public Object Handle(Map<String,String> params) {
        try {
            WxText wxText = WxText.builder()
                    .Content(params.get("Content").trim())
                    .CreateTime(Integer.parseInt(params.get("CreateTime").trim()))
                    .FromUserName(params.get("FromUserName").trim())
                    .MsgId(Long.parseLong(params.get("MsgId").trim()))
                    .MsgType(params.get("MsgType").trim())
                    .ToUserName(params.get("ToUserName").trim())
                    .build();
            log.info("Thread : {},WxText {}",Thread.currentThread(), wxText);
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        WxMessageUtil.wxMessageUtilMap.put("text",this);
    }
}
