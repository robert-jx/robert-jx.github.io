package com.yswr.websocket8500.constant;

import lombok.Data;

@Data
public class TicketMessage{
    private String ticket;
    private Integer expire_seconds;
    private String url;
}