//package com.yswr.websocket8500.utils;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.nacos.client.naming.utils.CollectionUtils;
//import com.yswr.websocket8500.constant.WxApplicationNeedApprovalTM;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import lombok.SneakyThrows;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
//import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
//import org.apache.rocketmq.client.producer.SendResult;
//import org.apache.rocketmq.common.message.MessageExt;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//
//import javax.annotation.Resource;
//import java.util.LinkedList;
//import java.util.List;
//
//@Component
//@Slf4j
//public class MQConsumeMsgListenerProcessor implements MessageListenerConcurrently {
//
//
//    @Resource
//    RestUtil restUtil;
//    @Resource
//    private ThreadPoolTaskExecutor poolTaskExecutor;
//    // wxTMNeedApprovalTag
//    @Value("${rocketmq.tag.need-approval}")
//    private String NEED_APPROVAL_TAG;
//    /**
//     * 目前只接受 wxTM~*
//     *
//     * 默认msg里只有一条消息，可以通过设置consumeMessageBatchMaxSize参数来批量接收消息
//     * 不要抛异常，如果没有return CONSUME_SUCCESS ，consumer会重新消费该消息，直到return CONSUME_SUCCESS
//     * @param msgList
//     * @param consumeConcurrentlyContext
//     * @return
//     */
//    @Override
//    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgList, ConsumeConcurrentlyContext consumeConcurrentlyContext) {
//        if (CollectionUtils.isEmpty(msgList)) {
//            log.info("MQ接收消息为空，直接返回成功");
//            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//        }
//        MessageExt messageExt = msgList.get(0);
//        try {
//            String topic = messageExt.getTopic();
//            String tags = messageExt.getTags();
//            String body = new String(messageExt.getBody(), "utf-8");
//            log.info("receive message is : {}", body);
////            List<WxApplicationNeedApprovalTM> list = null;
////            if (!StringUtils.isEmpty(body))
////            {
////                list = JSONArray.parseArray(body,WxApplicationNeedApprovalTM.class);
////            }
////            if (list==null||list.size() ==0 ){
////                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
////            }
////            List<WxMessageTask> wxMessageTasks = new LinkedList<>();
////            if (tags.equals(NEED_APPROVAL_TAG)){
////                for (WxApplicationNeedApprovalTM w:list
////                     ) {
////                    if (!StringUtils.isEmpty(w.getTouser())) {
////                        wxMessageTasks.add(new WxMessageTask(restUtil,w.getTouser(),w.getTemplate_id(), w.getUrl(), w.getData()));
////                    }
////                }
////            }
////            for (WxMessageTask w:wxMessageTasks
////                 ) {
////                poolTaskExecutor.execute(w);
////            }w
//
//        } catch (Exception e) {
//            log.error("获取MQ消息内容异常 {}",e);
//        }
//        // TODO 处理业务逻辑
//        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//    }
//
//    @Data
//    @AllArgsConstructor
//    @NoArgsConstructor
//    static class WxMessageTask implements Runnable {
//        private RestUtil restUtil;
//        private String openId;
//        private String templateId;
//        private String url;
//        private Object data;
//
//        @SneakyThrows
//        public void run() {
//            String sendResult = restUtil.sendTemplateMessage(openId,templateId,url,data);
//            log.info("WxMessageTask : "+sendResult);
//        }
//    }
//}