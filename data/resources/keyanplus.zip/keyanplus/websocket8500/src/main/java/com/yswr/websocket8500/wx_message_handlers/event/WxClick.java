package com.yswr.websocket8500.wx_message_handlers.event;

import lombok.Data;

@Data
public class WxClick {
    private String ToUserName;
    private String FromUserName;
    private Integer CreateTime;
    private String MsgType;
    private String Event;
    private String EventKey;
}
