package com.yswr.websocket8500.constant;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxApplicationNeedApprovalTM {
    private String touser;
    private String template_id;
    private String url;
    private WxApplicationNeedApprovalTMData data;
}
