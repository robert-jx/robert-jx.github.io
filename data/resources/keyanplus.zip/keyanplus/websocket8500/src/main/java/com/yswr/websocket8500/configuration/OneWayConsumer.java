package com.yswr.websocket8500.configuration;

import com.alibaba.fastjson.JSONArray;
import com.yswr.websocket8500.constant.WxApplicationNeedApprovalTM;
import com.yswr.websocket8500.utils.RestUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.LinkedList;
import java.util.List;

/**
 * 单向消息
 */
@Service
@Slf4j
@RocketMQMessageListener(consumerGroup = "my-consumer_labprovider", topic = "wxTM")
public class OneWayConsumer implements RocketMQListener<MessageExt> {
    @Resource
    RestUtil restUtil;
    @Resource
    private ThreadPoolTaskExecutor poolTaskExecutor;
    @Override
    @SneakyThrows
    public void onMessage(MessageExt messageExt) {
        if (messageExt==null){
            return;
        }
        String tags = messageExt.getTags();
        String body = new String(messageExt.getBody(), "utf-8");
//        log.info("body is "+body);
        log.info("{}",messageExt);
        List<WxApplicationNeedApprovalTM> list = null;
        if (!StringUtils.isEmpty(body))
        {
            list = JSONArray.parseArray(body, WxApplicationNeedApprovalTM.class);
        }
        log.info("{}",list);
        if (list==null||list.size()==0){
            return;
        }
        List<WxMessageTask> wxMessageTasks = new LinkedList<>();
                for (WxApplicationNeedApprovalTM w:list
                     ) {
                    if (!StringUtils.isEmpty(w.getTouser())) {
                        wxMessageTasks.add(new WxMessageTask(restUtil, w.getTouser(), w.getTemplate_id(), w.getUrl(), w.getData()));
                    }
            }
            for (WxMessageTask w:wxMessageTasks
                 ) {
                poolTaskExecutor.execute(w);
            }
    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Slf4j
    static class WxMessageTask implements Runnable {
        private RestUtil restUtil;
        private String openId;
        private String templateId;
        private String url;
        private Object data;

        @SneakyThrows
        public void run() {
            String sendResult = restUtil.sendTemplateMessage(openId,templateId,url,data);
            log.info("WxMessageTask : "+sendResult);
        }
    }
}
