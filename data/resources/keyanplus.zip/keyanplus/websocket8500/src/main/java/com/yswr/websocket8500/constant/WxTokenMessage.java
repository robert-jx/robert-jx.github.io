package com.yswr.websocket8500.constant;

import lombok.Data;

@Data
public class WxTokenMessage{
    private String access_token;
    private Integer expires_in;
}
