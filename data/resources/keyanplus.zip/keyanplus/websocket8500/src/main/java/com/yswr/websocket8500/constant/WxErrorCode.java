package com.yswr.websocket8500.constant;

import lombok.Data;

@Data
public class WxErrorCode {
    private Integer errcode;
    private String  errmsg;
}
