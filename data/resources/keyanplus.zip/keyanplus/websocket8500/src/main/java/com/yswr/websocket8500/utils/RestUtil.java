package com.yswr.websocket8500.utils;

import com.alibaba.fastjson.JSONObject;
import com.yswr.websocket8500.constant.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;
import java.util.Collections;
import java.util.List;

@Component
@Slf4j
public class RestUtil {
    @Value("${wx.appid}")
    private   String APP_ID ;
    @Value("${wx.secret}")
    private  String APP_SECRET ;
    @Resource
    WxTokenHolder wxTokenHolder;

    private final RestTemplate restTemplate = new RestTemplateBuilder().build();
    private  URI WX_GET_TOKEN_URL ;


    public static final String WX_MARK_TAG = "101";
    public static final String WX_NO_MARK_TAG = "100";

    public String getEVENT_LOGIN_PREFIX() {
        return "login_";
    }

    public String getEVENT_BIND_PREFIX() {
        return "bind_";
    }
    public String getEVENT_LOGIN_PARAMS() {
        return "login";
    }

    public String getEVENT_BIND_PARAMS() {
        return "bind";
    }


    public String loginWithOpenId(String openId){
        URI uri = URI.create("https://keyanplus.com/api/v1/oauth/login?openId="+openId+"&login_type=wx_public_openId");
        log.info("URI: {}",uri);
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        headers.add("Accept", MediaType.APPLICATION_JSON.toString());
        HttpEntity<String> formEntity = new HttpEntity<>(null, headers);
        return restTemplate.exchange(uri, HttpMethod.POST,formEntity,String.class).getBody();
    }

    public String getBaseMessage(String code){
        URI uri = URI.create("https://api.weixin.qq.com/sns/oauth2/access_token?appid="+APP_ID+"&secret="+APP_SECRET
                +"&code="+code+"&grant_type=authorization_code");
        ResponseEntity<String> baseMessageResponseEntity = restTemplate.getForEntity(uri,String.class);
//        log.info("baseMessageResponseEntity: {}",baseMessageResponseEntity);
//        assert baseMessageResponseEntity!=null;
//        BaseMessage baseMessage = JSONObject.parseObject(baseMessageResponseEntity.getBody(),BaseMessage.class);
        return baseMessageResponseEntity.getBody();
    }

    public WxTokenMessage getWxTokenMessage(){
         try {
             log.info("app_id :{}, app_secret : {}", APP_ID,APP_SECRET);
             if (WX_GET_TOKEN_URL==null){
                 WX_GET_TOKEN_URL = URI.create("https://api.weixin.qq.com/cgi-bin/token" +
                         "?grant_type=client_credential&appid="+APP_ID+"&secret="+APP_SECRET);
             }
             log.info("get WxTokenMessage {}",WX_GET_TOKEN_URL);
             String s = restTemplate.getForEntity(WX_GET_TOKEN_URL, String.class).getBody();
             log.info("response {}",s);
             return JSONObject.parseObject(s,WxTokenMessage.class);
         }
         catch (Exception e){
             e.printStackTrace();
             return null;
         }
     }
     //https://developers.weixin.qq.com/doc/offiaccount/Message_Management/Template_Message_Interface.html
    public String sendTemplateMessage(String openId,String templateId,String url,Object data){
        try {
            JSONObject first = new JSONObject();
            first.put("touser",openId);
            first.put("template_id",templateId);
            first.put("url",url);
            first.put("data",data);
            HttpHeaders headers = new HttpHeaders();
            MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
            headers.setContentType(type);
            headers.add("Accept", MediaType.APPLICATION_JSON.toString());
            HttpEntity<String> formEntity = new HttpEntity<>(JSONObject.toJSONString(first), headers);
            return restTemplate.exchange(URI.create("https://api.weixin.qq.com/cgi-bin/message/template/send?access_token="+wxTokenHolder.getToken())
                    , HttpMethod.POST,formEntity,String.class).getBody();
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    public String setUnionWx(ThirdWx thirdWx){
        try {
            try {
                HttpHeaders headers = new HttpHeaders();
                MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
                headers.setContentType(type);
                headers.add("Accept", MediaType.APPLICATION_JSON.toString());
                HttpEntity<String> formEntity = new HttpEntity<>(JSONObject.toJSONString(thirdWx), headers);
                return restTemplate.exchange(URI.create("https://keyanplus.com/api/v1/user/setThirdWx"), HttpMethod.POST,formEntity,String.class).getBody();
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    public TicketMessage getTicketMessage(HttpEntity<String> formEntity){
        try {
            return restTemplate.postForObject("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token="+wxTokenHolder.getToken(),formEntity, TicketMessage.class);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public String getUnionId(String openId){
        try {
            String str = restTemplate.getForEntity(URI.create("https://api.weixin.qq.com/cgi-bin/user/info?access_token="+
                    wxTokenHolder.getToken()+
                    "&openid="+openId+"&lang=zh_CN"), String.class).getBody();
            log.info("get union Id {}",str);
            WxUnion wxUnion = JSONObject.parseObject(str,WxUnion.class);
            return wxUnion==null?null:wxUnion.getUnionid();
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
     }

     public String tagAccount(String openId){
        try {
            List<String> singleList = Collections.singletonList(openId);
            JSONObject json = new JSONObject();
            json.put("openid_list", singleList);
            json.put("tagid",  WX_MARK_TAG);
            HttpHeaders headers = new HttpHeaders();
            MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
            headers.setContentType(type);
            headers.add("Accept", MediaType.APPLICATION_JSON.toString());
            HttpEntity<String> formEntity = new HttpEntity<>(json.toString(), headers);
            String result = restTemplate
                    .exchange("https://api.weixin.qq.com/cgi-bin/tags/members/batchtagging?access_token="
                            +wxTokenHolder.getToken(), HttpMethod.POST,formEntity,String.class).getBody();
            log.info(result);
            WxErrorCode wxErrorCode =  JSONObject.parseObject(result,WxErrorCode.class);
            log.info("wxErrorCode :{}" ,wxErrorCode);
            if (wxErrorCode==null||wxErrorCode.getErrcode()!=0){
                return "fail";
            }
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
     }

    @Deprecated
    public String untagAccount(String openId){
        try {
            List<String> singleList = Collections.singletonList(openId);
            JSONObject json = new JSONObject();
            json.put("openid_list", singleList);
            json.put("tagid",  WX_MARK_TAG);
            HttpHeaders headers = new HttpHeaders();
            MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
            headers.setContentType(type);
            headers.add("Accept", MediaType.APPLICATION_JSON.toString());
            HttpEntity<String> formEntity = new HttpEntity<>(json.toString(), headers);
            WxErrorCode result = restTemplate
                    .exchange("https://api.weixin.qq.com/cgi-bin/tags/members/batchuntagging?access_token="
                            +wxTokenHolder.getToken(), HttpMethod.POST,formEntity,WxErrorCode.class).getBody();
            if (result==null||result.getErrcode()!=0){
                return "fail";
            }
            return "success";
        }catch (Exception e){
            return "fail";
        }
    }
    public WxUnion getWxUserInfo(String openId){
        try {
            String str = restTemplate.getForEntity(URI.create("https://api.weixin.qq.com/cgi-bin/user/info?access_token="+
                    wxTokenHolder.getToken()+
                    "&openid="+openId+"&lang=zh_CN"), String.class).getBody();
            log.info("get union Id {}",str);
            return JSONObject.parseObject(str,WxUnion.class);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public String removeUnionWx(String unionId){
        try {
            return restTemplate
                    .exchange("https://keyanplus.com/api/v1/user/removeThirdWx?unionId="+unionId,HttpMethod.GET,null,String.class).getBody();
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public String bindUnionId(String username,String unionId){
        try {
            return restTemplate
                    .exchange("https://keyanplus.com/api/v1/user/bindAccount?username="+username +"&unionId="+unionId,HttpMethod.GET,null,String.class).getBody();
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
//    public String unbindUnionIdByName(String username){
//        try {
//            return restTemplate
//                    .exchange("https://keyanplus.com/api/v1/user/unbindAccountByName?username="+username,HttpMethod.GET,null,String.class).getBody();
//        }catch (Exception e){
//            e.printStackTrace();
//            return "fail";
//        }
//    }
    public String unbindUnionIdByUnionId(String unionId){
        try {
            return restTemplate
                    .exchange("https://keyanplus.com/api/v1/user/unbindAccountByUnionId?unionId="+unionId,HttpMethod.GET,null,String.class).getBody();
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

    public MvcResult<Object> getJwt(String ticket, String unionId){
        try {
            String s =  restTemplate.exchange(URI.create("https://keyanplus.com/api/v1/oauth/login?login_type=wx_public&ticket="+ticket+"&unionId="+unionId), HttpMethod.POST,null,String.class).getBody();
            return JSONObject.parseObject(s, MvcResult.class);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }




    public DailySign dailySign(String unionId){
        try {
            String result =  findNameByUnionId(unionId);
            if (StringUtils.isEmpty(result)){
                return null;
            }
            String s =  restTemplate.exchange(URI.create("https://keyanplus.com/api/v1/utils/members/checkin/"+result), HttpMethod.POST,null,String.class).getBody();
            log.info("str DAILY_SIGN:{}",s);
            return JSONObject.parseObject(s, DailySign.class);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public String findNameByUnionId(String unionId){
        return restTemplate
                .exchange("https://keyanplus.com/api/v1/user/getNameByUnionId/"+unionId,HttpMethod.GET,null,String.class).getBody();
    }
 }
