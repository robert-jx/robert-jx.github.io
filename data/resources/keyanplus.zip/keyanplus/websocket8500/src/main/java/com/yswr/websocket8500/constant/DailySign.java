package com.yswr.websocket8500.constant;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;

@Data
public class DailySign {
//    private String id;
//    private String requestId;
    private String message;
    private String data;
    private Integer points;
    private Integer continuousRecord;
}
