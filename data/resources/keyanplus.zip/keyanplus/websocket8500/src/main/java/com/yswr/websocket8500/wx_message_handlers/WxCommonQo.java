package com.yswr.websocket8500.wx_message_handlers;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "WxCommonQo") //XML文件中的根标识
@XmlType(propOrder = {
        "ToUserName",
        "FromUserName",
        "CreateTime",
        "MsgType",
        "Content",
        "MsgId"
}) //控制JAXB 绑定类中属性和字段的排序
public class WxCommonQo {
    private String ToUserName;
    private String FromUserName;
    private Integer CreateTime;
    private String MsgType;
    private String Content;
    private Long MsgId;

}
