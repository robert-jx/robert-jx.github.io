package com.yswr.userprovider8001;

import com.yswr.userprovider8001.dao.UserRepository;
import com.yswr.userprovider8001.entity.Account;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import javax.annotation.Resource;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@SpringBootTest
public class UserProvider8001ApplicationTests {
    @Resource
    UserRepository userRepository;

    @Test
    void contextLoads() {
        List<Account> accountList = new LinkedList<>();
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        for (int i = 1; i <= 50; i++) {
            String s = String.format("%02d", i);
            Account account= Account.builder().createTime(new Date(System.currentTimeMillis()))
                    .direction("测试方向")
                    .avatar("www.baidu.com")
                    .email("test"+i+"@edu.com")
                    .highestRecord("本科")
                    .institute("计算机学院")
                    .major("软件工程")
                    .name("test_"+i)
                    .password(passwordEncoder.encode("123456"))
                    .realName("测试人员"+i+"号")
                    // 12345678901 12345678902 12345678903 12345678904 12345678905 .... 12345678950
                    .phone("123456789"+s)
                    .university("测试大学")
                    .disable(false)
                    .build();
            accountList.add(account);
        }
        userRepository.saveAll(accountList);

    }
}
