package com.yswr.userprovider8001;

import com.yswr.userprovider8001.dao.ThirdWxRepository;
import com.yswr.userprovider8001.dao.UserRepository;
import com.yswr.userprovider8001.entity.Account;
import com.yswr.userprovider8001.entity.ThirdWx;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    @Resource
    UserRepository repository;
    @Resource
    ThirdWxRepository thirdWxRepository;


    public ThirdWx findThirdByUnionId(String unionId){
        return thirdWxRepository.findByUnionId(unionId).orElse(null);
    }

    public ThirdWx findThirdByUsername(String username){
        return thirdWxRepository.findByUsername(username).orElse(null);
    }
    public Account findUserByName(String name){
        name = name.trim();

        return repository.findByName(name).orElse(null);
    }

    public Account findUserByPhone(String phone){
        return repository.findByPhone(phone).orElseThrow(()-> new NullPointerException("没有该用户"));
    }

//    public Account findUserByUnionId(String unionId){
//        return repository.findByUnionId(unionId).orElseThrow(()-> new NullPointerException("没有该用户"));
//    }

    public Boolean existUserByUnionId(String unionId){
        return repository.existsAccountByUnionId(unionId);
    }

    public String findUserNameByUnionId(String unionId){
        return repository.findNameByUnionId(unionId);
    }

    public List<String> findAllUnionIdByUsernames(List<String> usernames){
        return repository.findAllUnionIdByNames(usernames);
    }
    public List<String> findAllOpenIdByUsernames(List<String> usernames){
        return repository.findAllOpenIdByNames(usernames);
    }

    public Account save(Account account){
        return repository.save(account);
    }
    public ThirdWx saveThirdWx(ThirdWx thirdWx){
        return thirdWxRepository.save(thirdWx);
    }
    @Transactional
    public void bindUnionId(String username,String unionId){
        repository.bindUnionId(username,unionId);
    }

    @Transactional
    public void unbindWxUnionByName(String username){
        repository.unbindWxUnionByName(username);
    }

    @Transactional
    public void unbindWxUnionByUnionId(String unionId){
        repository.unbindWxUnionByUnionId(unionId);
    }

    public void delete(Long id){
        repository.deleteById(id);
    }
    @Transactional
    public void deleteUnionWx(String unionId){
        repository.deleteByUnionId(unionId);
        thirdWxRepository.deleteByUnionId(unionId);
    }
    public boolean isExist(String name){
        return repository.existsAccountByName(name);
    }
    static class UserSpec {

        protected static Specification<Account> likeSearchKeyWord(Long labId){
            return (Specification<Account>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
