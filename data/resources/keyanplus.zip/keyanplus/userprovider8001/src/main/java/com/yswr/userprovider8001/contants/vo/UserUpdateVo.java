package com.yswr.userprovider8001.contants.vo;

import lombok.Data;

@Data
public class UserUpdateVo {
    private String university;
    private String major;
    private String highest_record;
    private String institute;
    private String direction;
    private String avatar;
    private String email;
}
