package com.yswr.userprovider8001.entity;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "third_wx")
public class ThirdWx {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    @Column(name = "public_open_id",unique = true)
    private String publicOpenId;
    private String nickname;
    @Column(name = "head_img_url")
    private String headImgUrl;
    @Column(name = "union_id",unique = true)
    private String unionId;

    ThirdWx(Long id,String nickname,String headImgUrl){
        this.id = id;
        this.nickname = nickname;
        this.headImgUrl = headImgUrl;
    }
}
