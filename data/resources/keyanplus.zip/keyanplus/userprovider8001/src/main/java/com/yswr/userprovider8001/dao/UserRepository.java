package com.yswr.userprovider8001.dao;

import com.yswr.userprovider8001.entity.Account;
import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Account,Long>, JpaSpecificationExecutor<User> {
    Optional <Account> findByPhone(String phone);
    Optional <Account> findByName(String name);
    Boolean existsAccountByName(String name);
//    Optional <Account> findByUnionId(String unionId);
    Boolean existsAccountByUnionId(String unionId);

    @Query(value = "select a.name  from Account as a where a.unionId = ?1")
    String findNameByUnionId(String unionId);


    @Query(value = "select a.union_id from account as a where a.name in ?1",nativeQuery = true)
    List<String> findAllUnionIdByNames(List<String> usernames);

    @Query(value = "select third_wx.public_open_id from (third_wx left join account on account.union_id = third_wx.union_id)  where account.name in ?1",nativeQuery = true)
    List<String> findAllOpenIdByNames(List<String> usernames);

    void deleteByUnionId(String unionId);

    @Modifying
    @Query(value = "update  Account as a  set a.unionId = ?2 where a.name = ?1")
    void bindUnionId(String username,String unionId);
    @Modifying
    @Query(value = "update  Account as a  set a.unionId = null where a.name = ?1")
    void unbindWxUnionByName(String username);

    @Modifying
    @Query(value = "update  Account as a  set a.unionId = null where a.unionId = ?1")
    void unbindWxUnionByUnionId(String unionId);
}
