package com.yswr.userprovider8001.contants;

import com.yswr.userprovider8001.entity.Account;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterUser {
    private Account account;
    private String registerCode;
}
