package com.yswr.userprovider8001.validation;

import com.yswr.userprovider8001.entity.Account;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.regex.Pattern;

/**
 * 手机号校验器
 * */
@Component
public class AccountValidator implements Validator{
    private Pattern p=Pattern.compile("^(?:86)?1(?:3\\d{3}|5[^4\\D]" +
            "\\d{2}|8\\d{3}|7(?:[35678]\\d{2}|4(?:0\\d|1[0-2]|9\\d))|9[189]\\d{2}|66\\d{2})\\d{6}$");



    @Override
    public ValidateResult validate(Object...objects) {
        Account account = (Account) objects[0];
//        用户名校验
        String name = account.getName();
        if (name!=null){
            return ValidateResult.builder().isOk(false).message("不能手动指定用户名").build();
        }
        String phone = account.getPhone();
//        手机号校验
        if (phone == null){
            return ValidateResult.builder().isOk(false).message("手机号码不能为空").build();
        } else if (phone.length() != 13){
            return ValidateResult.builder().isOk(false).message("手机长度错误，必须为13位数字").build();
        }else if (!p.matcher(phone).matches()){
            return ValidateResult.builder().isOk(false).message("手机格式错误，目前仅仅支持国内手机号，请仔细核对").build();
        }
//        姓名校验
        String realName = account.getRealName();
        if (StringUtils.isEmpty(realName)){
            return ValidateResult.builder().isOk(false).message("真实姓名不能为空").build();
        }else if (realName.length() >= 20 ){
            return ValidateResult.builder().isOk(false).message("真实姓名长度不能超过20").build();
        }
//        密码校验
        String password = account.getPassword();
        if (StringUtils.isEmpty(password)){
            return ValidateResult.builder().isOk(false).message("密码不能为空").build();
        }else if (password.length() >= 20 || password.length() <6){
            return ValidateResult.builder().isOk(false).message("密码长度范围为6～20").build();
        }
//        高校校验
        String university = account.getUniversity();
        if (StringUtils.isEmpty(university)){
            return ValidateResult.builder().isOk(false).message("所在高校信息不能为空").build();
        }else if (university.length() >= 50){
            return ValidateResult.builder().isOk(false).message("密码长度范围为6～20").build();
        }

        String email = account.getEmail();
        if (StringUtils.isEmpty(email)){
            return ValidateResult.builder().isOk(false).message("邮箱信息不能为空").build();
        }
//        else if (email.length() >= 27 || email.length()<=6){
//            return ValidateResult.builder().isOk(false).message("邮箱长度范围为6～20").build();
//        }else if (!email.endsWith("edu.cn")&&!email.endsWith("edu")){
//            return ValidateResult.builder().isOk(false).message("邮箱需要以edu.cn或者edu结尾").build();
//        }

//        学院校验
        String institute = account.getInstitute();
        if (StringUtils.isEmpty(institute)){
            return ValidateResult.builder().isOk(false).message("所在学院信息不能为空").build();
        }else if (institute.length() >= 50){
            return ValidateResult.builder().isOk(false).message("密码长度范围为6～20").build();
        }
//        最高学历校验
        String highestRecord = account.getHighestRecord();
        if (StringUtils.isEmpty(highestRecord)){
            return ValidateResult.builder().isOk(false).message("最高学历信息不能为空").build();
        }else if (highestRecord.length() >= 50){
            return ValidateResult.builder().isOk(false).message("最高学历信息长度范围为6～20").build();
        }
//        可选
//        学科校验
        String major = account.getMajor();
        if (!StringUtils.isEmpty(major)&&major.length() >= 50){
            return ValidateResult.builder().isOk(false).message("学科信息长度不能超过50").build();
        }
//        研究方向校验
        String direction = account.getDirection();
        if (!StringUtils.isEmpty(direction)&&direction.length() >= 50){
            return ValidateResult.builder().isOk(false).message("研究方向信息长度不能超过50").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }
}
