package com.yswr.userprovider8001.dao;

import com.yswr.userprovider8001.entity.ThirdWx;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ThirdWxRepository extends JpaRepository<ThirdWx,Long> {

    Optional<ThirdWx> findByUnionId(String unionId);

    @Query(value = "select t.union_id,t.public_open_id,t.id,t.head_img_url,t.nickname from  (third_wx as t left join account as a on t.union_id = a.union_id) where a.name = ?1",nativeQuery = true)
    Optional<ThirdWx> findByUsername(String username);

    void deleteByUnionId(String unionId);
}
