package com.yswr.userprovider8001.validation;

public interface Validator {

    public ValidateResult validate(Object ...objects);
}
