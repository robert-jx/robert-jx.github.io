package com.yswr.userprovider8001.validation;

import com.yswr.userprovider8001.contants.MvcResult;
import com.yswr.userprovider8001.contants.vo.UserUpdateVo;
import com.yswr.userprovider8001.entity.Account;
import org.springframework.stereotype.Component;

@Component
public class AccountUpdateValidator implements Validator{


    @Override
    public ValidateResult validate(Object... objects) {
        if (objects.length!=2){
            return ValidateResult.builder().isOk(false).message("方法调用错误").build();
        }
        UserUpdateVo userUpdateVo = (UserUpdateVo) objects[0];
        Account a = (Account)objects[1];


        if(userUpdateVo.getDirection()!=null){
            if (userUpdateVo.getDirection().length()<=50){
                a.setDirection(userUpdateVo.getDirection());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，专业方向长度应该控制在50字以内").build();
            }
        }
        if(userUpdateVo.getHighest_record()!=null){
            if (userUpdateVo.getHighest_record().length()<=50){
                a.setHighestRecord(userUpdateVo.getHighest_record());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，最高学历长度应该控制在50字以内").build();
            }
        }
        if(userUpdateVo.getInstitute()!=null){
            if (userUpdateVo.getInstitute().length()<=50){
                a.setInstitute(userUpdateVo.getInstitute());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，学院名称长度应该控制在50字以内").build();
            }
        }
        if(userUpdateVo.getMajor()!=null){
            if (userUpdateVo.getMajor().length()<=50){
                a.setMajor(userUpdateVo.getMajor());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，学科名称长度应该控制在50字以内").build();
            }
        }
        if(userUpdateVo.getUniversity()!=null){
            if (userUpdateVo.getUniversity().length()<=50){
                a.setUniversity(userUpdateVo.getUniversity());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，高校长度应该控制在50字以内").build();
            }
        }

        if(userUpdateVo.getAvatar()!=null){
            if (userUpdateVo.getAvatar().length()<255){
                a.setAvatar(userUpdateVo.getAvatar());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，url长度应该控制在255以内").build();
            }
        }
        if(userUpdateVo.getEmail()!=null){
            if (userUpdateVo.getEmail().length()<28){
                a.setEmail(userUpdateVo.getEmail());
            }else {
                return ValidateResult.builder().isOk(false).message("修改个人信息失败，邮箱长度应该控制在27以内").build();
            }
        }
        return ValidateResult.builder().isOk(true).build();
    }
}
