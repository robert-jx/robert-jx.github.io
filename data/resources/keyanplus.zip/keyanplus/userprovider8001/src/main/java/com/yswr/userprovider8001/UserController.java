package com.yswr.userprovider8001;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.yswr.userprovider8001.contants.MvcResult;
import com.yswr.userprovider8001.contants.RegisterUser;
import com.yswr.userprovider8001.contants.TokenResult;
import com.yswr.userprovider8001.contants.vo.UserUpdateVo;
import com.yswr.userprovider8001.entity.Account;
import com.yswr.userprovider8001.entity.ThirdWx;
import com.yswr.userprovider8001.utils.JwtUtil;
import com.yswr.userprovider8001.validation.AccountUpdateValidator;
import com.yswr.userprovider8001.validation.AccountValidator;
import com.yswr.userprovider8001.validation.ValidateResult;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.net.URI;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*",methods = {RequestMethod.POST,RequestMethod.PUT,RequestMethod.GET,RequestMethod.POST,RequestMethod.HEAD})
@Slf4j
public class UserController {
    private static final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    public static final String Redis_Login_prefix = "login_";
    public static final String Redis_Register_prefix = "register_";
    public static final String Redis_Fix_Phone_prefix = "fix_phone_";

    public static final String Redis_Fix_Phone_Confirm_prefix = "fix_phone_confirm_";
    public static final String Redis_Fix_Password_prefix = "fix_password_";
    private static final Pattern p=Pattern.compile("^(?:86)?1(?:3\\d{3}|5[^4\\D]" +
            "\\d{2}|8\\d{3}|7(?:[35678]\\d{2}|4(?:0\\d|1[0-2]|9\\d))|9[189]\\d{2}|66\\d{2})\\d{6}$");

    @Resource
    UserService userService;

    @Resource
    RedisTemplate<String,Object> redisTemplate;
    @Resource
    AccountValidator accountValidator;
    @Resource
    AccountUpdateValidator accountUpdateValidator;

    @Resource
    RestTemplate restTemplate;

    private JwtUtil.TokenMessage check(HttpServletRequest httpServletRequest) {
        try {
            String token = httpServletRequest.getHeader("Authentication");
            if (StringUtils.isEmpty(token)){
                throw new NullPointerException("缺少凭证，无法调用该接口");
            }
            return JwtUtil.getTokenMessage(token);
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    /**
     * 获得12个长度的十六进制的UUID
     * @return UUID
     */
    private static String get12UUID(){
        UUID id=UUID.randomUUID();
        String[] idd=id.toString().split("-");
        return idd[0]+idd[1];
    }
    /**
     * 查询是否存在该用户
     * 1。 被实验室系统调用
     * 2。 没有request 校验
     * */
    @GetMapping("/exist")
    public MvcResult<Object> existUser(@RequestParam String name){
        return MvcResult.builder().code(20000).data(userService.isExist(name)).build();
    }

    /**
     * 查询是否存在该用户
     * 1。 被第三方代理系统调用
     * */
    @GetMapping("/getByUnionId/{unionId}")
    public Boolean findByUnionId(@PathVariable String unionId){
        try {
            return userService.existUserByUnionId(unionId);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
    /**
     * 查询是否存在该用户
     * 1。 被第三方代理系统调用
     * */
    @GetMapping("/getNameByUnionId/{unionId}")
    public String findNameByUnionId(@PathVariable String unionId){
        try {
            return userService.findUserNameByUnionId(unionId);
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 添加wx记录
     *
     * return{
         * success
         * duplicate
         * fail
     * }
     *
     * */
    @PostMapping("/setThirdWx")
    public String setUnionWx(@RequestBody ThirdWx thirdWx){
        try {
            if (thirdWx.getId()!=null){
                return "fail";
            }
            String unionId = thirdWx.getUnionId();
            ThirdWx thirdWx1 = userService.findThirdByUnionId(unionId);
            String accountName = userService.findUserNameByUnionId(unionId);
            if (thirdWx1==null){
                userService.saveThirdWx(thirdWx);
            }
            return StringUtils.isEmpty(accountName)?"unbind":"bind";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

    @PostMapping("/getAllUnionId")
    public String getAllUnionId(@RequestBody List<String> usernames){
        try {
            if (usernames==null||usernames.isEmpty()){
                return "fail";
            }
            List<String> list = userService.findAllUnionIdByUsernames(usernames);
            if (list.isEmpty()){
                return "fail";
            }
            return JSONArray.toJSONString(list);
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

    @PostMapping("/getAllOpenId")
    public String getAllOpenId(@RequestBody List<String> usernames){
        try {
            if (usernames==null||usernames.isEmpty()){
                return "fail";
            }
            List<String> list = userService.findAllOpenIdByUsernames(usernames);
            if (list.isEmpty()){
                return "fail";
            }
            return JSONArray.toJSONString(list);
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }


    @GetMapping("/confirmPassword")
    public MvcResult<Object> confirmPassword(String password,HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Account account = userService.findUserByName(tokenMessage.getUsername());
            if (account==null){
                return MvcResult.DATA_NULL;
            }
            if (passwordEncoder.matches(password,account.getPassword())){
                redisTemplate.opsForValue().set(Redis_Fix_Phone_Confirm_prefix+account.getPhone(),true,300, TimeUnit.SECONDS);
                return MvcResult.SUCCESS;
            }
            return MvcResult.AUTHORIZE_ERROR;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    @Deprecated
    @GetMapping("/removeThirdWx")
    public String removeUnionWx(String unionId){
        try {
            userService.deleteUnionWx(unionId);
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

    /**
     * 修改手机号
     * */
    @GetMapping("/fixPhone")
    public MvcResult<Object> fixPhone(String newPhone,String code,HttpServletRequest request){

        try {

            if (newPhone.length() != 13){
                return MvcResult.builder().code(40300).message("手机长度错误，必须为13位数字").build();
            }else if (!p.matcher(newPhone).matches()){
                return MvcResult.builder().code(40300).message("手机格式错误，目前仅仅支持国内手机号，请仔细核对").build();
            }
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Account account = userService.findUserByName(tokenMessage.getUsername());
            if (account==null){
                return MvcResult.AUTHORIZE_ERROR;
            }
            // 校验code
            Boolean redis_confirm_code = (Boolean) Objects.requireNonNull(redisTemplate.opsForValue().get((Redis_Fix_Phone_Confirm_prefix + account.getPhone()).trim()));
            if (!redis_confirm_code){
                return MvcResult.builder().code(50000).message("没有确认密码").build();
            }
            // 校验code
            String redis_code = Objects.requireNonNull(redisTemplate.opsForValue().get((Redis_Fix_Phone_prefix + account.getPhone()).trim())).toString();
            if (!redis_code.equals(code)){
                return MvcResult.ILLEGAL_ARGS;
            }
            // 修改手机号
            account.setPhone(newPhone);
            userService.save(account);
            return MvcResult.SUCCESS;
        }catch (NullPointerException n){
            n.printStackTrace();
            return MvcResult.DATA_NULL;
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 修改密码
     * */
    @GetMapping("/fixPassword")
    public MvcResult<Object> fixPassword(String phone,String newPassword,String code,HttpServletRequest request){

        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }

            Account account = userService.findUserByName(tokenMessage.getUsername());
            if (account==null){
                return MvcResult.AUTHORIZE_ERROR;
            }

            // 校验code
            String redis_code = Objects.requireNonNull(redisTemplate.opsForValue().get((Redis_Fix_Password_prefix + phone).trim())).toString();
            if (!redis_code.equals(code)){
                return MvcResult.ILLEGAL_ARGS;
            }
            // 修改密码
            account.setPassword(passwordEncoder.encode(newPassword));
            userService.save(account);
            return MvcResult.SUCCESS;
        }catch (NullPointerException n){
            n.printStackTrace();
            return MvcResult.DATA_NULL;
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }



    /**
     * 网页端绑定账号
     * */
    @GetMapping("/bindAccountWeb")
    public MvcResult<Object> bindAccountWeb(HttpServletRequest  httpServletRequest,String unionId){
        try {
            JwtUtil.TokenMessage tokenMessage = check(httpServletRequest);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            String username = tokenMessage.getUsername();
            Account account = userService.findUserByName(username);
            if (account == null){
                return MvcResult.TOKEN_PARSE_ERROR;
            }

            ThirdWx thirdWx = userService.findThirdByUnionId(unionId);
            log.info("bind unionId :{}",unionId);
            if (thirdWx==null){
                return MvcResult.builder().message("用户没有关注公众号").code(50000).build();
            }
            if (account.getUnionId()!=null&&account.getUnionId().equals(unionId)){
                return MvcResult.builder().message("请勿重复绑定同一个账号").code(50000).build();
            }
            if (account.getUnionId()!=null){
                return MvcResult.builder().message("该账号已经绑定了一个微信用户，请先解除当前账号与微信的绑定").code(50000).build();
            }
            String existName = userService.findUserNameByUnionId(unionId);
            if (existName!=null){
                return MvcResult.builder().message("该微信账号已经绑定了其他账户，请先解除当前微信账号绑定的账户").code(50000).build();
            }

            userService.bindUnionId(username,unionId);
            String result = restTemplate.exchange("https://keyanplus.com/api/v1/third/wx/public/tagAccount?openId="+thirdWx.getPublicOpenId(), HttpMethod.GET,null,String.class).getBody();
            if ("success".equals(result)){
                return MvcResult.builder().message("绑定成功").code(20000).build();
            }else {
                userService.unbindWxUnionByName(username);
                return MvcResult.builder().message("绑定失败").code(40300).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 解除绑定账号网页端
     * */
    @GetMapping("/unbindAccount")
    public MvcResult<Object> unbindAccount(HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            String username = tokenMessage.getUsername();
            Account account = userService.findUserByName(username);
            if (account==null){
                return MvcResult.builder().code(50000).message("没有找到对应用户").build();
            }
            if (account.getUnionId()==null){
                return MvcResult.builder().code(50000).message("用户没有关联的微信信息").build();
            }
            ThirdWx thirdWx = userService.findThirdByUnionId(account.getUnionId());
            if (thirdWx==null){
                return MvcResult.builder().code(50000).message("用户没有关注公众号").build();
            }
            userService.unbindWxUnionByName(username);
//            String result = restTemplate.exchange("https://keyanplus.com/api/v1/third/wx/public/untagAccount?openId="+thirdWx.getPublicOpenId(), HttpMethod.GET,null,String.class).getBody();
//            if ("success".equals(result)){
//                return MvcResult.builder().message("解除绑定成功").code(20000).build();
//            }else {
//                userService.bindUnionId(username,account.getUnionId());
//                return MvcResult.builder().message("解除绑定失败").code(20000).build();
//            }
            return MvcResult.builder().message("解除绑定成功").code(20000).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 绑定账号
     * 内部接口
     * */
    @GetMapping("/bindAccount")
    public String bindAccount(String username,String unionId){
        try {
            log.info(username);
            Account account = userService.findUserByName(username);

            ThirdWx thirdWx = userService.findThirdByUnionId(unionId);
            if (thirdWx==null){
                return "no mark";
            }
//            if (account.getUnionId().equals(unionId)){
//                return "duplicate";
//            }
            String existName = userService.findUserNameByUnionId(unionId);
            if (existName!=null){
                return "unionIdBound";
            }
            userService.bindUnionId(username,unionId);
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }

//    /**
//     * 解除绑定账号
//     * */
//    @GetMapping("/unbindAccountByName")
//    public String unbindAccountByName(String username){
//        try {
//            userService.unbindWxUnionByName(username);
//            return "success";
//        }catch (Exception e){
//            e.printStackTrace();
//            return "fail";
//        }
//    }

    @GetMapping("/unbindAccountByUnionId")
    public String unbindAccountByUnionId(String unionId){
        try {
            userService.unbindWxUnionByUnionId(unionId);
            return "success";
        }catch (Exception e){
            e.printStackTrace();
            return "fail";
        }
    }


    /**
     * 获取用户信息
     * 1。要求用户已经登录
     * 2。
     * 3。
     * */
    @GetMapping("/getInfo")
    public MvcResult<Object> getInfo(HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Account a = userService.findUserByName(tokenMessage.getUsername());
            return MvcResult.builder().message("获取成功").code(20000).data(
                   a
            ).build();
        } catch (NullPointerException e){
            return MvcResult.builder().code(50000).message(e.getMessage()).build();
        }catch (ExpiredJwtException e){
            return MvcResult.TOKEN_EXPIRED;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    @GetMapping("/getWxInfo")
    public MvcResult<Object> getWxInfo(HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            ThirdWx t = userService.findThirdByUsername(tokenMessage.getUsername());
            t.setPublicOpenId(null);
            t.setUnionId(null);
            return MvcResult.builder().message("获取成功").code(20000).data(
                    t
            ).build();
        } catch (NullPointerException e){
            return MvcResult.builder().code(50000).message(e.getMessage()).build();
        }catch (ExpiredJwtException e){
            return MvcResult.TOKEN_EXPIRED;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 修改用户信息
     * 1。 要求用户必须登录，使用用户修改校验器
     * 2。 该接口不提供密码修改修改 该接口不提供手机号修改 该接口不提供状态修改
     * */
    @PutMapping("/")
    public MvcResult<Object> fixInfo(HttpServletRequest servletRequest, @RequestBody UserUpdateVo userUpdateVo){
        try {
            JwtUtil.TokenMessage tokenMessage = check(servletRequest);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Account a = userService.findUserByName(tokenMessage.getUsername());
            accountUpdateValidator.validate(userUpdateVo,a);
            userService.save(a);
            return MvcResult.builder().message("修改成功").code(20000).build();
        } catch (NullPointerException e){
            return MvcResult.builder().code(50000).message(e.getMessage()).build();
        }catch (ExpiredJwtException e){
            return MvcResult.TOKEN_EXPIRED;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }




    /**
     * 手机注册用户
     * 1。 使用用户校验器 ，验证user 参数信息。
     * 2。 查看是否存在手机号
     * 3。 校验redis 验证码
     * 4。 生成账户名
     * */
    @PostMapping("/phoneRegister")
    public MvcResult<Object> register(@RequestBody RegisterUser registerUser){
        //参数校验
        try {
            Account user = registerUser.getAccount();
            ValidateResult validateResult = accountValidator.validate(user);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().message(validateResult.getMessage()).code(40300).build();
            }
//        重复校验
            try {
                userService.findUserByPhone(user.getPhone());
                return MvcResult.builder().code(40306).message("用户已存在").build();
            }catch (NullPointerException n){
                // 用户不存在时
                log.info("no exist phone is :"+"register_" + user.getPhone());
                log.info("is equals register_13643053268 {}","register_13643053268".equals("register"+user.getPhone()));

                Object redisObject = redisTemplate.opsForValue().get(("register_" + user.getPhone()).trim());
                if (redisObject==null){
                    return MvcResult.builder().code(40304).message("短信尚未发送").build();
                }
                String redis_code = redisObject.toString();
                if (StringUtils.isEmpty(redis_code)){
                    return MvcResult.builder().code(40305).message("验证码已过期").build();
                }
                if (!redis_code.equals(registerUser.getRegisterCode())){
                    return MvcResult.builder().code(40306).message("验证码错误").build();
                }
//        成功注册逻辑
                try {
                    redisTemplate.delete("register_" + user.getPhone());
                    String encodedPassword = passwordEncoder.encode(user.getPassword());
                    user.setPassword(encodedPassword);
                    user.setName("kyp_" + get12UUID());
                    user.setPhone(user.getPhone());
                    user.setDisable(false);
                    userService.save(user);
                    String s  = restTemplate.exchange(URI.create("https://keyanplus.com/api/v1/utils/members/init/"+user.getName()),HttpMethod.POST,null,String.class).getBody();
                    log.info(user.getName()+ "register :" + s);
                    return MvcResult.builder().code(20000).message("注册成功")
                            .data(TokenResult.builder()
                                    .access_token(
                                            JwtUtil.generateToken(
                                                    JwtUtil.TokenMessage.builder()
                                                            .username(user.getName())
                                                            .role(JSONObject.toJSONString("ROLE_ALL"))
                                                            .build())
                                    )
                                    .refresh_token(JwtUtil.generateRefreshToken(
                                            JwtUtil.TokenMessage.builder()
                                                    .username(user.getName())
                                                    .role(JSONObject.toJSONString("ROLE_ALL"))
                                                    .build())
                                    )
                                    .build())
                            .build();
                }catch (Exception e){
                    e.printStackTrace();
                    return MvcResult.builder().code(50000).message("服务器错误，注册失败").build();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
//        redis校验码

    }

    /**
     * 删除用户
    * */
    @DeleteMapping("/")
    public MvcResult<Object> deleteUserById(@RequestParam Long id){
        try {
            userService.delete(id);
            log.info("假设调用实验室系统删除用户的接口");
            return MvcResult.builder().code(20000).message("删除成功").build();
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.builder().code(50000).message("删除失败").build();
        }
    }
}
