package com.yswr.userprovider8001.contants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MvcResult<T> {
    private Integer code;
    private String message;
    private T data;


    public static final MvcResult<Object> SUCCESS = MvcResult.builder().code(20000).message("调用成功").build();
    public static final MvcResult<Object> FAIL = MvcResult.builder().code(40300).message("登陆失败").build();
    public static final MvcResult<Object> ERROR = MvcResult.builder().code(50000).message("服务器发生错误，请联系客服").build();

    public static final MvcResult<Object> AUTHORIZE_ERROR = MvcResult.builder().code(50000).message("校验失败").build();
    public static final MvcResult<Object> DATA_NULL = MvcResult.builder().code(20002).message("没有相关数据").build();
    public static final MvcResult<Object> NO_IN_LAB = MvcResult.builder().message("您没有在任何一个实验室中").code(20001).build();
    public static final MvcResult<Object> NO_ARGS =  MvcResult.builder().code(40300).message("缺少必要参数").build();
    public static final MvcResult<Object> ILLEGAL_ARGS = MvcResult.builder().code(40300).message("不合法的参数").build();


    /**
     * 40390～40399
     * token相关错误错误码集合
     */
    public static final MvcResult<Object> AUTHENTICATION_TOKEN_NULL =  MvcResult.builder().message("token 不能为空").code(40398).build();
    public static final MvcResult<Object> REFRESH_TOKEN_EXPIRED =  MvcResult.builder().message("refresh_token 已过期").code(40399).build();
    public static final MvcResult<Object> TOKEN_PARSE_ERROR =  MvcResult.builder().code(40397).message("token 失效，解析失败").build();
    public static final MvcResult<Object> TOKEN_EXPIRED =  MvcResult.builder().code(40397).message("token 过期").build();

    /**
     * 40380～40389
     * 用户相关错误错误码集合
     */
    public static final MvcResult<Object> LAB_USER_NULL =  MvcResult.builder().code(40380).message("没有找到实验室成员").build();


}
