mv ../target/user8001-v1.jar .
docker-compose down



 docker-compose up -d --build