package com.yswr.authorize8000;

import com.yswr.authorize8000.utils.SmsUtil;
	import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;
import java.util.regex.Pattern;

@SpringBootTest
class Authorize8000ApplicationTests {
	private Pattern p=Pattern.compile("^(?:86)?1(?:3\\d{3}|5[^4\\D]" +
			"\\d{2}|8\\d{3}|7(?:[35678]\\d{2}|4(?:0\\d|1[0-2]|9\\d))|9[189]\\d{2}|66\\d{2})\\d{6}$");

	@Resource
	SmsUtil smsUtil;
	@Resource
	RedisTemplate<String,Object> redisTemplate;
	@Resource
	RestTemplate restTemplate;
	@Test
	void contextLoads() {
		URI uri = URI.create("https://keyanplus.com/api/v1/oauth/login?openId=123&login_type=wx_public_openId");
		HttpHeaders headers = new HttpHeaders();
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setContentType(type);
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());
		HttpEntity<String> formEntity = new HttpEntity<>(null, headers);
		System.out.println(restTemplate.exchange(uri, HttpMethod.POST,formEntity,String.class).getBody());
	}

	@Test
	void contextLoads2(){
		System.out.println(redisTemplate.opsForValue().get("register_8613643053268"));
	}

}
