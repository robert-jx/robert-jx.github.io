package com.yswr.authorize8000.validation;

import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

/**
 * 手机号校验器
 * */
@Component
public class AccountPhoneValidator implements Validator{
    private static final Pattern p=Pattern.compile("^(?:86)?1(?:3\\d{3}|5[^4\\D]" +
            "\\d{2}|8\\d{3}|7(?:[35678]\\d{2}|4(?:0\\d|1[0-2]|9\\d))|9[189]\\d{2}|66\\d{2})\\d{6}$");

    @Override
    public ValidateResult validate(Object...objects) {
        String phone = objects[0].toString();
        if (phone == null){
            return ValidateResult.builder().isOk(false).message("手机号码不能为空").build();
        } else if (phone.length() != 13){
            return ValidateResult.builder().isOk(false).message("手机长度错误，必须为13位数字").build();
        }else if (!p.matcher(phone).matches()){
            return ValidateResult.builder().isOk(false).message("手机格式错误，目前仅仅支持国内手机号，请仔细核对").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }
}
