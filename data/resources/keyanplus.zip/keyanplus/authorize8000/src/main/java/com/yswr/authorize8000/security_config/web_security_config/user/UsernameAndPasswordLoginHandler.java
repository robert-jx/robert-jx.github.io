package com.yswr.authorize8000.security_config.web_security_config.user;

import com.yswr.authorize8000.security_config.custom.AbstractLoginHandler;
import com.yswr.authorize8000.security_config.custom.LoginException;
import com.yswr.authorize8000.security_config.web_security_config.basic.CAuthenticationToken;
import com.yswr.authorize8000.security_config.web_security_config.basic.CLoginFilter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
@Component
public class UsernameAndPasswordLoginHandler extends AbstractLoginHandler implements InitializingBean {
    public final   static  String AUTH_TYPE = "user";
    private final   static  String AUTH_param1 = "username";
    private final   static  String AUTH_param2 = "password";
    private String username;
    private String password;
    @Override
    public void loadParams(HttpServletRequest request) throws LoginException {
       username =  request.getParameter(AUTH_param1);
       password =  request.getParameter(AUTH_param2);
       if ( StringUtils.isEmpty(username)||StringUtils.isEmpty(password))
       {
           throw new LoginException("缺少验证信息");
       }
       /**
        * 添加验证代码
        * */
    }

    @Override
    public Authentication generateAuthenticaiton() throws LoginException{

        CAuthenticationToken authRequest = new CAuthenticationToken(
                username, password,AUTH_TYPE,null);
        /**
         * 添加额外字段
         * */
        return authRequest;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        CLoginFilter.registerHandler(AUTH_TYPE,this);
    }
}
