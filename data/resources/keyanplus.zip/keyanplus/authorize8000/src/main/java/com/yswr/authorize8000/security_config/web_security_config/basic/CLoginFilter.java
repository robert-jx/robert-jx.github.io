package com.yswr.authorize8000.security_config.web_security_config.basic;

import com.alibaba.fastjson.JSONObject;
import com.yswr.authorize8000.contants.MvcResult;
import com.yswr.authorize8000.contants.TokenResult;
import com.yswr.authorize8000.security_config.custom.AbstractLoginHandler;
import com.yswr.authorize8000.utils.JwtUtil;
import com.yswr.authorize8000.security_config.custom.LoginException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

/**
 * 实现自定义登陆过滤链
 * */
@Slf4j
public class CLoginFilter extends AbstractAuthenticationProcessingFilter {

    protected static final String AUTH_PARAMS = "login_type";
    private static final HashMap<String, AbstractLoginHandler> handlers = new HashMap<>(8);
    public static void registerHandler(String type,AbstractLoginHandler abstractLoginHandler){
        handlers.put(type,abstractLoginHandler);
    }
    private final AuthenticationManager authenticationManager;
    public CLoginFilter(AuthenticationManager authenticationManager){
        super(new AntPathRequestMatcher("/oauth/login","POST"));
        this.authenticationManager = authenticationManager;
    }
    @Override
    protected boolean requiresAuthentication(HttpServletRequest request, HttpServletResponse response) {
        String token = request.getHeader("Authentication");
        if (token!=null&&!request.getRequestURI().startsWith("/oauth/login")||SecurityContextHolder.getContext().getAuthentication()!=null){
            return false;
        }
        log.info("enter login filter url is :{}",request.getRequestURL());
        return super.requiresAuthentication(request,response);
    }
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        String type = request.getParameter(AUTH_PARAMS);

        AbstractLoginHandler abstractLoginHandler =handlers.get(type);
        if (abstractLoginHandler == null){
            throw new LoginException("没有指定认证类型");
        }
        abstractLoginHandler.loadParams(request);
        Authentication authentication = abstractLoginHandler.generateAuthenticaiton();
        log.info("attemptAuthentication : {}",authentication);
        return authenticationManager.authenticate(authentication);
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response, FilterChain chain, Authentication authResult)
            throws IOException {
        SecurityContextHolder.getContext().setAuthentication(authResult);
        CAuthenticationToken authenticationToken = (CAuthenticationToken) authResult;
        log.info("login success : {}",authResult.getDetails());
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=UTF-8");
        response.getWriter().write(JSONObject.toJSONString(
                MvcResult.builder().code(20000).message("登录成功")
                        .data(TokenResult.builder()
                                .access_token(
                                        JwtUtil.generateToken(
                                                JwtUtil.TokenMessage.builder()
                                                        .username(authResult.getPrincipal().toString())
                                                        .realName(authenticationToken.getDetails().toString())
                                                        .role(JSONObject.toJSONString(authResult.getAuthorities()))
                                                        .build())
                                )
                                .refresh_token(JwtUtil.generateRefreshToken(
                                        JwtUtil.TokenMessage.builder()
                                                .username(authResult.getPrincipal().toString())
                                                .realName(authenticationToken.getDetails().toString())
                                                .role(JSONObject.toJSONString(authResult.getAuthorities()))
                                                .build())
                                )
                                .build())
                        .build())
                );
//        chain.doFilter(request,response);
    }

    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
        log.info("unSuccess");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=UTF-8");
        response.getWriter().write(JSONObject.toJSONString(
                MvcResult.builder().code(40300).message(failed.getMessage()).build()
        ));
    }
}
