package com.yswr.authorize8000.service.user;

import com.yswr.authorize8000.dao.UserRepository;
import com.yswr.authorize8000.entity.Account;
import com.yswr.authorize8000.service.user.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    UserRepository userRepository;
    @Override
    public Account loadUserByUsername(String username) {
        return userRepository.findByName(username).orElse(null);
    }

    @Override
    public Account loadUserByPhone(String phone) {
        return userRepository.findByPhone(phone).orElse(null);
    }

    @Override
    public Account loadUserByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    @Override
    public Account loadUserByUnionId(String unionId) {
        return userRepository.findByUnionId(unionId).orElse(null);
    }
    @Override
    public Account loadUserByOpenId(String openId){
        return userRepository.findByOpenId(openId).orElse(null);
    }
}
