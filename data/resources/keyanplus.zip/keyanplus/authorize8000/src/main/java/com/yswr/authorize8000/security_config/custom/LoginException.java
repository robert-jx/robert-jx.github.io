package com.yswr.authorize8000.security_config.custom;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

/**
 * 用于全局捕捉登陆出现的问题
 * */

public class LoginException extends AuthenticationException {
    public LoginException(String message) {
        super(message);
    }
}
