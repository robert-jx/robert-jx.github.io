package com.yswr.authorize8000.security_config.web_security_config.basic;

import com.yswr.authorize8000.security_config.custom.CUserDetail;
import com.yswr.authorize8000.security_config.authenticationserver_config.CUserDetailService;
import com.yswr.authorize8000.security_config.custom.LoginException;
import com.yswr.authorize8000.security_config.web_security_config.phone.PhoneAndMessageLoginHandler;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * 附加登陆校验逻辑
 * */



@AllArgsConstructor
@Slf4j
public class CAuthenticationProvider extends CAbstractAuthenticationProvider {
    private final PasswordEncoder passwordEncoder;
    private final CUserDetailService cUserDetailService;
    /**
     * 根据自定义login_message 返回数据库中查找到的对象
     * */
    @Override
    protected CUserDetail retrieveUser(String login_message, CAuthenticationToken authentication) throws AuthenticationException {
        CUserDetail loadedUser;
        log.info("Login Message{}",login_message);
        loadedUser = this.cUserDetailService.loadUserByUsername(login_message);
        if (loadedUser == null) {
            throw new LoginException("登陆错误没找到该用户");
        } else {
            return loadedUser;
        }
    }
    /**
     * 进行密码校验
     * */
    @Override
    protected void additionalAuthenticationChecks(CUserDetail userDetails, CAuthenticationToken authentication) throws AuthenticationException {
        // 用户名密码验证
        if (authentication.getType().contains("password")){
            String presentedPassword = authentication.getCredentials().toString();
            if (!this.passwordEncoder.matches(presentedPassword, userDetails.getPassword())) {
                throw new BadCredentialsException("密码错误");
            }
        }

    }
}

