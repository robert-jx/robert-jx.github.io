package com.yswr.authorize8000.security_config.web_security_config.basic;

import com.yswr.authorize8000.security_config.custom.CUserDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsChecker;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.Assert;
/**
 * 定义登陆认证主逻辑
 * */
@Slf4j
public abstract class CAbstractAuthenticationProvider implements AuthenticationProvider {
    protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
//    private final UserDetailsChecker preAuthenticationChecks = new DefaultPreAuthenticationChecks();
//    private final UserDetailsChecker postAuthenticationChecks = new DefaultPostAuthenticationChecks();


    /**
     * 重新创建一个经过认证的token，principal 为账户名 credentials 为密码   user 为数据库读回的用户
     * */
    protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, CUserDetail user) {
        CAuthenticationToken result = new CAuthenticationToken(user.getUsername(), authentication.getCredentials(),
                ((CAuthenticationToken) authentication).getType(),
                AuthorityUtils.createAuthorityList("ROLE_USER"));
//        result.setDetails(authentication.getDetails());
        result.setDetails(user.getRealName());
        return result;
    }
    /**
     * 定义校验逻辑
     * 匹配CAuthenticationToken 的凭证进行校验
     * 分为3部分
     * 1. 获取用户
     * 2. 校验用户与凭证
     * 3. 生成认证成功凭证
     * */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        Assert.isInstanceOf(CAuthenticationToken.class, authentication,
                () -> messages.getMessage(
                        "CAbstractAuthenticationProvider.onlySupports",
                        "Only CAuthenticationToken is supported"));
        CAuthenticationToken cAuthenticationToken  = (CAuthenticationToken)authentication;
        CUserDetail user = retrieveUser(cAuthenticationToken.getType()+","+cAuthenticationToken.getPrincipal().toString(),
                cAuthenticationToken);
        log.info("CAbstractAuthenticationProvider: 查询到user ：{}", user);
//        preAuthenticationChecks.check(user);
        additionalAuthenticationChecks(user,
                (CAuthenticationToken) authentication);
        /*
        * 缓存处理
        * */
//        postAuthenticationChecks.check(user);
        return createSuccessAuthentication(authentication.getPrincipal(),authentication,user);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return (CAuthenticationToken.class
                .isAssignableFrom(authentication));
    }

    protected abstract CUserDetail retrieveUser(String login_message, CAuthenticationToken authentication)
            throws AuthenticationException;

    protected abstract void additionalAuthenticationChecks(CUserDetail userDetails,
                                                           CAuthenticationToken authentication)
            throws AuthenticationException;
//    private class DefaultPreAuthenticationChecks implements UserDetailsChecker {
//        @Override
//        public void check(UserDetails user) {
//            if (!user.isAccountNonLocked()) {
//                log.debug("User account is locked");
//
//                throw new LockedException(messages.getMessage(
//                        "AbstractUserDetailsAuthenticationProvider.locked",
//                        "User account is locked"));
//            }
//
//            if (!user.isEnabled()) {
//                log.debug("User account is disabled");
//
//                throw new DisabledException(messages.getMessage(
//                        "AbstractUserDetailsAuthenticationProvider.disabled",
//                        "User is disabled"));
//            }
//
//            if (!user.isAccountNonExpired()) {
//                log.debug("User account is expired");
//
//                throw new AccountExpiredException(messages.getMessage(
//                        "AbstractUserDetailsAuthenticationProvider.expired",
//                        "User account has expired"));
//            }
//        }
//    }
//
//    private class DefaultPostAuthenticationChecks implements UserDetailsChecker {
//        @Override
//        public void check(UserDetails user) {
//            if (!user.isCredentialsNonExpired()) {
//                log.debug("User account credentials have expired");
//
//                throw new CredentialsExpiredException(messages.getMessage(
//                        "AbstractUserDetailsAuthenticationProvider.credentialsExpired",
//                        "User credentials have expired"));
//            }
//        }
//    }
}
