package com.yswr.authorize8000.security_config.web_security_config;

import com.yswr.authorize8000.security_config.web_security_config.basic.CLoginFilter;
import com.yswr.authorize8000.service.user.UserService;
//import com.yswr.authorize8000.security_config.web_security_config.basic.CLoginFilter;
import com.yswr.authorize8000.security_config.authenticationserver_config.CUserDetailService;
import com.yswr.authorize8000.security_config.web_security_config.basic.CAuthenticationProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


/*
* 资源中心认证配置
* */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    /**
     * 安全拦截机制 同spring boot
     */
    @Resource
    private RedisTemplate<String,Object> redisTemplate;

    @Resource
    private  UserService userService;

    @Resource
    private  PasswordEncoder passwordEncoder;

//
//    @Bean(name = "myAuthenticationManagerBean")
//    @Override
//    public AuthenticationManager authenticationManagerBean() throws Exception {
//        return super.authenticationManagerBean();
//    }
    public AuthenticationProvider getAuthenticationProvider() {
        CAuthenticationProvider daoAuthenticationProvider = new CAuthenticationProvider(passwordEncoder,userDetailsService());
        return daoAuthenticationProvider;
    }
     public AuthenticationManager getAuthenticationManagerBean(){
        List<AuthenticationProvider> authenticationProviders = new ArrayList<>();
        authenticationProviders.add(getAuthenticationProvider());
        return new ProviderManager(authenticationProviders);
    }


    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .addFilterBefore(new CLoginFilter(getAuthenticationManagerBean()),UsernamePasswordAuthenticationFilter.class)
                .authorizeRequests()
                // 放行
                .antMatchers("/**")
                .permitAll()
                // 其他请求必须认证通过
                .anyRequest().authenticated()
                .and()
                .formLogin() // 允许表单登录
//                .successForwardUrl("/login-success") //自定义登录成功跳转页
                .and()

                .csrf().disable();
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

    }
    @Bean
    @Override
    protected CUserDetailService userDetailsService() {
        return new CUserDetailService(redisTemplate,userService);
    }


}
