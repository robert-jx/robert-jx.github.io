package com.yswr.authorize8000.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GeneratorType;
import org.hibernate.id.UUIDGenerationStrategy;
import org.hibernate.tuple.GeneratedValueGeneration;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "account")
@Entity
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    private String name;
    private String password;
    private String phone;
    private String email;
    private Boolean disable;
    private String avatar;
    @Column(name = "realname")
    private String realName;
    private String university;
    private String major;
    @Column(name = "highest_record")
    private String highestRecord;
    private String institute;
    private String direction;
    @Column(name = "create_time")
    private Date createTime = new Date();
    @Column(name = "union_id")
    private String unionId;
}
