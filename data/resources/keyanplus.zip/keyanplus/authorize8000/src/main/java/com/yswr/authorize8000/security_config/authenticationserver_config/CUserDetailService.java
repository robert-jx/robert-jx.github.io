package com.yswr.authorize8000.security_config.authenticationserver_config;

import com.alibaba.fastjson.JSONObject;
import com.yswr.authorize8000.contants.BaseMessage;
import com.yswr.authorize8000.controller.AuthenticationController;
import com.yswr.authorize8000.entity.Account;
import com.yswr.authorize8000.security_config.web_security_config.email.EmailAndPasswordLoginHandler;
import com.yswr.authorize8000.security_config.web_security_config.phone.PhoneAndMessageLoginHandler;
import com.yswr.authorize8000.security_config.web_security_config.phone.PhoneAndPasswordLoginHandler;
import com.yswr.authorize8000.security_config.web_security_config.user.UsernameAndPasswordLoginHandler;
import com.yswr.authorize8000.security_config.web_security_config.wx.WxPublicOpenIdLoginHandler;
import com.yswr.authorize8000.security_config.web_security_config.wx.WxPublicUnionIdLoginHandler;
import com.yswr.authorize8000.service.user.UserService;
import com.yswr.authorize8000.security_config.custom.CUserDetail;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Slf4j
@AllArgsConstructor
public class CUserDetailService implements UserDetailsService
{
    private final RedisTemplate<String,Object> redisTemplate;
    private final UserService userService;

    public static void main(String[] args) {
        String str = "gQHU7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAycGMzczhwMC1lUkUxLVNoT2h2Y1oAAgRez-JfAwRYAgAA;o2-Y4wxBGHaULmpV9G-7QPS6_olg";
        String [] s = str.split("\\;");
        log.info("{} {} {}",s.length,s[0],s[1]);
    }

    @Override
    public CUserDetail loadUserByUsername(String login_message) throws UsernameNotFoundException {
        String []params = login_message.split(",");
        Account account = null;

        switch (params[0]) {
            case UsernameAndPasswordLoginHandler.AUTH_TYPE:
                account = userService.loadUserByUsername(params[1]);
                break;
            case PhoneAndPasswordLoginHandler.AUTH_TYPE:
                account = userService.loadUserByPhone(params[1]);
                break;
            case EmailAndPasswordLoginHandler.AUTH_TYPE:
                account = userService.loadUserByEmail(params[1]);
                break;
            case PhoneAndMessageLoginHandler.AUTH_TYPE: {
                String[] details = params[1].split("-");
                String phone = details[0];
                String code = details[1];
                Object ob = redisTemplate.opsForValue().get(AuthenticationController.Redis_Login_prefix + phone);
                String rawCode = ob == null ? "" : ob.toString();
                if (StringUtils.isEmpty(rawCode)) {
                    throw new UsernameNotFoundException("验证码已经过期");
                }
                if (rawCode.equals(code)) {
                    account = userService.loadUserByPhone(phone);
                } else {
                    throw new UsernameNotFoundException("验证码错误");
                }
                break;
            }
            case WxPublicUnionIdLoginHandler.AUTH_TYPE:
            {
                String[] details = params[1].split(";");
                log.info(params[1]);
                log.info("details :{}", details.length);
                String ticket = details[0];
                String unionId = details[1];
                log.info(ticket);
                Object o = redisTemplate.opsForValue().get(ticket.substring(2, 6));
                String openId = o == null ? "" : o.toString();
                log.info(openId);
                if (StringUtils.isEmpty(openId) || "0".equals(openId)) {
                    throw new UsernameNotFoundException("用户未扫码");
                }
                log.info(unionId);
                account = userService.loadUserByUnionId(unionId);
                break;
            }
            case WxPublicOpenIdLoginHandler
                    .AUTH_TYPE: {
                String openId = params[1];
                account = userService.loadUserByOpenId(openId);
                break;
            }
            default:
                throw new UsernameNotFoundException("错误的验证类型");
        }
        log.info("登陆的用户为：{}",account);
        if (account==null){
            throw new UsernameNotFoundException("没有该用户");
        }
        // 返回带有用户权限信息的User  暂时定为ALL
        return new CUserDetail(account.getName(),
                account.getPassword(), AuthorityUtils.createAuthorityList("ROLE_ALL"),account.getRealName());
    }
}
