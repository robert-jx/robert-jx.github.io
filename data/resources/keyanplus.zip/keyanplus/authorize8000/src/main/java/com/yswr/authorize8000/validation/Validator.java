package com.yswr.authorize8000.validation;

public interface Validator {

    public ValidateResult validate(Object ...objects);
}
