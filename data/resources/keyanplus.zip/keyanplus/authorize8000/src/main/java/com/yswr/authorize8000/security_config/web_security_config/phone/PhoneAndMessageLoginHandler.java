package com.yswr.authorize8000.security_config.web_security_config.phone;

import com.yswr.authorize8000.security_config.custom.AbstractLoginHandler;
import com.yswr.authorize8000.security_config.custom.LoginException;
import com.yswr.authorize8000.security_config.web_security_config.basic.CAuthenticationToken;
import com.yswr.authorize8000.security_config.web_security_config.basic.CLoginFilter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Component
public class PhoneAndMessageLoginHandler extends AbstractLoginHandler implements InitializingBean {
    public final   static  String AUTH_TYPE = "phone_message";
    private final   static  String AUTH_param1 = "phone";
    private final   static  String AUTH_param2 = "code";
    private String phone;
    private String code;

    @Override
    public void loadParams(HttpServletRequest request) throws LoginException {
        phone =  request.getParameter(AUTH_param1);
        code =  request.getParameter(AUTH_param2);
        if ( StringUtils.isEmpty(phone)||StringUtils.isEmpty(code))
        {
            throw new LoginException("缺少验证信息");
        }
        /**
         * 添加验证代码
         * */
    }

    @Override
    public Authentication generateAuthenticaiton() throws AuthenticationException {
        CAuthenticationToken authRequest = new CAuthenticationToken(
                phone+"-"+code, code,AUTH_TYPE);
        /**
         * 添加额外字段
         * */
        return authRequest;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        CLoginFilter.registerHandler(AUTH_TYPE,this);
    }
}
