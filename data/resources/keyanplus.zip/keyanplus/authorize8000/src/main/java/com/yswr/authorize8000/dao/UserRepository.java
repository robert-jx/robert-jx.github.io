package com.yswr.authorize8000.dao;

import com.yswr.authorize8000.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Account,Long> {
    Optional <Account> findByName(String name);
    Optional <Account> findByEmail(String email);
    Optional <Account> findByPhone(String phone);
    Optional <Account> findByUnionId(String unionId);

    @Query(value = "select * from (account left join third_wx on account.union_id = third_wx.union_id) " +
            "where third_wx.public_open_id = ?1",nativeQuery = true)
    Optional<Account> findByOpenId(String openId);
}
