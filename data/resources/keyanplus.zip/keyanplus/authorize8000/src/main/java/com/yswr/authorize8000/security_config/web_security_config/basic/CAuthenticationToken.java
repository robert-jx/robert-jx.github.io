package com.yswr.authorize8000.security_config.web_security_config.basic;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
/**
 * 自定义token
 * */
public class CAuthenticationToken extends AbstractAuthenticationToken {
    private static final long serialVersionUID = 110L;
    private final Object principal;
    private Object credentials;
    private String type;
    public static final String SPRING_SECURITY_RESTFUL_TYPE_SMS = "phone";
    public static final String SPRING_SECURITY_RESTFUL_TYPE_SMS_CODE = "verifyCode";
    public static final String SPRING_SECURITY_RESTFUL_TYPE_EMAIL = "email";
    public static final String SPRING_SECURITY_RESTFUL_TYPE_USER = "user";
    public static final String SPRING_SECURITY_RESTFUL_TYPE_USER_NAME = "username";
    public static final String SPRING_SECURITY_RESTFUL_TYPE_USER_PWD = "password";
    /**
     * This constructor can be safely used by any code that wishes to create a
     * <code>UsernamePasswordAuthenticationToken</code>, as the {@link
     * #isAuthenticated()} will return <code>false</code>.
     *
     */
    public CAuthenticationToken(Object principal, Object credentials,String type) {
        super(null);
        this.principal = principal;
        this.credentials = credentials;
        this.type = type;
        this.setAuthenticated(false);
    }

    /**
     * This constructor should only be used by <code>AuthenticationManager</code> or <code>AuthenticationProvider</code>
     * implementations that are satisfied with producing a trusted (i.e. {@link #isAuthenticated()} = <code>true</code>)
     * token token.
     *
     * @param principal
     * @param credentials
     * @param authorities
     */
    public CAuthenticationToken(Object principal, Object credentials,String type, Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        this.credentials = credentials;
        this.type = type;
        super.setAuthenticated(true);
    }


    @Override
    public Object getCredentials() {
        return this.credentials;
    }

    @Override
    public Object getPrincipal() {
        return this.principal;
    }

    public String getType() {
        return this.type;
    }

    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        if(isAuthenticated) {
            throw new IllegalArgumentException("Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
        } else {
            super.setAuthenticated(false);
        }
    }

    public void eraseCredentials() {
        super.eraseCredentials();
        this.credentials = null;
    }
}
