package com.yswr.authorize8000.service.user;


import com.yswr.authorize8000.entity.Account;

public interface UserService  {
     Account loadUserByUsername(String username);
     Account loadUserByPhone(String phone);
     Account loadUserByEmail(String email);
     Account loadUserByUnionId(String UnionId);

     Account loadUserByOpenId(String openId);
}
