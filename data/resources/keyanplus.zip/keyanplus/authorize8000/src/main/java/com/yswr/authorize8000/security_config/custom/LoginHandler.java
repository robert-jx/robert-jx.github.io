package com.yswr.authorize8000.security_config.custom;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import javax.servlet.http.HttpServletRequest;

/**
 * 定义登陆处理器
 * 负责校验和生成CAuthenticaiton
 * */

public interface LoginHandler {

    Authentication generateAuthenticaiton() throws AuthenticationException;
}
