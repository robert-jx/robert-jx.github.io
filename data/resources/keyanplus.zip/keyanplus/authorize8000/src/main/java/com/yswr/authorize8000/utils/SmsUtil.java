package com.yswr.authorize8000.utils;

import com.tencentcloudapi.common.exception.TencentCloudSDKException;
import com.tencentcloudapi.sms.v20190711.SmsClient;
import com.tencentcloudapi.sms.v20190711.models.SendSmsRequest;
import com.tencentcloudapi.sms.v20190711.models.SendSmsResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.RandomUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Random;
@Slf4j
@Component
public class SmsUtil {

    @Value("${tx.sms.app_id}")
    private String appId;
    @Value("${tx.sms.sign}")
    private String sign;
    @Value("${tx.sms.template_id.login}")
    private String loginTemplateId;
    @Value("${tx.sms.template_id.register}")
    private String registerTemplateId;

    @Value("${tx.sms.template_id.fixPhone}")
    private String fixPhoneTemplateId;
    @Value("${tx.sms.template_id.fixPassword}")
    private String fixPasswordTemplateId;

    @Resource
    private SmsClient smsClient;
    private final Random random = new Random();

    private SendSmsResponse sendSingleRequest(String phone,String templateId){
        SendSmsRequest req = new SendSmsRequest();

        /* 填充请求参数，这里 request 对象的成员变量即对应接口的入参
         * 您可以通过官网接口文档或跳转到 request 对象的定义处查看请求参数的定义
         * 基本类型的设置:
         * 帮助链接：
         * 短信控制台：https://console.cloud.tencent.com/smsv2
         * sms helper：https://cloud.tencent.com/document/product/382/3773 */

        /* 短信应用 ID: 在 [短信控制台] 添加应用后生成的实际 SDKAppID，例如1400006666 */
        try {
            req.setSmsSdkAppid(appId);

            /* 短信签名内容: 使用 UTF-8 编码，必须填写已审核通过的签名，可登录 [短信控制台] 查看签名信息 */
            req.setSign(sign);
            /* 国际/港澳台短信 senderid: 国内短信填空，默认未开通，如需开通请联系 [sms helper] */
//        String senderid = "xxx";
//        req.setSenderId(senderid);

            /* 用户的 session 内容: 可以携带用户侧 ID 等上下文信息，server 会原样返回 */
//        String session = "xxx";
//        req.setSessionContext(session);

            /* 短信码号扩展号: 默认未开通，如需开通请联系 [sms helper] */
//        String extendcode = "xxx";
//        req.setExtendCode(extendcode);

            /* 模板 ID: 必须填写已审核通过的模板 ID，可登录 [短信控制台] 查看模板 ID */
//        String templateID = "400000";
            req.setTemplateID(templateId);

            /* 下发手机号码，采用 e.164 标准，+[国家或地区码][手机号]
             * 例如+8613711112222， 其中前面有一个+号 ，86为国家码，13711112222为手机号，最多不要超过200个手机号*/
//        String[] phoneNumbers = {"+8621212313123", "+8612345678902", "+8612345678903"};

            String[] phoneNumbers = {phone};
            req.setPhoneNumberSet(phoneNumbers);

//            long SmsStartTime = System.currentTimeMillis();
            /* 模板参数: 若无模板参数，则设置为空*/
            StringBuilder codeblr = new StringBuilder();
            for (int i = 0; i < 6; i++) {
                int r = random.nextInt(10); //每次随机出一个数字（0-9）
                codeblr.append(r);
            }
//            long SmsBlockTime = (System.currentTimeMillis() - SmsStartTime);
//            log.info("产生验证码 {}",SmsBlockTime);
            String code = codeblr.toString();
            String[] templateParams = {code};
            req.setTemplateParamSet(templateParams);

            /* 通过 client 对象调用 SendSms 方法发起请求。注意请求方法名与请求对象是对应的
             * 返回的 res 是一个 SendSmsResponse 类的实例，与请求对象对应 */
            SendSmsResponse res = smsClient.SendSms(req);
            res.getSendStatusSet()[0].setMessage(code);
            // 输出 JSON 格式的字符串回包
//            System.out.println(SendSmsResponse.toJsonString(res));
//
//            // 可以取出单个值，您可以通过官网接口文档或跳转到 response 对象的定义处查看返回字段的定义
//            System.out.println(res.getRequestId());
            return res;
        } catch (
                TencentCloudSDKException e) {
            e.printStackTrace();
            return null;
        }
    }

    public SendSmsResponse sendRegisterCode(String phone){
        return sendSingleRequest(phone,registerTemplateId);
    }

    public SendSmsResponse sendLoginCode(String phone) {
       return sendSingleRequest(phone,loginTemplateId);
    }

    public SendSmsResponse sendFixPhoneCode(String phone) {
        return sendSingleRequest(phone,fixPhoneTemplateId);
    }

    public SendSmsResponse sendFixPasswordCode(String phone) {
        return sendSingleRequest(phone,fixPasswordTemplateId);
    }
}
