package com.yswr.authorize8000.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.tencentcloudapi.sms.v20190711.models.SendSmsResponse;
import com.tencentcloudapi.sms.v20190711.models.SendStatus;
import com.yswr.authorize8000.contants.MvcResult;
import com.yswr.authorize8000.contants.TokenResult;
import com.yswr.authorize8000.entity.Account;
import com.yswr.authorize8000.service.user.UserService;
import com.yswr.authorize8000.utils.JwtUtil;
import com.yswr.authorize8000.utils.SmsUtil;
import com.yswr.authorize8000.validation.AccountPhoneValidator;
import com.yswr.authorize8000.validation.ValidateResult;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.concurrent.TimeUnit;

import static com.yswr.authorize8000.contants.MvcResult.*;

/**
 * 编写者： 吴经纶
 * 完成第一次校验时间：2020-12-28
 * */
@Slf4j
@RestController
@RequestMapping("/oauth")
public class AuthenticationController {
    private static final String prefix = "+";
    public static final String Redis_Login_prefix = "login_";
    public static final String Redis_Fix_Phone_prefix = "fix_phone_";
    public static final String Redis_Register_prefix = "register_";
    public static final String Redis_Fix_Password_prefix = "fix_password_";

    public static final int Redis_Code_Expire = 300;
    public static final String LIMIT_SMS_ERROR ="LimitExceeded.PhoneNumberDailyLimit";
    @Resource
    AccountPhoneValidator accountPhoneValidator;
    @Resource
    private SmsUtil smsUtil;
    @Resource
    private UserService userService;

    @Resource
    private RedisTemplate<String,Object> redisTemplate;


    private JwtUtil.TokenMessage check(HttpServletRequest httpServletRequest) {
        try {
            String token = httpServletRequest.getHeader("Authentication");
            if (StringUtils.isEmpty(token)){
                throw new NullPointerException("缺少凭证，无法调用该接口");
            }
            return JwtUtil.getTokenMessage(token);
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }



    /**
     * 发送手机注册验证码
     * 1。 未做限流，进行手机校验器校验（正则）
     * 2。 每次请求都访问一次redis，如果redis上对应key值时间，返回给用户实时下一次注册时间
     * 3。 若用户第一次请求该接口，发送短信给用户，腾讯云有请求次数限制
     * */
    @PostMapping("/sendRegisterCode")
    public MvcResult<Object> sendRegisterCode(String phone){
        try {
            //        校验参数phone
            ValidateResult validateResult = accountPhoneValidator.validate(phone);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(403010).message(validateResult.getMessage()).build();
            }
//        获取redis缓存上phone的时间，超过一分钟则允许重新发送
            Long redis_status = redisTemplate.opsForValue().getOperations().getExpire(Redis_Register_prefix+phone);
            assert  redis_status!=null;
            if (redis_status>=240){
                return MvcResult.builder().code(40308).message("注册短信已发送,请于"+(redis_status-240)+"秒后重新发送短信进行注册").build();
            }
//        获取发送短信后的返回值，根据返回值返回不同结果
            SendSmsResponse sendSmsResponse =  smsUtil.sendRegisterCode(prefix+phone);
            if (sendSmsResponse==null){
                return  ERROR;
            }
            SendStatus sendStatus = sendSmsResponse.getSendStatusSet()[0];
            if ("Ok".equals(sendStatus.getCode())){
                log.info("Ok register phone is :"+prefix + phone);
                redisTemplate.opsForValue().set(Redis_Register_prefix + phone,sendStatus.getMessage(),Redis_Code_Expire, TimeUnit.SECONDS);
                return  REGISTER_SMS_SENT;
            }else if (LIMIT_SMS_ERROR.equals(sendStatus.getCode())){
                return  SMS_LIMIT_ERROR;
            }else {
                return UNKNOWN_ERROR;
            }
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    /**
     * 发送手机登录验证码
     * 1。 未做限流，进行手机校验器校验（正则）
     * 2。 每次请求都访问一次redis，如果redis上对应key值时间，返回给用户实时下一次登录时间
     * 3。 若用户第一次请求该接口，发送短信给用户，腾讯云有请求次数限制
     * */
    @PostMapping("/sendLoginCode")
    public MvcResult<Object> sendLoginCode(@RequestParam  String phone){
//        同注册
       try {
           ValidateResult validateResult = accountPhoneValidator.validate(phone);
           if (!validateResult.getIsOk()){
               return MvcResult.builder().code(403010).message(validateResult.getMessage()).build();
           }
           Long redis_status = redisTemplate.opsForValue().getOperations().getExpire(Redis_Login_prefix+phone);
           assert  redis_status!=null;
           if (redis_status>=240){
               return MvcResult.builder().code(40308).message("修改手机号码的短信已发送,若未收到短信，请于"+(redis_status-240)+"秒后重新发送短信进行登录").build();
           }
           SendSmsResponse sendSmsResponse =  smsUtil.sendLoginCode(prefix+phone);
           if (sendSmsResponse==null){
               return  ERROR;
           }
           SendStatus sendStatus = sendSmsResponse.getSendStatusSet()[0];
           if ("Ok".equals(sendStatus.getCode())){
               log.info("Ok Login phone is :"+prefix + phone);
               redisTemplate.opsForValue().set(Redis_Login_prefix + phone,sendStatus.getMessage(),Redis_Code_Expire, TimeUnit.SECONDS);
               return  LOGIN_SMS_SENT;
           }else if (LIMIT_SMS_ERROR.equals(sendStatus.getCode())){
               return SMS_LIMIT_ERROR;
           }else {
               return UNKNOWN_ERROR;
           }
       }catch (Exception e){
           e.printStackTrace();
           return ERROR;
       }
    }


    @GetMapping("/sendFixPhoneCode")
    public MvcResult<Object> sendFixPhoneCode(String phone){
        try {
            ValidateResult validateResult = accountPhoneValidator.validate(phone);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(403010).message(validateResult.getMessage()).build();
            }
            Long redis_status = redisTemplate.opsForValue().getOperations().getExpire(Redis_Fix_Phone_prefix+phone);
            assert  redis_status!=null;
            if (redis_status>=240){
                return MvcResult.builder().code(40308).message("修改手机号短信已发送,若未收到短信，请于"+(redis_status-240)+"秒后重新发送短信进行修改").build();
            }
            SendSmsResponse sendSmsResponse =  smsUtil.sendFixPhoneCode(prefix+phone);
            if (sendSmsResponse==null){
                return  ERROR;
            }
            SendStatus sendStatus = sendSmsResponse.getSendStatusSet()[0];
            if ("Ok".equals(sendStatus.getCode())){
                log.info("Ok fix phone is :"+prefix + phone);
                redisTemplate.opsForValue().set(Redis_Fix_Phone_prefix + phone,sendStatus.getMessage(),Redis_Code_Expire, TimeUnit.SECONDS);
                return  FIX_PHONE_SMS_SENT;
            }else if (LIMIT_SMS_ERROR.equals(sendStatus.getCode())){
                return SMS_LIMIT_ERROR;
            }else {
                return UNKNOWN_ERROR;
            }
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    @GetMapping("/sendFixPasswordCode")
    public MvcResult<Object> sendFixPasswordCode(String phone){
        try {
            ValidateResult validateResult = accountPhoneValidator.validate(phone);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(403010).message(validateResult.getMessage()).build();
            }
            Long redis_status = redisTemplate.opsForValue().getOperations().getExpire(Redis_Fix_Password_prefix+phone);
            assert  redis_status!=null;
            if (redis_status>=240){
                return MvcResult.builder().code(40308).message("修改密码短信已发送,若未收到短信，请于"+(redis_status-240)+"秒后重新发送短信进行密码修改").build();
            }
            SendSmsResponse sendSmsResponse =  smsUtil.sendFixPasswordCode(prefix+phone);
            if (sendSmsResponse==null){
                return  ERROR;
            }
            SendStatus sendStatus = sendSmsResponse.getSendStatusSet()[0];
            if ("Ok".equals(sendStatus.getCode())){
                log.info("Ok fix password phone is :"+prefix + phone);
                redisTemplate.opsForValue().set(Redis_Fix_Password_prefix + phone,sendStatus.getMessage(),Redis_Code_Expire, TimeUnit.SECONDS);
                return  FIX_PASSWORD_SMS_SENT;
            }else if (LIMIT_SMS_ERROR.equals(sendStatus.getCode())){
                return SMS_LIMIT_ERROR;
            }else {
                return UNKNOWN_ERROR;
            }
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    /**
     * 刷新token 接口
     * 完成返回码统一
     * 简单的参数校验
     * 1。 access_token 不能为空
     * 2。 refresh_token 不能为空
     * */
    @PostMapping("/refresh")
    public MvcResult<Object> refreshToken(@RequestBody TokenResult message){
        String access_token = message.getAccess_token();
        String refresh_token = message.getRefresh_token();
        if (StringUtils.isEmpty(access_token)||StringUtils.isEmpty(refresh_token)){
            return AUTHENTICATION_TOKEN_NULL;
        }
        try {
            JwtUtil.parseToken(refresh_token);
        }catch (Exception e){
            return  REFRESH_TOKEN_EXPIRED;
        }

        try {
            Claims claims  = JwtUtil.parseToken(access_token);
            if (System.currentTimeMillis()-claims.getExpiration().getTime()<=1000*60*5){
                String new_token = JwtUtil.refreshToken(claims);
                log.info("success refresh valid token");
                return MvcResult.builder().message("刷新成功").code(20000)
                        .data(
                                TokenResult.builder()
                                        .access_token(new_token)
                                        .refresh_token(refresh_token)
                                        .build()
                        ).build();
            }
            return AUTHENTICATION_VALID;
        }catch (ExpiredJwtException eje){
              String newEje = JwtUtil.refreshToken(eje);
              return MvcResult.builder().message("刷新成功").code(20000)
                      .data(
                              TokenResult.builder()
                                      .access_token(newEje)
                                      .refresh_token(refresh_token)
                                      .build()
                      ).build();
        }catch (Exception e){
            log.info("刷新异常");
            return   ERROR;
        }
    }




}
