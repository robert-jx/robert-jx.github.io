package com.yswr.authorize8000.security_config.custom;

import org.springframework.security.core.Authentication;

import javax.servlet.http.HttpServletRequest;
/**
 *
 * 登陆处理器
 * 外加参数加载方法
 * */
public abstract class AbstractLoginHandler implements LoginHandler{


    public abstract void loadParams(HttpServletRequest request) throws LoginException;

}
