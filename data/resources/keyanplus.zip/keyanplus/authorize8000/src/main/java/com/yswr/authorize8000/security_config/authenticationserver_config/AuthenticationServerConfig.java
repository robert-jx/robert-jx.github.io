package com.yswr.authorize8000.security_config.authenticationserver_config;

//import com.yswr.authorize8000.security_config.web_security_config.basic.CLoginFilter;
import lombok.AllArgsConstructor;
        import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
        import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.builders.JdbcClientDetailsServiceBuilder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.code.AuthorizationCodeServices;
import org.springframework.security.oauth2.provider.code.InMemoryAuthorizationCodeServices;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
        import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/*
 * 认证中心主配置
 * */

@Configuration
@EnableAuthorizationServer
@AllArgsConstructor
public class AuthenticationServerConfig extends AuthorizationServerConfigurerAdapter {
    private final JwtTokenStore jwtTokenStore;
    private final JwtAccessTokenConverter jwtAccessTokenConverter;
    private final PasswordEncoder passwordEncoder;
    private final DataSource dataSource;
    private final CUserDetailService cUserDetailService;
    private final AuthorizationServerTokenServices tokenServices;
    /**
     * 设置授权码模式的授权码如何存取，暂时采用内存方式
     *
     * 待改进
     */
    public AuthorizationCodeServices authorizationCodeServices() {
        return new InMemoryAuthorizationCodeServices();
    }
    /*
     * 设置用户认证
     * */
    public AuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(cUserDetailService);
//        具有中文提示  后期统一使用模板返回
        daoAuthenticationProvider.setHideUserNotFoundExceptions(true);
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder);
        return daoAuthenticationProvider;
    }
    private AuthenticationManager authenticationManager(){
        List<AuthenticationProvider> authenticationProviders = new ArrayList<>();
        authenticationProviders.add(daoAuthenticationProvider());
        return new ProviderManager(authenticationProviders);
    }

    /**
     * 配置服务端认证访问层
     */
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) {
//  装配解析器


        endpoints

                // 认证管理器
                .authenticationManager(authenticationManager())
                .userDetailsService(cUserDetailService)
                // 授权码服务
                .authorizationCodeServices(authorizationCodeServices())
                // 令牌管理服务
                .tokenServices(tokenServices)
//                jwt 密钥
                .tokenStore(jwtTokenStore)
//                令牌解析器
                .accessTokenConverter(jwtAccessTokenConverter)
//                允许访问令牌端点到方法
                .allowedTokenEndpointRequestMethods(HttpMethod.GET, HttpMethod.POST);
    }

    /**
     * 配置客户端令牌访问端点安全约束
     */
    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) {
        security

                // oauth/check_token公开  第1行和第2行分别是允许已授权用户访问 checkToken 接口和获取 token 接口
                .checkTokenAccess("permitAll()")
                // oauth/token_key 公开密钥
                .tokenKeyAccess("permitAll()")
                // 允许表单认证 允许客户端访问 OAuth2 授权接口，否则请求 token 会返回 401。
                .allowFormAuthenticationForClients();
    }
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        JdbcClientDetailsServiceBuilder jcsb = clients.jdbc(dataSource);
        jcsb.passwordEncoder(passwordEncoder);
    }
}
