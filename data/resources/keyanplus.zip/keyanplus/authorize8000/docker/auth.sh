mv ../target/authorize8000-v1.jar .

docker-compose down



docker-compose up -d --build