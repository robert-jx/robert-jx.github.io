package com.yswr.gateway8999;

import lombok.extern.slf4j.Slf4j;
import org.omg.CORBA.ServerRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.netty.NettyReactiveWebServerFactory;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.HttpHandler;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.server.HandlerFunction;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@SpringBootApplication
@EnableDiscoveryClient
@RefreshScope
@Slf4j
public class Gateway8999Application {


	public static void main(String[] args) {
		SpringApplication.run(Gateway8999Application.class, args);
	}
//	@Bean
//	public GlobalFilter customFilter() {
//		return new CustomGlobalFilter();
//	}


	@RestController
	public static class TestController{
		@GetMapping("/hello")
		public Mono<String> hello() {   // 【改】返回类型为Mono<String>
			return Mono.just("Welcome to reactive world ~");     // 【改】使用Mono.just生成响应式数据
		}
	}
//  @PostConstruct
//    public void startRedirectServer() {
//        NettyReactiveWebServerFactory httpNettyReactiveWebServerFactory = new NettyReactiveWebServerFactory(8080);
//        httpNettyReactiveWebServerFactory.getWebServer((request, response) -> {
//            URI uri = request.getURI();
//            URI httpsUri;
//            try {
//                httpsUri = new URI("https", uri.getUserInfo(), uri.getHost(), 8999, uri.getPath(), uri.getQuery(), uri.getFragment());
//            } catch (URISyntaxException e) {
//                return Mono.error(e);
//            }
//            response.setStatusCode(HttpStatus.MOVED_PERMANENTLY);
//            response.getHeaders().setLocation(httpsUri);
//            return response.setComplete();
//        }).start();
//    }

	/*
	 * 后期考虑将clientId clientSecret 填入到Basic 中
	 * */
//	public static class CustomGlobalFilter implements GlobalFilter, Ordered {
//
//		@Override
//		public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
//			if (exchange.getRequest().getPath().toString().startsWith("/elabauthorize")){
//				URI uri = exchange.getRequest().getURI();
//				StringBuilder query = new StringBuilder();
//				String originalQuery = uri.getRawQuery();
//				if (StringUtils.hasText(originalQuery)) {
//					query.append(originalQuery);
//					if (originalQuery.charAt(originalQuery.length() - 1) != '&') {
//						query.append('&');
//					}
//				}
//				query.append("client_id=elabgateway&client_secret=123456");
//				try {
//					log.info(query.toString());
//					URI newUri = UriComponentsBuilder.fromUri(uri)
//							.replaceQuery(query.toString())
//							.build(true)
//							.toUri();
//
//					ServerHttpRequest request = exchange.getRequest().mutate().uri(newUri).build();
//
//					return chain.filter(exchange.mutate().request(request).build());
//				} catch (RuntimeException ex) {
//					throw new IllegalStateException("Invalid URI query: \"" + query.toString() + "\"");
//				}
//			}
//			return chain.filter(exchange);
//		}
//
//		@Override
//		public int getOrder() {
//			return -1;
//		}
//	}
}