package com.yswr.gateway8999;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import javax.annotation.Resource;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

@Configuration
public class SolutionRouter {
    @Resource
    SolutionHolder solutionHolder;
    @Bean
    public RouterFunction<ServerResponse> timerRouter() {
        return route(GET("/time"), req -> solutionHolder.getTime(req))
                .andRoute(GET("/date"), req-> solutionHolder.getDate(req));  // 这种方式相对于上一行更加简洁
    }
}
