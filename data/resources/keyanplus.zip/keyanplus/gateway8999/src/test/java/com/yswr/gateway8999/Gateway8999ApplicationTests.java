package com.yswr.gateway8999;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gateway8999ApplicationTests {

	@Test
	void contextLoads() {
	}

}
