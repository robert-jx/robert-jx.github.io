package com.yswr.labprovider8003;

import com.alibaba.fastjson.JSONObject;
import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.labdetail.ShortUrlJson;
import com.yswr.labprovider8003.dao.InstrumentRepository;
import com.yswr.labprovider8003.dao.LabRepository;
import com.yswr.labprovider8003.entity.Account;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.service.InstrumentSummaryService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.LinkedHashMap;

@SpringBootTest
public class LabProvider8003ApplicationTests {
    @Resource
    LabRepository labRepository;
    @Resource
    InstrumentRepository instrumentRepository;
    @Resource
    RestTemplate restTemplate;
    @Resource
    InstrumentSummaryService instrumentSummaryService;
    @Test
    void contextLoads() {
        labRepository.findAll();
    }
    @Test
    void delete() {
        instrumentSummaryService.deleteAll();
    }
    @Test
    void rest(){
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("Authentication","eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ7XCJyb2xlXCI6XCJbe1xcXCJhdXRob3JpdHlcXFwiOlxcXCJST0xFX1VTRVJcXFwifV1cIixcInVzZXJuYW1lXCI6XCJreXBfY2NmZGIzOTY1OWE2XCJ9IiwiaXNzIjoiSVNTVUVSIiwiaWF0IjoxNjA4MDQzMjE4LCJleHAiOjE2MDkyMzkzMTR9.hMlNa1OlcMJeTKMM-UK4c5A-XxtwM8Uu7S2kqxOcBKM");
        HttpEntity<Object> requestEntity = new HttpEntity<>(null, map);
        MvcResult body = restTemplate.exchange("https://keyanplus.com/api/v1/user/getInfo", HttpMethod.GET,requestEntity, MvcResult.class).getBody();
        LinkedHashMap l = (LinkedHashMap)body.getData();
        System.out.println(l);
    }


}
