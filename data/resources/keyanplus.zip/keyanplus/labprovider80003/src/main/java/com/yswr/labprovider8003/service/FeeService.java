package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.fee.FeeSpecQo;
import com.yswr.labprovider8003.contants.project.ProjectSpecQo;
import com.yswr.labprovider8003.dao.FeeRepository;
import com.yswr.labprovider8003.entity.Fee;
import com.yswr.labprovider8003.entity.Project;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Service
public class FeeService {
    @Resource
    FeeRepository feeRepository;


    public Fee findByLabIdAndProjectIdAndName(Long labId,Long projectId,String name){
        return  feeRepository.findByFkLabIdAndFkProjectIdAndNameAndIsDelete(labId,projectId,name,false).orElse(null);
    }

    public List<Fee> findAllByLabIdAndProjectId(Long labId,Long projectId){
        return  feeRepository.findByFkLabIdAndFkProjectIdAndIsDelete(labId,projectId,false).orElse(null);
    }
    public Fee getById(Long feeId){
        return feeRepository.findById(feeId).orElse(null);
    }

    public Fee save(Fee fee){
        return feeRepository.save(fee);
    }
    public List<Fee> saveInBatch(Collection<Fee> fees){
        return feeRepository.saveAll(fees);
    }

    public Page<Fee> findAllByFeeSpecQo(FeeSpecQo feeSpecQo, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return feeRepository.findAll(FeeService.FeeSpec.findAllWithQo(feeSpecQo), PageRequest.of(index,page));
        }else {
            return feeRepository.findAll(FeeService.FeeSpec.findAllWithQo(feeSpecQo),PageRequest.of(index,page,sort));
        }
    }



    public List<Fee> findAllByLabIdDynamic(FeeSpecQo feeSpecQo){
        return feeRepository.findAll(FeeService.FeeSpec.findAllWithQo(feeSpecQo));
    }

    public List<Fee> findAllById(Collection<Long> ids){
        return feeRepository.findAllById(ids);
    }

//    public void deleteInBatch(Collection<Fee> feeSet){
//        feeRepository.deleteInBatch(feeSet);
//    }

    static class FeeSpec {
        protected static Specification<Fee> findAllWithQo(FeeSpecQo feeSpecQo){
            return (Specification<Fee>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                if (feeSpecQo.getProject_name()!=null){
                    predicates.add(cb.like(root.get("projectName"),feeSpecQo.getProject_name()+"%"));
                }
                if (feeSpecQo.getLabId()!=null){
                    predicates.add(cb.equal(root.get("fkLabId"),feeSpecQo.getLabId()));
                }
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
