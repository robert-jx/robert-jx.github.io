package com.yswr.labprovider8003.contants.application;

import lombok.Data;

import java.sql.Timestamp;
import java.util.Set;

@Data
public class InstrumentAppointInsert {
    private String name;
    private Integer selfId;
    private String pid;
    private Long labId;
    private String startTime;
    private String endTime;
    private String title;
    private String content;
    private Set<Long> manager_ids;
}
