package com.yswr.labprovider8003.contants.application;

import lombok.Data;

import java.util.Set;

@Data
public class ApplicationInsert {
    private String type;
    private Set<Long> fkManagerIds;
    private Long sponsorId;
    private Long fkLabId;
    private String title;
    private String content;
    private Set<String> urls;
}
