package com.yswr.labprovider8003.contants.tags;

import com.yswr.labprovider8003.entity.Tag;

public enum LabTags {
    LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY(Tag.builder().name("实验室公用").permission("01100").id(1L).build()),
    HIGH_USABLE_VISIBLE_APPOINT_APPLY(Tag.builder().name("需申请预约").permission("11111").id(2L).build()),
    HIGH_USABLE_VISIBLE_APPOINT_UNAPPLY(Tag.builder().name("预约仪器").permission("11110").id(3L).build()),
    HIGH_USABLE_VISIBLE_DISAPPOINT_APPLY(Tag.builder().name("只需要申请").permission("11101").id(4L).build());

    private final Tag tag;
    LabTags(Tag tag){
        this.tag = tag;
    }
    public Tag getTag() {
        return tag;
    }
}
