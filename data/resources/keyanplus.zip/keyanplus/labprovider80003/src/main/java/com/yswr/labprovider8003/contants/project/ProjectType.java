package com.yswr.labprovider8003.contants.project;

public enum ProjectType {
    学生项目("学生项目"),教师项目("教师项目");
    private final String type;
    ProjectType (String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static Boolean isIn(String type){
        try {
            ProjectType.valueOf(ProjectType.class,type);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
