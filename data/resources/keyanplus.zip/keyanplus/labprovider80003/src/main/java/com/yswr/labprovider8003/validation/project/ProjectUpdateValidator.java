package com.yswr.labprovider8003.validation.project;

import com.yswr.labprovider8003.contants.project.ProjectInsert;
import com.yswr.labprovider8003.contants.project.ProjectLevel;
import com.yswr.labprovider8003.contants.project.ProjectType;
import com.yswr.labprovider8003.contants.project.ProjectUpdate;
import com.yswr.labprovider8003.controller.LabController;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.text.ParseException;

@Component
public class ProjectUpdateValidator implements Validator , InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        ProjectUpdate project = (ProjectUpdate) objects[0];
        if (project==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        if (project.getId()==null||project.getId()<=0){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到id参数").build();
        }
        //项目名称校验
        if (StringUtils.isEmpty(project.getName())){

        }else if (project.getName().length()>=30){
            return ValidateResult.builder().isOk(false).message("参数错误，项目名称长度需小于30个字符").build();
        }
        //项目等级校验
        if (StringUtils.isEmpty(project.getLevel())){

        }else if (project.getLevel().length()>=10){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级需小于10个字符").build();
        }else if (!ProjectLevel.isIn(project.getLevel())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不符合规范").build();
        }
        //项目类型校验
        if (StringUtils.isEmpty(project.getType())){

        }else if (project.getLevel().length()>=10){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级需小于10个字符").build();
        }else if (!ProjectType.isIn(project.getType())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不符合规范").build();
        }

        if (project.getLabId()==null||project.getLabId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属实验室不能为空").build();
        }


        if (project.getLeaders()==null||project.getLeaders().size()==0) {

        }
        if (project.getMembers()==null||project.getMembers().size()==0) {
           
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(ProjectUpdate.class,this);
    }
}
