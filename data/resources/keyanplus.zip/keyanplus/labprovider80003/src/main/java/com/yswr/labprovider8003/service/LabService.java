package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.labdetail.LabRole;
import com.yswr.labprovider8003.contants.tags.LabTags;
import com.yswr.labprovider8003.dao.LabRepository;
import com.yswr.labprovider8003.entity.Lab;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.Tag;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

@Service
public class LabService {
    @Resource
    LabRepository labRepository;

    private final static String DEFAULT_LAB_TAG = "未定义分类";
    public Long save(Lab lab){
        labRepository.save(lab);
        return lab.getId();
    }
    @Transactional
    public Long saveWithTransactional(Lab lab,String username, LinkedHashMap l , TagService tagService, LabDetailService labDetailService){
        lab = labRepository.save(lab);
        LabDetail labDetail = labDetailService.save( LabDetail.builder()
                    .isDelete(false)
                    .fkAccountName(username)
                    .fkLabId(lab.getId())
                    .work(true)
                    .role(LabRole.OWNER.getRole())
                    .createTime(new Date(System.currentTimeMillis()))
                    .realName(l.get("realName").toString())
                    .record(l.get("highestRecord").toString())
                    .build());
            tagService.save(Tag.builder()
                    .fkAdminIds(labDetail.getId()+"")
                    .fkLabId(lab.getId()).name(DEFAULT_LAB_TAG)
                    .permission(LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag().getPermission()
                    ).build());
        return lab.getId();
    }

    public Lab findLabById(Long labId){
        return labRepository.findById(labId).orElseThrow(()->new NullPointerException("没有该实验室"));
    }

    public List<Lab> findLabsByNameAndNotDelete(String name){
        return labRepository.findAllByNameAndIsDelete(name,false);
    }

    public Boolean fixLabName(Lab lab,String name){
        try {
            lab.setName(name);
            labRepository.save(lab);
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return  false;
        }
    }

//    public void deleteLabById(Long labId){
//        labRepository.deleteById(labId);
//    }
    @Transactional
    public void deleteLabByIdTransactional(Lab lab,LabDetailService labDetailService){
        Long labId = lab.getId();
        List<LabDetail> labDetails = labDetailService.findAllByLabId(labId);
        if (labDetails==null){
            lab.setIsDelete(true);
            labRepository.save(lab);
            return;
        }
        for (LabDetail l:labDetails
             ) {
            l.setIsDelete(true);
        }
        labDetailService.saveInBatch(labDetails);
        lab.setIsDelete(true);
        labRepository.save(lab);
    }

}
