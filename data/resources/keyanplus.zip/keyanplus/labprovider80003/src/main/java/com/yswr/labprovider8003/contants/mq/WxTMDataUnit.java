package com.yswr.labprovider8003.contants.mq;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class WxTMDataUnit {
    private String value;
    private String color ="#173177" ;

//    public static final WxTMDataUnit DEFAULT_NEED_APPROVAL_FIRST = new WxTMDataUnit("您有一条待审批的申请","#173177");
}
