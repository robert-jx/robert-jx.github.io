package com.yswr.labprovider8003.contants.fee;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class FeeQo {
    private Long labId;
    private String projectName;

    private Integer index;
    private Integer pageSize;
    private List<String> ascProperties;
    private List<String> descProperties;
}
