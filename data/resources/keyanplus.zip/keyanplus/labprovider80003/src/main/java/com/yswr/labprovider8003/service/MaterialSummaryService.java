package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.configuration.AsyncConfiguration;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryInsert;
import com.yswr.labprovider8003.contants.material.MaterialSummaryFail;
import com.yswr.labprovider8003.contants.material.MaterialSummaryInsert;
import com.yswr.labprovider8003.contants.tags.LabTags;
import com.yswr.labprovider8003.dao.MaterialRepository;
import com.yswr.labprovider8003.dao.MaterialSummaryRepository;
import com.yswr.labprovider8003.entity.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
@Log4j2
public class MaterialSummaryService {
    @Resource
    MaterialSummaryRepository materialSummaryRepository;
    @Resource
    MaterialRepository materialRepository;
    @Resource
    MaterialSummaryService materialSummaryService;
    @Resource
    private AsyncConfiguration executorService;
    private String get8UUID(){
        UUID id=UUID.randomUUID();
        String[] idd=id.toString().split("-");
        return idd[0];
    }
    public List<MaterialSummary> findMaterialSummariesByLabId(Long labId){
        return materialSummaryRepository.findAllByFkLabIdAndIsDelete(labId,false).orElse(null);
    }
    public MaterialSummary findMaterialSummaryByLabIdAndName(Long labId, String name){
        return materialSummaryRepository.findByFkLabIdAndName(labId,name).orElse(null);
    }
    public MaterialSummary findMaterialSummaryByLabIdAndNameNotDelete(Long labId, String name){
        return materialSummaryRepository.findByFkLabIdAndNameAndIsDelete(labId,name,false).orElse(null);
    }
    public List<MaterialSummary> findAllMaterialSummariesNameByLabId(Long labId){
        return materialSummaryRepository.findAllNameByFkLabIdNotDelete(labId).orElse(null);
    }

    public MaterialSummary findMaterialSummaryByIdAndLabIdAndNotDelete(Long id,Long labId){
        return materialSummaryRepository.findByIdAndFkLabIdAndIsDelete(id,labId,false).orElse(null);
    }

    public void RemoveAllTagByFkLabIdAndFkTagIds(Long labId, List<Long>  tagIds){
        materialSummaryRepository.RemoveAllTagByFkLabIdAndFkTagId(labId,tagIds);
    }


    @Transactional(rollbackOn = RuntimeException.class)
    public List<MaterialSummaryInsert> insertSummaryAndMaterialToDb(Set<Material> set ,
                                            MaterialSummary materialSummary,
                                            MaterialSummaryInsert raw,int total) {
        try {
            if (set.size() != 0) {
                materialRepository.saveAll(set);

//            throw  new RuntimeException("test bad");

//
            }
            materialSummaryRepository.save(materialSummary);

//            throw new RuntimeException("bad");
            return null;
        } catch (Exception e) {
            e.printStackTrace();
//            throw  e;
//            TransactionInterceptor
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            List<MaterialSummaryInsert> list = new LinkedList<>();
            for (int i = 0; i < total; i++) {
                list.add(raw);
            }
            return list;
        }
//        return null;
    }



    public List<MaterialSummaryInsert> addMaterialSummaryList(Long fkLabId, List<MaterialSummaryInsert> materialSummaryInserts, Timestamp date, String pid, TagService tagService){
        Map<String, Tag> tagMap = new HashMap<>();
        tagMap.put(LabTags.HIGH_USABLE_VISIBLE_APPOINT_UNAPPLY.getTag().getName(),LabTags.HIGH_USABLE_VISIBLE_APPOINT_APPLY.getTag());
        tagMap.put(LabTags.HIGH_USABLE_VISIBLE_APPOINT_APPLY.getTag().getName(),LabTags.HIGH_USABLE_VISIBLE_APPOINT_UNAPPLY.getTag());
        tagMap.put(LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag().getName(),LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag());
        List<Tag> tags = tagService.findAllByLabId(fkLabId);

        for (Tag t: tags
        ) {
            tagMap.put(t.getName(),t);
        }
        Map<String,MaterialSummary> existMaterialSummary = new HashMap<>();
        for (MaterialSummary tmp :
                findMaterialSummariesByLabId(fkLabId)) {
            existMaterialSummary.put(tmp.getName(),tmp);
//            log.info("existInstrumentSummary name :{},count {}",tmp.getName(),tmp.getCurCount());
        }

        ConcurrentHashMap<MaterialSummaryInsert,Integer> newSummaryCountMap = new ConcurrentHashMap<>(32);

        AtomicBoolean isValid = new AtomicBoolean(true);

        // 统计出现次数
        materialSummaryInserts.parallelStream().forEach(
                (v)->{
                    if (!v.getFkLabId().equals(fkLabId)){
                        isValid.set(false);
                        return;
                    }
                    int num = newSummaryCountMap.getOrDefault(v,0);
                    if (v.getNumber()!=null){
                        if (v.getNumber()>=0){
                            num+=v.getNumber();
                        }else {
                            ++num;
                        }
                        newSummaryCountMap.put(v,num);
                    }else {
                        newSummaryCountMap.put(v,++num);
                    }
                }
        );

        // 防止属性不同但是名称相同情况
        Set<String> renameSet = new HashSet<>(8);
        newSummaryCountMap.forEach(
                (k,v)->{
                    //  不要出现相同名字但是其他属性不同的情况，系统会为其重新重命名，新生成一个总览，
                    while (!renameSet.add(k.getName())){
                        k.setName(k.getName()+"-"+get8UUID());
                        log.info("renameSet : name :{},count:{}",k.getName(),v);
                    }
                    renameSet.add(k.getName());
                    log.info("newSummaryCountMap : name :{},count:{}",k.getName(),v);
                }
        );


        // 分别用一个线程载入一个SummaryCountMap的一个key类
        int size = newSummaryCountMap.size();
        // 存储每个key类返回来的成功执行数字
        List<Future<List<MaterialSummaryInsert>>> futures = new ArrayList<>(size);
        newSummaryCountMap.forEach(
                (k,v)->{
                    Callable<List<MaterialSummaryInsert>> task1 = () -> {
                        // 插入数据
//                        log.info("enter {}",Thread.currentThread());
                        Tag tag;
                        if (k.getTagName()!=null&&tagMap.containsKey(k.getTagName())){
                            tag = tagMap.get(k.getTagName());
                        }else {
                            tag = LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag();
                        }
                        Set<Material> materialSet = new LinkedHashSet<>();
                        if (Tag.needHighManagement(tag)) {
                            log.info("need management {}",Thread.currentThread());
                            for (int i = 0; i < v; i++) {

                                materialSet.add(Material.builder()
                                        .isDelete(false)
                                        .alias(k.getName())
                                        .brand(k.getBrand())
                                        .createTime(date)
                                        .fkLabId(fkLabId)
                                        .fkPid(pid)
                                        .isApply(false)
                                        .name(k.getName())
                                        .specifications(k.getSpecifications())
                                        .place(k.getPlace())
                                        .specifications(k.getSpecifications())
                                        .cas(k.getCas())
                                        .concentration(k.getConcentration())
                                        .selfId(i)
                                        .supplierName(k.getSupplierName())
                                        .build());
                            }
                        }
                        MaterialSummary materialSummarySave ;
                        // 已经确保k的name不会出现重复，对已存在的总览只修改数量
                        if (existMaterialSummary.containsKey(k.getName())){
                            materialSummarySave = existMaterialSummary.get(k.getName());
                            materialSummarySave.setCurCount(materialSummarySave.getCurCount()+v);
//                            log.info("cache newName :{},newCount:{}",k.getName(),v);
                            String []places = materialSummarySave.getPlace()==null?null:materialSummarySave.getPlace().split(",");
                            String splitSet = null;
                            if (places!=null&&!StringUtils.isEmpty(k.getPlace())){
                                Set<String> stringSet = new HashSet<>(Arrays.asList(places));
                                stringSet.add(k.getPlace());
                                splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");

                            }
                            if (splitSet!=null){
                                materialSummarySave.setPlace(splitSet);
                            }else {
                                if (!StringUtils.isEmpty(k.getPlace())){
                                    materialSummarySave.setPlace(k.getPlace());
                                }
                            }
                        }else{
//                            instrumentSummarySave = InstrumentSummary.builder()
//                                    .attachment(k.getAttachment())
//                                    .brand(k.getBrand())
//                                    .fkLabId(fkLabId)
//                                    .fkTagId(tag.getId())
//                                    .name(k.getName())
//                                    .picture(k.getPicture())
//                                    .place(k.getPlace())
//                                    .remark(k.getRemark())
//                                    .supplierName(k.getSupplierName())
//                                    .unit(k.getUnit())
//                                    .typeName(k.getTypeName())
//                                    .build();
                            materialSummarySave = new MaterialSummary();
                            BeanUtils.copyProperties(k,materialSummarySave);
                            materialSummarySave.setCurCount(v);
                            materialSummarySave.setFkTagId(tag.getId());
                            materialSummarySave.setTagName(tag.getName());
                            materialSummarySave.setIsDelete(false);
                        }

                        //
                        log.info("{} by add :{}",materialSummarySave,v);
                        return materialSummaryService.insertSummaryAndMaterialToDb(materialSet,materialSummarySave,k,v);

//                        int inserts = insertSummaryAndMaterialToDb(materialSet,materialSummarySave);
//                        if (inserts==-1){
//                            inserts = newSummaryCountMap.get(k);
//                        }
//                        return MaterialSummaryFail.builder().name(k.getName()).count(v-inserts).build();
                    };
                    futures.add(executorService.doLogisticsExecutor().submit(task1));
                }
        );
        try {
            List<MaterialSummaryInsert> list = new LinkedList<>();
            for (Future<List<MaterialSummaryInsert>> f: futures
            ) {
                List<MaterialSummaryInsert> i = f.get();
                if (i!=null){
                    list.addAll(i);
                }
            }
            return list;
        }catch (InterruptedException| ExecutionException e){
            e.printStackTrace();
            return null;
        }
    }













    public Page<MaterialSummary> findAllByLabIdDynamic(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return materialSummaryRepository.findAll(MaterialSummaryService.MaterialSummarySpec.findAllWithLabId(labId), PageRequest.of(index,page));
        }else {
            return materialSummaryRepository.findAll(MaterialSummaryService.MaterialSummarySpec.findAllWithLabId(labId),PageRequest.of(index,page,sort));
        }
    }
    public void save (MaterialSummary materialSummary){
        materialSummaryRepository.save(materialSummary);
    }

    @Transactional
    public void deleteBydLabIdAndNames(Long labId,List<String> names){


        materialSummaryRepository.removeAllByFkLabIdAndNames(labId,names);
        materialRepository.removeAllByFkLabIdAndNames(labId,names);
    }



    static class MaterialSummarySpec {

        protected static Specification<MaterialSummary> findAllWithLabId(Long labId){
            return (Specification<MaterialSummary>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
