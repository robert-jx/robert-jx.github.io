package com.yswr.labprovider8003.entity;


import com.alibaba.excel.annotation.ExcelProperty;
import com.yswr.labprovider8003.configuration.TimestampConverter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Scanner;

@Entity
@Table(name = "lab_borrow_record")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BorrowRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @ExcelProperty(index = 0, value = "ID号")
    private Long id;
    @Column(name = "goods_id")
//    @ExcelProperty(index = 1, value = "领取物品ID")
    private Long goodsId;
    @Column(name = "goods_name")
    @ExcelProperty(index =0, value = "领取物品名称")
    private String goodsName;
    @Column(name = "goods_properties")
    private String goodsProperties;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @ExcelProperty(index =1, value = "审批人")
    @Column(name = "manager_name")
    private String managerName;
    @ExcelProperty(index =2, value = "领取人")
    @Column(name = "borrower_name")
    private String borrowerName;
    @ExcelProperty(converter = TimestampConverter.class,index =3, value = "领取时间")
    @Column(name = "goods_time")
    private Timestamp goodsTime;
    @ExcelProperty(index =4, value = "领取地点")
    @Column(name = "goods_place")
    private String goodsPlace;
    @ExcelProperty(index =5, value = "领取数量")
    @Column(name = "goods_number")
    private Integer goodsNumber;


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num = scanner.nextDouble();
        if (num == 0){
            System.out.println("0.000");
        }
        double x =num/2;
        double y = x/num;
        while (true){

            double distance = Math.abs(x-y);
            if (distance < 0.01){
                System.out.printf("%.3f",x);
                break;
            }
             y = num/x;
            x = (x + y) /2;
        }
    }
}
