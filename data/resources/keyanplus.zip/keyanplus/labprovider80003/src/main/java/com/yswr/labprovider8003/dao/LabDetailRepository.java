package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.LabDetail;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
@Repository
public interface LabDetailRepository extends JpaRepository<LabDetail,Long>, JpaSpecificationExecutor<LabDetail> {

    Optional<LabDetail> findByFkAccountNameAndFkLabId(String fkAccountName,Long labId);

    Optional<LabDetail> findByFkAccountNameAndFkLabIdAndIsDelete(String fkAccountName,Long labId,Boolean isDelete);

    Optional<LabDetail> findByFkAccountNameAndFkLabIdAndWorkAndIsDelete(String fkAccountName,Long labId,Boolean work,Boolean isDelete);

    Optional<LabDetail> findByFkAccountNameAndWorkAndIsDelete(String name,Boolean work,Boolean isDelete);

    Optional<List<LabDetail>> findAllByFkLabId(Long labId);

    Optional<List<LabDetail>> findAllByFkLabIdAndIsDelete(Long labId,Boolean isDelete);

    Optional<List<LabDetail>> findAllByFkAccountName(String name);

    Optional<List<LabDetail>> findAllByFkAccountNameAndWorkAndIsDelete(String name,Boolean work,Boolean isDelete);

    @Query(value = "select l.id , l.role, l.realName from LabDetail as l where l.fkLabId = ?1 and l.isDelete = false  and  l.work = true")
    Optional<List<LabDetail>>  findAllIdAndNameAndRoleByLabIdAndWorkAndNotDelete(Long labId);

    Optional<List<LabDetail>> findAllByIdInAndWork(Collection<Long> ids,Boolean work);
    Optional<List<LabDetail>> findAllByIdInAndWorkAndIsDelete(Collection<Long> ids,Boolean work,Boolean isDelete);

    Optional<LabDetail> findByIdAndFkLabIdAndWork(Long id,Long labId,Boolean work);
    Optional<LabDetail> findByIdAndFkLabIdAndWorkAndIsDelete(Long id,Long labId,Boolean work,Boolean isDelete);


    @Query(value = "select l.role from LabDetail as l where l.fkLabId = ?1 and l.fkAccountName = ?2 and l.work = true and l.isDelete = false ")
    String  findCurrentRoleByLabIdAndFkAccountNameAndWorkAndNotDelete(Long labId,String name);

    @Modifying
    @Transactional
    @Query(value = "update LabDetail as l set l.role = ?2 where l.id = ?1 ")
    void updateLabMemberRole(Long labDetailId,String role);

    @Modifying
    @Query(value = "update LabDetail as l set l.role = " +
            "(case when l.id = ?1 then 'ADMIN' when l.id = ?2 then  'OWNER' else '' end )" +
            " where l.id = ?1 or l.id = ?2")
    Integer moveOwner(Long id,Long  targetId);



    @Modifying
    @Transactional
    @Query(value = "update LabDetail as l set l.role = ?2 where l.id in ?1 ")
    void updateLabMemberRoles(List<Long> labDetailId,String role);

    @Modifying
    @Transactional
    @Query(value = "update LabDetail as l set l.work = ?2 where l.id in ?1 ")
    Integer updateLabMemberStates(List<Long> labDetailId,Boolean state);

}
