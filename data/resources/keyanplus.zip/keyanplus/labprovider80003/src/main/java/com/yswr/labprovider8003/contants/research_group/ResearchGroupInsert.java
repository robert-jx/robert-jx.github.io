package com.yswr.labprovider8003.contants.research_group;

import lombok.Data;

import javax.persistence.Column;
import java.util.Date;

@Data
public class ResearchGroupInsert {
    private String name;
    private String leaderName;
    private Long fkLabId;
    private Boolean showForAll;
    private String introduce;
}
