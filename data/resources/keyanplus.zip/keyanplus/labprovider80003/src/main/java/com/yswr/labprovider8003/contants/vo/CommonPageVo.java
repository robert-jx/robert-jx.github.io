package com.yswr.labprovider8003.contants.vo;

import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.ResearchGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonPageVo<T> {
    private List<T> data;
    private Integer totalPages;
    private Long totalElements;
    private Integer size;
}
