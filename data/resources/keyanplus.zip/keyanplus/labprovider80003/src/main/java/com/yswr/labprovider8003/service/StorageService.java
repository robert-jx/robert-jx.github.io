package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.dao.StorageRepository;
import com.yswr.labprovider8003.entity.Storage;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Service
public class StorageService {
    @Resource
    StorageRepository repository;
    public List<Storage> findAllByLabId(Long labId){
        return repository.findAllByFkLabId(labId).orElse(null);
    }
    public List<Storage> save(Collection<Storage> s){
        return repository.saveAll(s);
    }

    public void  deleteById(Long id){
        repository.deleteById(id);
    }
}
