package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.project.ProjectSpecQo;
import com.yswr.labprovider8003.dao.PrizeRepository;
import com.yswr.labprovider8003.entity.Prize;
import com.yswr.labprovider8003.entity.Project;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;

@Service
public class PrizeService {
    @Resource
    PrizeRepository prizeRepository;

    public Prize save(Prize prize){
        return prizeRepository.save(prize);
    }

    public Page<Prize> findAllByLabId(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return prizeRepository.findAllByFkLabId(labId, PageRequest.of(index,page));
        }else {
            return prizeRepository.findAllByFkLabId(labId,PageRequest.of(index,page,sort));
        }
    }
}
