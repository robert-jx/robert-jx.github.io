package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.InstrumentSummary;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.Logistics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface InstrumentSummaryRepository  extends JpaRepository<InstrumentSummary,Long> , JpaSpecificationExecutor<InstrumentSummary> {

    @Query(value = "select i.name from InstrumentSummary as i where i.fkLabId = ?1 and i.isDelete = false ")
    Optional<List<InstrumentSummary>> findAllNameByFkLabIdNotDelete(Long labId);
    @Query(value = "select i.name,i.curCount from InstrumentSummary as i where i.fkLabId = ?1 and i.isDelete = false ")
    Optional<List<InstrumentSummary>> findAllNameAndCountByFkLabIdNotDelete(Long labId);

    Optional<List<InstrumentSummary>> findAllByFkLabIdAndIsDelete(Long labId,boolean isDelete);


    Optional<InstrumentSummary> findByFkLabIdAndName(Long labId,String name);

    Optional<InstrumentSummary> findByFkLabIdAndNameAndIsDelete(Long labId,String name,boolean isDelete);

    Optional<InstrumentSummary> findByIdAndFkLabIdAndIsDelete(Long id,Long labId,boolean isDelete);


    Optional<List<InstrumentSummary>> findAllByFkLabId(Long labId);

    @Modifying
    @Transactional
    @Query(value = "update InstrumentSummary as l set l.fkTagId = null , l.tagName = null  where l.fkLabId = ?1 and l.fkTagId in ?2")
    void RemoveAllTagByFkLabIdAndFkTagId(Long labId,List<Long> tagId);


    @Modifying
    @Transactional
    @Query(value = "update InstrumentSummary as l set l.isDelete = true where l.name in ?2 and l.fkLabId = ?1 ")
    void removeAllByFkLabIdAndNames(Long labId,List<String> names);
}
