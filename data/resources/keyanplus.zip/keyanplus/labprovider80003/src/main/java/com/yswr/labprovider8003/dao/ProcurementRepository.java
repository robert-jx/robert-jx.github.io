package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Procurement;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProcurementRepository extends JpaRepository<Procurement,Long> {

   Page<Procurement> findAllByFkLabId(Long labId, Pageable pageable);
}
