package com.yswr.labprovider8003.contants.tags;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InstrumentVo {
    private String name;
    private String typeName;
    private String tag;
    private String remark;
    private String unit;
//    private Double price;
    private String place;
    private String picture;
    private String supplierName;
    private String brand;
}
