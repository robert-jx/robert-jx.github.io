package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.dao.InstrumentRepository;
import com.yswr.labprovider8003.entity.Instrument;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Service
public class InstrumentService {
    @Resource
    InstrumentRepository instrumentRepository;

    public void saveInBatch(List<Instrument> instruments){
        instrumentRepository.saveAll(instruments);
    }

    public List<Instrument> findInstrumentsByName(Long labId,String name){
        return instrumentRepository.findAll(InstrumentSpec.findAllWithInstrumentQo(InstrumentQo.builder().labId(labId).name(name).build()));
    }
    public List<String> findAllPlaceByName(Long labId,String name){
        return instrumentRepository.findAllPlaceByNameAndLabId(name,labId);
    }
    public List<String> findAllPlaceByNameNotDelete(Long labId,String name){
        return instrumentRepository.findAllPlaceByNameAndLabIdAndNotDelete(name,labId);
    }

    public Instrument findByLabIdAndPidAndSid(Long labId,String pid,Integer sid){
        return instrumentRepository.findByFkLabIdAndFkPidAndAndSelfId(labId,pid,sid).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public Instrument findByLabIdAndPidAndSidNotDelete(Long labId,String pid,Integer sid){
        return instrumentRepository.findByFkLabIdAndFkPidAndSelfIdAndIsDelete(labId,pid,sid,false).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public List<Instrument> findByLabIdAndPid(Long labId, String pid){
        return instrumentRepository.findAllByFkLabIdAndFkPid(labId,pid).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public List<Instrument> findByLabIdAndPidNotDelete(Long labId, String pid){
        return instrumentRepository.findAllByFkLabIdAndFkPidAndIsDelete(labId,pid,false).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    @Data
    @Builder
    static class InstrumentQo{
        private Long labId;
        private String name;
    }


    static class InstrumentSpec {

        protected static Specification<Instrument> findAllWithInstrumentQo(InstrumentQo instrumentQo){
            return (Specification<Instrument>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();

                if (instrumentQo.getLabId()!=null){

                    predicates.add(cb.equal(root.get("fkLabId"), instrumentQo.getLabId()));
                }
                if (!StringUtils.isEmpty(instrumentQo.getName())){
                    predicates.add(cb.equal(root.get("name"), instrumentQo.getName().trim()));

                }
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
