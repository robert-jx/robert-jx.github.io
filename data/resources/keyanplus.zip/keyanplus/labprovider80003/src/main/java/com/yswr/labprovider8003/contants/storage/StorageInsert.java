package com.yswr.labprovider8003.contants.storage;

import lombok.Data;

@Data
public class StorageInsert {
    private Long labId;
    private String name;
    private String detail;
}
