package com.yswr.labprovider8003.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSONObject;
import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.material.MaterialSummaryFail;
import com.yswr.labprovider8003.contants.material.MaterialSummaryInsert;
import com.yswr.labprovider8003.exception.IllegalException;
import com.yswr.labprovider8003.service.InstrumentSummaryService;
import com.yswr.labprovider8003.service.MaterialSummaryService;
import com.yswr.labprovider8003.service.TagService;
import com.yswr.labprovider8003.utils.ExcelUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.*;

public class MaterialExcelListener extends AnalysisEventListener<MaterialSummaryInsert> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MaterialExcelListener.class);
    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
//    boolean isFail = false;
    String tagName = null;
    Long labId =null;
    HttpServletResponse response = null;
    String pid = null;
    TagService tagService = null;
    ExcelUtil excelUtil = null;
    MaterialSummaryService materialSummaryService =null;
    private static final int BATCH_COUNT = 100;
    List<MaterialSummaryInsert> fails = new LinkedList<>();
    List<MaterialSummaryInsert> list = new LinkedList<>();

    public MaterialExcelListener(HttpServletResponse response,
                                   TagService tagService, ExcelUtil excelUtil,
                                   MaterialSummaryService materialSummaryService,
                                   String tagName, Long labId, String pid) {
        // 这里是demo，所以随便new一个。实际使用如果到了spring,请使用下面的有参构造函数
        this.materialSummaryService = materialSummaryService;
        this.tagName = tagName;
        this.labId = labId;
        this.response =response;
        this.pid = pid;
        this.tagService = tagService;
        this.excelUtil = excelUtil;
    }

    public static void main(String[] args) throws ClassNotFoundException {
        String str = "213.1";
        String news = str.replaceAll("\\.","[.]");
    }
    public static void change(String str,char ch[]){
        ch[0] = 'b';
    }


    /**
     * 如果使用了spring,请使用这个构造方法。每次创建Listener的时候需要把spring管理的类传进来
     *
     */
    public MaterialExcelListener() {
    }
    @Override
    public void invoke(MaterialSummaryInsert data, AnalysisContext context) throws IllegalException {
        try {
            if (StringUtils.isEmpty(data.getName())){
//            throw new IllegalException("illegal data");
//                isFail = true;
                this.fails.add(data);
            }else {
                data.setFkLabId(labId);
                if (!StringUtils.isEmpty(tagName)){
                    data.setTagName(tagName);
                }
                list.add(data);
                // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
                if (list.size() >= BATCH_COUNT) {
                    saveData();
                    // 存储完成清理 list
                    list.clear();
                }
            }
        }catch (IllegalException i){
            throw i;
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        try {
            saveData();
                Set<String> excludeColumnFiledNames = new HashSet<>();
                excludeColumnFiledNames.add("fkLabId");
                excludeColumnFiledNames.add("fkTagId");
                if (fails.size()==0){
                    LOGGER.info("success！");
                    response.getWriter().write(JSONObject.toJSONString(MvcResult.ADD_SUCCESS));
//                    excelUtil.download(response,MaterialSummaryFail.class,Collections.singletonList(MaterialSummaryFail.builder().count(0).name("全部录入成功").build()),excludeColumnFiledNames,"导入失败总览表");
                }else {
                    LOGGER.info("fail some！");

                    excelUtil.download(response,MaterialSummaryInsert.class,fails,excludeColumnFiledNames,"导入失败总览表");
                }

//            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void saveData()  {
        try {

//            if (!isFail){
                LOGGER.info("{}条数据！", list.size());
                List<MaterialSummaryInsert> fails = materialSummaryService.addMaterialSummaryList(labId,list,new Timestamp(System.currentTimeMillis())
                        ,pid,tagService
                );
                if (fails!=null){
                    this.fails.addAll(fails);
                }
//            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
