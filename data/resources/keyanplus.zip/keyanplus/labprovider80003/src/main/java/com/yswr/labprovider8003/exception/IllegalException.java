package com.yswr.labprovider8003.exception;

public class IllegalException extends RuntimeException{

    public IllegalException(String message) {
        super(message);
    }
}
