package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.dao.ResearchGroupDetailRepository;
import com.yswr.labprovider8003.dao.ResearchGroupRepository;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.ResearchGroup;
import com.yswr.labprovider8003.entity.ResearchGroupDetail;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.transaction.Transactional;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

@Service
public class ResearchGroupService {
    @Resource
    ResearchGroupRepository researchGroupRepository;
    @Resource
    ResearchGroupDetailRepository researchGroupDetailRepository;

    @Transactional
    public void moveLabResearchGroupDetailWithTransactional(Long groupId,Set<ResearchGroupDetail> researchGroupDetails){
        researchGroupDetailRepository.deleteAllByFkResearchGroupId(groupId);
        researchGroupDetailRepository.saveAll(researchGroupDetails);
    }

    public List<ResearchGroupDetail> joinLabResearchGroupInBatch(Set<ResearchGroupDetail> researchGroupDetails){
       return researchGroupDetailRepository.saveAll(researchGroupDetails);
    }
    public List<ResearchGroupDetail> updateLabResearchGroupInBatch(Set<ResearchGroupDetail> researchGroupDetails){

        return researchGroupDetailRepository.saveAll(researchGroupDetails);
    }
    public Long deleteLabResearchGroupByGroupId(Long groupId){
        return researchGroupDetailRepository.deleteAllByFkResearchGroupId(groupId);
    }
    public List<ResearchGroupDetail> findAllLabResearchGroupDetailsCanSeeByLabId(Long labId){
        return researchGroupDetailRepository.findAllLabResearchGroupDetailsCanSeeByLabId(labId).orElse(null);
    }
    public List<ResearchGroupDetail> findAllLabResearchGroupDetailsByLabId(Long labId){
        return researchGroupDetailRepository.findAllByFkLabId(labId).orElse(null);
    }

    public List<ResearchGroupDetail> findAllLabResearchGroupDetailsByGroupId(Long groupId){
        return researchGroupDetailRepository.findAllByFkResearchGroupId(groupId).orElse(null);
    }

    public Boolean isShowForAll(Long groupId){
        return researchGroupRepository.isShowForAll(groupId);
    }

    public Page<ResearchGroup> findAllWithPageable( Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return researchGroupRepository.findAll( PageRequest.of(index,page));
        }else {
            return researchGroupRepository.findAll(PageRequest.of(index,page,sort));
        }
    }

    public List<ResearchGroup> findAllByLabId( Long labId){
        return researchGroupRepository.findAllByFkLabId(labId).orElse(null);
    }

    public Page<ResearchGroup> findAllByLabIdWithPageable( Long labId,Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return researchGroupRepository.findAllByFkLabId(labId, PageRequest.of(index,page));
        }else {
            return researchGroupRepository.findAllByFkLabId(labId, PageRequest.of(index,page,sort));
        }
    }
    public Page<ResearchGroup> findAllByLabIdWithPageableAndCanSee( Long labId,Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return researchGroupRepository.findAllByFkLabIdAndShowForAll(labId, true,PageRequest.of(index,page));
        }else {
            return researchGroupRepository.findAllByFkLabIdAndShowForAll(labId, true,PageRequest.of(index,page,sort));
        }
    }
    public ResearchGroup findById(Long id){
        return researchGroupRepository.findById(id).orElseThrow(()->new NullPointerException("没有找到该用户"));
    }

    public List<ResearchGroupDetail> findAllDetailByLabDetailId(Long id){
        return researchGroupDetailRepository.findAllByFkLabDetailId(id).orElse(null);
    }
    public ResearchGroup save(ResearchGroup researchGroup){
        return researchGroupRepository.save(researchGroup);
    }
    @Transactional
    public void deleteInBatch(List<ResearchGroup> researchGroup){
        List<Long> groupIds = new LinkedList<>();
        for (ResearchGroup r:researchGroup
             ) {
            groupIds.add(r.getId());
        }
        researchGroupDetailRepository.deleteAllByFkResearchGroupIdIn(groupIds);
        researchGroupRepository.deleteInBatch(researchGroup);
    }
}
