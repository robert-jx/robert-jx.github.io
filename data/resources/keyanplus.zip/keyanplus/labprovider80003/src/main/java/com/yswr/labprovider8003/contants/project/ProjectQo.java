package com.yswr.labprovider8003.contants.project;

import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class ProjectQo {

    private String name;
    private Set<String> level;
    private Set<String> type;
    private Long labId;
    private Integer index;
    private Integer pageSize;
    private List<String> ascProperties;
    private List<String> descProperties;
}
