package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.InstrumentSummary;
import com.yswr.labprovider8003.entity.MaterialSummary;
import com.yswr.labprovider8003.service.InstrumentSummaryService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public interface MaterialSummaryRepository extends JpaRepository<MaterialSummary, Long> , JpaSpecificationExecutor<MaterialSummary> {


    @Query(value = "select m.name  from MaterialSummary as m where m.fkLabId = ?1 and m.isDelete = false ")
    Optional<List<MaterialSummary>> findAllNameByFkLabIdNotDelete(Long labId);
    Optional<List<MaterialSummary>> findAllByFkLabId(Long labId);
    Optional<List<MaterialSummary>> findAllByFkLabIdAndIsDelete(Long labId,Boolean isDelete);

    Optional<MaterialSummary> findByFkLabIdAndName(Long labId,String name);
    Optional<MaterialSummary> findByIdAndFkLabIdAndIsDelete(Long id,Long labId,boolean isDelete);

    Optional<MaterialSummary> findByFkLabIdAndNameAndIsDelete(Long labId,String name,boolean isDelete);
    @Modifying
    @Transactional
    @Query(value = "update MaterialSummary as l set l.fkTagId = null , l.tagName = null  where l.fkLabId = ?1 and l.fkTagId in ?2")
    void RemoveAllTagByFkLabIdAndFkTagId(Long labId,List<Long> tagId);
    @Modifying
    @Transactional
    @Query(value = "update MaterialSummary as l set l.isDelete = true where l.name in ?2 and l.fkLabId = ?1 ")
    void removeAllByFkLabIdAndNames(Long labId,List<String> names);
}
