package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.InstrumentApplication;
import com.yswr.labprovider8003.entity.MaterialApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MaterialApplicationRepository extends JpaRepository<MaterialApplication,Long>, JpaSpecificationExecutor<MaterialApplication> {

    @Modifying
    @Query("update MaterialApplication as i set  i.isSuccess = true ,i.managerName = ?2 where i.id = ?1")
    Integer successApplication(Long id,String managerName);
    @Modifying
    @Query("update MaterialApplication as i set  i.isFail = true  ,i.managerName = ?2  where  i.id = ?1")
    Integer failApplication(Long id,String managerName);

    Optional<MaterialApplication> findByFkApplicationId(Long fk_id);
}
