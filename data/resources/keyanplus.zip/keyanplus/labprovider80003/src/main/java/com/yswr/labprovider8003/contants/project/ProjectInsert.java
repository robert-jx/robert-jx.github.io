package com.yswr.labprovider8003.contants.project;

import com.yswr.labprovider8003.contants.fee.FeeInsert;
import lombok.Data;

import java.util.Date;
import java.util.Set;
@Data
public class ProjectInsert {
    private String name;
    private String level;
    private String type;
    private Set<String> leaders;
    private Set<String> members;
    private Long labId;
    private String createTime;
    private Boolean createDocument;
    private Set<FeeInsert> feeInserts;
}
