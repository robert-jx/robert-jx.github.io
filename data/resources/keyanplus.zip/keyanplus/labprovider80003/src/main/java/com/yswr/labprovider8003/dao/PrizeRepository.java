package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Prize;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrizeRepository extends JpaRepository<Prize,Long>  {


    Page<Prize> findAllByFkLabId(Long labId, Pageable pageRequest);
}
