package com.yswr.labprovider8003.contants.application;

public enum  ApplicationType {
    仪器预约("仪器预约"),
    仪器申请("仪器申请"),
    药剂申请("药剂申请"),
    事假("事假"),
    病假("病假"),
    其他("其他");

    private final String value;
    ApplicationType(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static Boolean isCorrectType (String type){
       try {
           ApplicationType.valueOf(type);
           return true;
       }catch (Exception e){
           return false;
       }
    }
}
