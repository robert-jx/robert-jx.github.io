package com.yswr.labprovider8003.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;
@Data
public class Account {
    private Long id;
    private String name;
    private String password;
    private String phone;
    private String email;
    private Boolean disable;
    private String avatar;
    private String realName;
    private String university;
    private String major;
    private String highestRecord;
    private String institute;
    private String direction;
    private Date createTime = new Date();
    private String unionId;
}
