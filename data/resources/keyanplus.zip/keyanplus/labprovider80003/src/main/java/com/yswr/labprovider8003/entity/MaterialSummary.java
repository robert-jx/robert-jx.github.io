package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "lab_material_summary")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialSummary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(name = "cur_count")
    private Integer curCount;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "type_name")
    private String typeName;
    @Column(name = "fk_tag_id")
    private Long fkTagId;
    @Column(name = "unit")
    private String unit;
    @Column(name = "picture")
    private String picture;
    @Column(name = "brand")
    private String brand;
    @Column(name = "supplier_name")
    private String supplierName;
    @Column(name = "tag_name")
    private String tagName;
    @Column(name = "cas")
    private String cas;
    @Column(name = "concentration")
    private String concentration;
    @Lob
    @Column(name = "place")
    private String place;
    @Column(name = "is_delete")
    private Boolean isDelete;
    @Column(name = "specifications")
    private String specifications;

}
