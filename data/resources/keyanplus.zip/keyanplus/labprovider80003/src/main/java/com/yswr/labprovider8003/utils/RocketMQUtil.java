//package com.yswr.labprovider8003.utils;
//
//import lombok.extern.slf4j.Slf4j;
//import org.apache.rocketmq.client.exception.MQBrokerException;
//import org.apache.rocketmq.client.exception.MQClientException;
//import org.apache.rocketmq.client.producer.DefaultMQProducer;
//import org.apache.rocketmq.client.producer.SendResult;
//import org.apache.rocketmq.common.message.Message;
//import org.apache.rocketmq.remoting.common.RemotingHelper;
//import org.apache.rocketmq.remoting.exception.RemotingException;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.Resource;
//import java.io.UnsupportedEncodingException;
//
//@Component
//@Slf4j
//public class RocketMQUtil {
//    @Resource(name = "wxMessageProducer")
//    DefaultMQProducer wxMessageProducer;
//
//
//
//    public SendResult sendResultSync(String topic,String tag,String content) throws UnsupportedEncodingException, InterruptedException, RemotingException, MQClientException, MQBrokerException {
//        Message msg = new Message(topic/* Topic */,
//                tag /* Tag */,
//                (content).getBytes(RemotingHelper.DEFAULT_CHARSET) /* Message body */
//        );
//        //Call send message to deliver message to one of brokers.
//        SendResult sendResult = wxMessageProducer.send(msg);
//        log.info("Class RocketMQUtil Method sendResultSync sendResult is :{}",sendResult);
//        return sendResult;
//    }
//
//}
