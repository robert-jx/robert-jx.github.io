package com.yswr.labprovider8003.contants.fee;

import lombok.Data;

import javax.persistence.Column;
import java.util.Date;

@Data
public class FeeInsert {
    private String name;
    private Double totalFee;
    private Long fkProjectId;
    private String createTime;
    private Long fkLabId;
    private String startTime;
    private String endTime;

}
