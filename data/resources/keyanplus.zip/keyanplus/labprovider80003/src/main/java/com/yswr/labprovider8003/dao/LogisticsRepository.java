package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.Logistics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface LogisticsRepository extends JpaRepository<Logistics ,Long> , JpaSpecificationExecutor<Logistics> {
}
