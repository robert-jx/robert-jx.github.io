package com.yswr.labprovider8003.contants.tags;

import lombok.Data;

@Data
public class CategoryInsert {
    private String name;
    private Long labId;
}
