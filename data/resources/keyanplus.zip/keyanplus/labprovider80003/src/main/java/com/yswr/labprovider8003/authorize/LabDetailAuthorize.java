package com.yswr.labprovider8003.authorize;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.labdetail.LabRole;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.service.LabDetailService;
import com.yswr.labprovider8003.utils.JwtUtil;
import com.yswr.labprovider8003.validation.ValidateResult;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;


/**
 * 权限校验类
 *
* */
@Component
public class LabDetailAuthorize {

    public  MvcResult<Object> authorizeAboveMember(HttpServletRequest request, Long labId,LabDetailService labDetailService){
        return  this.authorize(request,labId,labDetailService,
                LabRole.OWNER,
                LabRole.ADMIN,
                LabRole.CATEGORY_ADMIN,
                LabRole.MEMBER);
    }
    public  MvcResult<Object> authorizeAboveCATEGORYADMIN(HttpServletRequest request, Long labId,LabDetailService labDetailService){
        return  this.authorize(request,labId,labDetailService,
                LabRole.OWNER,
                LabRole.ADMIN,
                LabRole.CATEGORY_ADMIN);
    }
    public  MvcResult<Object> authorizeAboveADMIN(HttpServletRequest request, Long labId,LabDetailService labDetailService){
        return  this.authorize(request,labId,labDetailService,
                LabRole.OWNER,
                LabRole.ADMIN);
    }

    public MvcResult<Object> authorize(HttpServletRequest httpServletRequest, Long labId,LabDetailService labDetailService, LabRole... allowRole){
        try {
            String token = httpServletRequest.getHeader("Authentication");
            if (StringUtils.isEmpty(token)){
                return MvcResult.AUTHENTICATION_TOKEN_NULL;
            }
            JwtUtil.TokenMessage tokenMessage= JwtUtil.getTokenMessage(token);
            for (LabRole labRole : allowRole) {
                if (labRole == LabRole.NONE) {
                    return MvcResult.builder().code(0).data(tokenMessage).build();
                }
            }
            if (labId==null){
                return MvcResult.AUTHORIZE_ERROR;
            }
            String labDetailRole =  labDetailService.findCurrentRoleByLabIdAndName(labId,tokenMessage.getUsername());
            if (StringUtils.isEmpty(labDetailRole)){
                return MvcResult.LAB_USER_NULL;
            }
            for (LabRole labRole : allowRole) {
                if (labRole.getRole().equals(labDetailRole)) {
                    return MvcResult.builder().code(0).message(labDetailRole).data(tokenMessage).build();
                }
            }
            return MvcResult.LAB_USER_NO_POWER;
        }catch (ExpiredJwtException j){
            return  MvcResult.TOKEN_EXPIRED;
        }catch (JwtException je){
            return MvcResult.TOKEN_PARSE_ERROR;
        } catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }

    }
}
