package com.yswr.labprovider8003.entity;

import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "lab_instrument")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Instrument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(name = "fk_pid")
    private String fkPid;
    @Column(name = "self_id")
    private Integer selfId;
    private String place;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    private String remark;
    @Column(name = "brand")
    private String brand;
    @Column(name = "supplier_name")
    private String supplierName;
    @Column(name = "create_time")
    private Timestamp createTime;
    @Column(name = "is_apply")
    private Boolean isApply;
    @Column(name = "alias")
    private String alias;
    @Column(name = "specifications")
    private String specifications;

    @Column(name = "is_delete")
    private Boolean isDelete;

}
