package com.yswr.labprovider8003.entity;


import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "lab_project")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "name")
    private String name;
    private String level;
    private String type;
    private String leaders;
    private String members;
    @Column(name = "create_time")
    private Date createTime;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "is_delete")
    private Boolean isDelete;

    public Project(Long id,String name,String level,String type){
        this.id = id;
        this.type = type;
        this.name = name;
        this.level = level;
    }
}
