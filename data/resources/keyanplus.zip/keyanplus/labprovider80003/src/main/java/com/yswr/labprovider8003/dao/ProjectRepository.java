package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectRepository extends JpaRepository<Project,Long> , JpaSpecificationExecutor<Project> {



    @Query("select new Project(p.id,p.name,p.level,p.type) from Project as p where p.fkLabId = ?1 and  p.isDelete = false ")
    List<Project> findAllNameAndLevelAndTypeAndIdByLabId(Long labId);

    Boolean existsByFkLabIdAndNameAndIsDelete(Long labId,String name,Boolean isDelete);
//    Optional<Project> findByFkLabIdAndName(Long labId, String name);
}
