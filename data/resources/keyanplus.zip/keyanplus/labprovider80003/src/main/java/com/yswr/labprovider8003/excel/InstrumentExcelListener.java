package com.yswr.labprovider8003.excel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryInsert;
import com.yswr.labprovider8003.exception.IllegalException;
import com.yswr.labprovider8003.service.InstrumentSummaryService;
import com.yswr.labprovider8003.service.TagService;
import com.yswr.labprovider8003.utils.ExcelUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.sql.Timestamp;
import java.util.*;

import static com.yswr.labprovider8003.contants.MvcResult.ADD_SUCCESS;

public class InstrumentExcelListener extends AnalysisEventListener<InstrumentSummaryInsert> {
    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentExcelListener.class);
    /**
     * 每隔5条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
//    boolean isFail = false;
    String tagName = null;
    Long labId =null;
    HttpServletResponse response = null;
    String pid = null;
    TagService tagService = null;
    ExcelUtil excelUtil = null;
    private static final int BATCH_COUNT = 100;
    List<InstrumentSummaryInsert> fails = new LinkedList<>();
    List<InstrumentSummaryInsert> list = new LinkedList<>();
    /**
     * 假设这个是一个DAO，当然有业务逻辑这个也可以是一个service。当然如果不用存储这个对象没用。
     */
    private InstrumentSummaryService instrumentSummaryService;

    public InstrumentExcelListener(HttpServletResponse response,
                                   TagService tagService, ExcelUtil excelUtil,
                                   InstrumentSummaryService instrumentSummaryService,
                                   String tagName, Long labId, String pid) {
        // 这里是demo，所以随便new一个。实际使用如果到了spring,请使用下面的有参构造函数
        this.instrumentSummaryService = instrumentSummaryService;
        this.tagName = tagName;
        this.labId = labId;
        this.response =response;
        this.pid = pid;
        this.tagService = tagService;
        this.excelUtil = excelUtil;
    }

    /**
     * 如果使用了spring,请使用这个构造方法。每次创建Listener的时候需要把spring管理的类传进来
     *
     */
    public InstrumentExcelListener() {
    }

    /**
     * 这个每一条数据解析都会来调用
     *
     *
     */
    @Override
    public void invoke(InstrumentSummaryInsert instrumentSummaryInsert, AnalysisContext analysisContext) throws IllegalException{
        try {
            if (StringUtils.isEmpty(instrumentSummaryInsert.getName())||instrumentSummaryInsert.getFkLabId()==null){
                this.fails.add(instrumentSummaryInsert);
            }else{
                instrumentSummaryInsert.setFkLabId(labId);
                if (!StringUtils.isEmpty(tagName)){
                    instrumentSummaryInsert.setTagName(tagName);
                }


                list.add(instrumentSummaryInsert);
                // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
                if (list.size() >= BATCH_COUNT) {
                    saveData();
                    // 存储完成清理 list
                    list.clear();
                }
            }

        }catch (IllegalException i){
            throw i;
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 所有数据解析完成了 都会来调用
     *
     * @param context
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 这里也要保存数据，确保最后遗留的数据也存储到数据库
        try {
            saveData();
            Set<String> excludeColumnFiledNames = new HashSet<>();
            excludeColumnFiledNames.add("fkTagId");
            excludeColumnFiledNames.add("fkLabId");
//            if (isFail){
//                LOGGER.info("fail！");
//                excelUtil.download(response,InstrumentSummaryInsert.class, Collections.singletonList(InstrumentSummaryInsert.builder().name("失败记录超过500条,导入错误,建议删除该批次导入物品，减少导入数量重新导入").build()),null,"导入失败总览表");
//            }
            if (fails.size()==0){
                LOGGER.info("success！");
                response.getWriter().write(JSON.toJSONString(ADD_SUCCESS));
//                excelUtil.download(response,InstrumentSummaryInsert.class,Collections.singletonList(InstrumentSummaryInsert.builder().name("全部录入成功").build()),null,"导入失败总览表");
            }else {
                LOGGER.info("fail some！");
                excelUtil.download(response,InstrumentSummaryInsert.class,fails,excludeColumnFiledNames,"导入失败总览表");
            }
        }catch (Exception e){
            e.printStackTrace();
        }


//        response.flushBuffer();
    }

    /**
     * 加上存储数据库
     */
    private void saveData()  {
        try {

//            if (!isFail){
                LOGGER.info("{}条数据！", list.size());
                List<InstrumentSummaryInsert> fails = instrumentSummaryService.addInstrumentSummaryList(labId,list,new Timestamp(System.currentTimeMillis())
                        ,pid,tagService
                );
//                LOGGER.info("addInstrumentSummaryList fail Size : {}",fails.size());
                this.fails.addAll(fails);
//            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
