package com.yswr.labprovider8003.contants.material;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MaterialSummaryFail {
    @ExcelProperty(index = 0,value = "导入对象")
    private String name;
    @ExcelProperty(index = 1,value = "导入失败数量")
    private int count;
}
