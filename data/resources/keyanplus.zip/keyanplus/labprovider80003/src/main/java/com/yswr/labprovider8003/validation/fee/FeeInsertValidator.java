package com.yswr.labprovider8003.validation.fee;

import com.yswr.labprovider8003.contants.fee.FeeInsert;
import com.yswr.labprovider8003.controller.LabController;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.text.ParseException;
@Component
public class FeeInsertValidator implements Validator, InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        FeeInsert feeInsert = (FeeInsert) objects[0];
        if (feeInsert==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }

        if (StringUtils.isEmpty(feeInsert.getName())){
            return ValidateResult.builder().isOk(false).message("参数错误，经费名称不能为空").build();
        }else if (feeInsert.getName().length()>=50){
            return ValidateResult.builder().isOk(false).message("参数错误，项目名称长度需小于50个字符").build();
        }
        if (feeInsert.getFkProjectId()==null||feeInsert.getFkProjectId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属项目不能为空").build();
        }
        if (feeInsert.getFkLabId()==null||feeInsert.getFkLabId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属实验室不能为空").build();
        }
        if (feeInsert.getTotalFee()==null||feeInsert.getTotalFee()<=0) {
            return ValidateResult.builder().isOk(false).message("参数错误，经费金额要大于等于0").build();
        }
        if (feeInsert.getCreateTime()==null){
            return ValidateResult.builder().isOk(false).message("参数错误，创建时间不能为空").build();
        }else {
            try {
                LabController.sdf.parse(feeInsert.getCreateTime());
            }catch (ParseException e){
                return ValidateResult.builder().isOk(false).message("参数错误，创建时间格式错误，目标格式：「1999-01-20」").build();
            }
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(FeeInsert.class,this);
    }
}
