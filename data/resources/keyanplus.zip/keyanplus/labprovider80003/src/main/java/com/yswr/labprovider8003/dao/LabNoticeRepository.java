package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.LabNotice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository

public interface LabNoticeRepository extends JpaRepository<LabNotice,Long> , JpaSpecificationExecutor<LabNotice> {

    Optional<List<LabNotice>> findAllByIdInAndFkLabId(List<Long> ids,Long labId);
}
