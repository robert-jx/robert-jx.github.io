package com.yswr.labprovider8003.contants.project;


import lombok.Data;

import java.util.Set;

@Data
public class ProjectSpecQo {
    private String name;
    private Set<String> level;
    private Set<String> type;
    private Long labId;
}
