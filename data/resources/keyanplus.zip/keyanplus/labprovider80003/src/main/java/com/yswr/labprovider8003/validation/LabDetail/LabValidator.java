package com.yswr.labprovider8003.validation.LabDetail;

import com.yswr.labprovider8003.contants.LabInsert;
import com.yswr.labprovider8003.entity.Lab;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.regex.Pattern;

/**
 * 手机号校验器
 * */
@Component
public class LabValidator implements Validator, InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    private static final Pattern p=Pattern.compile("^(?:86)?1(?:3\\d{3}|5[^4\\D]" +
            "\\d{2}|8\\d{3}|7(?:[35678]\\d{2}|4(?:0\\d|1[0-2]|9\\d))|9[189]\\d{2}|66\\d{2})\\d{6}$");



    @Override
    public ValidateResult validate(Object...objects) {
        LabInsert labInsert = (LabInsert) objects[0];
        if(labInsert==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        String name =  labInsert.getName();
        if (StringUtils.isEmpty(name)) {
            return ValidateResult.builder().isOk(false).message("实验室名称不能为空").build();
        } else if (name.length() >= 30) {
            return ValidateResult.builder().isOk(false).message("实验室长度不能超过20").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(LabInsert.class,this);
    }
}
