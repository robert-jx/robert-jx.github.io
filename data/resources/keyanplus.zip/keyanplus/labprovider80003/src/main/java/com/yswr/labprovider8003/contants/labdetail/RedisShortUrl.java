package com.yswr.labprovider8003.contants.labdetail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RedisShortUrl {
    private String url;
    private String time;
}
