package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab_goods_type")
@Entity
public class GoodsType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    @Column(name = "type_name")
    private String typeName;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "create_time")
    private Date createTime;
}
