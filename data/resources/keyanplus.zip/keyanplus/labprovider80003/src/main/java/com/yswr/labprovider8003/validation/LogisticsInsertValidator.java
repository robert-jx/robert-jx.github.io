package com.yswr.labprovider8003.validation;

import com.yswr.labprovider8003.contants.logistics.LogisticsInsert;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Component
public class LogisticsInsertValidator implements Validator, InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        LogisticsInsert logisticsInsert = (LogisticsInsert) objects[0];
        if (logisticsInsert==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        if (StringUtils.isEmpty(logisticsInsert.getName())){
            return ValidateResult.builder().isOk(false).message("参数错误，物品名称不能为空").build();
        }
        if (StringUtils.isEmpty(logisticsInsert.getUnit())){
            return ValidateResult.builder().isOk(false).message("参数错误，物品单位不能为空").build();
        }

//        if (StringUtils.isEmpty(logisticsInsert.getDate())){
//            return ValidateResult.builder().isOk(false).message("参数错误，物品添加日期不能为空").build();
//        }
//        if (StringUtils.isEmpty(logisticsInsert.getTypeName())){
//            return ValidateResult.builder().isOk(false).message("参数错误，物品标签不能为空").build();
//        }
        if (logisticsInsert.getFkTagId()==null||logisticsInsert.getFkTagId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属分类不能为空").build();
        }
        if (logisticsInsert.getFkLabId()==null||logisticsInsert.getFkLabId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属实验室不能为空").build();
        }
        if (logisticsInsert.getTotal()==null||logisticsInsert.getTotal()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，物品总量不能为空").build();
        }
        if (StringUtils.isEmpty(logisticsInsert.getProperties())) {
            return ValidateResult.builder().isOk(false).message("参数错误，物品属性选项不能为空").build();
        }else if ("INSTRUMENT".equals(logisticsInsert.getProperties())){
//            if (StringUtils.isEmpty(logisticsInsert.getAttachment())){
//                return ValidateResult.builder().isOk(false).message("参数错误，物品不能为空").build();
//            }
        }else if ("MATERIAL".equals(logisticsInsert.getProperties())){
//            if (StringUtils.isEmpty(logisticsInsert.getCas())){
//                return ValidateResult.builder().isOk(false).message("参数错误，物品cas号不能为空").build();
//            }
//            if (StringUtils.isEmpty(logisticsInsert.getConcentration())){
//                return ValidateResult.builder().isOk(false).message("参数错误，浓度值不能为空").build();
//            }
        }else {
            return ValidateResult.builder().isOk(false).message("参数错误，物品属性选项格式错误").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(LogisticsInsert.class,this);
    }
}
