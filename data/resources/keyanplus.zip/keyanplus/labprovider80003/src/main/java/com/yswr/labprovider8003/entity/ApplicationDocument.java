package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "application_document")
@Entity
public class ApplicationDocument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    @Column(name = "url")
    private String url;
    @Column(name = "fk_application_id")
    private Long fkApplicationId;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
}
