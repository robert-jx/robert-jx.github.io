package com.yswr.labprovider8003.contants.tags;

import lombok.Data;

import java.util.List;

@Data
public class TagDelete {
    private Long labId;
    private List<Long> ids;
}
