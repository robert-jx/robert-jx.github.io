package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.configuration.AsyncConfiguration;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryInsert;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryUpdate;
import com.yswr.labprovider8003.contants.tags.LabTags;
import com.yswr.labprovider8003.dao.InstrumentRepository;
import com.yswr.labprovider8003.dao.InstrumentSummaryRepository;
import com.yswr.labprovider8003.entity.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
@Slf4j
public class InstrumentSummaryService {
    @Resource
    InstrumentSummaryRepository instrumentSummaryRepository;
    @Resource
    private AsyncConfiguration executorService;
    @Resource
    InstrumentRepository instrumentRepository;
    @Resource
    InstrumentSummaryService instrumentSummaryService;
    private String get8UUID(){
        UUID id=UUID.randomUUID();
        String[] idd=id.toString().split("-");
        return idd[0];
    }
    public List<InstrumentSummary> findInstrumentSummariesByLabId(Long labId){
        return instrumentSummaryRepository.findAllByFkLabIdAndIsDelete(labId,false).orElse(new LinkedList<>());
    }
    public InstrumentSummary findInstrumentSummaryByLabIdAndName(Long labId, String name){
       return instrumentSummaryRepository.findByFkLabIdAndName(labId,name).orElse(null);
    }

    public InstrumentSummary findInstrumentSummaryByIdAndLabIdAndNotDelete(Long id, Long labId){
        return instrumentSummaryRepository.findByIdAndFkLabIdAndIsDelete(id,labId,false).orElse(null);
    }

    public InstrumentSummary findInstrumentSummaryByLabIdAndNameAndNotDelete(Long labId, String name){
        return instrumentSummaryRepository.findByFkLabIdAndNameAndIsDelete(labId,name,false).orElse(null);
    }
    public List<InstrumentSummary> findInstrumentSummariesNameByLabId(Long labId){
        return instrumentSummaryRepository.findAllNameByFkLabIdNotDelete(labId).orElse(null);
    }
    public List<InstrumentSummary> findInstrumentSummariesNameAndCountByLabId(Long labId){
        return instrumentSummaryRepository.findAllNameAndCountByFkLabIdNotDelete(labId).orElse(new LinkedList<>());
    }


    public void RemoveAllTagByFkLabIdAndFkTagIds(Long labId, List<Long>  tagIds){
         instrumentSummaryRepository.RemoveAllTagByFkLabIdAndFkTagId(labId,tagIds);
    }



    public Page<InstrumentSummary> findAllByLabIdDynamic(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return instrumentSummaryRepository.findAll(InstrumentSummaryService.InstrumentSummarySpec.findAllWithLabId(labId), PageRequest.of(index,page));
        }else {
            return instrumentSummaryRepository.findAll(InstrumentSummaryService.InstrumentSummarySpec.findAllWithLabId(labId),PageRequest.of(index,page,sort));
        }
    }




    public  List<InstrumentSummaryInsert> addInstrumentSummaryList(Long fkLabId, List<InstrumentSummaryInsert> instrumentSummaries, Timestamp date, String pid, TagService tagService){
        Map<String, Tag> tagMap = new HashMap<>();
        tagMap.put(LabTags.HIGH_USABLE_VISIBLE_APPOINT_UNAPPLY.getTag().getName(),LabTags.HIGH_USABLE_VISIBLE_APPOINT_APPLY.getTag());
        tagMap.put(LabTags.HIGH_USABLE_VISIBLE_APPOINT_APPLY.getTag().getName(),LabTags.HIGH_USABLE_VISIBLE_APPOINT_UNAPPLY.getTag());
        tagMap.put(LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag().getName(),LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag());
        List<Tag> tags = tagService.findAllByLabId(fkLabId);

        for (Tag t: tags
        ) {
            tagMap.put(t.getName(),t);
        }

        Map<String,InstrumentSummary> existInstrumentSummary = new HashMap<>();
        // 查找实验室中没有被删除且存在的仪器
        for (InstrumentSummary tmp :
                findInstrumentSummariesByLabId(fkLabId)) {
            existInstrumentSummary.put(tmp.getName(),tmp);
//            log.info("existInstrumentSummary name :{},count {}",tmp.getName(),tmp.getCurCount());
        }

        ConcurrentHashMap<InstrumentSummaryInsert,Integer> newSummaryCountMap = new ConcurrentHashMap<>(32);

        AtomicBoolean isValid = new AtomicBoolean(true);

        // 统计出现次数
        instrumentSummaries.parallelStream().forEach(
                (v)->{
                    if (!v.getFkLabId().equals(fkLabId)){
                        isValid.set(false);
                        return;
                    }
//                    int num = newSummaryCountMap.getOrDefault(v,0);
                    int num = newSummaryCountMap.getOrDefault(v,0);
                    if (v.getNumber()!=null){
                        if (v.getNumber()>=0){
                            num+=v.getNumber();
                        }else {
                            ++num;
                        }
                        newSummaryCountMap.put(v,num);
//                    newSummaryCountMap.put(v,++num);
                    }else {
                        newSummaryCountMap.put(v,++num);
                    }
//                    newSummaryCountMap.put(v,num);
//                    newSummaryCountMap.put(v,++num);
                }
        );

        // 防止相同名称但是 equals 不同
        Set<String> renameSet = new HashSet<>(8);
        newSummaryCountMap.forEach(
                (k,v)->{
                    //  不要出现相同名字但是其他属性不同的情况，系统会为其重新重命名，新生成一个总览，
                    while (!renameSet.add(k.getName())){
                        k.setName(k.getName()+"-"+get8UUID());
                        log.info("renameSet : name :{},count:{}",k.getName(),v);
                    }
                    renameSet.add(k.getName());
                    log.info("newSummaryCountMap : name :{},count:{}",k.getName(),v);
                }
        );

        // 分别用一个线程载入一个SummaryCountMap的一个key类
        int size = newSummaryCountMap.size();
        // 存储每个key类返回来的成功执行数字
        List<Future<List<InstrumentSummaryInsert>>> futures = new ArrayList<>(size);
        newSummaryCountMap.forEach(
                (k,v)->{
                    Callable<List<InstrumentSummaryInsert>> task1 = () -> {
                        // 插入数据
//                        log.info("enter {}",Thread.currentThread());
                        Tag tag;
                        if (k.getTagName()!=null&&tagMap.containsKey(k.getTagName())){
                            tag = tagMap.get(k.getTagName());
                        }else {
                            tag = LabTags.LOW_USABLE_VISIBLE_DISAPPOINT_UNAPPLY.getTag();
                        }
                        Set<Instrument> instrumentSet = new LinkedHashSet<>();
                        log.info("{}",tag);
                        if (Tag.needHighManagement(tag)) {
                            log.info("need management {}",Thread.currentThread());
                            for (int i = 0; i < v; i++) {

                                instrumentSet.add(Instrument.builder()
                                        .isDelete(false)
                                        .alias(k.getName())
                                        .brand(k.getBrand())
                                        .createTime(date)
                                        .fkLabId(fkLabId)
                                        .fkPid(pid)
                                        .isApply(false)
                                        .name(k.getName())
                                        .place(k.getPlace())
                                        .remark(k.getRemark())
                                        .selfId(i)
                                        .supplierName(k.getSupplierName())
                                        .build());
                            }
                        }
                        InstrumentSummary instrumentSummarySave ;
                        // 已经确保k的name不会出现重复，对已存在的总览只修改数量
                        if (existInstrumentSummary.containsKey(k.getName())){
                            instrumentSummarySave = existInstrumentSummary.get(k.getName());
                            instrumentSummarySave.setCurCount(instrumentSummarySave.getCurCount()+v);
//                            log.info("cache newName :{},newCount:{}",k.getName(),v);
                            String []places = instrumentSummarySave.getPlace()==null?null:instrumentSummarySave.getPlace().split(",");
                            String splitSet = null;
                            if (places!=null&&!StringUtils.isEmpty(k.getPlace())){
                                Set<String> stringSet = new HashSet<>(Arrays.asList(places));
                                stringSet.add(k.getPlace());
                                splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");

                            }
                            if (splitSet!=null){
                                instrumentSummarySave.setPlace(splitSet);
                            }else {
                                if (!StringUtils.isEmpty(k.getPlace())){
                                    instrumentSummarySave.setPlace(k.getPlace());
                                }

                            }
                        }else{
//                            instrumentSummarySave = InstrumentSummary.builder()
//                                    .attachment(k.getAttachment())
//                                    .brand(k.getBrand())
//                                    .fkLabId(fkLabId)
//                                    .fkTagId(tag.getId())
//                                    .name(k.getName())
//                                    .picture(k.getPicture())
//                                    .place(k.getPlace())
//                                    .remark(k.getRemark())
//                                    .supplierName(k.getSupplierName())
//                                    .unit(k.getUnit())
//                                    .typeName(k.getTypeName())
//                                    .build();
                            instrumentSummarySave = new InstrumentSummary();
                            BeanUtils.copyProperties(k,instrumentSummarySave);
                            instrumentSummarySave.setCurCount(v);
                            instrumentSummarySave.setFkTagId(tag.getId());
                            instrumentSummarySave.setTagName(tag.getName());
                            instrumentSummarySave.setIsDelete(false);
                        }



                        //
                        log.info("{} by add :{}",instrumentSummarySave,v);
//                        int inserts = instrumentSummaryService.insertSummaryAndInstrumentToDb(instrumentSet,instrumentSummarySave);
//                        if (inserts==-1){
//                            inserts = newSummaryCountMap.get(k);
//                        }
                         return instrumentSummaryService.insertSummaryAndInstrumentToDb(instrumentSet,instrumentSummarySave,k,v);
//                        return InstrumentSummaryFail.builder().name(k.getName()).count(v-inserts).build();

                    };
                    futures.add(executorService.doLogisticsExecutor().submit(task1));
                }
        );
        try {
            List<InstrumentSummaryInsert> list = new LinkedList<>();
            for (Future<List<InstrumentSummaryInsert>> f: futures
            ) {
                List<InstrumentSummaryInsert> i = f.get();
                if (i!=null){
                    list.addAll(i);
                }
            }
            return list;
        }catch (InterruptedException| ExecutionException e){
            e.printStackTrace();
            return null;
        }
    }

//  子线程事务无法回滚问题 解决
    // 每一个读操作都是一个事务  每一个注入都是一个增强类  因为方法上有有@Trasactional 注解，所以
//    TransactionInterceptor  是 ProxyFactory 的主拦截器 ，
    //  事务管理又spring aop 实现  外加
    //   TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
//   AbstractTransactionStatus
//   @Override
//    public void setRollbackOnly() {
//        this.rollbackOnly = true;
//    }

    @Transactional(rollbackOn = RuntimeException.class)
    public List<InstrumentSummaryInsert> insertSummaryAndInstrumentToDb(Set<Instrument> set ,InstrumentSummary instrumentSummary,InstrumentSummaryInsert raw,int total){

//        Set<Instrument>  inserts = null;
//        InstrumentSummary instrumentSummaryFail =null;
//        Set<InstrumentSummaryInsert> fails = null;
        try {
            if (set.size()!=0){

                // 数据库一致性，如果这次事务提交，是不会出现缺失数据的情况，只有可能是出现脏读或者幻读。
                instrumentRepository.saveAll(set);
//                inserts = new LinkedHashSet<>();
//                for (Instrument insert:inserts
//                ) {
//                    log.info("insert {}",insert);
//                    if (instrumentSummary.getId()==null){
//                        insert.setId(null);
//                    }
//                }
//                for (Instrument i:set
//                ) {
//                    log.info("set :{}",i);
//                    if (!inserts.contains(i)){
//                        throw new RuntimeException("插入缺少数据");
//                    }
//                }
            }
            instrumentSummaryRepository.save(instrumentSummary);
//            throw  new RuntimeException("test bad");
//            throw new  RuntimeException("bad");
            return  null;
        }catch (Exception e){
            e.printStackTrace();
//            throw  e;
//            TransactionInterceptor
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            List<InstrumentSummaryInsert> list = new LinkedList<>();
            for (int i = 0; i < total; i++) {
                list.add(raw);
            }
            return  list;
        }
//        return  inserts;
    }





    public void save (InstrumentSummary instrumentSummary){
        instrumentSummaryRepository.save(instrumentSummary);
    }



    public void update(InstrumentSummaryUpdate instrumentSummaryUpdate){
//        instrumentSummaryRepository.
    }

    public void deleteAll(){
        instrumentSummaryRepository.deleteAll();
    }
    public void deleteBydLabIdAndNames(Long labId,List<String> names){
        instrumentSummaryRepository.removeAllByFkLabIdAndNames(labId,names);
        instrumentRepository.removeAllByFkLabIdAndNames(labId,names);
    }
    static class InstrumentSummarySpec {

        protected static Specification<InstrumentSummary> findAllWithLabId(Long labId){
            return (Specification<InstrumentSummary>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
