package com.yswr.labprovider8003.contants.notice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoticeInsert {
    private String title;
    private String content;
    private Integer priority;
    private Long labId;
    private String sponsorName;
}
