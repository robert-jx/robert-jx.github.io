package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.dao.GoodsTypeRepository;
import com.yswr.labprovider8003.entity.GoodsType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Service
public class TypeService {
    @Resource
    GoodsTypeRepository goodsTypeRepository;

    public Page<GoodsType> findAllGoodsTypeByLabIdDynamic(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return goodsTypeRepository.findAll(TypeService.GoodsTypeSpec.findAllWithLabId(labId), PageRequest.of(index,page));
        }else {
            return goodsTypeRepository.findAll(TypeService.GoodsTypeSpec.findAllWithLabId(labId),PageRequest.of(index,page,sort));
        }
    }
    public List<GoodsType> findAllNameByLabId(Long labId){
        return goodsTypeRepository.findAllNameByLabId(labId).orElse(null);
    }

    public GoodsType findById(Long id){
        return goodsTypeRepository.findById(id).orElse(null);
    }


//    是否存在重命名
    public Boolean isDuplicateName(String name,Long labId){
        return goodsTypeRepository.existsByTypeNameAndAndFkLabId(name,labId);
    }


    public List<GoodsType> findAllGoodsTypeByName(String name){
       return goodsTypeRepository.findAllByTypeName(name).orElse(null);
    }

    public void deleteGoodsType(GoodsType goodsType){
         goodsTypeRepository.delete(goodsType);
    }

    public GoodsType saveGoodsType(GoodsType goodsType){
       return goodsTypeRepository.save(goodsType);
    }

    static class GoodsTypeSpec {

        protected static Specification<GoodsType> findAllWithLabId(Long labId){
            return (Specification<GoodsType>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }



}
