package com.yswr.labprovider8003.entity;

import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.labdetail.LabRole;
import com.yswr.labprovider8003.contants.tags.LabTags;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "lab_tag")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(name = "permission")
    private String permission;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "fk_admin_ids")
    private String fkAdminIds;


    public static Boolean needHighManagement(Tag tag){
        assert tag!=null;
        return tag.getPermission().charAt(0)=='1';
    }
    public static Boolean isUsable(Tag tag,@Nullable  Set<String> idSet,@Nullable Set<String> adminSet,LabDetail labDetail){
        assert tag!=null;
        assert labDetail!=null;

        String role = labDetail.getRole();
        String objectTagId =  tag.getId()+"";
        boolean canUse =  tag.getPermission().charAt(1)=='1';
        if (canUse){
            return true;
        }
        boolean haveTag = false;
        if (idSet!=null){
            haveTag = idSet.contains(objectTagId);
        }
        if (tag.id<= LabTags.values().length){
            return true;
        }
        return role.equals(LabRole.OWNER.getRole())||
                role.equals(LabRole.ADMIN.getRole())||
                (LabRole.CATEGORY_ADMIN.getRole().equals(role)&&adminSet!=null&&adminSet.contains(labDetail.getId()+"") )||
                (LabRole.MEMBER.getRole().equals(role)&&!canUse&&haveTag);
    }

    //  仅仅用户可见和实验室可见，管理员都可见  如果是默认id默认可见
    public static Boolean canVisible(Tag tag, @Nullable Set<String> idSet,@Nullable Set<String> adminSet, LabDetail labDetail){
        assert tag!=null;
        assert labDetail!=null;


        String role = labDetail.getRole();
        String objectTagId =  tag.getId()+"";
        boolean canSee =  tag.getPermission().charAt(2)=='1';
        if (canSee){
            return true;
        }
        boolean haveTag = false;
        if (idSet!=null){
            haveTag = idSet.contains(objectTagId);
        }
        if (tag.id<= LabTags.values().length){
            return true;
        }
        return role.equals(LabRole.OWNER.getRole())||
                role.equals(LabRole.ADMIN.getRole())||
                (LabRole.CATEGORY_ADMIN.getRole().equals(role)&&adminSet!=null&&adminSet.contains(labDetail.getId()+"")) ||
                (LabRole.MEMBER.getRole().equals(role)&&!canSee&&haveTag);
    }
    public static Boolean needAppoint(Tag tag){
        assert tag!=null;
        return tag.getPermission().charAt(3)=='1';
    }
    public static Boolean needApply(Tag tag){
        assert tag!=null;
        return tag.getPermission().charAt(4)=='1';
    }
}
