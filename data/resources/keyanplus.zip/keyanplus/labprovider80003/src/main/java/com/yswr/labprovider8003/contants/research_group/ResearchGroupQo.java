package com.yswr.labprovider8003.contants.research_group;

import lombok.Data;

import java.util.List;
@Data
public class ResearchGroupQo {
    private Long labId;
    private Integer index;
    private Integer pageSize;
    private List<String> ascProperties;
    private List<String> descProperties;
}
