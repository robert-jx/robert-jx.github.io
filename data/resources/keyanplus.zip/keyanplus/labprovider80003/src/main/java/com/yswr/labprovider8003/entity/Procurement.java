package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "lab_procurement")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Procurement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "goods_name")
    private String goodsName;
    @Column(name = "goods_num")
    private Integer goodsNum;
    @Column(name = "goods_price")
    private Double goodsPrice;
    @Column(name = "fk_fee_id")
    private Long fkFeeId;
    @Column(name = "manager_name")
    private String managerName;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "fk_logistics_id")
    private Long fkLogisticsId;
    @Column(name = "fee_name")
    private String feeName;
    @Column(name = "create_time")
    private Timestamp createTime;
    @Column(name = "properties")
    private String properties;
    @Column(name = "is_delete")
    private Boolean isDelete =false;
    @Column(name = "is_in_lab")
    private Boolean isInLab;
    @Column(name = "specifications")
    private String specifications;

}
