package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Instrument;
import com.yswr.labprovider8003.entity.Logistics;
import com.yswr.labprovider8003.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface InstrumentRepository  extends JpaRepository<Instrument,Long> , JpaSpecificationExecutor<Instrument> {

    Optional<Instrument> findByFkLabIdAndFkPidAndAndSelfId(Long labId,String pid,Integer selfId);
    Optional<Instrument> findByFkLabIdAndFkPidAndSelfIdAndIsDelete(Long labId,String pid,Integer selfId,boolean isDelete);

    Optional<List<Instrument>> findAllByFkLabIdAndFkPid(Long labId, String pid);
    Optional<List<Instrument>> findAllByFkLabIdAndFkPidAndIsDelete(Long labId, String pid,boolean isDelete);

    Optional<List<Instrument>> findAllByFkLabId(Long labId);
    Optional<List<Instrument>> findAllByFkLabIdAndIsDelete(Long labId,boolean isDelete);

    @Query(value = "select distinct i.place from Instrument  as i  where i.name =?1 and i.fkLabId=?2")
    List<String> findAllPlaceByNameAndLabId(String name,Long labId);
    @Query(value = "select distinct i.place from Instrument  as i  where i.name =?1 and i.fkLabId=?2 and  i.isDelete = false")
    List<String> findAllPlaceByNameAndLabIdAndNotDelete(String name,Long labId);

    @Modifying
    @Transactional
    @Query(value = "update Instrument as l set l.isDelete = true where l.name in ?2 and l.fkLabId = ?1 ")
    void removeAllByFkLabIdAndNames(Long labId,List<String> names);
}
