package com.yswr.labprovider8003.contants.research_group;

import com.yswr.labprovider8003.contants.labdetail.ResearchDetailInsert;
import lombok.Data;

import java.util.List;

@Data
public class ResearchGroupDetailsUpdate {
    private Long labId;
    private Long researchGroupId;
//    private String researchGroupName;
    private List<ResearchDetailInsert> researchDetailUpdates;
}
