package com.yswr.labprovider8003.contants.labdetail;

import lombok.Data;

@Data
public class ShortUrlJson {
    private String _id;
    private String longUrl;
    private String shortUrl;
    private String validTimestamp;
    private Integer clickCount;
}
