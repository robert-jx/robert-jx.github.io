package com.yswr.labprovider8003.validation.application;


import com.yswr.labprovider8003.contants.application.InstrumentAppointInsert;
import com.yswr.labprovider8003.contants.project.ProjectInsert;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Component
public class InstrumentAppointValidator implements Validator , InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        InstrumentAppointInsert instrumentAppointInsert = (InstrumentAppointInsert) objects[0];
        if (instrumentAppointInsert==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        //仪器名称校验
        if (StringUtils.isEmpty(instrumentAppointInsert.getName())){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器姓名不能为空").build();
        }else if (instrumentAppointInsert.getName().length()>30){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器姓名长度过长").build();
        }
        //仪器selfId校验
        if (instrumentAppointInsert.getSelfId()<=0){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器识别号不能为空").build();
        }
        //仪器批号校验
        if (StringUtils.isEmpty(instrumentAppointInsert.getPid())){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器批号不能为空").build();
        }else if (instrumentAppointInsert.getPid().length()>30){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器批号长度过长").build();
        }

//        if (StringUtils.isEmpty(instrumentAppointInsert.getTitle())){
//            return ValidateResult.builder().isOk(false).message("参数错误，仪器标题不能为空").build();
//        }else if (instrumentAppointInsert.getTitle().length()>255){
//            return ValidateResult.builder().isOk(false).message("参数错误，仪器标题长度过长").build();
//        }
        //仪器所属实验室校验
        if (instrumentAppointInsert.getLabId()<=0){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器所属实验室不能为空").build();
        }
        //项目名称校验
        if (instrumentAppointInsert.getSelfId()<=0){
            return ValidateResult.builder().isOk(false).message("参数错误，仪器识别号不能为空").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(InstrumentAppointInsert.class,this);
    }
}
