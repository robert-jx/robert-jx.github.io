package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

/**
 * 课题组
 *
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab_research_group")
@Entity
public class ResearchGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    private String name;
    @Column(name = "leader_name")
    private String leaderName;
    private Long fkLabId;
    private Boolean showForAll;
    private String introduce;
    @Column(name = "create_time")
    private Date createTime = new Date();
}
