package com.yswr.labprovider8003.contants.labdetail;

import lombok.Data;

import java.util.List;

@Data
public class LabDetailStateUpdate {
    private Boolean state;
    private List<Long> ids;
}
