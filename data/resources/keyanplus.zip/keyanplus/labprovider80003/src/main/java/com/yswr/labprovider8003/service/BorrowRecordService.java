package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.contants.borrowrecord.BorrowRecordQo;
import com.yswr.labprovider8003.dao.BorrowRecordRepository;
import com.yswr.labprovider8003.entity.BorrowRecord;
import com.yswr.labprovider8003.entity.InstrumentSummary;
import com.yswr.labprovider8003.entity.LabNotice;
import com.yswr.labprovider8003.entity.MaterialSummary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.awt.print.Pageable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static com.yswr.labprovider8003.contants.MvcResult.*;

@Service
public class BorrowRecordService {

    @Resource
    BorrowRecordRepository borrowRecordRepository;


    public void save(BorrowRecord borrowRecord){
        borrowRecordRepository.save(borrowRecord);
    }

    @Transactional
    public MvcResult<Object> borrow(BorrowRecord borrowRecord, InstrumentSummaryService instrumentSummaryService, MaterialSummaryService materialSummaryService){
        if  ("INSTRUMENT".equals(borrowRecord.getGoodsProperties())){
            InstrumentSummary instrumentSummary =  instrumentSummaryService.findInstrumentSummaryByIdAndLabIdAndNotDelete(borrowRecord.getGoodsId(), borrowRecord.getFkLabId());
            if (instrumentSummary==null){
                return DATA_NULL;
            }

            if(instrumentSummary.getCurCount()-borrowRecord.getGoodsNumber()>0){
                instrumentSummary.setCurCount(instrumentSummary.getCurCount()- borrowRecord.getGoodsNumber());
            }else {
                instrumentSummary.setCurCount(0);
            }
            instrumentSummaryService.save(instrumentSummary);
        }else{
            MaterialSummary materialSummary =  materialSummaryService.findMaterialSummaryByIdAndLabIdAndNotDelete(borrowRecord.getGoodsId(),  borrowRecord.getFkLabId());
            if (materialSummary==null){
                return DATA_NULL;
            }
            if(materialSummary.getCurCount()-borrowRecord.getGoodsNumber()>0){
                materialSummary.setCurCount(materialSummary.getCurCount()- borrowRecord.getGoodsNumber());

            }else {
                materialSummary.setCurCount(0);
            }
            materialSummaryService.save(materialSummary);
        }

        borrowRecordRepository.save(borrowRecord);
        return ADD_SUCCESS;
    }

    /**
    * 动态数据
    * */
    public Page<BorrowRecord> findAllByLabIdDynamic(BorrowRecordQo borrowRecordQo){
        boolean needSort = true;
        if (borrowRecordQo.getIndex()==null||borrowRecordQo.getPageSize()==null||borrowRecordQo.getPageSize()==0){
            needSort = false;
        }
        List<String> ascProperties = borrowRecordQo.getAscProperties();
        List<String> descProperties = borrowRecordQo.getDescProperties();
        List<Sort.Order> orders = new LinkedList<>();
        if (ascProperties!=null){
            for (String p:ascProperties
            ) {
                orders.add(Sort.Order.asc(p));
            }
        }
        if (descProperties!=null){
            for (String p:descProperties
            ) {
                orders.add(Sort.Order.desc(p));
            }
        }
        Sort sort = Sort.by(orders);
        if (needSort){
            return borrowRecordRepository.findAll(BorrowRecordService.BorrowRecordSpec.findAllWithLabId(borrowRecordQo),PageRequest.of(borrowRecordQo.getIndex(),borrowRecordQo.getPageSize(),sort));

        }else {
            return borrowRecordRepository.findAll(BorrowRecordService.BorrowRecordSpec.findAllWithLabId(borrowRecordQo), PageRequest.of(borrowRecordQo.getIndex(),borrowRecordQo.getPageSize()));
        }
    }


    //labId 不能为空
    static class BorrowRecordSpec{
        protected static Specification<BorrowRecord> findAllWithLabId(BorrowRecordQo borrowRecordQo){
            return (Specification<BorrowRecord>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), borrowRecordQo.getLabId()));
                if (!StringUtils.isEmpty(borrowRecordQo.getBorrowerName())){
                    predicates.add(cb.equal(root.get("borrowerName"),borrowRecordQo.getBorrowerName()));
                }
                if (!StringUtils.isEmpty(borrowRecordQo.getManagerName())){
                    predicates.add(cb.equal(root.get("managerName"),borrowRecordQo.getManagerName()));
                }
                if (!StringUtils.isEmpty(borrowRecordQo.getGoodsName())){
                    predicates.add(cb.equal(root.get("goodsName"),borrowRecordQo.getGoodsName()));
                }
                if (!StringUtils.isEmpty(borrowRecordQo.getGoodsPlace())){
                    predicates.add(cb.equal(root.get("goodsPlace"),borrowRecordQo.getGoodsPlace()));
                }
                if (!StringUtils.isEmpty(borrowRecordQo.getGoodsProperties())){
                    predicates.add(cb.equal(root.get("goodsProperties"),borrowRecordQo.getGoodsProperties()));
                }
                if (borrowRecordQo.getStartTimestamp()!=null){
                    predicates.add(cb.greaterThanOrEqualTo(root.get("goodsTime"),new Timestamp(borrowRecordQo.getStartTimestamp())));
                }
                if (borrowRecordQo.getEndTimestamp()!=null){
                    predicates.add(cb.lessThanOrEqualTo(root.get("goodsTime"),new Timestamp(borrowRecordQo.getEndTimestamp())));
                }
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
