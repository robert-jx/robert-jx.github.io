package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.dao.MaterialRepository;
import com.yswr.labprovider8003.entity.Material;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Service
public class MaterialService {
    @Resource
    MaterialRepository repository;
    public List<Material> saveInBatch(List<Material> materials){
        return repository.saveAll(materials);
    }
    public Material findByLabIdAndPidAndSid(Long labId, String pid, Integer sid){
        return repository.findByFkLabIdAndFkPidAndSelfId(labId,pid,sid).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public Material findByLabIdAndPidAndSidNotDelete(Long labId, String pid, Integer sid){
        return repository.findByFkLabIdAndFkPidAndSelfIdAndIsDelete(labId,pid,sid,false).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public List<Material> findByLabIdAndPid(Long labId, String pid){
        return repository.findAllByFkLabIdAndFkPid(labId,pid).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }
    public List<Material> findByLabIdAndPidNotDelete(Long labId, String pid){
        return repository.findAllByFkLabIdAndFkPidAndIsDelete(labId,pid,false).orElseThrow(()->new NullPointerException("没有找到该物品"));
    }

    public List<Material> findMaterialsByName(Long labId,String name){
        return repository.findAll(MaterialSpec.findAllWithMaterialQo(MaterialQo.builder().labId(labId).name(name).build()));
    }

    public List<String> findMaterialsPlaceByName(Long labId,String name){
        return repository.findAllPlaceByNameAndLabId(name,labId);
    }
    public List<String> findMaterialsPlaceByNameNotDelete(Long labId,String name){
        return repository.findAllPlaceByNameAndLabIdAndNotDelete(name,labId);
    }

    public void deleteByLabIdAndNames(Long labId,List<String> names){
        repository.removeAllByFkLabIdAndNames(labId,names);
    }

    @Data
    @Builder
    static class MaterialQo{
        private Long labId;
        private String name;
    }


    static class MaterialSpec {

        protected static Specification<Material> findAllWithMaterialQo(MaterialService.MaterialQo materialQo){
            return (Specification<Material>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                if (materialQo.getLabId()!=null){
                    predicates.add(cb.equal(root.get("fkLabId"), materialQo.getLabId()));
                }
                if (!StringUtils.isEmpty(materialQo.getName())){
                    predicates.add(cb.equal(root.get("name"), materialQo.getName()));
                }
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
