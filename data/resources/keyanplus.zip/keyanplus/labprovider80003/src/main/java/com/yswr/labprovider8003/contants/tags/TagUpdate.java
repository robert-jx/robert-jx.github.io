package com.yswr.labprovider8003.contants.tags;

import lombok.Data;

import java.util.List;

@Data
public class TagUpdate {
    private List<Long> detailAdd;
    private List<Long> detailDel;
    private List<String> adminAdd;
    private List<String> adminDel;
    private String permission;
    private String name;
    private Long labId;
    private Long id;
}
