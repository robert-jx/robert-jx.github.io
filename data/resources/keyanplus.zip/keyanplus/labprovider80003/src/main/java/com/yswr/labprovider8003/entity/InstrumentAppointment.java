package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab_instrument_appointment")
@Entity
public class InstrumentAppointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    @Column(name = "fk_pid")
    private String fkPid;
    @Column(name = "self_id")
    private Integer selfId;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "start_time")
    private Timestamp startTime;
    @Column(name = "end_time")
    private Timestamp endTime;
    @Column(name = "create_time")
    private Date createTime;
    @Column(name = "sponsor_id")
    private Long sponsorId;
    @Column(name = "sponsor_name")
    private String sponsorName;
    @Column(name = "is_delete")
    private Boolean isDelete;
    @Column(name = "is_success")
    private Boolean isSuccess;
    @Column(name = "is_fail")
    private Boolean isFail = false;
    @Column(name = "fk_application_id")
    private Long fkApplicationId;
    @Column(name = "is_cancel")
    private Boolean isCancel = false;
    @Column(name = "manager_name")
    private Boolean managerName ;
}
