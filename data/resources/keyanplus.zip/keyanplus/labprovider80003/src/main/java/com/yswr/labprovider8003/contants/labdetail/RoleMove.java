package com.yswr.labprovider8003.contants.labdetail;

import lombok.Data;

import java.util.List;

@Data
public class RoleMove {
    private String role;
    private List<Long> targetIds;
}
