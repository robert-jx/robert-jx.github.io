package com.yswr.labprovider8003.contants.labdetail;

import lombok.Data;

@Data
public class ResearchDetailInsert {
    private String name;
    private Long id;
}
