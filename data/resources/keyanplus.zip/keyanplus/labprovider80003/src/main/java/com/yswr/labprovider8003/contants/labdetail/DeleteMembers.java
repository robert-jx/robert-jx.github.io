package com.yswr.labprovider8003.contants.labdetail;

import com.yswr.labprovider8003.entity.LabDetail;
import lombok.Data;

import java.util.List;

@Data
public class DeleteMembers {
    private Long labId;
    private List<LabDetail> labDetails;
    private Boolean deleteResearch = false;
}
