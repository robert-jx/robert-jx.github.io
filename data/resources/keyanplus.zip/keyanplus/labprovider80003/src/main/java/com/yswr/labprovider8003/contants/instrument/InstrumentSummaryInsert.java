package com.yswr.labprovider8003.contants.instrument;


import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class InstrumentSummaryInsert {

    @ExcelProperty(index = 0,value = "仪器名称")
    private String name;
    @ExcelProperty(index = 1,value = "分类名称")
    private String tagName;
    @ExcelProperty(index = 2,value = "标签名称")
    private String typeName;
    @ExcelProperty(index = 3,value = "品牌名称")
    private String brand;
    @ExcelProperty(index = 4,value = "供应商名称")
    private String supplierName;
    @ExcelProperty(index = 5,value = "存放地址")
    private String place;
    @ExcelProperty(index = 6,value = "单位")
    private String unit;
    @ExcelProperty(index = 7,value = "附件地址")
    private String attachment;
    @ExcelProperty(index = 8,value = "备注")
    private String remark;
    @ExcelProperty(index = 9,value = "图片地址")
    private String picture;
    @ExcelProperty(index = 10,value = "规格")
    private String specifications;
    @ExcelProperty(index = 11,value = "数量")
    private Integer number;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InstrumentSummaryInsert that = (InstrumentSummaryInsert) o;
        return name.equals(that.name) &&
                Objects.equals(tagName, that.tagName) &&
                Objects.equals(typeName, that.typeName) &&
                Objects.equals(brand, that.brand) &&
                Objects.equals(supplierName, that.supplierName) &&
                Objects.equals(place, that.place) &&
                Objects.equals(unit, that.unit) &&
                Objects.equals(attachment, that.attachment) &&
                Objects.equals(remark, that.remark) &&
                Objects.equals(picture, that.picture) &&
                Objects.equals(specifications, that.specifications) &&
                Objects.equals(fkTagId, that.fkTagId) &&
                fkLabId.equals(that.fkLabId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, tagName, typeName, brand, supplierName, place, unit, attachment, remark, picture, specifications, fkTagId, fkLabId);
    }

    private Long fkTagId;
    private Long fkLabId;
}
