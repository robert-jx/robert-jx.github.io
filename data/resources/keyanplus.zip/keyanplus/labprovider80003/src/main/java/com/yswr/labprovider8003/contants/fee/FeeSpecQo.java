package com.yswr.labprovider8003.contants.fee;

import lombok.Data;

@Data
public class FeeSpecQo {
    private String project_name;
    private Long labId;
}
