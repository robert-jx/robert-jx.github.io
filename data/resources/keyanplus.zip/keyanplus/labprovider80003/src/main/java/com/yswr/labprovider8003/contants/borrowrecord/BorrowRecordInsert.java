package com.yswr.labprovider8003.contants.borrowrecord;

import com.alibaba.fastjson.JSONObject;
import com.yswr.labprovider8003.entity.BorrowRecord;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class BorrowRecordInsert {
    private String goodsName;
    private Long goodsId;
    private String goodsProperties;
    private Long fkLabId;
    private String managerName;
    private String borrowerName;
    private Long goodsTime;
    private String goodsPlace;
    private Integer goodsNumber;

    public static void main(String[] args) {
        System.out.println(JSONObject.toJSONString(  BorrowRecordInsert.builder()
                .borrowerName("test")
                .fkLabId(5L)
                .goodsId(1L)
                .goodsName("test")
                .goodsNumber(1)
                .goodsPlace("test")
                .goodsProperties("INSTRUMENT")
                .goodsTime(System.currentTimeMillis())
                .managerName("test")
                .build()));
    }
}
