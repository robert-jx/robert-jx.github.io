package com.yswr.labprovider8003.contants.application;

public enum  ApplicationState {
    init("未审批"),
    success("审批通过"),
    fail("审批不通过");

    private final String value;
    ApplicationState(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static Boolean isCorrectType (String type){
        try {
            ApplicationState.valueOf(type);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
