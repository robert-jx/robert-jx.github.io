package com.yswr.labprovider8003.contants.project;

public enum ProjectLevel {

    国家级("国家级"),省级("省级"),市级("市级"),校级("校级"),其他("其他");
    private final String level;
    ProjectLevel (String level){
        this.level = level;
    }

    public String getLevel() {
        return level;
    }

    public static Boolean isIn(String level){
        try {
            ProjectLevel.valueOf(ProjectLevel.class,level);
            return true;
        }catch (Exception e){
            return false;
        }
    }

}
