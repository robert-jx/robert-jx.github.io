package com.yswr.labprovider8003.contants.research_group;

import com.yswr.labprovider8003.entity.ResearchGroup;
import lombok.Data;

import java.util.List;

@Data
public class ResearchGroupDelete {
    private Long fkLabId;
    private List<ResearchGroup> researchGroups;
}
