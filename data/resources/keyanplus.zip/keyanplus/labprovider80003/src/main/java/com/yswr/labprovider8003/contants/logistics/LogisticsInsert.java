package com.yswr.labprovider8003.contants.logistics;

import com.yswr.labprovider8003.entity.Logistics;
import lombok.Data;

import javax.persistence.Column;


@Data
public class LogisticsInsert {
    private Long fkLabId;
    private Long fkTagId;
    private String place;
    private String cas;
    private String concentration;
    private String name;
    private String typeName;
    private String properties;
    private Integer total;
    private String date;
    private String remark;
    private String unit;
    private Double price;
    private String picture;
    private String supplierName;
    private String brand;
    private String attachment;
    // 规格
    private String specifications;
}
