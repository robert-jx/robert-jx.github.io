package com.yswr.labprovider8003.contants.labdetail;


public enum LabRole{
    OWNER("OWNER"),ADMIN("ADMIN"),CATEGORY_ADMIN("CATEGORY_ADMIN"),MEMBER("MEMBER"),NONE("NONE");
    private final String role;
    LabRole (String role){
        this.role = role;
    }

    public String getRole() {
        return role;
    }
}
