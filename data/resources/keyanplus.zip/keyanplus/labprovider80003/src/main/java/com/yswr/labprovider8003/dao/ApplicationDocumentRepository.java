package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.ApplicationDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationDocumentRepository extends JpaRepository<ApplicationDocument,Long>{

    Integer deleteAllByFkApplicationId(Long applicationId);
}
