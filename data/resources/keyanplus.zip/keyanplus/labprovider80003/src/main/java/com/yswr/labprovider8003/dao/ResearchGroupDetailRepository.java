package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.ResearchGroup;
import com.yswr.labprovider8003.entity.ResearchGroupDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.swing.text.html.Option;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

public interface ResearchGroupDetailRepository extends JpaRepository<ResearchGroupDetail,Long> {
    Optional<List<ResearchGroupDetail>> findAllByFkLabId(Long labId);
    Optional<List<ResearchGroupDetail>> findAllByFkLabIdAndFkResearchGroupId(Long labId,Long groupId);
    Optional<List<ResearchGroupDetail>> findAllByFkResearchGroupId(Long groupId);

    Optional<List<ResearchGroupDetail>> findAllByFkLabDetailId(Long labDetailId);
    @Query("select r from ResearchGroupDetail as r inner join ResearchGroup as g on r.fkResearchGroupId = g.id where g.showForAll = true and r.fkLabId =?1")
    Optional<List<ResearchGroupDetail>> findAllLabResearchGroupDetailsCanSeeByLabId(Long labId);

    @Modifying
    @Transactional
    Long deleteAllByFkResearchGroupId(Long groupId);

    @Modifying
    @Transactional
    Long deleteAllByFkResearchGroupIdIn(List<Long> groupId);
}
