package com.yswr.labprovider8003.controller;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.exception.ExcelAnalysisException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yswr.labprovider8003.authorize.LabDetailAuthorize;
import com.yswr.labprovider8003.contants.*;
import com.yswr.labprovider8003.contants.application.*;
import com.yswr.labprovider8003.contants.borrowrecord.BorrowRecordInsert;
import com.yswr.labprovider8003.contants.borrowrecord.BorrowRecordQo;
import com.yswr.labprovider8003.contants.fee.FeeInsert;
import com.yswr.labprovider8003.contants.fee.FeeQo;
import com.yswr.labprovider8003.contants.fee.FeeSpecQo;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryInsert;
import com.yswr.labprovider8003.contants.instrument.InstrumentSummaryUpdate;
import com.yswr.labprovider8003.contants.labdetail.*;
import com.yswr.labprovider8003.contants.logistics.LabLogistics;
import com.yswr.labprovider8003.contants.logistics.LogisticsInsert;
import com.yswr.labprovider8003.contants.logistics.LogisticsQo;
import com.yswr.labprovider8003.contants.material.MaterialSummaryInsert;
import com.yswr.labprovider8003.contants.material.MaterialSummaryUpdate;
import com.yswr.labprovider8003.contants.mq.WxApplicationNeedApprovalTM;
import com.yswr.labprovider8003.contants.mq.WxApplicationNeedApprovalTMData;
import com.yswr.labprovider8003.contants.mq.WxTMDataUnit;
import com.yswr.labprovider8003.contants.notice.NoticeDelete;
import com.yswr.labprovider8003.contants.notice.NoticeInsert;
import com.yswr.labprovider8003.contants.prize.PrizeInsert;
import com.yswr.labprovider8003.contants.procurement.ProcurementInsert;
import com.yswr.labprovider8003.contants.project.*;
import com.yswr.labprovider8003.contants.qo.CommonQo;
import com.yswr.labprovider8003.contants.research_group.*;
import com.yswr.labprovider8003.contants.storage.StorageInsert;
import com.yswr.labprovider8003.contants.tags.*;
import com.yswr.labprovider8003.contants.vo.CommonPageVo;
import com.yswr.labprovider8003.entity.*;
import com.yswr.labprovider8003.excel.InstrumentExcelListener;
import com.yswr.labprovider8003.excel.MaterialExcelListener;
import com.yswr.labprovider8003.service.*;
import com.yswr.labprovider8003.utils.ExcelUtil;
import com.yswr.labprovider8003.utils.JwtUtil;
import com.yswr.labprovider8003.validation.LabDetail.LabDetailValidator;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.ValidatorContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.hibernate.TransactionException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

import static com.yswr.labprovider8003.contants.MvcResult.*;

/**
 * 实验室相关controller
 * 1。增加实验室
 * 2。实验室增添人员
 *  a。生成半小时短链接（内含code，实验室id ，将code存在redis上 uri为前段的静态页面），返回给用户
 *  b。用户点击链接，跳转到前段，前段读取用户信息，将（用户信息，code，实验室id）发送到后端接口上
 * 3。后端操作数据库添加用户
 *
 */
@RestController
@RequestMapping("/lab")
@Slf4j
public class LabController {
    @Resource
    private LabService labService;
    @Resource
    private BorrowRecordService borrowRecordService ;
    @Resource
    private ExcelUtil excelUtil;
    @Resource
    LabDetailValidator labDetailValidator;
    @Resource
    ValidatorContext validatorContext;
    @Resource
    RestTemplate restTemplate;
    @Resource
    LabNoticeService labNoticeService;
    @Resource
    LabDetailService labDetailService;
    @Resource
    ResearchGroupService researchGroupService;
    @Resource
    LabLogisticsService labLogisticsService;
    @Resource
    InstrumentSummaryService instrumentSummaryService;
    @Resource
    InstrumentService instrumentService;
    @Resource
    MaterialService materialService;
    @Resource
    MaterialSummaryService materialSummaryService;
    @Resource
    TagService tagService;
    @Resource
    ProjectService projectService;
    @Resource
    TypeService typeService;
    @Resource
    FeeService feeService;
    @Resource
    LabDetailAuthorize labDetailAuthorize;
    @Resource
    PrizeService prizeService;
    @Resource
    StorageService storageService;
    @Resource
    ProcurementService procurementService;
    @Resource
    ApplicationService applicationService;
    @Resource
    RedisTemplate<String,Object> redisTemplate;
    @Resource
    private RocketMQTemplate rocketMQTemplate;
//    @Resource
//    private ThreadPoolTaskExecutor poolTaskExecutor;

    @Value("${rocketmq.tag.need-approval}")
    String wxMessageTMApprovalTag;
    @Value("${rocketmq.topic.tm}")
    String WX_MESSAGE_TOPIC;
    private final static String WX_MESSAGE_TEMPLATE_NEED_APPROVAL_ID= "j64TIk_KRFVfZN72SaTlwjygthTOANeC32n5LhZADbs";

    private final static String TAG_SEPARATOR= ",";
    private final static String CATEGORY_SEPARATOR= ",";
    private final static String PROJECT_PERSON_SEPARATOR= ",";
    private final static String RECENT_OPERATION_PREFIX= "ro_";


    private final static AtomicInteger generateInt = new AtomicInteger(1);
    private final static AtomicLong latestLong = new AtomicLong(0);

    private final static Tag TAG_FOR_ALL= Tag.builder().id(1L).name("实验室公用").permission("1100").build();
    private final static Tag TAG_FOR_APPLY_APPOINT= Tag.builder().id(2L).name("需申请预约").permission("1111").build();
    private final static Tag TAG_FOR_INSTRUMENT_APPOINT= Tag.builder().id(3L).name("预约仪器").permission("1110").build();
    private static URI getShortUrlUri;
    public final  static SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd" );
    public final  static SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private String get8UUID(){
        UUID id=UUID.randomUUID();
        String[] idd=id.toString().split("-");
        return idd[0];
    }
    private static final char[] digits = { //
            '0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
            'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
            'o', 'p', 'q', 'r', 's', 't', 'u', 'v'};
    public static String generate8RandomString(){
        boolean isRepeat = false;
        long time = System.currentTimeMillis();
        if (latestLong.longValue() == time){
            isRepeat =true;
            generateInt.addAndGet(1);
        }else {
            latestLong.set(time);
            generateInt.set(0);
        }

        System.out.println(time);
        StringBuilder stringBuilder = new StringBuilder();
        while (time>0){
            long idx = 0;
             long last= time%10;
             time = time/10;
             if (time>0){
                 long next = time%10;
                 time = time/10;
                 idx = next*10+last;
             }else {
                 idx = last;
             }
             while (idx>=32) {
                 stringBuilder.append('z');
                 idx-= 32;
             }
            stringBuilder.append(digits[(int)idx]);
        }
        String result = stringBuilder.toString();
        if (isRepeat){
            result+= generateInt;
        }
//        System.out.println(result);
        return  result;
    }

    public static void main(String[] args) {
        Thread t1 = new Thread(()->{
            System.out.println("T1");

            System.out.println(generate8RandomString());
            System.out.println(generate8RandomString());
        });
        Thread t2 = new Thread(()->{
            System.out.println("T2");
            System.out.println(generate8RandomString());
            System.out.println(generate8RandomString());
        });
       Executor e =   Executors.newFixedThreadPool(5);
       e.execute(t1);
       e.execute(t2);
    }

    static {
        try {
            getShortUrlUri = new URI("https://keyanplus.com/api/v1/utils/urls");
//            getShortUrlUri = new URI("http://10.0.16.26:3000/urls");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }
    private JwtUtil.TokenMessage check(HttpServletRequest httpServletRequest) {
        try {
            String token = httpServletRequest.getHeader("Authentication");
            if (StringUtils.isEmpty(token)){
                throw new NullPointerException("缺少凭证，无法调用该接口");
            }
            return JwtUtil.getTokenMessage(token);
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    /**
     *   添加快捷操作
     *   redis
     * */
    @GetMapping("/setRecentOperation")
    public MvcResult<Object> setRecentOperation(String operations,HttpServletRequest request){
        try {
            if (StringUtils.isEmpty(operations)){
                return NO_ARGS;
            }
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            String username = tokenMessage.getUsername();
            redisTemplate.opsForValue().set(RECENT_OPERATION_PREFIX+username,operations);
            return ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    @GetMapping("/getRecentOperation")
    public MvcResult<Object> getRecentOperation(HttpServletRequest request){
        try {

            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            String username = tokenMessage.getUsername();
            Object o = redisTemplate.opsForValue().get(RECENT_OPERATION_PREFIX+username);
            if  (o== null){
                return DATA_NULL;
            }
            return MvcResult.builder().code(20000).message("获取成功").data(o).build();
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }




    /**
     * 查看所有的仪器预约
     * */
    @GetMapping("/getAllAppointment")
    public MvcResult<Object> getAllAppointment(Long labId, HttpServletRequest request){
        try {
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<InstrumentAppointment> instrumentAppointments = applicationService.findAllInstrumentAppointment(labId);
            if (instrumentAppointments.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().code(20000).message("查询成功").data(instrumentAppointments).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    @PostMapping("/getNotice")
    public MvcResult<Object> getAllNotice(@RequestBody CommonQo commonQo,HttpServletRequest request){
        try {
            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            Page<LabNotice> labNotices =  labNoticeService.findAllByLabIdDynamic(labId,index,page,Sort.by(orders));
            if (labNotices.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<LabNotice>builder()
                    .data(labNotices.getContent())
                    .size(labNotices.getSize())
                    .totalElements(labNotices.getTotalElements())
                    .totalPages(labNotices.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    @PostMapping("/getAppointment")
    public MvcResult<Object> getAllAppointment(@RequestBody AppointQo appointQo, HttpServletRequest request){
        try {
            Long labId = appointQo.getLabId();
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<InstrumentAppointment> appointments = applicationService.findAllDynamic(appointQo);
            if (appointments.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().data(appointments).code(20000).message("获取成功").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取分类和人员映射
     * 已更新校验代码
     * */
    @GetMapping("/init")
    public MvcResult<Object> getTagHash(HttpServletRequest request,Long labId){
        try {
//            JwtUtil.TokenMessage tokenMessage = check(request);
//            if (tokenMessage==null){
//                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
//            }
//            LabDetail member = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
//            if (member==null||!member.getWork()){
//                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确或您已经不在此实验室").build();
//            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Map<String,Object> map = new HashMap<>(4);
            map.put("tagHash",tagService.findAllByLabId(labId));
            map.put("labDetails",labDetailService.findAllByLabId(labId));
            return MvcResult.builder().message("获取映射列表成功").code(20000).data(map).build();
        }catch (Exception e){
            e.printStackTrace();
            return  MvcResult.ERROR;
        }
    }

    /**
     * 动态查找经费
     * */
    @GetMapping("/getAllFees")
    public MvcResult<Object> getAllFees(HttpServletRequest request,Long labId,String projectName){
        try {
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Fee> fees;
            if (StringUtils.isEmpty(projectName)){
                FeeSpecQo feeSpecQo = new FeeSpecQo();
                feeSpecQo.setLabId(labId);
                fees = feeService.findAllByLabIdDynamic(feeSpecQo);
            }else {
                FeeSpecQo feeSpecQo = new FeeSpecQo();
                feeSpecQo.setLabId(labId);
                feeSpecQo.setProject_name(projectName);
                fees = feeService.findAllByLabIdDynamic(feeSpecQo);
            }
            if (fees==null||fees.size()==0){
                return MvcResult.DATA_NULL;
            }
           return MvcResult.builder().message("获取成功").code(20000).data(fees).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 查看申请事务
     * 事假 病假
     * */
    @PostMapping("/getApplication")
    public MvcResult<Object> findAllApplicationWithPage(@RequestBody ApplicationQo applicationQo,HttpServletRequest request){
        try {
            Long labId = applicationQo.getLabId();
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);

            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<Application> applications = applicationService.findAllApplicationWithSpec(applicationQo);
            if (applications.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Application>builder()
                    .data(applications.getContent())
                    .size(applications.getSize())
                    .totalElements(applications.getTotalElements())
                    .totalPages(applications.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 查看申请的仪器
     * 事假 病假
     * */
    @PostMapping("/getInstrumentApplication")
    public MvcResult<Object> findAllInstrumentApplicationWithPage(@RequestBody GoodsApplicationQo goodsApplicationQo,HttpServletRequest request){
        try {
            Long labId = goodsApplicationQo.getLabId();
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);

            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<InstrumentApplication> applications = applicationService.findAllInstrumentApplicationDynamic(goodsApplicationQo);
            if (applications.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<InstrumentApplication>builder()
                    .data(applications.getContent())
                    .size(applications.getSize())
                    .totalElements(applications.getTotalElements())
                    .totalPages(applications.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 查看申请的药剂
     * 事假 病假
     * */
    @PostMapping("/getMaterialApplication")
    public MvcResult<Object> findAllMaterialApplicationWithPage(@RequestBody GoodsApplicationQo goodsApplicationQo,HttpServletRequest request){
        try {
            Long labId = goodsApplicationQo.getLabId();
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);

            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<MaterialApplication> applications = applicationService.findAllMaterialApplicationDynamic(goodsApplicationQo);
            if (applications.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<MaterialApplication>builder()
                    .data(applications.getContent())
                    .size(applications.getSize())
                    .totalElements(applications.getTotalElements())
                    .totalPages(applications.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 获取实验室所有物品名称
     * 已更新校验代码
     * */
    @GetMapping("/goodsNames")
    public MvcResult<Object> getGoodsName(HttpServletRequest request,@RequestParam Long labId){
        try {
//            JwtUtil.TokenMessage tokenMessage = check(request);
//            if (tokenMessage==null){
//                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
//            }
//            LabDetail member = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
//            if (member==null||!member.getWork()){
//                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确或您已经不在此实验室").build();
//            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<InstrumentSummary> instrumentSummaries = instrumentSummaryService.findInstrumentSummariesNameByLabId(labId);
            List<MaterialSummary> materialSummaries = materialSummaryService.findAllMaterialSummariesNameByLabId(labId);
            Map<String,Object> map = new HashMap<>(4);
            map.put("instrumentList",instrumentSummaries);
            map.put("materialList",materialSummaries);
            return MvcResult.builder().message("获取成功").code(20000).data(map).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取单个物品
     * 已更新校验代码
     * */
    @GetMapping("/goods")
    public MvcResult<Object> getGoods(HttpServletRequest request,@RequestParam Long labId,@RequestParam String name,@RequestParam String type){
        try {
//            JwtUtil.TokenMessage tokenMessage = check(request);
//            if (tokenMessage==null){
//                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
//            }
//            LabDetail member = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
//            if (member==null||!member.getWork()){
//                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确或您已经不在此实验室").build();
//            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);

            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            if("INSTRUMENT".equals(type)){
                return MvcResult.builder().data(instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,name)).code(20000).message("获取成功").build();

            }else if ("MATERIAL".equals(type)){
                return MvcResult.builder().data(materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId,name)).code(20000).message("获取成功").build();

            }else {
                return MvcResult.builder().message("获取失败").code(40300).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    @GetMapping("/findAllInstrumentPlace")
    public MvcResult<Object> getAllInstrumentPlaceByName(HttpServletRequest request,@RequestParam Long labId,@RequestParam String name){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<String> strings = instrumentService.findAllPlaceByNameNotDelete(labId,name);
            if (strings.isEmpty()){
                return DATA_NULL;
            }
            return MvcResult.builder().message("获取成功").code(20000).data(strings).build();
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    @GetMapping("/findAllMaterialPlace")
    public MvcResult<Object> getAllMaterialPlace(HttpServletRequest request,@RequestParam Long labId,@RequestParam String name){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<String> strings = materialService.findMaterialsPlaceByNameNotDelete(labId,name);
            if (strings.isEmpty()){
                return DATA_NULL;
            }
            return MvcResult.builder().message("获取成功").code(20000).data(strings).build();
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    /**
    * 按名称获取物品
     * 已更新校验代码
    * */
    @GetMapping("/goodsByName")
    public MvcResult<Object> getGoodsByName(HttpServletRequest request,@RequestParam Long labId,@RequestParam String name,@RequestParam String type){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);

            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            if("INSTRUMENT".equals(type)){
                List<Instrument> instruments = instrumentService.findInstrumentsByName(labId,name);
                if (instruments==null){
                    MvcResult.builder().code(20002).message("没有相关数据").build();
                }
                log.info("{}",instruments);
                return MvcResult.builder().data(instruments).code(20000).message("获取成功").build();

            }else if ("MATERIAL".equals(type)){
                List<Material> materials =  materialService.findMaterialsByName(labId,name);
                if (materials==null){
                    MvcResult.builder().code(20002).message("没有相关数据").build();
                }
                return MvcResult.builder().data(materials).code(20000).message("获取成功").build();

            }else {
                return MvcResult.builder().message("获取失败").code(40300).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取实验室所有标签名称
     * */
    @GetMapping("/getAllCategoriesName")
    public MvcResult<Object> getAllCategoriesNameByLabId(Long labId,HttpServletRequest request){
        try {
            if (labId==null||labId<=0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<GoodsType> goodsTypes = typeService.findAllNameByLabId(labId);
            return MvcResult.builder().code(20000).message("获取成功").data(goodsTypes).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取标签分页信息
     * 已更新校验代码
     * */
    @PostMapping("/getCategories")
    public MvcResult<Object> getCategories(@RequestBody CommonQo commonQo,HttpServletRequest request){
        try {

            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
//            LabDetail admin = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
//            if (admin==null||!admin.getWork()){
//                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确或您已经不在此实验室").build();
//            }
//            if (!admin.getRole().equals(LabRole.ADMIN.getRole())
//                    &&!admin.getRole().equals(LabRole.OWNER.getRole())){
//                return  MvcResult.builder().code(40300).message("权限不足，只有实验室拥有者和管理员才能查看标签信息").build();
//            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            Page<GoodsType> types =  typeService.findAllGoodsTypeByLabIdDynamic(labId,index,page,Sort.by(orders));
            if (types.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<GoodsType>builder()
                    .data(types.getContent())
                    .size(types.getSize())
                    .totalElements(types.getTotalElements())
                    .totalPages(types.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }
    /**
     * 获取单个实验室信息
     * 可以公开给所有人
     * */
    @GetMapping("/")
    public MvcResult<Object> getLabInfo(@RequestParam Long labId ){
        try {
            Lab lab = labService.findLabById(labId);
            if (lab.getIsDelete()){
                return DATA_NULL;
            }
            return MvcResult.builder().data(lab).message("获取实验室信息成功").code(20000).build();
        }catch (NullPointerException e){
            return MvcResult.builder().code(40321).message(e.getMessage()).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查询和自己有关的实验室
     * 已更新校验代码
     * */
    @GetMapping("/person")
    public MvcResult<Object> getLabHistory(HttpServletRequest request){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,null,labDetailService,
                    LabRole.NONE);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String name = ((JwtUtil.TokenMessage) authorizeResult.getData()).getUsername();
            return MvcResult.builder().code(20000).data(labDetailService.findAllByAccountId(name)).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 获取成员当前实验室
     * 已更新校验代码
     * */
    @GetMapping("/curLab")
    public MvcResult<Object> getCurrentLab(HttpServletRequest request){
        try {
//            JwtUtil.TokenMessage tokenMessage = check(request);
//            if (tokenMessage==null){
//                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
//            }
//            String name = tokenMessage.getUsername();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,null,labDetailService,
                    LabRole.NONE);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String name = ((JwtUtil.TokenMessage) authorizeResult.getData()).getUsername();
            LabDetail labDetail = labDetailService.getCurLab(name);
            if (labDetail==null){
              return  MvcResult.NO_IN_LAB;
            }
            return MvcResult.builder().code(20000).data(labDetail).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 获取成员在当前实验室中的更多信息
     * */
    @GetMapping("/curLabDetail")
    public MvcResult<Object> getCurrentLabDetail(HttpServletRequest request){
        try {
//            JwtUtil.TokenMessage tokenMessage = check(request);
//            if (tokenMessage==null){
//                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
//            }
//            String name = tokenMessage.getUsername();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,null,labDetailService,
                    LabRole.NONE);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String name = ((JwtUtil.TokenMessage) authorizeResult.getData()).getUsername();
            LabDetail labDetail = labDetailService.getCurLab(name);
            if (labDetail==null){
                return  MvcResult.NO_IN_LAB;
            }
            List<ResearchGroupDetail> researchGroupDetails = researchGroupService.findAllDetailByLabDetailId(labDetail.getId());
            Map<String,Object> map = new LinkedHashMap<>();
            map.put("labDetail",labDetail);
            map.put("researchGroupDetails",researchGroupDetails);
            return MvcResult.builder().code(20000).data(map).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取自己的角色
     * */
    @GetMapping("/self")
    public MvcResult<Object> getLabHistory(HttpServletRequest request,@RequestParam Long labId){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String name = ((JwtUtil.TokenMessage) authorizeResult.getData()).getUsername();
            return MvcResult.builder().code(20000).data(labDetailService.findByAccountNameAndLabIdAndWorkAndNotDelete(name,labId)).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    @GetMapping("/getMemberNames")
    public MvcResult<Object> getLabDetails(Long labId , HttpServletRequest request){
        try {
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }
            List<LabDetail>  labDetails = labDetailService.findAllLabDetailNameAndRoleAndIdByLabIdAndWorkAndNotDelete(labId);
            if (labDetails==null||labDetails.size()==0){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().code(20000).message("获取成功").data(labDetails).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


//    public static void main(String[] args) {
//        Set<String> set1 = new HashSet<String>(Arrays.asList("1", "2","3","5","6"));
//        Set<String> set2 = new HashSet<String>(Arrays.asList("1", "2","4"));
//        set2.retainAll(set1);
//        log.info("set2 : {}",set2);
//        return;
//    }

    /**
     * 查询实验室人员
     * 公开给所有人
     * 可能存在暴露属性名暴露的问题？
     * 1. 查询实验室所有分类信息
     * 2. 检验所有分类管理员是否被删除了对应分类，懒更新其权限，若其有关联的分类，将分类载入管理员信息中
     *
     * */
    @PostMapping("/members")
    public MvcResult<Object> getLabMembers(@RequestBody LabDetailQo labDetailQo){
        Long labId = labDetailQo.getLabId();
        Integer index= labDetailQo.getIndex();
        Integer page = labDetailQo.getPageSize();
        if (labId==null||index==null||page==null){
            return MvcResult.NO_ARGS;
        }
        try {
            List<Tag> tags = tagService.findAllByLabId(labId);
            Page<LabDetail> labDetails = labDetailService.findAllByLabIdDynamic(labDetailQo);
            List<LabDetail> moveDetailList = new LinkedList<>();
            Set<String> existTagIds = new HashSet<>();
            Map<String,List<Tag>> map = new HashMap<>();
            if (tags!=null&&tags.size()!=0){
                for (Tag t:tags
                ) {
                    existTagIds.add(t.getId()+"");
                    // 配置每个管理员对应的分类
                    for (String s:t.getFkAdminIds().split(TAG_SEPARATOR)
                    ) {
                        if (!StringUtils.isEmpty(s)){
                            List<Tag> tags1 = map.getOrDefault(s,new LinkedList<>());
                            tags1.add(t);
                            map.put(s,tags1);
                        }
                    }
                }
            }

            if (!labDetails.isEmpty()){
                for (LabDetail l:labDetails.getContent()
                ) {
                    log.info("existTagIds : {}",existTagIds);
                    // 实验室人员的关联分类
                    if (l.getTagIds()!=null){
                        Set<String> tagSet = new HashSet<>(Arrays.asList(l.getTagIds().split(TAG_SEPARATOR)));
                        // 如果因为 existTagIds 缺少了原有的分类，导致tagSet取交集后发生了改变，返回true
                        if ( tagSet.retainAll(existTagIds)){
                            l.setTagIds(StringUtils.arrayToDelimitedString(tagSet.toArray(), TAG_SEPARATOR));
                            moveDetailList.add(l);
                        }
                        // 将分类信息填装到实验室管理员中发送给前段
                        if(!l.getRole().equals(LabRole.MEMBER.getRole())){
                            List<Tag> tags1 = map.get(l.getId()+"");
                            if (tags.size()==0&&l.getRole().equals(LabRole.CATEGORY_ADMIN.getRole())){
                                l.setRole(LabRole.MEMBER.getRole());
                                moveDetailList.add(l);
                                continue;
                            }
                            l.setTags(tags1);
                        }
                    }
                }
            }
            labDetailService.saveInBatch(moveDetailList);
            return MvcResult.builder().code(20000).message("查询成功").data(LabDetailVo.builder()
                    .data(labDetails.getContent())
                    .size(labDetails.getSize())
                    .totalElements(labDetails.getTotalElements())
                    .totalPages(labDetails.getTotalPages()).build())
                    .build();
        }catch (TransactionException e){
            e.printStackTrace();
            return MvcResult.builder().code(50006).message("属性名错误").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查询实验室的课题组
     * 使用check校验
     * 1。 查找两类课题组 如果用户不在实验室中，只能查询可见的课题组
     * 2。 反之，可以查看所有课题组
     * */
    @PostMapping("/researchGroups")
    public MvcResult<Object> getResearchGroups(@RequestBody ResearchGroupQo researchGroupQo,HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            Long labId = researchGroupQo.getLabId();
            Integer index= researchGroupQo.getIndex();
            Integer page = researchGroupQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            //不是用户，或者用户不在实验室中
            if (tokenMessage==null|| !labDetailService.isInLab(tokenMessage.getUsername())){
                Page<ResearchGroup> researchGroups = researchGroupService.findAllByLabIdWithPageableAndCanSee(labId,index,page,null);
                if (researchGroups.isEmpty()){
                    return MvcResult.DATA_NULL;
                }

                return MvcResult.builder().data(CommonPageVo.<ResearchGroup>builder()
                        .data(researchGroups.getContent())
                        .size(researchGroups.getSize())
                        .totalElements(researchGroups.getTotalElements())
                        .totalPages(researchGroups.getTotalPages()).build())
                        .message("获取成功").code(20000).build();
            }
            //用户在实验室中
            Page<ResearchGroup> researchGroups = researchGroupService.findAllByLabIdWithPageable(labId,index,page,null);
            if (researchGroups.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().data(CommonPageVo.<ResearchGroup>builder()
                    .data(researchGroups.getContent())
                    .size(researchGroups.getSize())
                    .totalElements(researchGroups.getTotalElements())
                    .totalPages(researchGroups.getTotalPages()).build())
                    .message("获取成功").code(20000).build();
        } catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看项目
     * 1. 已经添加校验器校验
     * 已经更新校验代码
     * */
    @PostMapping("/getProjects")
    public MvcResult<Object> getProject(HttpServletRequest request,@RequestBody ProjectQo projectQo){
        try {
            //--- 校验代码 写死---- //
            Long labId = projectQo.getLabId();
            Integer index= projectQo.getIndex();
            Integer page = projectQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,projectQo.getLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            //--- 校验代码 写死---- //

            List<String> ascProperties = projectQo.getAscProperties();
            List<String> descProperties = projectQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            ProjectSpecQo projectSpecQo = new ProjectSpecQo();
            projectSpecQo.setLabId(projectQo.getLabId());
            projectSpecQo.setLevel(projectQo.getLevel());
            projectSpecQo.setName(projectQo.getName());
            projectSpecQo.setType(projectQo.getType());
            Page<Project> types =  projectService.findAllByProjectSpecQo(projectSpecQo,projectQo.getIndex(),projectQo.getPageSize(),Sort.by(orders));
            if (types.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Project>builder()
                    .data(types.getContent())
                    .size(types.getSize())
                    .totalElements(types.getTotalElements())
                    .totalPages(types.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看费用
     * 1. 已经添加校验器校验
     * 已经更新校验代码
     * */
    @PostMapping("/getFees")
    public MvcResult<Object> getFee(HttpServletRequest request,@RequestBody FeeQo feeQo){
        try {
            //--- 校验代码 写死---- //
            Long labId = feeQo.getLabId();
            Integer index= feeQo.getIndex();
            Integer page = feeQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,feeQo.getLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            //--- 校验代码 写死---- //

            List<String> ascProperties = feeQo.getAscProperties();
            List<String> descProperties = feeQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            FeeSpecQo feeSpecQo = new FeeSpecQo();
            feeSpecQo.setLabId(feeQo.getLabId());
            feeSpecQo.setProject_name(feeQo.getProjectName());
            Page<Fee> types = feeService.findAllByFeeSpecQo(feeSpecQo,index,page,Sort.by(orders));
            if (types.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Fee>builder()
                    .data(types.getContent())
                    .size(types.getSize())
                    .totalElements(types.getTotalElements())
                    .totalPages(types.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }




    @PostMapping("/getBorrowRecord")
    public MvcResult<Object> getBorrowRecord(@RequestBody BorrowRecordQo borrowRecordQo,HttpServletRequest httpServletRequest){
        try {
            if (borrowRecordQo.getLabId()==null||borrowRecordQo.getLabId()<=0){
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(httpServletRequest,borrowRecordQo.getLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<BorrowRecord> borrowRecords = borrowRecordService.findAllByLabIdDynamic(borrowRecordQo);
            if (borrowRecords.isEmpty()){
                return  DATA_NULL;
            }
            return builder().code(20000).data(borrowRecords).build();
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    @PostMapping("/exportBorrowRecord")
    public void exportBorrowRecord(@RequestBody BorrowRecordQo borrowRecordQo, HttpServletRequest httpServletRequest, HttpServletResponse response){
        try {
            if (borrowRecordQo.getLabId()==null||borrowRecordQo.getLabId()<=0){
                log.info("exportBorrowRecord：illegal args");
            }else {
                MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(httpServletRequest,borrowRecordQo.getLabId(),labDetailService);
                if (authorizeResult.getCode()!=0){
                    log.info("exportBorrowRecord：auth fail");
                    return ;
                }
                Page<BorrowRecord> borrowRecords = borrowRecordService.findAllByLabIdDynamic(borrowRecordQo);
                log.info("{}",borrowRecords.getContent());
                Set<String> excludeColumnFiledNames = new HashSet<String>();
                excludeColumnFiledNames.add("id");
                excludeColumnFiledNames.add("goodsId");
                excludeColumnFiledNames.add("goodsProperties");
                excludeColumnFiledNames.add("fkLabId");
                excelUtil.download(response,BorrowRecord.class,borrowRecords.getContent(),null,"领取记录");
//                response.setContentType("application/vnd.ms-excel");
//                response.setCharacterEncoding("utf-8");
//                // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
//                String fileName = URLEncoder.encode("测试", "UTF-8").replaceAll("\\+", "%20");
//                response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");
//                EasyExcel.write(response.getOutputStream(), BorrowRecord.class).sheet("模板").doWrite(borrowRecords.getContent());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 获取所有课题组人员信息和人员信息
     * 公开允许公开的课题组人员信息
     * 获取所有实验室用户
     * */
    @GetMapping("/researchGroupsAndDetails")
    public MvcResult<Object> getResearchGroupsDetailsWithLabId(@RequestParam Long labId ,HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null|| !labDetailService.isInLab(tokenMessage.getUsername())){
                List<ResearchGroupDetail> researchGroupDetails = researchGroupService.findAllLabResearchGroupDetailsCanSeeByLabId(labId);
                List<LabDetail> labDetails =  labDetailService.findAllLabDetailNameAndRoleAndIdByLabIdAndWorkAndNotDelete(labId);
                Map<String,Object> map = new HashMap<>(4);
                map.put("researchGroupDetails",researchGroupDetails);
                map.put("labDetails",labDetails);
                return MvcResult.builder().code(20000).message("获取成功").data(map).build();
            }
            List<ResearchGroupDetail> researchGroupDetails = researchGroupService.findAllLabResearchGroupDetailsByLabId(labId);
            List<LabDetail> labDetails =  labDetailService.findAllLabDetailNameAndRoleAndIdByLabIdAndWorkAndNotDelete(labId);
            Map<String,Object> map = new HashMap<>(4);
            map.put("researchGroupDetails",researchGroupDetails);
            map.put("labDetails",labDetails);
            return MvcResult.builder().code(20000).message("获取成功").data(map).build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取某个课题组人员信息
     * 公开允许公开的课题组人员信息
     * */
    @GetMapping("/researchGroupAndDetails")
    public MvcResult<Object> getResearchGroupsDetailsWithGroupId(@RequestParam Long researchGroupId, HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null|| !labDetailService.isInLab(tokenMessage.getUsername())){
                if (!researchGroupService.isShowForAll(researchGroupId)){
                    return MvcResult.builder().message("课题组已设置隐藏课题组信息").code(20000).build();
                }
            }
            List<ResearchGroupDetail> researchGroupDetails = researchGroupService.findAllLabResearchGroupDetailsByGroupId(researchGroupId);
            return MvcResult.builder().code(20000).message("获取成功").data(researchGroupDetails).build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }

    /**
     * 查看物流
     * 需要是实验室管理人员
     * 已更新校验代码
     * */
    @PostMapping("/getLogistics")
    public MvcResult<Object> getLogistics(@RequestBody LogisticsQo logisticsQo, HttpServletRequest request){
        try{
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Long labId = logisticsQo.getLabId();
            Integer index= logisticsQo.getIndex();
            Integer page = logisticsQo.getPageSize();
            boolean isInLab = logisticsQo.getIsInLab();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = logisticsQo.getAscProperties();
            List<String> descProperties = logisticsQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<Logistics> logistics = labLogisticsService.findAllByLabIdDynamic(isInLab,labId,index,page,Sort.by(orders));
            if (logistics.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Logistics>builder()
                    .data(logistics.getContent())
                    .size(logistics.getSize())
                    .totalElements(logistics.getTotalElements())
                    .totalPages(logistics.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看药剂
     * 已经更新校验代码
     * */
    @PostMapping("/getMaterialsSummary")
    public MvcResult<Object> getMaterials(@RequestBody CommonQo commonQo,HttpServletRequest request){
        try{
            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<MaterialSummary> materialSummaries = materialSummaryService.findAllByLabIdDynamic(labId,index,page,Sort.by(orders));
            if (materialSummaries.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<MaterialSummary>builder()
                    .data(materialSummaries.getContent())
                    .size(materialSummaries.getSize())
                    .totalElements(materialSummaries.getTotalElements())
                    .totalPages(materialSummaries.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }
    /**
     * 获取分类
     * 已经更新校验代码
     * */
    @PostMapping("/getTags")
    public MvcResult<Object> getTags(@RequestBody CommonQo commonQo,HttpServletRequest request){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            Long labId = commonQo.getLabId();

            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<Tag> tags =  tagService.findAllByLabIdDynamic(labId,index,page,Sort.by(orders));
            if (tags.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Tag>builder()
                    .data(tags.getContent())
                    .size(tags.getSize())
                    .totalElements(tags.getTotalElements())
                    .totalPages(tags.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }

    /**
     * 查看仪器库存
     * 已经更新校验代码
     * */
    @PostMapping("/getInstrumentSummary")
    public MvcResult<Object> getInstruments(@RequestBody CommonQo commonQo,HttpServletRequest request){
        try{
            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<InstrumentSummary> instrumentSummaries = instrumentSummaryService.findAllByLabIdDynamic(labId,index,page,Sort.by(orders));
            if (instrumentSummaries.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<InstrumentSummary>builder()
                    .data(instrumentSummaries.getContent())
                    .size(instrumentSummaries.getSize())
                    .totalElements(instrumentSummaries.getTotalElements())
                    .totalPages(instrumentSummaries.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看特定仪器
     * 无需request校验
    * */
    @GetMapping("/instrument")
    public MvcResult<Object> getInstrument(Long labId,String pid,Integer sid){
        try{
            Instrument instrument =  instrumentService.findByLabIdAndPidAndSidNotDelete(labId,pid,sid);
            InstrumentSummary instrumentSummary = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,instrument.getName());
            Long tagId = instrumentSummary.getFkTagId();
            String permission = "";
            if (tagId!=null&&tagId!=0){
                 permission = tagService.getPermission(instrumentSummary.getFkTagId());
            }
            return MvcResult.builder().message("获取成功").data(InstrumentVo.builder().brand(instrumentSummary.getBrand())
                    .name(instrument.getName())
                    .picture(instrumentSummary.getPicture())
                    .place(instrument.getPlace())
                    .remark(instrument.getRemark())
                    .supplierName(instrumentSummary.getSupplierName())
                    .tag(permission)
                    .typeName(instrumentSummary.getTypeName())
                    .unit(instrumentSummary.getUnit())
                    .build()).code(20000).build();
        }catch (NullPointerException n){
            return MvcResult.builder().code(40342).message(n.getMessage()).build();
        } catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看特定药剂
     * 无需request校验
     * */
    @GetMapping("/material")
    public MvcResult<Object> getMaterial(Long labId,String pid,Integer sid){
        try{

            Material material =  materialService.findByLabIdAndPidAndSidNotDelete(labId,pid,sid);
            MaterialSummary materialSummary = materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId,material.getName());
            String permission = "";
            Long tagId = materialSummary.getFkTagId();
            if (tagId!=null&&tagId!=0){
                 permission = tagService.getPermission(materialSummary.getFkTagId());
            }
            return MvcResult.builder().message("获取成功").data(MaterialVo.builder().brand(materialSummary.getBrand())
                    .name(material.getName())
                    .picture(materialSummary.getPicture())
                    .place(material.getPlace())
                    .cas(material.getCas())
                    .concentration(material.getConcentration())
                    .supplierName(materialSummary.getSupplierName())
                    .tag(permission)
                    .typeName(materialSummary.getTypeName())
                    .unit(materialSummary.getUnit())
                    .build()).code(20000).build();
        }catch (NullPointerException n){
            return MvcResult.builder().code(40342).message(n.getMessage()).build();
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看某一批特定仪器
     * 已经更新校验代码
     * */
    @GetMapping("/instruments")
    public MvcResult<Object> getInstruments(Long labId,String pid,HttpServletRequest request){
        try{
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Instrument> instruments =  instrumentService.findByLabIdAndPidNotDelete(labId,pid);
            if(instruments==null){
                return MvcResult.builder().message("没有相关数据").code(20002).build();
            }
            return MvcResult.builder().message("获取成功").code(20000).data(instruments).build();
        }catch (NullPointerException n){
            return MvcResult.builder().code(40342).message(n.getMessage()).build();
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 查看某一批特定药剂
     * 已经更新校验代码
     * */
    @GetMapping("/materials")
    public MvcResult<Object> getMaterials(Long labId,String pid,HttpServletRequest request){
        try{
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Material> materials =  materialService.findByLabIdAndPidNotDelete(labId,pid);
            if(materials==null){
                return MvcResult.builder().message("没有相关数据").code(20002).build();
            }
           return MvcResult.builder().message("获取成功").code(20000).data(materials).build();
        }catch (NullPointerException n){
            return MvcResult.builder().code(40342).message(n.getMessage()).build();
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 获取所有的存储地址
     * */
    @GetMapping("/storages")
    public MvcResult<Object> getStorages(Long labId,HttpServletRequest request){
        try {
            if (labId==null||labId==0){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,labId,labDetailService,LabRole.NONE);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Storage> storages =  storageService.findAllByLabId(labId);
            if (storages==null){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().message("获取成功").code(20000).data(storages).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 查看采购
     * */
    @PostMapping("/getProcurement")
    public MvcResult<Object> getProcurement(@RequestBody CommonQo commonQo,HttpServletRequest request){

        try {
            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<Procurement> procurements = procurementService.findAllByLabId(labId,index,page,Sort.by(orders));
            if(procurements.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Procurement>builder()
                    .data(procurements.getContent())
                    .size(procurements.getSize())
                    .totalElements(procurements.getTotalElements())
                    .totalPages(procurements.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 添加借还记录
     * */
    @PostMapping("/borrowRecord")
    public MvcResult<Object> addBorrowRecord(@RequestBody  BorrowRecordInsert borrowRecord, HttpServletRequest request){
        try {
            Long labId = borrowRecord.getFkLabId();
            if (labId==null||labId<=0

                ||StringUtils.isEmpty(borrowRecord.getBorrowerName())
                    ||borrowRecord.getGoodsId()==null
                    ||borrowRecord.getGoodsId()<=0
                    ||StringUtils.isEmpty(borrowRecord.getGoodsName())
                    ||borrowRecord.getGoodsNumber()==null
                    ||borrowRecord.getGoodsNumber()<=0
                    ||StringUtils.isEmpty(borrowRecord.getGoodsPlace())
                    || (!"INSTRUMENT".equals(borrowRecord.getGoodsProperties()) && !"MATERIAL".equals(borrowRecord.getGoodsProperties()) )
                    ||borrowRecord.getGoodsTime()==null||borrowRecord.getGoodsTime()<=0
                    || StringUtils.isEmpty(borrowRecord.getManagerName())

            ){
                log.info("{},{},{},{},{},{},{},{}",StringUtils.isEmpty(borrowRecord.getBorrowerName()),
                        borrowRecord.getGoodsId()==null ||borrowRecord.getGoodsId()<=0,
                        StringUtils.isEmpty(borrowRecord.getGoodsName())
                ,borrowRecord.getGoodsNumber()==null  ||borrowRecord.getGoodsNumber()<=0,
                        StringUtils.isEmpty(borrowRecord.getGoodsPlace()),
                        (!"INSTRUMENT".equals(borrowRecord.getGoodsProperties()) && !"MATERIAL".equals(borrowRecord.getGoodsProperties()) )
                ,borrowRecord.getGoodsTime()==null ||borrowRecord.getGoodsTime()<=0,StringUtils.isEmpty(borrowRecord.getManagerName()));
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            return    borrowRecordService.borrow(BorrowRecord.builder()
                    .borrowerName(borrowRecord.getBorrowerName())
                    .managerName(borrowRecord.getManagerName())
                    .goodsId(borrowRecord.getGoodsId())
                    .goodsName(borrowRecord.getGoodsName())
                    .goodsNumber(borrowRecord.getGoodsNumber())
                    .goodsPlace(borrowRecord.getGoodsPlace())
                    .goodsProperties(borrowRecord.getGoodsProperties())
                    .goodsTime(new Timestamp(borrowRecord.getGoodsTime()))
                    .fkLabId(borrowRecord.getFkLabId())
                    .build(),instrumentSummaryService,materialSummaryService);
        }catch (Exception e){
            e.printStackTrace();
            return  ERROR;
        }
    }
    /**
     * 批量添加存储地址
     * */
    @PostMapping("/storages")
    public MvcResult<Object> saveStorages(@RequestBody List<StorageInsert> storageInserts, HttpServletRequest request){
        try {

            Set<Storage> storages = new HashSet<>();
            for (StorageInsert s:storageInserts
                 ) {
                if (s.getLabId()==null||s.getLabId()==0){
                    return MvcResult.NO_ARGS;
                }
                storages.add(Storage.builder().name(s.getName()).detail(s.getDetail()).fkLabId(s.getLabId()).build());
            }
            Long labId = storageInserts.get(0).getLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            storageService.save(storages);
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 获取分页奖项
     * */
    @PostMapping("/getPrizes")
    public MvcResult<Object> getPrizes(@RequestBody CommonQo commonQo ,HttpServletRequest request){
        try{
            Long labId = commonQo.getLabId();
            Integer index= commonQo.getIndex();
            Integer page = commonQo.getPageSize();
            if (labId==null||index==null||page==null){
                return MvcResult.NO_ARGS;
            }
            List<String> ascProperties = commonQo.getAscProperties();
            List<String> descProperties = commonQo.getDescProperties();
            List<Sort.Order> orders = new LinkedList<>();
            if (ascProperties!=null){
                for (String p:ascProperties
                ) {
                    orders.add(Sort.Order.asc(p));
                }
            }
            if (descProperties!=null){
                for (String p:descProperties
                ) {
                    orders.add(Sort.Order.desc(p));
                }
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Page<Prize> prizes = prizeService.findAllByLabId(labId,index,page,Sort.by(orders));
            if (prizes.isEmpty()){
                return MvcResult.DATA_NULL;
            }
            return  MvcResult.builder().code(20000).message("查询成功").data(CommonPageVo.<Prize>builder()
                    .data(prizes.getContent())
                    .size(prizes.getSize())
                    .totalElements(prizes.getTotalElements())
                    .totalPages(prizes.getTotalPages()).build())
                    .build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 查看实验室所有项目名
     * */

    @GetMapping("/getAllProject")
    public MvcResult<Object> getAllProject(Long labId,HttpServletRequest request){
        try {
            if (labId<=0){
                return MvcResult.NO_ARGS;
            }

            Lab lab = labService.findLabById(labId);
            if (lab==null||lab.getIsDelete()){
                return MvcResult.DATA_NULL;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Project> projects =projectService.findAllNameAndLevelAndTypeAndIdByLabId(labId);
            if (projects==null||projects.size()==0){
                return MvcResult.DATA_NULL;
            }
            return MvcResult.builder().code(20000).message("获取成功").data(projects).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
//
//    @Data
//    @AllArgsConstructor
//    @NoArgsConstructor
//    static class WxMessageTask implements Runnable {
//        private RocketMQUtil rocketMQUtil;
//        private String topic;
//        private String tag;
//        private String content;
//
//        @SneakyThrows
//        public void run() {
//            SendResult sendResult = rocketMQUtil.sendResultSync(topic,tag,content);
//        }
//    }

    /**
     *   传送消息到消息队列
     *   一次远程调用获取所有管理员的UnionId
     *   其中 topic 为  wxMessageTopic
     *    其中 tag 为  wxMessageTopic
     * */
    private void sendToManagers(List<String> accounts,Application application) {
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        headers.add("Accept", MediaType.APPLICATION_JSON.toString());
        HttpEntity<Object> requestEntity = new HttpEntity<>(JSONArray.toJSONString(accounts), headers);

        String body = restTemplate.exchange("https://keyanplus.com/api/v1/user/getAllOpenId"
                , HttpMethod.POST,requestEntity, String.class).getBody();

        log.info("getAllOpenId body is :"+body);
        if (!"fail".equals(body)){
            List<String> openIds = JSONArray.parseArray(body,String.class);
            if (openIds!=null&&openIds.size()!=0){
                List<WxApplicationNeedApprovalTM> applicationNeedApprovalTMS = new LinkedList<>();
                for (String o:openIds
                ) {
                   applicationNeedApprovalTMS.add(WxApplicationNeedApprovalTM.builder().template_id(WX_MESSAGE_TEMPLATE_NEED_APPROVAL_ID)
                                                        .touser(o)
                                                        .url("https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxe8e722ddf56fc585&redirect_uri=https%3A%2F%2Fkeyanplus.com%2Fapi%2Fv1%2Fthird%2Fwx%2Fcallback&response_type=code&scope=snsapi_base&state=apply")
                                                        .data(WxApplicationNeedApprovalTMData.builder()
                                                                    .first(WxTMDataUnit.builder().value(application.getTitle()).build())
                                                                    .keyword1(WxTMDataUnit.builder().value(application.getType()).build())
                                                                    .keyword2(WxTMDataUnit.builder().value(application.getSponsorName()).build())
                                                                    .keyword3(WxTMDataUnit.builder().value(sdf2.format(application.getCreateTime())).build())
                                                                    .remark(WxTMDataUnit.builder().value(application.getContent()).build())
                                                                    .build()).build());
                }
                rocketMQTemplate.sendOneWay(WX_MESSAGE_TOPIC,JSONArray.toJSONString(applicationNeedApprovalTMS).getBytes());
//                poolTaskExecutor.execute(new WxMessageTask(rocketMQUtil,WX_MESSAGE_TOPIC,wxMessageTMApprovalTag, JSONArray.toJSONString(applicationNeedApprovalTMS)));
            }
        }
    }

    /**
     * 添加仪器申请记录接口
     *  是精细化物品（selfId，pid） （在精细化层面上添加记录（时间））
     *      *          不是精细化物品 只生成申请记录 （在总览层面上 ）
     *      *          移动端或者智能化设备记录使用日志(对于精细化管理的仪器要做是否申请的校验)
     * */
    @PostMapping("/addInstrumentApplication")
    public MvcResult<Object> addInstrumentApplication(@RequestBody  GoodsApplicationInsert goodsApplicationInsert, HttpServletRequest request){
        try {
            Long labId = goodsApplicationInsert.getLabId();
            String name = goodsApplicationInsert.getName();
            String title= goodsApplicationInsert.getTitle();
            String content = goodsApplicationInsert.getContent();
            Set<Long> managerIds = goodsApplicationInsert.getManagerIds();
            log.info("{}",managerIds);
            if (labId <= 0 || StringUtils.isEmpty(name) || StringUtils.isEmpty(title) || managerIds == null||managerIds.isEmpty()){
                return NO_ARGS;
            }
            if (managerIds.size()>3){
                return MvcResult.builder().message("目前仅支持3位审批人").code(20000).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0) {
                return authorizeResult;
            }
            JwtUtil.TokenMessage tokenMessage = (JwtUtil.TokenMessage) authorizeResult.getData();
            LabDetail labDetail = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
            InstrumentSummary instrumentSummary = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,name);
            if (instrumentSummary == null||labDetail == null){
                return DATA_NULL;
            }
            Tag tag = tagService.getTag(instrumentSummary.getFkTagId());
            if ( tag ==null){
                return MvcResult.DATA_NULL;
            }
            Set<String> idSet = null;
            if (labDetail.getTagIds()!=null){
                idSet =  new HashSet<String>(Arrays.asList(labDetail.getTagIds().split(TAG_SEPARATOR)));
            }
            Set<String> adminSet = null;
            if (tag.getFkAdminIds()!=null){
                adminSet = new HashSet<String>(Arrays.asList(tag.getFkAdminIds().split(TAG_SEPARATOR)));
            }


            Boolean canSee = Tag.canVisible(tag,idSet,adminSet,labDetail);
            // 不可见的情况
            if (!canSee){
                return MvcResult.CANT_SEE_TAG;
            }
            Boolean canUse = Tag.isUsable(tag,idSet,adminSet,labDetail);
            if (!canUse){
                return MvcResult.CANT_USE_TAG;
            }
            if (Tag.needAppoint(tag)){
                return NEED_APPOINT_TAG;
            }
            if (!Tag.needApply(tag)){
                return CANT_APPLY_TAG;
            }

            List<LabDetail> labDetails = labDetailService.findAllCurLabDetailById(managerIds);
            if (labDetails==null||labDetails.isEmpty()||labDetails.size()!=managerIds.size()){
                return MvcResult.NO_ARGS;
            }
            List<String> names = new LinkedList<>();
            List<String> accounts = new LinkedList<>();
            for (LabDetail n:labDetails
            ) {
                if (!n.getRole().equals(LabRole.ADMIN.getRole())&&!n.getRole().equals(LabRole.OWNER.getRole())){
                    return MvcResult.builder().message("只能选取管理员或者实验室拥有着处理事务申请").code(40300).build();
                }
                names.add(n.getRealName());
                accounts.add(n.getFkAccountName());
            }
            Application application = Application.builder()
                    .content(content)
                    .fkLabId(labId)
                    .title(title)
                    .isCancel(false)
                    .managerIds(StringUtils.arrayToDelimitedString(managerIds.toArray(),TAG_SEPARATOR))
                    .managerNames(StringUtils.arrayToDelimitedString(names.toArray(),TAG_SEPARATOR))
                    .sponsorId(labDetail.getId())
                    .sponsorName(labDetail.getRealName())
                    .createTime(new Timestamp(System.currentTimeMillis()))
                    .type(ApplicationType.仪器申请.getValue())
                    .isDelete(false)
                    .state(ApplicationState.init.getValue())
                    .build();
            // 可见 可用 无需预约 且需要申请
            if (Tag.needHighManagement(tag)){
                // 校验参数
                Integer selfId = goodsApplicationInsert.getSelfId();
                String pid = goodsApplicationInsert.getPid();
                if (selfId<=0||StringUtils.isEmpty(pid)){
                    return  NO_ARGS;
                }
            }
            applicationService.saveInstrumentApplication(application,goodsApplicationInsert,labDetail);
            sendToManagers(accounts,application);
            return ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    /**
     * 药剂申请接口
     *   是精细化物品（selfId，pid） （在精细化层面上添加记录（时间））
     *      *          不是精细化物品 只生成申请记录 （在总览层面上 ）
     *      *          移动端或者智能化设备记录使用日志(对于精细化管理的仪器要做是否申请的校验)
     * */
    @PostMapping("/addMaterialApplication")
    public MvcResult<Object> addMaterialApplication(@RequestBody GoodsApplicationInsert goodsApplicationInsert, HttpServletRequest request){
        try {
            Long labId = goodsApplicationInsert.getLabId();
            String name = goodsApplicationInsert.getName();
            String title= goodsApplicationInsert.getTitle();
            String content = goodsApplicationInsert.getContent();
            Set<Long> managerIds = goodsApplicationInsert.getManagerIds();
            if (labId<=0||StringUtils.isEmpty(name)||StringUtils.isEmpty(title)
                    ||managerIds==null
                    ||managerIds.size()==0){
                return NO_ARGS;
            }
            if (managerIds.size()>3){
                return MvcResult.builder().message("目前仅支持3位审批人").code(20000).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0) {
                return authorizeResult;
            }
            JwtUtil.TokenMessage tokenMessage = (JwtUtil.TokenMessage) authorizeResult.getData();
            LabDetail labDetail = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
            MaterialSummary materialSummary = materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId,name);
            if (materialSummary == null||labDetail == null){
                return DATA_NULL;
            }
            Tag tag = tagService.getTag(materialSummary.getFkTagId());
            if ( tag ==null){
                return MvcResult.DATA_NULL;
            }
            Set<String> idSet = null;
            if (labDetail.getTagIds()!=null){
                idSet = new HashSet<String>(Arrays.asList(labDetail.getTagIds().split(TAG_SEPARATOR)));
            }
            Set<String> adminSet =null;
            if (tag.getFkAdminIds()!=null){
                adminSet = new HashSet<String>(Arrays.asList(tag.getFkAdminIds().split(TAG_SEPARATOR)));
            }

            Boolean canSee = Tag.canVisible(tag,idSet,adminSet,labDetail);
            // 不可见的情况
            if (!canSee){
                return MvcResult.CANT_SEE_TAG;
            }
            Boolean canUse = Tag.isUsable(tag,idSet,adminSet,labDetail);
            if (!canUse){
                return MvcResult.CANT_USE_TAG;
            }
            if (Tag.needAppoint(tag)){
                return NEED_APPOINT_TAG;
            }
            if (!Tag.needApply(tag)){
                return CANT_APPLY_TAG;
            }

            List<LabDetail> labDetails = labDetailService.findAllCurLabDetailById(managerIds);

            if (labDetails==null||labDetails.isEmpty()||labDetails.size()!=managerIds.size()){
                return MvcResult.NO_ARGS;
            }
            List<String> names = new LinkedList<>();
            List<String> accounts = new LinkedList<>();

            for (LabDetail n:labDetails
            ) {
                if (!n.getRole().equals(LabRole.ADMIN.getRole())&&!n.getRole().equals(LabRole.OWNER.getRole())){
                    return MvcResult.builder().message("只能选取管理员或者实验室拥有着处理事务申请").code(40300).build();
                }
                names.add(n.getRealName());
                accounts.add(n.getFkAccountName());
            }
            // 可见 可用 无需预约 且需要申请
            if (Tag.needHighManagement(tag)){
                // 校验参数
                Integer selfId = goodsApplicationInsert.getSelfId();
                String pid = goodsApplicationInsert.getPid();
                if (selfId==null||selfId<0||StringUtils.isEmpty(pid)){
                    return  NO_ARGS;
                }
            }
            Application application = Application.builder()
                    .content(content)
                    .fkLabId(labId)
                    .isCancel(false)
                    .title(title)
                    .managerIds(StringUtils.arrayToDelimitedString(managerIds.toArray(),TAG_SEPARATOR))
                    .managerNames(StringUtils.arrayToDelimitedString(names.toArray(),TAG_SEPARATOR))
                    .sponsorId(labDetail.getId())
                    .createTime(new Timestamp(System.currentTimeMillis()))
                    .sponsorName(labDetail.getRealName())
                    .type(ApplicationType.药剂申请.getValue())
                    .isDelete(false)
                    .state(ApplicationState.init.getValue())
                    .build();

            applicationService.saveMaterialApplication(application,goodsApplicationInsert,labDetail);
            sendToManagers(accounts,application);
            return ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    /**
     * 使用仪器申请
     * 前提： 分类不会被修改， 预约默认精细化管理 但不一定要申请
     *
     * 预约表「
     *      预约的仪器名
     *      预约的用户
     *
     * 」
     *
     *
     * 1， 判断分类权限
     *  对当前用户 是否可用 是否可见
     *  a。 需要预约
     *          默认是精细化物品（selfId，pid），
     *          需要申请
     *              生成申请记录，等待审批
     *              审批成功后在预约表中添加记录
     *              移动端或者智能化设备记录使用日志(对于精细化管理的仪器要做是否申请的校验)
     *          不需要申请
     *              直接在预约表中添加记录
     *              移动端或者智能化设备记录使用日志
     *
     *  c。 无需走接口
     *          移动端或者智能化设备记录使用日志(Journal)
     *
     *
     *
     * 使用药剂申请
     *
     *  a   需要申请
     *      *          是精细化物品（selfId，pid） （在精细化层面上添加记录（时间））
     *      *          不是精细化物品 只生成申请记录 （在总览层面上 ）
     *      *          移动端或者智能化设备记录使用日志(对于精细化管理的仪器要做是否申请的校验)
     *  b。 无需走接口
     *      *          移动端或者智能化设备记录使用日志(Journal)
     *
     *     */
    @PostMapping("/instrumentAppoint")
    public MvcResult<Object> instrumentAppoint(@RequestBody InstrumentAppointInsert instrumentAppointInsert,HttpServletRequest request)
    {
        try {
            // 没有做时间校验和实验室人员校验
            ValidateResult validateResult = validatorContext.validate(InstrumentAppointInsert.class,instrumentAppointInsert);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(40300).message(validateResult.getMessage()).build();
            }
            String startTime = instrumentAppointInsert.getStartTime();
            String endTime = instrumentAppointInsert.getEndTime();
            String name = instrumentAppointInsert.getName();
            if (StringUtils.isEmpty(startTime)||StringUtils.isEmpty(endTime)||StringUtils.isEmpty(name)){
                return MvcResult.NO_ARGS;
            }
            Timestamp start = Timestamp.valueOf(startTime);
            Timestamp end = Timestamp.valueOf(endTime);

            Long labId = instrumentAppointInsert.getLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0) {
                log.info("{}",authorizeResult);
                return authorizeResult;
            }
            JwtUtil.TokenMessage tokenMessage = (JwtUtil.TokenMessage) authorizeResult.getData();
            LabDetail labDetail = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
            // 校验完成
            InstrumentSummary instrumentSummary = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,name);
            Instrument instrument = instrumentService.findByLabIdAndPidAndSidNotDelete(labId, instrumentAppointInsert.getPid(), instrumentAppointInsert.getSelfId());

            if (instrumentSummary == null||labDetail==null||instrument==null ){
                return MvcResult.DATA_NULL;
            }
            if (!instrument.getName().equals(instrumentSummary.getName())){
                return MvcResult.ILLEGAL_ARGS;
            }
            Tag tag = tagService.getTag(instrumentSummary.getFkTagId());
            if ( tag ==null){
                return MvcResult.DATA_NULL;
            }

            // 获取人员相关id  idset  表示用户关联的tagId集合 如果tagId 没有包含该id 说明该id 对用户不可见和不可用
            String idSetString = labDetail.getTagIds();
            Set<String> idSet = null;
            if (!StringUtils.isEmpty(idSetString)){
                idSet = new HashSet<String>(Arrays.asList(idSetString.split(TAG_SEPARATOR)));
            }
            // 获取管理员相关id  adminset  表示标签关联的管理员集合 如果管理员是category管理员，则要求它在该tag的管理员列表中
            Set<String> adminSet = null;
            String adminSetString =tag.getFkAdminIds();
            if (!StringUtils.isEmpty(adminSetString)){
                adminSet = new HashSet<String>(Arrays.asList(tag.getFkAdminIds().split(TAG_SEPARATOR)));
            }

            Boolean canSee = Tag.canVisible(tag,idSet,adminSet,labDetail);
            // 不可见的情况
            if (!canSee){
                return MvcResult.CANT_SEE_TAG;
            }
            Boolean canUse = Tag.isUsable(tag,idSet,adminSet,labDetail);
            // 不可用的情况
            if (!canUse){
                return MvcResult.CANT_USE_TAG;
            }

            //该时段是否已经被预约了
            Boolean anyAppointment = applicationService.anyAppointment(labId,instrumentAppointInsert.getPid(), instrumentAppointInsert.getSelfId(), start,end);
//            log.info("{}",anyAppointment);
            if (anyAppointment){
                return MvcResult.builder().code(40300).message("该时间段此仪器已经被预约").build();
            }
            // 在关联用户范围外，可见可用  ｜｜ 在关联用户范围内可见可用
            // 判断是否需要预约
            if (!Tag.needAppoint(tag)){
                return MvcResult.CANT_APPOINT_TAG;
            }
            log.info("tag : {}",tag);
            // 判断需要申请与否
            if (Tag.needApply(tag)){
                if (StringUtils.isEmpty(instrumentAppointInsert.getTitle())){
                    return MvcResult.builder().code(40300).message("参数错误，仪器标题不能为空").build();
                }else if (instrumentAppointInsert.getTitle().length()>255){
                    return MvcResult.builder().code(40300).message("参数错误，仪器标题长度过长").build();
                }
                String content = instrumentAppointInsert.getContent();
                Set<Long> managerIds = instrumentAppointInsert.getManager_ids();
                if (managerIds==null||managerIds.isEmpty()){
                    return MvcResult.NO_ARGS;
                }
                if (managerIds.size()>3){
                    return MvcResult.builder().message("目前仅支持3位审批人").code(20000).build();
                }
                List<LabDetail> labDetails = labDetailService.findAllCurLabDetailById(managerIds);
                if (labDetails==null||labDetails.isEmpty()||labDetails.size()!=managerIds.size()){
                    return MvcResult.NO_ARGS;
                }
                List<String> names = new LinkedList<>();
                List<String> accounts = new LinkedList<>();
                for (LabDetail n:labDetails
                ) {
                    if (!n.getRole().equals(LabRole.ADMIN.getRole())&&!n.getRole().equals(LabRole.OWNER.getRole())){
                        return MvcResult.builder().message("只能选取管理员或者实验室拥有着处理事务申请").code(40300).build();
                    }
                    names.add(n.getRealName());
                    accounts.add(n.getFkAccountName());
                }

                Application application = Application.builder()
                        .content(content)
                        .isCancel(false)
                        .fkLabId(labId)
                        .title(instrumentAppointInsert.getTitle())
                        .managerIds(StringUtils.arrayToDelimitedString(managerIds.toArray(),TAG_SEPARATOR))
                        .managerNames(StringUtils.arrayToDelimitedString(names.toArray(),TAG_SEPARATOR))
                        .sponsorId(labDetail.getId())
                        .sponsorName(labDetail.getRealName())
                        .createTime(new Timestamp(System.currentTimeMillis()))
                        .type(ApplicationType.仪器预约.getValue())
                        .isDelete(false)
                        .state(ApplicationState.init.getValue())
                        .build();
                application=  applicationService.saveAppointment(application,instrumentAppointInsert,labDetail);
                sendToManagers(accounts,application);

            }else {
                applicationService.saveAppointment(instrumentAppointInsert,labDetail);
            }
            return MvcResult.ADD_SUCCESS;
        }catch (IllegalArgumentException illegalArgumentException){
            return MvcResult.ILLEGAL_ARGS;
        }
        catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 添加事务申请
     * */
    @PostMapping("/application")
    public MvcResult<Object> saveApplication(@RequestBody ApplicationInsert applicationInsert, HttpServletRequest request){
        try {
            Long labId  = applicationInsert.getFkLabId();
            Set<Long> managerIds = applicationInsert.getFkManagerIds();
            Long sponsorId = applicationInsert.getSponsorId();
            String type = applicationInsert.getType();
            if (managerIds==null||managerIds.size()==0||sponsorId<=0||labId<=0||StringUtils.isEmpty(type)|| !ApplicationType.isCorrectType(type)){
                return MvcResult.NO_ARGS;
            }
            if (managerIds.size()>3){
                return MvcResult.builder().message("目前仅支持选取3位管理员审批事务").build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveMember(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String content = applicationInsert.getContent();
            List<LabDetail> managers = labDetailService.findAllCurLabDetailByIdAndLabId(managerIds,labId);
            if (managers.size()!=managerIds.size()){
                return MvcResult.builder().message("存在不在该实验室的人员").code(50000).build();
            }
            LabDetail sponsor = labDetailService.findCurLabDetailByIdAndLabIdAndWorkAndNotDelete(sponsorId,labId);
            if (sponsor == null){
                return MvcResult.NO_IN_LAB;
            }
            List<String> names = new LinkedList<>();
            List<String> accounts = new LinkedList<>();
            for (LabDetail n:managers
                 ) {
                if (!n.getRole().equals(LabRole.ADMIN.getRole())&&!n.getRole().equals(LabRole.OWNER.getRole())){
                    return MvcResult.builder().message("只能选取管理员或者实验室拥有着处理事务申请").code(40300).build();
                }
                names.add(n.getRealName());
                accounts.add(n.getFkAccountName());
            }

            Application application = Application.builder()
                    .content(content)
                    .fkLabId(labId)
                    .managerIds(StringUtils.arrayToDelimitedString(managerIds.toArray(),TAG_SEPARATOR))
                    .managerNames(StringUtils.arrayToDelimitedString(names.toArray(),TAG_SEPARATOR))
                    .sponsorId(sponsorId)
                    .sponsorName(sponsor.getRealName())
                    .createTime(new Timestamp(System.currentTimeMillis()))
                    .type(type)
                    .isCancel(false)
                    .title(applicationInsert.getTitle())
                    .isDelete(false)
                    .state(ApplicationState.init.getValue())
                    .build();
            application =applicationService.saveApplicationWithTransactional(application,applicationInsert.getUrls());
            log.info("broadcast to typed admin");
            sendToManagers(accounts,application);
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 添加实验室公告
    * */
    @PostMapping("/notice")
    public MvcResult<Object> addNotice(HttpServletRequest request,@RequestBody NoticeInsert noticeInsert){
        try {
            if (noticeInsert==null){
                return NO_ARGS;
            }
            long labId = noticeInsert.getLabId()==null?0:noticeInsert.getLabId();
            String content = noticeInsert.getContent();
            int priority = noticeInsert.getPriority()==null?0:noticeInsert.getPriority();
            String title = noticeInsert.getTitle();
            String sponsorName = noticeInsert.getSponsorName();
            if (StringUtils.isEmpty(title)||priority<0||labId<=0||StringUtils.isEmpty(sponsorName)){
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            labNoticeService.save(LabNotice.builder()
                                    .content(content)
                                    .createTime(new Timestamp(System.currentTimeMillis()))
                                    .fkLabId(labId)
                                    .priority(priority)
                                    .sponsorName(sponsorName)
                                    .title(title)
                                    .build());
            return ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    /**
     * 增加保藏
     * 没有做重复校验
     * */
    @PostMapping("/prize")
    public MvcResult<Object> addPrize(HttpServletRequest request,@RequestBody PrizeInsert prizeInsert){
        try {
            Long labId = prizeInsert.getLabId();
            String source = prizeInsert.getSource();
            String name = prizeInsert.getName();
            Date date = prizeInsert.getCreate_time()==null?new Date(System.currentTimeMillis()):sdf.parse(prizeInsert.getCreate_time());
            String typeName = prizeInsert.getTypeName()==null?"":prizeInsert.getTypeName();
            if (labId==null||StringUtils.isEmpty(source)||StringUtils.isEmpty(name)){
                return  MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Prize prize = prizeService.save(Prize.builder()
                    .createTime(date)
                    .document(prizeInsert.getDocument())
                    .typeName(typeName)
                    .fkLabId(labId)
                    .name(name)
                    .source(source)
                    .build());
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 添加标签
     * */
    @PostMapping("/category")
    public MvcResult<Object> addCategory(@RequestBody CategoryInsert categoryInsert,HttpServletRequest request){
        try{
            Long labId = categoryInsert.getLabId();
            if (categoryInsert.getName()==null||categoryInsert.getLabId()==null||categoryInsert.getLabId()<=0){
                return  MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
//            List<GoodsType> goodsTypes =  typeService.findAllGoodsTypeByName(categoryInsert.getName());
//            if (goodsTypes!=null&& goodsTypes.get(0)!=null){
//                return MvcResult.builder().code(40327).message("该标签已存在").build();
//            }
            if (typeService.isDuplicateName(categoryInsert.getName(),labId)){
                return MvcResult.builder().code(40327).message("该标签已存在").build();
            }
            typeService.saveGoodsType(GoodsType.builder().typeName(categoryInsert.getName()).createTime(new Date(System.currentTimeMillis())).fkLabId(categoryInsert.getLabId()).build());
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }

    /**
     * 添加项目经费
     * 添加相同的经费名称的经费，经费的金额叠加
     * 项目在生成的时候会有多个经费生成，此接口为单独生成经费信息
     * 可用于 经费增加 （总金额增加，当前金额增加）
     * 或者  经费新增
     * */
    @PostMapping("/fee")
    public MvcResult<Object> createFee(HttpServletRequest request,@RequestBody FeeInsert feeInsert){
        try {
            Long labId = feeInsert.getFkLabId();

            ValidateResult validateResult = validatorContext.validate(FeeInsert.class,feeInsert);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(40300).message(validateResult.getMessage()).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0) {
                return authorizeResult;
            }

            Project project = projectService.findById(feeInsert.getFkProjectId()) ;
            if (project==null){
                return MvcResult.builder().code(40300).message("没有找到所属项目").build();
            }
            Fee feeExist= feeService.findByLabIdAndProjectIdAndName(feeInsert.getFkLabId(), feeInsert.getFkProjectId(),feeInsert.getName());
            if (feeExist!=null){
                feeExist.setCurFee(feeExist.getCurFee()+feeInsert.getTotalFee());
                feeExist.setTotalFee(feeExist.getTotalFee()+feeInsert.getTotalFee());
                feeService.save(feeExist);
            }else {
                feeService.save(Fee.builder()
                        .createTime(new Date())
                        .startTime(sdf.parse(feeInsert.getStartTime()))
                        .endTime(sdf.parse(feeInsert.getEndTime()))
                        .curFee(feeInsert.getTotalFee())
                        .fkLabId(feeInsert.getFkLabId())
                        .fkProjectId(feeInsert.getFkProjectId())
                        .name(feeInsert.getName())
                        .isDelete(false)
                        .projectName(project.getName())
                        .totalFee(feeInsert.getTotalFee())
                        .build());
            }
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 添加分类 是否查出来的列表数量和未差的时候一样
     * 1.权限校验 列表之间重复校验 非法id 校验
     * 2. 将关联管理员的用户身份转为分类管理员，并将id信息保存到分类中
     * 3. 对分类做重命名处理
     * 4. 新增分类更新分类相关用户的分类信息
     * 已经更新校验代码
     * */
    @PostMapping("/tag")
    public MvcResult<Object> createTag(@RequestBody TagInsert tagInsert,HttpServletRequest request){
        try {
            Long labId = tagInsert.getFkLabId();
            if (labId==null||labId<=0||tagInsert.getFkAdminIds()==null||tagInsert.getFkLabDetailIds()==null
                    ||tagInsert.getFkLabDetailIds().size()==0||tagInsert.getFkAdminIds().size()==0){
                return  MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            StringBuilder fkAdminIdsBuilder = new StringBuilder();
            // 查找所有将要成为的分类管理员的实验室成员
            List<LabDetail> labCategories = labDetailService.findAllCurLabDetailById(tagInsert.getFkAdminIds());
            // 校验是否有非法的实验室成员id
            if (labCategories.size()!=tagInsert.getFkAdminIds().size()){
                return  MvcResult.builder().code(40300).message("找不到关联管理员列表中对应实验室成员").build();
            }
            List<LabDetail> labDetails = labDetailService.findAllCurLabDetailById(tagInsert.getFkLabDetailIds());
            if (labDetails.size()!=tagInsert.getFkLabDetailIds().size()){
                return  MvcResult.builder().code(40300).message("找不到关联实验室成员列表中对应实验室成员").build();
            }
            // 允许管理员列表和 实验室人员列表中的id重复
//            AtomicReference<Boolean> duplicate = new AtomicReference<>(false);
//            tagInsert.getFkAdminIds().forEach((e)->{
//                if (tagInsert.getFkLabDetailIds().contains(e)){
//                    duplicate.set(true);
//                }
//            });
//            if(duplicate.get()){
//                return  MvcResult.builder().code(40300).message("关联列表中不能有同一个用户").build();
//            }
            // 设置成员权限
            for (LabDetail l:labCategories
                 ) {
                if (l.getRole().equals(LabRole.MEMBER.getRole())){
                    l.setRole(LabRole.CATEGORY_ADMIN.getRole());
                }
            }
            // 将新的管理员信息转为字符串
            for (Long id:tagInsert.getFkAdminIds()
                 ) {
                fkAdminIdsBuilder.append(id).append(TAG_SEPARATOR);
            }
            String fkAdminIds = fkAdminIdsBuilder.toString();
            // 查看相似的标签名字列表
            List<Tag> tagExist = tagService.findByNameLikeAndFkLabId(labId,tagInsert.getName());
            if (tagExist!=null&&tagExist.size()>0){
//                tagInsert.setName(tagInsert.getName()+"("+tagExist.size()+")");
                tagInsert.setName(tagInsert.getName()+"-"+get8UUID());
            }
            // 配置标签
            tagService.saveWithTransactional(tagInsert,labDetails, labCategories,fkAdminIds,labDetailService);
            return MvcResult.builder().message("添加分类成功").code(20000).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }




    /**
     * 增加采购
     * 1. 按照logistics 的属性 在对应表中进行操作
     * 2。 判断是不是一个新的类别，若是一个新的类别，在对应总览表中增加记录，但是数量为0
     *      若是一个旧的类别，不进行增加记录
     * 3。 扣除相关费用
     * 4。 在采购单中生成记录，设置状态为2 未入库状态
     * */
    @PostMapping("/procurement")
    public MvcResult<Object> saveProcurement(@RequestBody ProcurementInsert procurementInsert, HttpServletRequest request){
        try {


            //采购信息 校验
            if (
//                    procurementInsert.getLabId()==null||procurementInsert.getLabId()<=0
//                    ||StringUtils.isEmpty(procurementInsert.getGoodsName())
//                    ||procurementInsert.getGoodsNum()==null
//                    ||procurementInsert.getGoodsNum()<0
                    procurementInsert.getFkFeeId()==null
                    ||procurementInsert.getFkFeeId()<=0
                    ||StringUtils.isEmpty(procurementInsert.getManagerName())
                    ||procurementInsert.getLogisticsInsert()==null
            ){
                return MvcResult.NO_ARGS;
            }
            //  物流信息校验
            LogisticsInsert logisticsInsert = procurementInsert.getLogisticsInsert();
            ValidateResult validateResult = validatorContext.validate(LogisticsInsert.class,logisticsInsert);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(40335).message(validateResult.getMessage()).build();
            }
            // 权限校验
            Long labId = logisticsInsert.getFkLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            String name = logisticsInsert.getName();
            String unit = logisticsInsert.getUnit();
            Double price = logisticsInsert.getPrice();
            String picture = logisticsInsert.getPicture();
            String brand = logisticsInsert.getBrand();
//            String place = logisticsInsert.getPlace();
            String supplierName = logisticsInsert.getSupplierName();
            String properties = logisticsInsert.getProperties();
            String cas = logisticsInsert.getCas();
            String concentration = logisticsInsert.getConcentration();
            String pid = get8UUID();
            String specifications = logisticsInsert.getSpecifications();

            // 经费合法校验
            Fee fee = feeService.getById(procurementInsert.getFkFeeId());
            if (fee==null){
                return MvcResult.builder().code(40325).message("没有找到对应经费项").build();
            }
            //  资金充足校验
            double totalPrice = price*logisticsInsert.getTotal();
            if (fee.getCurFee()<totalPrice){
                return MvcResult.builder().code(50000).message("资金不足").build();
            }
            InstrumentSummary instrumentSummary ;
            MaterialSummary materialSummary ;
            //  根据采购类型进行不同的采购动作
            if ("INSTRUMENT".equals(properties)){
                // 根据是否已经存在在物品进行不同的采购动作
                instrumentSummary =instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,name);
                if (instrumentSummary!=null){
                    //  若是已存在的采购仪器，在未入库之前，只修改它相关的总览信息中的供应商和
                    instrumentSummary.setSupplierName(supplierName);
                    instrumentSummary.setBrand(brand);
                    // 如果采购是上传了图片地址，则修改它的总览中的图片信息
                    if (!StringUtils.isEmpty(picture)){
                        instrumentSummary.setPicture(picture);
                    }
                }else {
                    // 校验tag 合法性
                    instrumentSummary = new InstrumentSummary();
                    if (logisticsInsert.getFkTagId()!=null){
                        Tag tag;
                        if (logisticsInsert.getFkTagId()<LabTags.values().length){
                            tag = LabTags.values()[logisticsInsert.getFkTagId().intValue()-1].getTag();
                        }else {
                            tag = tagService.getTag(logisticsInsert.getFkTagId());
                        }
                        if (tag==null){
                            return MvcResult.builder().code(40325).message("没有找到对应分类").build();
                        }
                        instrumentSummary.setTagName(tag.getName());
                        instrumentSummary.setFkTagId(tag.getId());
                    }else {
                        return MvcResult.builder().code(40325).message("没有找分类不能为空").build();
                    }
                    // 新增仪器总览

                    instrumentSummary.setCurCount(0);
                    instrumentSummary.setPicture(picture);
                    instrumentSummary.setBrand(brand);
                    instrumentSummary.setSupplierName(supplierName);
                    instrumentSummary.setUnit(unit);
                    instrumentSummary.setFkLabId(labId);
                    instrumentSummary.setSpecifications(specifications);
                    instrumentSummary.setName(name);
                    instrumentSummary.setTypeName(logisticsInsert.getTypeName());
                    instrumentSummary.setRemark(logisticsInsert.getRemark());
                    instrumentSummary.setAttachment(logisticsInsert.getAttachment());
                }
                instrumentSummary.setIsDelete(false);
                // 配置采购  减少相应的资金
                procurementService.addProcurementWithInstrument(procurementInsert,fee,pid,
                                                                labLogisticsService,instrumentSummaryService,feeService,
                                                                instrumentSummary);
            }else if ("MATERIAL".equals(properties)){
                materialSummary = materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId,name);
                if (materialSummary!=null){
                    materialSummary.setSupplierName(supplierName);
                    materialSummary.setBrand(brand);
                    // 如果采购是上传了图片地址，则修改它的总览中的图片信息
                    if (!StringUtils.isEmpty(picture)){
                        materialSummary.setPicture(picture);
                    }
                }else {
                    materialSummary = new MaterialSummary();
                    if (logisticsInsert.getFkTagId()!=null){
                        Tag tag;
                        if (logisticsInsert.getFkTagId()<LabTags.values().length){
                            tag = LabTags.values()[logisticsInsert.getFkTagId().intValue()-1].getTag();
                        }else {
                            tag = tagService.getTag(logisticsInsert.getFkTagId());
                        }
                        if (tag==null){
                            return MvcResult.builder().code(40325).message("没有找到对应分类").build();
                        }
                        materialSummary.setTagName(tag.getName());
                        materialSummary.setFkTagId(tag.getId());
                    }else {
                        return MvcResult.builder().code(40325).message("没有找分类不能为空").build();
                    }

                    materialSummary.setCas(cas);
                    materialSummary.setCurCount(0);
                    materialSummary.setConcentration(concentration);
                    materialSummary.setPicture(picture);
                    materialSummary.setSpecifications(specifications);
                    materialSummary.setBrand(brand);
                    materialSummary.setSupplierName(supplierName);
                    materialSummary.setUnit(unit);
                    materialSummary.setFkLabId(labId);
                    materialSummary.setName(name);
                    materialSummary.setTypeName(logisticsInsert.getTypeName());
                }
                materialSummary.setIsDelete(false);
                procurementService.addProcurementWithMaterial(procurementInsert,fee,pid,
                                                                labLogisticsService,materialSummaryService,feeService,
                                                                materialSummary);
            }else {
                return MvcResult.builder().message("properties 参数不正确").code(50000).build();
            }
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }



    /**
     * 采购的入库
     * */
    @GetMapping("procurementLoad")
    public MvcResult<Object> makeProcurementLoadInRepository(HttpServletRequest request,Long id,Long labId,String properties,String place){
        try {
            //权限校验
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            // 存在性校验
            Procurement p =   procurementService.findById(id);
            if (p==null){
                return MvcResult.DATA_NULL;
            }
            assert p.getFkLogisticsId()!=null;
            // 存在性校验
            Logistics logistics = labLogisticsService.findById(p.getFkLogisticsId());
            if (logistics==null){
                return MvcResult.DATA_NULL;
            }
            // 物流已入库校验
            if (logistics.getState().equals(LabLogistics.EXIST_IN_LAB.getValue())){
                return MvcResult.builder().code(40300).message("该采购订单已经完成入库").build();
            }
            // 如果是仪器入库
            if ("INSTRUMENT".equals(properties)){
                InstrumentSummary i = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,logistics.getName());
                if (i==null){
                    return MvcResult.DATA_NULL;
                }
                // tag 合法性校验
               if (i.getFkTagId()!=null){
                   Tag tag = tagService.getTag(i.getFkTagId());
                   if (tag == null){
                       return MvcResult.DATA_NULL;
                   }
                   if (Tag.needHighManagement(tag)){
                       //  精密型入库
                       procurementService.moveInstrumentToRepository(p,logistics,labLogisticsService,i,instrumentSummaryService,instrumentService,place);
                   }else {
                       //  普通入库x`
                       procurementService.moveInstrumentToRepository(p,logistics,labLogisticsService,i,instrumentSummaryService,null,place);
                   }
               }else {
                   procurementService.moveInstrumentToRepository(p,logistics,labLogisticsService,i,instrumentSummaryService,null,place);
               }
            }else if ("MATERIAL".equals(properties)){
                MaterialSummary m = materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId,logistics.getName());
                if (m==null){
                    return MvcResult.DATA_NULL;
                }
                if (m.getFkTagId()!=null){
                    Tag tag = tagService.getTag(m.getFkTagId());
                    if (tag == null){
                        return MvcResult.DATA_NULL;
                    }
                    if (Tag.needHighManagement(tag)){
                        procurementService.moveMaterialToRepository(p,logistics,labLogisticsService,m,materialSummaryService,materialService,place);
                    }else {
                        procurementService.moveMaterialToRepository(p,logistics,labLogisticsService,m,materialSummaryService,null,place);
                    }
                }else {
                    procurementService.moveMaterialToRepository(p,logistics,labLogisticsService,m,materialSummaryService,null,place);
                }
            }else {
                return MvcResult.NO_ARGS;
            }

            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    //    public MvcResult<Object> addInstrumentList
    //   (@RequestBody List<InstrumentSummary> instrumentSummaries,HttpServletRequest request){
//            CountDownLatch countDownLatch = new CountDownLatch(2);
//            log.info("countDownLatch Size : {}",countDownLatch.getCount());
//            instrumentSummaryService.addInstrumentSummaryListWithTransactional(labId,instrumentSummaries,new Timestamp(System.currentTimeMillis())
//                ,pid,tagService,countDownLatch
//            );
//            CyclicBarrier cyclicBarrier = new CyclicBarrier(n,action);
//            countDownLatch.await();


    // sql事务乐观锁 使用concurrentMap 分类一类开一个线程包含事务 roback可能有bug countdown future cycle Barrier
    // 未测试高并发条件  400~700ms 30条记录
    @PostMapping(value = "/addInstrumentList")
      public void addInstrumentList(@Nullable String defaultTagName, Long labId, HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
//                return ILLEGAL_ARGS;
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().write(JSONObject.toJSONString(authorizeResult));
                return;
            }

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;

            Map<String,MultipartFile> files = multipartRequest.getFileMap();

            if (files.size() != 1) {
                log.info("{}",files.size());
                response.getWriter().write(JSON.toJSONString(ILLEGAL_ARGS));
                return;
            }
            response.setHeader("Content-disposition", "attachment;filename*=utf-8'' 失败记录表.xlsx");
            String pid = get8UUID();
            long startTime=System.nanoTime();   //获取开始时间
            for (MultipartFile file:files.values()
                 ) {
                log.info("{}",file);
                InputStream in = file.getInputStream();
                EasyExcel.read(in, InstrumentSummaryInsert.class,
                        new InstrumentExcelListener(response,tagService,excelUtil,instrumentSummaryService,defaultTagName,labId,pid))
                        .ignoreEmptyRow(true)
                        .sheet().doRead();
            }
            long endTime=System.nanoTime(); //获取结束时间
           log.info("程序运行时间：{} ns",(endTime-startTime));

        }catch (ExcelAnalysisException i){
            i.printStackTrace();
            response.getWriter().write(JSON.toJSONString(ILLEGAL_ARGS));
        }
        catch (Exception e){
            e.printStackTrace();
            response.getWriter().write(JSON.toJSONString(ERROR));
        }
    }


    @PostMapping(value = "/addMaterialList")
    public void addMaterialList(@Nullable String defaultTagName, Long labId, HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
//                return ILLEGAL_ARGS;
                response.setContentType("application/json;charset=utf-8");
                response.getWriter().write(JSONObject.toJSONString(authorizeResult));
                return;
            }

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;

            Map<String,MultipartFile> files = multipartRequest.getFileMap();

            if (files.size() != 1) {
                log.info("{}",files.size());
                response.getWriter().write(JSON.toJSONString(ILLEGAL_ARGS));
                return;
            }
            response.setHeader("Content-disposition", "attachment;filename*=utf-8'' 失败记录表.xlsx");
            String pid = get8UUID();
            long startTime=System.nanoTime();   //获取开始时间
            for (MultipartFile file:files.values()
            ) {
                log.info("{}",file);
                InputStream in = file.getInputStream();
                EasyExcel.read(in, MaterialSummaryInsert.class,
                        new MaterialExcelListener(response,tagService,excelUtil,materialSummaryService,defaultTagName,labId,pid))
                        .ignoreEmptyRow(true)
                        .sheet().doRead();
            }
            long endTime=System.nanoTime(); //获取结束时间
            log.info("程序运行时间：{} ns",(endTime-startTime));
        }catch (ExcelAnalysisException i){
            i.printStackTrace();
            response.getWriter().write(JSON.toJSONString(ILLEGAL_ARGS));
        }
        catch (Exception e){
            e.printStackTrace();
            response.getWriter().write(JSON.toJSONString(ERROR));

        }
    }

    /**
     * 进一批库存
     * 进行插入校验器替换
     * 已经更新校验代码
     * */
    @PostMapping("/logistics")
    public MvcResult<Object> addLogistics(@RequestBody LogisticsInsert logisticsInsert,HttpServletRequest request){

        try {

            // 参数校验
            ValidateResult validateResult = validatorContext.validate(LogisticsInsert.class,logisticsInsert);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().code(40335).message(validateResult.getMessage()).build();
            }

            Long labId = logisticsInsert.getFkLabId();

            String str = logisticsInsert.getDate();

//            Date date = sdf.parse(str);
            Timestamp date;
            if (StringUtils.isEmpty(str)){
                date = new Timestamp(System.currentTimeMillis());
            }else {
              date  = Timestamp.valueOf(str);
            }

            String pid = get8UUID();
            // 权限校验
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }

            // tag 合法性校验
            Tag tag = null;
            if(logisticsInsert.getFkTagId()!=null){
                if (logisticsInsert.getFkTagId()<LabTags.values().length){
                    tag = LabTags.values()[logisticsInsert.getFkTagId().intValue()-1].getTag();
                }else {
                    tag = tagService.getTag(logisticsInsert.getFkTagId());
                }
                if (tag==null){
                    return MvcResult.builder().code(40325).message("没有找到对应标签").build();
                }
            }
               // 2进制转10进制

           labLogisticsService.addLogisticsWithTransactional(logisticsInsert,date,pid,tag,labLogisticsService,instrumentService
                                                            ,materialService,instrumentSummaryService,materialSummaryService);
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 创建实验室课题组
     * 1。 检查token
     * 2。 检查个人权限
     * 3. 新增重命名
     * 已经更新校验代码
     * */
    @PostMapping("/researchGroup")
    public MvcResult<Object> createResearchGroup(@RequestBody ResearchGroupInsert researchGroupInsert,HttpServletRequest request){
        try {
            ValidateResult result = validatorContext.validate(ResearchGroupInsert.class,researchGroupInsert);
            if (!result.getIsOk()){
                return MvcResult.builder().code(40335).message(result.getMessage()).build();
            }
            Long labId = researchGroupInsert.getFkLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<ResearchGroup> researchGroups  = researchGroupService.findAllByLabId(labId);
            int count = 0;
            if (researchGroups!=null&&researchGroups.size()!=0){
                for (ResearchGroup r:researchGroups
                ) {
                    if (r.getName().contains(researchGroupInsert.getName())){
                        count++;
                    }
                }
            }
            ResearchGroup researchGroup = ResearchGroup.builder().build();
            if (count!=0){
                researchGroup.setName(researchGroupInsert.getName()+"—"+get8UUID());
            }else {
                researchGroup.setName(researchGroupInsert.getName());
            }
            researchGroup.setShowForAll(researchGroupInsert.getShowForAll());
            researchGroup.setLeaderName(researchGroupInsert.getLeaderName());
            researchGroup.setIntroduce(researchGroupInsert.getIntroduce());
            researchGroup.setCreateTime(new Date(System.currentTimeMillis()));
            researchGroup.setFkLabId(researchGroupInsert.getFkLabId());
            return MvcResult.builder().message("添加课题组成功").code(20000).data( researchGroupService.save(researchGroup)).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 添加项目
     * 1. 已经添加校验器校验
     * 已经更新校验代码
     * */
    @PostMapping("/project")
    public MvcResult<Object> createProject(HttpServletRequest request,@RequestBody  ProjectInsert projectInsert){
        try {
            //--- 校验代码 写死---- //
            ValidateResult validateResult = validatorContext.validate(ProjectInsert.class,projectInsert);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().message(validateResult.getMessage()).code(40300).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,projectInsert.getLabId(),labDetailService,LabRole.ADMIN,LabRole.OWNER);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            //--- 校验代码 写死---- //

            // 重命名校验
            if (projectService.isNameDuplicate(projectInsert.getName(),projectInsert.getLabId())){
                return MvcResult.builder().message("添加失败，已存在项目名的项目").code(50000).build();
            }

            // 人员参数构造
            StringBuilder leaderString = new StringBuilder();
            StringBuilder memberString = new StringBuilder();
            for (String l:
                 projectInsert.getLeaders()) {
                leaderString.append(l).append(PROJECT_PERSON_SEPARATOR);
            }
            for (String m:
            projectInsert.getMembers()) {
                memberString.append(m).append(PROJECT_PERSON_SEPARATOR);
            }
            // 费用参数构造
            Set<Fee> fees = new HashSet<>();
            if (projectInsert.getFeeInserts()!=null&&projectInsert.getFeeInserts().size()!=0) {
                for (FeeInsert feeInsert : projectInsert.getFeeInserts()
                ) {
                    // 校验费用参数
                    validatorContext.validate(FeeInsert.class, feeInsert);
                    if (!validateResult.getIsOk()) {
                        return MvcResult.builder().message(validateResult.getMessage()).code(40300).build();
                    }
                    fees.add(Fee.builder()
                            .createTime(new Date())
                            .startTime(sdf.parse(feeInsert.getStartTime()))
                            .endTime(sdf.parse(feeInsert.getEndTime()))
                            .curFee(feeInsert.getTotalFee())
                            .fkLabId(feeInsert.getFkLabId())
                            .isDelete(false)
//                            .fkProjectId(feeInsert.getFkProjectId())
                            .name(feeInsert.getName())
//                            .projectName(projectInsert.getName())
                            .totalFee(feeInsert.getTotalFee())
                            .build());
                }
            }
            // 添加项目
            projectService.save(Project.builder()
                                        .createTime(sdf.parse(projectInsert.getCreateTime()))
                                        .fkLabId(projectInsert.getLabId())
                                        .leaders(leaderString.toString())
                                        .members(memberString.toString())
                                        .isDelete(false)
                                        .level(projectInsert.getLevel())
                                        .name(projectInsert.getName())
                                        .type(projectInsert.getType()).build(),feeService,fees);
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * ！！！
     * 批量添加课题组人员
     * 校验是否已经在课题组中
     *  缺少成员是否在实验室的校验
     * */
    @PostMapping("/joinResearchGroup")
    public MvcResult<Object> joinResearchGroup(HttpServletRequest request,@RequestBody ResearchGroupDetailInsert researchGroupDetailInsert){
        try {
            // 缺少人员信息校验
            Long labId = researchGroupDetailInsert.getLabId();
            if (labId==null){
                return MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Long groupId = researchGroupDetailInsert.getGroupId();
            //  检查课题组信息
            ResearchGroup researchGroup = researchGroupService.findById(groupId);
            if (researchGroup == null){
                return  MvcResult.builder().code(40300).message("没有找到对应课题组信息").build();
            }
            Set<Long> groupDetailsId = new HashSet<>();
            List<ResearchGroupDetail> researchGroupDetails = researchGroupService.findAllLabResearchGroupDetailsByGroupId(groupId);
            //          检验成员是否已在课题组中
            if (researchGroupDetails!=null&&researchGroupDetails.size()!=0){
                for (ResearchGroupDetail r:researchGroupDetails
                ) {
                    groupDetailsId.add(r.getFkLabDetailId());
                }
                for (ResearchDetailInsert r:researchGroupDetailInsert.getDetailInserts()
                ) {
                    if (groupDetailsId.contains(r.getId())){
                        return MvcResult.builder().message(r.getName()+"已经在该课题组中").code(40355).build();
                    }
                }
            }
            // 构建新增课题组人员集合
            Set<ResearchGroupDetail> researchGroupDetailSet = new HashSet<>();
            for (ResearchDetailInsert id:researchGroupDetailInsert.getDetailInserts()
            ) {
                researchGroupDetailSet.add(ResearchGroupDetail.builder()
                        .fkLabDetailId(id.getId())
                        .fkResearchGroupId(groupId)
                        .detailName(id.getName())
                        .fkLabId(labId)
                        .groupName(researchGroupDetailInsert.getGroupName())
                        .build());
            }
            researchGroupService.joinLabResearchGroupInBatch(researchGroupDetailSet);
            return MvcResult.builder().code(20000).message("添加课题组人员成功").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 创建实验室
     * 要求
     * 1。 一个人当前只能在一个实验室中
     * 2。 创建实验室默认成为实验室拥有者
     * 3。 设置实验室人员数为1
     * 4。 自动对空实验室简介补全
     * 已经更新校验代码
     * */
    @PostMapping("/")
    public MvcResult<Object> createLab(@RequestBody LabInsert labInsert, HttpServletRequest request){
        try {
            ValidateResult v = validatorContext.validate(LabInsert.class,labInsert);
            if (!v.getIsOk()){
                return MvcResult.builder().code(403020).message(v.getMessage()).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,null,labDetailService,LabRole.NONE);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            JwtUtil.TokenMessage tokenMessage = (JwtUtil.TokenMessage) authorizeResult.getData();
            String accountName = tokenMessage.getUsername();
            if (labDetailService.isInLab(accountName)){
                return  MvcResult.builder().code(40300).message("创建失败，您已经拥有一个一个实验室，请先退出原先的实验室").build();
            }
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("Authentication",request.getHeader("Authentication"));
            HttpEntity<Object> requestEntity = new HttpEntity<>(null, map);
            MvcResult body = restTemplate.exchange("https://keyanplus.com/api/v1/user/getInfo", HttpMethod.GET,requestEntity, MvcResult.class).getBody();
            LinkedHashMap l = (LinkedHashMap)body.getData();
            if (l==null){
                return MvcResult.builder().code(50000).message("创建失败，获取个人信息失败").build();
            }
            Lab lab = new Lab();
            if (labInsert.getInfo()==null){
                lab.setInfo("当前实验室没有设置简介");
            }
            lab.setCount(1);
            lab.setName(labInsert.getName());
            lab.setIsDelete(false);
            lab.setCreateTime(new Date(System.currentTimeMillis()));
            Long labId = labService.saveWithTransactional(lab,accountName,l,tagService,labDetailService);
            restTemplate.exchange(new URI("https://keyanplus.com/api/v1/utils/COS/labDir/"+labId),HttpMethod.POST,null,Void.class);
            return  MvcResult.builder().code(20000).message("创建实验室成功").data(labId).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     *  生成短链接
     *  已经更新校验代码
     * */
    @PostMapping("/inviteUrl")
    public MvcResult<Object> generateInviteUrl(@RequestParam Long labId,@RequestParam Integer hour,HttpServletRequest request){
        MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
        if (authorizeResult.getCode()!=0){
            return authorizeResult;
        }
        if (hour < 1){
            return  MvcResult.builder().code(40300).message("参数错误，生成的链接有效时间不能小于一小时").build();
        }
        //暂时不加动态
        try {
            JwtUtil.TokenMessage tokenMessage = (JwtUtil.TokenMessage) authorizeResult.getData();
            LabDetail host = labDetailService.findByAccountNameAndLabIdAndWorkAndNotDelete(tokenMessage.getUsername(),labId);
            assert host!=null;
            Lab lab = labService.findLabById(labId);
            if (lab== null || lab.getIsDelete()){
                return DATA_NULL;
            }
//            https://keyanplus.com/invite?labId=5&username=吴经纶&labName=给给实验室
            String longUrl = "https://keyanplus.com/invite" + "?labId=" + labId+"&username="
                    +tokenMessage.getUsername()+"&labName="+lab.getName()+"&realName="+ host.getRealName()+"&record="+ host.getRecord();
            log.info(longUrl);
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("longUrl",longUrl);
            map.add("validTimestamp",hour*60*60*1000+"");
//            HttpHeaders httpHeaders = new HttpHeaders();
//            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Object> requestEntity = new HttpEntity<>(map, null);
//            获取短链接
            ShortUrlJson body = restTemplate.exchange(getShortUrlUri, HttpMethod.POST,requestEntity, ShortUrlJson.class).getBody();
//            System.out.println(body);
            assert  body!=null;
//            管理实验室端链接 永久存在 只存最新
//            redisTemplate.opsForValue().set(REDIS_LAB_INVITE_PREFIX+labId,body.getShortUrl());
            return MvcResult.builder().code(20000).message("成功生成邀请链接，有效期"+hour+"小时").data(body.getShortUrl()).build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 实验室添加用户
     * 1。 短链接回调
     * 没有更新校验
     * */
    @PostMapping("/detail")
    public MvcResult<Object> addLabDetail(@RequestBody LabDetail labDetail,HttpServletRequest request){
        JwtUtil.TokenMessage tokenMessage = check(request);
        if (tokenMessage==null){
            return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
        }
        labDetail.setFkAccountName(tokenMessage.getUsername());
        ValidateResult validateResult = labDetailValidator.validate(labDetail,request.getHeader("Authentication"));
        if (!validateResult.getIsOk()){
            return MvcResult.builder().code(40323).message(validateResult.getMessage()).build();
        }
        try {
            Boolean exist = labDetailService.isInLab(tokenMessage.getUsername());
            if (exist){
                return MvcResult.builder().code(40300).message("您已在一个实验室中").build();
            }
            labDetail.setWork(true);
            labDetail.setRole("MEMBER");
            labDetail.setIsDelete(false);
            labDetail.setRealName(tokenMessage.getRealName());
            log.info("add LabDetail:{}",labDetail);
//            获取短链接
            labDetailService.saveWithTransactional(labDetail,labService);
            return MvcResult.ADD_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 修改
     *
     * */



    @PutMapping("/fixMaterialSummary")
    public MvcResult<Object> fixMaterialSummary(@RequestBody MaterialSummaryUpdate materialSummaryUpdate,HttpServletRequest request){
        try {
            if (materialSummaryUpdate.getId()==null||materialSummaryUpdate.getId()<=0
                    ||materialSummaryUpdate.getLabId()==null||materialSummaryUpdate.getLabId()<=0)
            {
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,materialSummaryUpdate.getLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            MaterialSummary materialSummary= materialSummaryService.findMaterialSummaryByIdAndLabIdAndNotDelete(materialSummaryUpdate.getId(),materialSummaryUpdate.getLabId());
            if (materialSummary==null){
                return DATA_NULL;
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getCas())) {
                materialSummary.setCas(materialSummaryUpdate.getCas());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getTypeName())) {
                materialSummary.setTypeName(materialSummaryUpdate.getTypeName());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getBrand())) {
                materialSummary.setBrand(materialSummaryUpdate.getBrand());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getUnit())) {
                materialSummary.setUnit(materialSummaryUpdate.getUnit());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getPicture())) {
                materialSummary.setPicture(materialSummaryUpdate.getPicture());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getSupplierName())) {
                materialSummary.setSupplierName(materialSummaryUpdate.getSupplierName());
            }
            if (materialSummaryUpdate.getTagId()!=null&&materialSummaryUpdate.getTagId()>0) {
                Tag tag = tagService.getTag(materialSummaryUpdate.getId());
                if (tag == null){
                    return  DATA_NULL;
                }
                materialSummary.setTagName(tag.getName());
                materialSummary.setFkTagId(tag.getId());
            }
            if (!StringUtils.isEmpty(materialSummaryUpdate.getConcentration())) {
                materialSummary.setConcentration(materialSummaryUpdate.getConcentration());
            }
            materialSummaryService.save(materialSummary);
            return  FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }



    @PutMapping("/fixInstrumentSummary")
    public MvcResult<Object> fixInstrumentSummary(@RequestBody InstrumentSummaryUpdate instrumentSummaryUpdate,HttpServletRequest request){
        try {
            if (instrumentSummaryUpdate.getId()==null||instrumentSummaryUpdate.getId()<=0
            ||instrumentSummaryUpdate.getLabId()==null||instrumentSummaryUpdate.getLabId()<=0)
            {
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,instrumentSummaryUpdate.getLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            InstrumentSummary instrumentSummary= instrumentSummaryService.findInstrumentSummaryByIdAndLabIdAndNotDelete(instrumentSummaryUpdate.getId(),instrumentSummaryUpdate.getLabId());
            if (instrumentSummary==null){
                return DATA_NULL;
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getTypeName())) {
                instrumentSummary.setTypeName(instrumentSummaryUpdate.getTypeName());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getUnit())) {
                instrumentSummary.setUnit(instrumentSummaryUpdate.getUnit());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getPicture())) {
                instrumentSummary.setPicture(instrumentSummaryUpdate.getPicture());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getSupplierName())) {
                instrumentSummary.setSupplierName(instrumentSummaryUpdate.getSupplierName());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getBrand())) {
                instrumentSummary.setBrand(instrumentSummaryUpdate.getBrand());
            }
            if (instrumentSummaryUpdate.getTagId()!=null&&instrumentSummaryUpdate.getTagId()>0) {
                Tag tag = tagService.getTag(instrumentSummaryUpdate.getTagId());
                if (tag == null){
                    return  DATA_NULL;
                }
                instrumentSummary.setTagName(tag.getName());
                instrumentSummary.setFkTagId(tag.getId());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getRemark())) {
                instrumentSummary.setRemark(instrumentSummaryUpdate.getRemark());
            }
            if (!StringUtils.isEmpty(instrumentSummaryUpdate.getAttachment())) {
                instrumentSummary.setAttachment(instrumentSummaryUpdate.getAttachment());
            }
            instrumentSummaryService.save(instrumentSummary);
            return FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }





    @PutMapping("/project")
    public MvcResult<Object> fixProject(@RequestBody ProjectUpdate projectUpdate,HttpServletRequest request){
        try {
            //--- 校验代码 写死---- //
            ValidateResult validateResult = validatorContext.validate(ProjectUpdate.class,projectUpdate);
            if (!validateResult.getIsOk()){
                return MvcResult.builder().message(validateResult.getMessage()).code(40300).build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,projectUpdate.getLabId(),labDetailService,LabRole.ADMIN,LabRole.OWNER);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            //--- 校验代码 写死---- //

            Project project = projectService.findById(projectUpdate.getId());
            if (project == null){
                return DATA_NULL;
            }


            // 重命名校验
            if(!StringUtils.isEmpty(projectUpdate.getName())){
                if (projectService.isNameDuplicate(projectUpdate.getName(),projectUpdate.getLabId())){
                    return MvcResult.builder().message("修改失败，已存在项目名的项目").code(50000).build();
                }else {
                    project.setName(projectUpdate.getName());
                }
            }

            StringBuilder leaderString = null;
            // 人员参数构造
            if (projectUpdate.getLeaders()!=null){
                leaderString = new StringBuilder();
                for (String l:
                        projectUpdate.getLeaders()) {
                    leaderString.append(l).append(PROJECT_PERSON_SEPARATOR);
                }
            }
            if (leaderString!=null){
                project.setLeaders(leaderString.toString());
            }else {
                project.setLeaders(null);
            }


            StringBuilder memberString = null;
            if (projectUpdate.getMembers()!=null){
                memberString = new StringBuilder();
                for (String m:
                        projectUpdate.getMembers()) {
                    memberString.append(m).append(PROJECT_PERSON_SEPARATOR);
                }
            }
            if (memberString!=null){
                project.setMembers(memberString.toString());
            }else {
                project.setMembers(null);
            }
            if (!StringUtils.isEmpty(projectUpdate.getType())){
                if (ProjectType.isIn(projectUpdate.getType())){
                    project.setType(projectUpdate.getType());
                }
            }
            if (!StringUtils.isEmpty(projectUpdate.getLevel())){
                if (ProjectLevel.isIn(projectUpdate.getLevel())){
                    project.setLevel(projectUpdate.getLevel());
                }
            }
            // 费用参数构造
            Set<Fee> fees = null;
            if (projectUpdate.getFeeInserts()!=null&&projectUpdate.getFeeInserts().size()!=0) {
                fees = new HashSet<>();
                for (FeeInsert feeInsert : projectUpdate.getFeeInserts()
                ) {
                    // 校验费用参数
                    validatorContext.validate(FeeInsert.class, feeInsert);
                    if (!validateResult.getIsOk()) {
                        return MvcResult.builder().message(validateResult.getMessage()).code(40300).build();
                    }
                    fees.add(Fee.builder()
                            .createTime(new Date())
                            .startTime(sdf.parse(feeInsert.getStartTime()))
                            .endTime(sdf.parse(feeInsert.getEndTime()))
                            .curFee(feeInsert.getTotalFee())
                            .fkLabId(feeInsert.getFkLabId())
//                            .fkProjectId(feeInsert.getFkProjectId())
                            .name(feeInsert.getName())
//                            .projectName(projectInsert.getName())
                            .totalFee(feeInsert.getTotalFee())
                            .build());
                }
            }
            List<Fee> feesDeletes = null;
            if (projectUpdate.getFeeDeletes()!=null&&projectUpdate.getFeeDeletes().size()!=0){
               feesDeletes = feeService.findAllById(projectUpdate.getFeeDeletes());
            }
            // 添加项目
            projectService.saveAndDelete(project,feeService,fees,feesDeletes);
            return FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }




    @GetMapping("/application/cancel")
    public MvcResult<Object> cancelApplication(Long applicationId,Long labId,HttpServletRequest request){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }

            if (applicationId<=0){
                return NO_ARGS;
            }
            Application application = applicationService.findById(applicationId);
            if (application==null){
                return DATA_NULL;
            }
            if (!application.getState().equals(ApplicationState.init.getValue())){
                return MvcResult.builder().code(50000).message("无法撤销不是未审批的申请").build();
            }
            applicationService.cancel(application);
            return FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    /**
     * 实验室所有者修改实验室人员权限
     * 1。检查token
     * 2。检查修改对象是否和自己是同一实验室的
     * 3。检查设置的权限是否非法
     * 4. 判断是否为移交所有者请求
     *  a.移交所有者权限，对方成为实验室所有者
     *  b.修改实验室成员权限
     * 6。 检查是否自给自足
     * 没有更新校验代码
     * */
    @PutMapping("/host/roles")
    public MvcResult<Object> updateRole(HttpServletRequest request , @RequestBody RoleMove roleMove){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            List<Long> ids = roleMove.getTargetIds();
            String role = roleMove.getRole();
            if (ids==null||ids.size() == 0){
                return MvcResult.NO_ARGS;
            }
            if (ids.size() > 1 && role.equals(LabRole.OWNER.getRole())){
                return MvcResult.builder().code(40300).message("参数错误，移交所有者权限时只能指定一人").build();
            }
            List<LabDetail> targets = labDetailService.findAllCurLabDetailById(ids);
            if (targets==null|| targets.size()==0){
                return  MvcResult.builder().code(40300).message("没有找到对应用户列表，请查看参数是否正确").build();
            }
            Long targetLabId = targets.get(0).getFkLabId();
//            权限检查
            LabDetail host = labDetailService.findByAccountNameAndLabIdAndWorkAndNotDelete(tokenMessage.getUsername(),targetLabId);
            if (host==null||!host.getRole().equals(LabRole.OWNER.getRole())||!host.getWork()){
                return  MvcResult.builder().code(40300).message("权限异常，只有该实验室的所有者才能调用此接口或您已经不在此实验室").build();
            }
            if (role.equals(LabRole.OWNER.getRole())) {
                Long id = ids.get(0);
                if (host.getId().equals(id)){
                    return MvcResult.builder().message("您已经是实验室拥有者").code(40300).build();
                }
                labDetailService.moveOwner(host.getId(),id);
//                labDetailService.updateRole(id,role);
//                labDetailService.updateRole(host.getId(),LabRole.ADMIN.getRole());
                return MvcResult.builder().message("设置角色成功").code(20000).build();
            }else if (role.equals(LabRole.ADMIN.getRole())
                        ||role.equals(LabRole.CATEGORY_ADMIN.getRole())
                        ||role.equals(LabRole.MEMBER.getRole()))   {
                for (Long id:ids
                     ) {
                    if (id.equals(host.getId())){
                        return MvcResult.builder().message("不能将自己设置为管理员，请将另一位实验室成员设置为拥有者，您会自动降级为管理员").code(40300).build();
                    }
                }
                    labDetailService.updateRoles(ids,role);
                    return MvcResult.builder().message("设置角色成功").code(20000).build();
            } else{
                return MvcResult.builder().message("设置角色失败，角色格式错误").code(40331).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
    * 实验室管理员修改实验室人员权限
    * 1。检查token
    * 2。检查修改对象是否和自己是同一实验室的
    * 3. 检查被设置人的角色是否高于或等于Admin
    * 4。 检查要设置的权限是否高于或等于Admin
    * 5。检查设置的权限是否非法
    * 6。 检查是否自给自足
    * */
    @PutMapping("/admin/roles")
    public MvcResult<Object> updateMemberRole(HttpServletRequest request , @RequestBody RoleMove roleMove){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }

            List<Long> ids = roleMove.getTargetIds();
            String role = roleMove.getRole();
            if (ids==null||ids.size() == 0){
                return MvcResult.builder().code(40300).message("参数错误，列表参数不能为空").build();
            }
            List<LabDetail> targets = labDetailService.findAllCurLabDetailById(ids);
            if (targets==null|| targets.size()==0){
                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确").build();
            }
            Long targetLabId = targets.get(0).getFkLabId();
            LabDetail admin = labDetailService.findByAccountNameAndLabIdAndWorkAndNotDelete(tokenMessage.getUsername(),targetLabId);
            if (admin==null||(!admin.getRole().equals(LabRole.ADMIN.getRole()))||!admin.getWork()){
                return  MvcResult.builder().code(40300).message("权限异常，只有该实验室的管理员才能调用此接口或您已经不在此实验室").build();
            }

            for (LabDetail target:targets
                 ) {
                if (admin.getId().equals(target.getId())){
                    return  MvcResult.builder().code(40300).message("不能对自己执行此操作").build();
                }
                if (LabRole.OWNER.getRole().equals(target.getRole())||LabRole.ADMIN.getRole().equals(target.getRole())){
                    return  MvcResult.builder().code(40300).message("权限不足，无法设置比自己更高的权限的人").build();
                }
                if (LabRole.OWNER.getRole().equals(role)||LabRole.ADMIN.getRole().equals(role)){
                    return  MvcResult.builder().code(40300).message("权限不足，无法设置与自己平级或高于自身的角色").build();
                }else if (LabRole.CATEGORY_ADMIN.getRole().equals(role)||LabRole.MEMBER.getRole().equals(role)){
                    continue;
                }else {
                    return MvcResult.builder().message("设置角色失败，角色格式错误").code(40331).build();
                }
            }
            try {
                labDetailService.updateRoles(ids,role);
                return MvcResult.builder().message("设置角色成功").code(20000).build();
            }catch (Exception e){
                e.printStackTrace();
                return MvcResult.builder().message("设置角色失败，服务器发生异常，请联系客服").code(50006).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
    * 移入历史成员
     * 缺少实验室成员校验
     * 没有更新校验代码
    * */
    @PutMapping("/member/state")
    public MvcResult<Object> updateMemberState(HttpServletRequest request ,@RequestBody LabDetailStateUpdate labDetailStateUpdate){
        try {
            JwtUtil.TokenMessage tokenMessage = check(request);
            if (tokenMessage==null){
                return  MvcResult.builder().code(40300).message("校验失败，请重新获取登录凭证").build();
            }
            List<Long> ids = labDetailStateUpdate.getIds();
            Boolean state = labDetailStateUpdate.getState();
            if (ids==null||ids.size() == 0||state==null){
                return MvcResult.NO_ARGS;
            }

            List<LabDetail> targets = labDetailService.findAllCurLabDetailById(ids);
            if (targets==null|| targets.size()==0){
                return  MvcResult.builder().code(40300).message("没有找到对应用户，请查看参数是否正确").build();
            }
            Long targetLabId = targets.get(0).getFkLabId();
            log.info(targetLabId+"");
            LabDetail admin = labDetailService.findByAccountNameAndLabIdAndWorkAndNotDelete(tokenMessage.getUsername(),targetLabId);

//            log.info("{}",admin);
            if (admin==null||(!admin.getRole().equals(LabRole.ADMIN.getRole())&&!admin.getRole().equals(LabRole.OWNER.getRole()))||!admin.getWork()){
                return  MvcResult.builder().code(40300).message("权限异常，只有该实验室的管理员和所有者才能调用此接口或您已经不在此实验室").build();
            }
            Lab lab  = labService.findLabById(admin.getFkLabId());
            if (lab==null||lab.getIsDelete()){
                return DATA_NULL;
            }

            if (admin.getRole().equals(LabRole.OWNER.getRole())){
                for (LabDetail target:targets
                ) {
                    if (admin.getId().equals(target.getId())){
                        return  MvcResult.builder().code(40300).message("不能对自己执行此操作").build();
                    }
                }
            }else if(admin.getRole().equals(LabRole.ADMIN.getRole())){
                for (LabDetail target:targets
                ) {
                    if (admin.getId().equals(target.getId())){
                        return  MvcResult.builder().code(40300).message("不能对自己执行此操作").build();
                    }
                    if (LabRole.OWNER.getRole().equals(target.getRole())||LabRole.ADMIN.getRole().equals(target.getRole())){
                        return  MvcResult.builder().code(40300).message("权限不足，无法设置比自己更高或平等权限的人").build();
                    }else if (LabRole.MEMBER.getRole().equals(target.getRole())||LabRole.CATEGORY_ADMIN.getRole().equals(target.getRole())){
                        ;
                    }
                    else {
                        return MvcResult.builder().message("移入历史成员失败").code(40331).build();
                    }
                }
            }
            try {
                labDetailService.updateStatesWithTransactional(ids,state,lab,labService);
                return MvcResult.builder().message("移入历史成员成功").code(20000).build();
            }catch (Exception e){
                e.printStackTrace();
                return MvcResult.builder().message("移入历史成员失败，服务器发生异常，请联系客服").code(50006).build();
            }
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    @PutMapping("/notice")
    public MvcResult<Object> fixNotice(@RequestBody LabNotice labNotice,HttpServletRequest request){
        try {
            long labId = labNotice.getFkLabId();
            if (labId <= 0){
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            labNoticeService.update(labNotice);
            return FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    /**
     * 修改标签
     * 缺少标签信息校验
     * 更新校验代码
     * */
    @PutMapping("/category")
    public MvcResult<Object> fixCategory(@RequestBody GoodsType goodsType,HttpServletRequest request){
        try{
            GoodsType goodsTypeExist = typeService.findById(goodsType.getId());
            if (goodsTypeExist==null){
                return  MvcResult.builder().code(40300).message("没有找到对应标签").build();
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,goodsTypeExist.getFkLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<GoodsType> goodsTypes =  typeService.findAllGoodsTypeByName(goodsType.getTypeName());
            if (goodsType.getTypeName()!=null){
                if (goodsTypes.size()==1&&goodsTypes.get(0).equals(goodsType)){
                    goodsTypeExist.setTypeName(goodsType.getTypeName());
                }else {
                    return MvcResult.builder().code(40327).message("该标签已存在").build();
                }
            }
            typeService.saveGoodsType(goodsTypeExist);
            return MvcResult.FIX_SUCCESS;
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }
    /**
     * 修改课题组成员
     *
     * 缺少信息校验
     * 缺少成员是否在实验室的校验
     *
     * 更新校验代码
     * */
    @PutMapping("/researchGroupDetails")
    public MvcResult<Object> updateResearchGroupDetail(@RequestBody ResearchGroupDetailsUpdate researchGroupDetailsUpdate,HttpServletRequest request){
        try{
            Long labId = researchGroupDetailsUpdate.getLabId();
            Long researchId = researchGroupDetailsUpdate.getResearchGroupId();
            if (labId==null||researchId==null){
                return  MvcResult.NO_ARGS;
            }

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            ResearchGroup researchGroup = researchGroupService.findById(researchId);
            if (researchGroup==null){
                return  MvcResult.builder().code(40300).message("没有找到对应课题组").build();
            }
            Set<ResearchGroupDetail> researchGroupDetails = new HashSet<>();
            if (researchGroupDetailsUpdate.getResearchDetailUpdates()==null){
                return  MvcResult.builder().code(40300).message("课题修改人员列表不能为空").build();
            }
            if(researchGroupDetailsUpdate.getResearchDetailUpdates()!=null){
                for (ResearchDetailInsert id:researchGroupDetailsUpdate.getResearchDetailUpdates()
                ) {
                    researchGroupDetails.add(ResearchGroupDetail.builder()
                            .fkLabDetailId(id.getId())
                            .fkResearchGroupId(researchId)
                            .detailName(id.getName())
                            .fkLabId(labId)
                            .groupName(researchGroup.getName())
                            .build());
                }
                researchGroupService.moveLabResearchGroupDetailWithTransactional(researchId,researchGroupDetails);
//                researchGroupService.deleteLabResearchGroupByGroupId(researchId);
//                researchGroupService.joinLabResearchGroupInBatch(researchGroupDetails);
            }
            return MvcResult.builder().code(20000).message("修改课题组人员成功").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 修改分类信息
     * 1. 权限校验
     * 2. 判断分类是否存在
     * 3. 获取分类中已经保存的分类管理员信息，在之后的增加和减少时及时修改里面的信息
     * 4. 添加管理员时更新角色信息，删除管理员时更新角色信息，要求只能是member晋升为category管理员，或者是category管理员变为member
     * 5. 获取修改的关联成员列表，并对成员列表进行分类信息的增加，减少，最后保存分类信息
     * 更新校验代码
     * */
    @PutMapping("/tag")
    public MvcResult<Object> fixTag(HttpServletRequest request, @RequestBody TagUpdate tagUpdate){
        try {
            // 参数校验
            Long labId = tagUpdate.getLabId();
            Long id = tagUpdate.getId();
            if (labId==null||id==null){
                return  MvcResult.NO_ARGS;
            }
            // 权限校验
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            // 默认分类校验
            if (id<=128){
                return  MvcResult.builder().code(40300).message("系统分类不可修改").build();
            }
            // 存在性校验
            Tag tagExist = tagService.getTag(id);
            if (tagExist==null){
                return  MvcResult.builder().code(40300).message("分类不存在").build();
            }
            // 增减列表重复校验
            boolean duplicate = false;
            for (String a:tagUpdate.getAdminAdd()
                 ) {
                if (tagUpdate.getAdminDel().contains(a)){
                    duplicate = true;
                    break;
                }
            }
            if (duplicate){
                return  MvcResult.builder().code(40300).message("分类关联管理员的增删列表中的值不能重复").build();
            }
            for (Long a:tagUpdate.getDetailAdd()
            ) {
                if (tagUpdate.getDetailDel().contains(a)){
                    duplicate = true;
                    break;
                }
            }
            if (duplicate){
                return  MvcResult.builder().code(40300).message("分类关联成员的增删列表中的值不能重复").build();
            }

            // 解析原管理员列表
            Set<String> adminSet = new HashSet<>(Arrays.asList(tagExist.getFkAdminIds().split(TAG_SEPARATOR)));

            Set<LabDetail>  movedLabDetails = new LinkedHashSet<>();


            // 新增管理员信息
            if (tagUpdate.getAdminAdd()!=null&&tagUpdate.getAdminAdd().size()!=0){
                List<Long> labAdminLongs = tagUpdate.getAdminAdd().stream().map(Long::parseLong).collect(Collectors.toList());
                List<LabDetail> labAdmins =labDetailService.findAllCurLabDetailById( labAdminLongs);
                if (labAdmins.size()!=labAdminLongs.size()){
                    return  MvcResult.builder().code(40300).message("新增关联管理员列表中存在不存在的值").build();
                }
                for (LabDetail l:labAdmins
                ) {

                    if (l.getRole().equals(LabRole.MEMBER.getRole())){
                        l.setRole(LabRole.CATEGORY_ADMIN.getRole());
                    }
                }
                movedLabDetails.addAll(labAdmins);
                adminSet.addAll(tagUpdate.getAdminAdd());
//                labDetailService.saveInBatch(labAdmins);
            }
            // 删除管理员信息
            if (tagUpdate.getAdminDel()!=null&&tagUpdate.getAdminDel().size()!=0){
                List<Long> labAdminLongs = tagUpdate.getAdminDel().stream().map(Long::parseLong).collect(Collectors.toList());
                List<LabDetail> labAdmins =labDetailService.findAllCurLabDetailById( labAdminLongs);
                if (labAdmins.size()!=labAdminLongs.size()){
                    return  MvcResult.builder().code(40300).message("删除关联管理员列表中存在不存在的值").build();
                }
                for (LabDetail l:labAdmins
                ) {
                    // 交给查询时懒修改
//                   if (l.getRole().equals(LabRole.CATEGORY_ADMIN.getRole())){
//                       l.setRole(LabRole.MEMBER.getRole());
//                   }
                    if (l.getRole().equals(LabRole.MEMBER.getRole())){
                        return MvcResult.builder().message("删除管理员列表中不能有普通成员").code(50000).build();
                    }
                }
                adminSet.removeAll(tagUpdate.getAdminDel());
                movedLabDetails.addAll(labAdmins);
//                labDetailService.saveInBatch(labAdmins);
            }

//            Set<Long> fixDetails = new HashSet<>();
//            List<LabDetail> labDetails = new LinkedList<>();
            // 新增关联人员信息
            if (tagUpdate.getDetailAdd()!=null&&tagUpdate.getDetailAdd().size()!=0){
                List<LabDetail> detailAdd= labDetailService.findAllCurLabDetailById(tagUpdate.getDetailAdd());
                for (LabDetail l:detailAdd
                ) {
                    Set<String> tempSet  = new HashSet<>(Arrays.asList(l.getTagIds().split(TAG_SEPARATOR)));
                    tempSet.add(id+"");
                    tempSet.remove("");
                    boolean isInMovedLabDetails = false;
                    for (LabDetail m:movedLabDetails
                         ) {
                        if (m.getId().equals(l.getId())){
                            isInMovedLabDetails = true;
                            m.setTagIds(StringUtils.arrayToDelimitedString(tempSet.toArray(), TAG_SEPARATOR));
                        }
                    }
                    if (!isInMovedLabDetails){
                        l.setTagIds(StringUtils.arrayToDelimitedString(tempSet.toArray(), TAG_SEPARATOR));
                        movedLabDetails.add(l);
                    }
                }

            }
            // 删除关联人员信息
            if (tagUpdate.getDetailDel()!=null&&tagUpdate.getDetailDel().size()!=0){
                List<LabDetail> detailDel= labDetailService.findAllCurLabDetailById(tagUpdate.getDetailDel());
                for (LabDetail l:detailDel
                ) {
                    Set<String> tempSet  = new HashSet<>(Arrays.asList(l.getTagIds().split(TAG_SEPARATOR)));
                    tempSet.remove(id+"");
                    tempSet.remove("");
                    boolean isInMovedLabDetails = false;
                    for (LabDetail m:movedLabDetails
                    ) {
                        if (m.getId().equals(l.getId())){
                            isInMovedLabDetails = true;
                            m.setTagIds(StringUtils.arrayToDelimitedString(tempSet.toArray(), TAG_SEPARATOR));
                        }
                    }
                    if (!isInMovedLabDetails){
                        l.setTagIds(StringUtils.arrayToDelimitedString(tempSet.toArray(), TAG_SEPARATOR));
                        movedLabDetails.add(l);
                    }
                }
            }
            // 校验分类信息
            if (tagUpdate.getName()!=null){
                List<Tag> tagList = tagService.getTagsByName(tagUpdate.getName());
                if (tagList==null){
                    tagExist.setName(tagUpdate.getName());
                }
                else {
                    return MvcResult.builder().code(40353).message("该分类名称已存在").build();
                }
            }
            if (tagUpdate.getPermission()!=null){
                tagExist.setPermission(tagUpdate.getPermission());
            }

//            labDetailService.saveInBatch(movedLabDetails);
//            String fkAdminIds = StringUtils.arrayToDelimitedString(adminSet.toArray(), TAG_SEPARATOR);
//            tagExist.setFkAdminIds(fkAdminIds);
//            tagService.save(tagExist);

            // 事务大前提 ： 修改的分类信息中， 管理员的增删 或 实验室人员的增删不会发生重复, 当管理员列表和成员列表重复时， movedLabDetails 中只保留一份LabDetail数据
            // 修改标签关联管理员涉及到 管理员个人信息和标签信息， 修改标签关联用户只涉及个人信息
            String fkAdminIds = StringUtils.arrayToDelimitedString(adminSet.toArray(), TAG_SEPARATOR);
            tagExist.setFkAdminIds(fkAdminIds);
            tagService.saveTagFixWithTransactional(movedLabDetails,tagExist,labDetailService);
            return MvcResult.builder().code(20000).message("修改成功").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }




    /**
     * 修改课题组信息
     * 更新校验代码
     * */
    @PutMapping("researchGroup")
    public MvcResult<Object> updateResearchGroup(HttpServletRequest request , @RequestBody ResearchGroupUpdate researchGroupUpdate){
        try {
            ValidateResult result = validatorContext.validate(ResearchGroupUpdate.class,researchGroupUpdate);
            if (!result.getIsOk()){
                return MvcResult.builder().code(40335).message(result.getMessage()).build();
            }
            Long labId = researchGroupUpdate.getFkLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            Long id  = researchGroupUpdate.getId();
            ResearchGroup researchGroup = researchGroupService.findById(id);
            if (researchGroup==null){
                return MvcResult.DATA_NULL;
            }
            researchGroup.setIntroduce(researchGroupUpdate.getIntroduce());
            researchGroup.setLeaderName(researchGroupUpdate.getLeaderName());
            researchGroup.setShowForAll(researchGroupUpdate.getShowForAll());
            researchGroup.setName(researchGroupUpdate.getName());
            researchGroupService.save(researchGroup);
            return MvcResult.FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 审批所有申请
     * */
    @GetMapping("/approvalApplication")
    public MvcResult<Object> approvalApplication(String applicationState, Long applicationId,  String instruction,HttpServletRequest request){
        try {
            if (applicationId<=0|| !ApplicationState.isCorrectType(applicationState)){
                return MvcResult.NO_ARGS;
            }
            Application application = applicationService.findById(applicationId);
            if (application==null){
                return MvcResult.DATA_NULL;
            }
            if (!application.getState().equals(ApplicationState.init.getValue())){
                return MvcResult.builder().code(50000).message("请勿重复审批").build();
            }
            if (application.getIsCancel()||application.getIsDelete()){
                return MvcResult.builder().code(50000).message("该申请已经被取消或删除").build();
            }
            Long labId = application.getFkLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            JwtUtil.TokenMessage tokenMessage  = (JwtUtil.TokenMessage)authorizeResult.getData();
            String  managerName= tokenMessage.getRealName();
            if (application.getType().equals(ApplicationType.仪器预约.getValue())){

                InstrumentAppointment appointment = applicationService.findByApplicationId(applicationId);
                if (appointment==null){
                    return MvcResult.DATA_NULL;
                }
                String name = appointment.getName();
                InstrumentSummary instrumentSummary = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId,name);
                if (instrumentSummary==null){
                    return MvcResult.DATA_NULL;
                }

                Tag tag = tagService.getTag(instrumentSummary.getFkTagId());
                if (tag==null){
                    return MvcResult.DATA_NULL;
                }
                Set<String> adminSet = new HashSet<>(Arrays.asList(tag.getFkAdminIds().split(TAG_SEPARATOR)));

                LabDetail labDetail = labDetailService.findByAccountNameAndLabId(tokenMessage.getUsername(),labId);
                if (labDetail == null){
                    return MvcResult.DATA_NULL;
                }
                if (labDetail.getRole().equals(LabRole.CATEGORY_ADMIN.getRole())&&!adminSet.contains(labDetail.getId()+"")){
                    return MvcResult.LAB_USER_NO_POWER;
                }
                applicationService.examineApplicationAndAppointment(managerName,ApplicationState.valueOf(applicationState).getValue(),instruction,applicationId,appointment.getId());
            }else if (application.getType().equals(ApplicationType.仪器申请.getValue())){
                InstrumentApplication instrumentApplication = applicationService.findInstrumentApplicationByFkApplicationId(applicationId);
                if (instrumentApplication==null){
                    return DATA_NULL;
                }
                applicationService.examineApplicationAndInstrumentApplication(managerName,applicationState,instruction,applicationId,instrumentApplication.getId());
            }else if (application.getType().equals(ApplicationType.药剂申请.getValue())){
                MaterialApplication materialApplication = applicationService.findMaterialApplicationByFkApplicationId(applicationId);
                if (materialApplication==null){
                    return DATA_NULL;
                }
                applicationService.examineApplicationAndMaterialApplication(managerName,applicationState,instruction,applicationId,materialApplication.getId());
            }
            else if (application.getType().equals(ApplicationType.事假.getValue())
                    ||application.getType().equals(ApplicationType.病假.getValue())
                    ||application.getType().equals(ApplicationType.其他.getValue())){

                applicationService.examineApplication(ApplicationState.valueOf(applicationState).getValue(),instruction,applicationId);
            }else {
                return NO_ARGS;
            }
            return MvcResult.FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    @PutMapping("/fixLabName")
    public MvcResult<Object> fixLabName(Long id,String name,HttpServletRequest request){
        try {
            if (id<=0||name.length()>30){
                return MvcResult.NO_ARGS;
            }
            Lab lab = labService.findLabById(id);
            if (lab==null||lab.getIsDelete()){
                return MvcResult.DATA_NULL;
            }
            if (lab.getName().equals(name)){
                return FIX_SUCCESS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,id,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<Lab> nameDuplicate = labService.findLabsByNameAndNotDelete(name);
            if (!nameDuplicate.isEmpty()){
                return MvcResult.builder().code(50000).message("修改失败,实验室名称已存在").build();
            }
            boolean isSuccess =labService.fixLabName(lab,name);
            if (!isSuccess){
                return MvcResult.builder().code(50000).message("修改失败").build();
            }
            return FIX_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 删除操作
     * */
    @DeleteMapping("/deleteProject")
    public MvcResult<Object> deleteProject(Long id,HttpServletRequest request){
        try {
            if (id<=0){
                return MvcResult.NO_ARGS;
            }
            Project project = projectService.findById(id);
            if (project==null|| project.getIsDelete()){
                return MvcResult.DATA_NULL;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,project.getFkLabId(),labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            boolean isSuccess = projectService.delete(project,feeService);
            if (!isSuccess){
                return MvcResult.builder().code(50000).message("删除失败").build();
            }
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }
    /**
     * 删除申请操作
     */
    @DeleteMapping("/deleteApplication")
    public MvcResult<Object> deleteApplication(Long id,HttpServletRequest request){
        try {
            if (id<=0){
                return MvcResult.NO_ARGS;
            }
            Application application = applicationService.findById(id);
            if (application==null){
                return MvcResult.DATA_NULL;
            }
            Long labId  = application.getFkLabId();
            if (labId==null||labId<=0){
                return MvcResult.DATA_NULL;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            application.setIsDelete(true);
            applicationService.deleteApplication(application);
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }


    /**
     * 删除实验室操作（不是真正的删除）
     * */
    @GetMapping("/del")
    public MvcResult<Object> hideLab(Long labId,HttpServletRequest request){
        try {
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,labId,labDetailService,LabRole.OWNER);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            log.info("···············假设给实验室的其他用户发送解散消息····················");
            Lab lab = labService.findLabById(labId);
            if (lab==null||lab.getIsDelete()){
                return MvcResult.DATA_NULL;
            }
            labService.deleteLabByIdTransactional(lab,labDetailService);
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

    /**
     * 销毁实验室操作
     * 1。缺少敏感操作验证
     * 2。缺少对用户的通知
     * 3。 校验是否为拥有着
     * 4。 先删除detail 再删除lab
     *  更新校验代码
     *  等待修改，不是真正意义上的删除
     * */
//    @Deprecated
//    @DeleteMapping("/fire")
//    public MvcResult<Object> fireLab(HttpServletRequest request,@RequestParam Long labId){
//        try {
//            MvcResult<Object> authorizeResult = labDetailAuthorize.authorize(request,labId,labDetailService,LabRole.OWNER);
//            if (authorizeResult.getCode()!=0){
//                return authorizeResult;
//            }
//            log.info("···············假设给实验室的其他用户发送解散消息····················");
//            List<LabDetail> labDetails = labDetailService.findAllByLabId(labId);
//            if (labDetails==null){
//                labService.deleteLabById(labId);
//                return  MvcResult.builder().code(20000).message("解散成功").build();
//            }
//            labDetailService.deleteAll(labDetails);
//            labService.deleteLabById(labId);
//            return  MvcResult.builder().code(20000).message("解散成功").build();
//        }catch (Exception e){
//            e.printStackTrace();
//            return MvcResult.ERROR;
//        }
//    }



    /**
     * 删除分类
     *  更新校验代码
     * */
    @DeleteMapping("/tags")
    public MvcResult<Object> deleteTag(@RequestBody TagDelete tagDelete,HttpServletRequest request){
        try {
            Long labId = tagDelete.getLabId();
            List<Long> ids = tagDelete.getIds();
            if (labId==null||ids==null||ids.size()==0){
                return  MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveCATEGORYADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            for (Long id:
            ids) {
                if (id<=128){
                    return MvcResult.builder().message("不能删除系统默认分类").code(40355).build();
                }
            }
            List<Tag> tagExists = tagService.getTags(ids,labId);
            if (tagExists==null||tagExists.size()==0||tagExists.size()!=ids.size()){
                return  MvcResult.builder().code(40300).message("分类不存在").build();
            }
//            instrumentSummaryService.RemoveAllTagByFkLabIdAndFkTagIds(labId,ids);
//            materialSummaryService.RemoveAllTagByFkLabIdAndFkTagIds(labId,ids);
//            tagService.delete(tagExists);
            // 实验室成员信息在查的时候懒该更改
            tagService.deleteWithTransactional(tagExists,labId,ids,instrumentSummaryService,materialSummaryService);
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }


    @DeleteMapping("/storage")
    public MvcResult<Object> deleteStorage(Long id,Long labId,HttpServletRequest request){
        try {
            if (id<=0||labId<=0){
                return NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            storageService.deleteById(id);
            return  DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    /**
     * 删除标签
     * 更新校验代码
     * */
    @DeleteMapping("/category")
    public MvcResult<Object> deleteCategory(@RequestBody GoodsType goodsType,HttpServletRequest request){
        try{
            Long labId = goodsType.getFkLabId();
            if (goodsType.getId()==null||goodsType.getFkLabId()==null){
                return  MvcResult.NO_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            typeService.deleteGoodsType(goodsType);
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            return MvcResult.ERROR;
        }
    }

    /**
     * 管理员删除用户
     * */
    private void checkLabDetails( List<LabDetail> labDetails) throws Exception{
        for (LabDetail l: labDetails
        ) {
            if (!l.getRole().equals(LabRole.MEMBER.getRole())){
                throw  new Exception("不能删除管理员和创建者");
            }
        }
    }
    /**
     * 管理员，拥有者批量删除用户
     * 1。 无法删除除了MEMBER身份之外的人员
     * 2。 只允许管理员或者拥有者进行删除
     * 3。 删除的人员不能多于当前实验室人员
     * 4。 删除有身份的用户需要先下了他的权限
     * 5。 是否删除他在实验室对应的记录？
     * 6. 更新实验室人数
     * 更新校验代码
     * */
    @DeleteMapping("/members")
    public MvcResult<Object> deleteDetail(@RequestBody DeleteMembers deleteMembers,HttpServletRequest request){
        List<LabDetail> labDetails = deleteMembers.getLabDetails();
        Long labId  = deleteMembers.getLabId();
        MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
        if (authorizeResult.getCode()!=0){
            return authorizeResult;
        }
        try {
            checkLabDetails(labDetails);
            Lab lab = labService.findLabById(labId);
            if(lab==null){
                return  MvcResult.builder().code(40300).message("删除失败，找不到实验室信息").build();
            }
            if (lab.getCount()<labDetails.size()){
                return  MvcResult.builder().code(40300).message("删除失败，删除人员多于实验室人员").build();
            }
//            labDetailService.deleteAll(labDetails);
//            lab.setCount(lab.getCount()-labDetails.size());
//            labService.save(lab);

            labDetailService.deleteAllInBatchWithTransactional(labDetails,labService,lab);
            log.info("同步删除关联记录");
            if (deleteMembers.getDeleteResearch()){
                log.info("同步删除课题组记录");
            }
            log.info("发送被踢出的通知给其他人");
            return MvcResult.builder().code(20000).message("删除成功").build();
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.builder().code(40333).message(e.getMessage()).build();
        }
    }
    /**
     * 删除课题组
     * 缺少参数校验
     * 更新校验代码
     * */
    @DeleteMapping("/researchGroups")
    public MvcResult<Object> deleteResearchGroupInBatch(@RequestBody ResearchGroupDelete researchGroupDelete,HttpServletRequest request){
        try {
            if (researchGroupDelete.getFkLabId()==null||researchGroupDelete.getFkLabId()==0
                    ||researchGroupDelete.getResearchGroups()==null||researchGroupDelete.getResearchGroups().size()==0){
                return MvcResult.NO_ARGS;
            }
            Long labId = researchGroupDelete.getFkLabId();
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            List<ResearchGroup> list = researchGroupDelete.getResearchGroups();
            researchGroupService.deleteInBatch(list);
            return MvcResult.DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return MvcResult.ERROR;
        }
    }

        @DeleteMapping("/instrumentSummaryWithNames")
    public MvcResult<Object> deleteAllInstrumentSummaryInBatch(String names, Long labId,HttpServletRequest request){

        try {
            if (labId<=0||StringUtils.isEmpty(names)){
                return ILLEGAL_ARGS;
            }

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            instrumentSummaryService.deleteBydLabIdAndNames(labId, CollectionUtils.arrayToList(names.split(",")));
            return DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }


    @DeleteMapping("/materialSummaryWithNames")
    public MvcResult<Object> deleteAllMaterialSummaryInBatch(String names, Long labId,HttpServletRequest request){

        try {
            if (labId<=0||StringUtils.isEmpty(names)){
                return ILLEGAL_ARGS;
            }

            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            materialSummaryService.deleteBydLabIdAndNames(labId, CollectionUtils.arrayToList(names.split(",")));
            return DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }

    @DeleteMapping("/notice")
    public MvcResult<Object> deleteAllNoticeInBatch(@RequestBody NoticeDelete noticeDelete,HttpServletRequest request){

        try {
            long labId = noticeDelete.getLabId();
            if (labId<=0){
                return ILLEGAL_ARGS;
            }
            MvcResult<Object> authorizeResult = labDetailAuthorize.authorizeAboveADMIN(request,labId,labDetailService);
            if (authorizeResult.getCode()!=0){
                return authorizeResult;
            }
            labNoticeService.deleteInBatch(noticeDelete);
            return DEL_SUCCESS;
        }catch (Exception e){
            e.printStackTrace();
            return ERROR;
        }
    }



//    @ExceptionHandler(ExcelAnalysisException.class)
//    public MvcResult<Object> illegalExceptionHandler(HttpServletResponse response,Exception e) {
//        e.printStackTrace();
//        response.setCharacterEncoding("utf-8");
//        response.setHeader("Content-Type","application/json;charset=utf-8");
//        return ILLEGAL_ARGS;
//    }
}
