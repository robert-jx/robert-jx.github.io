package com.yswr.labprovider8003.contants.procurement;

import com.yswr.labprovider8003.contants.logistics.LogisticsInsert;
import lombok.Data;

@Data
public class ProcurementInsert {
//    private Long labId;
//    private String goodsName;
//    private Integer goodsNum;
//    private Double goodsPrice;
    private String create_time;
    private Long fkFeeId;
    private String managerName;
    private LogisticsInsert logisticsInsert;
}
