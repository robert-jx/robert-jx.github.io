package com.yswr.labprovider8003.contants.logistics;

import com.yswr.labprovider8003.entity.Tag;

public enum  LabLogistics {
    EXIST_IN_LAB(1),
    NOT_IN_LAB(2);

    private final Integer value;
    LabLogistics(Integer value){
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
