package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "lab_fee")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Fee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "name")
    private String name;
    @Column(name = "total_fee")
    private Double totalFee;
    @Column(name = "fk_project_id")
    private Long fkProjectId;
    @Column(name = "project_name")
    private String projectName;
    @Column(name = "create_time")
    private Date createTime;
    @Column(name = "start_time")
    private Date startTime;
    @Column(name = "end_time")
    private Date endTime;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "cur_fee")
    private Double curFee;
    @Column(name = "is_delete")
    private Boolean isDelete = false;
}
