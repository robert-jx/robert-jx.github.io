package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface MaterialRepository extends JpaRepository<Material,Long>, JpaSpecificationExecutor<Material> {


    Optional<Material> findByFkLabIdAndFkPidAndSelfId(Long labId,String pid,Integer sid);
    Optional<Material> findByFkLabIdAndFkPidAndSelfIdAndIsDelete(Long labId,String pid,Integer sid,boolean isDelete);

    Optional<List<Material>> findAllByFkLabIdAndFkPid(Long labId,String pid);
    Optional<List<Material>> findAllByFkLabIdAndFkPidAndIsDelete(Long labId,String pid,boolean isDelete);

    Optional<List<Material>> findAllByFkLabId(Long labId);

    Optional<List<Material>> findAllByFkLabIdAndIsDelete(Long labId,boolean isDelete);
//    单表distinct
//    多表group by
//    group by 必须放在 order by 和 limit之前，不然会报错
    @Query(value = "select distinct i.place from Material  as i  where i.name =?1 and i.fkLabId=?2 ")
    List<String> findAllPlaceByNameAndLabId(String name,Long labId);
    @Query(value = "select distinct i.place from Material  as i  where i.name =?1 and i.fkLabId=?2 and i.isDelete = false ")
    List<String> findAllPlaceByNameAndLabIdAndNotDelete(String name,Long labId);

    @Modifying
    @Transactional
    @Query(value = "update Material as l set l.isDelete = true where l.name in ?2 and l.fkLabId = ?1 ")
    void removeAllByFkLabIdAndNames(Long labId,List<String> names);
}
