package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Lab;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LabRepository extends JpaRepository<Lab,Long> {

    List<Lab> findAllByNameAndIsDelete(String name,Boolean isDelete);
}
