package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "lab_notice")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LabNotice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    @Lob
    private String content;
    @Column(name = "create_time")
    private Timestamp createTime;
    @Column(name = "sponsor_name")
    private String sponsorName;
    private Integer priority;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
}
