package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.labdetail.LabDetailQo;
import com.yswr.labprovider8003.contants.labdetail.LabRole;
import com.yswr.labprovider8003.dao.LabDetailRepository;
import com.yswr.labprovider8003.entity.Lab;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

@Service
public class LabDetailService {
    @Resource
    LabDetailRepository labDetailRepository;

    public LabDetail save(LabDetail labDetail){
        return labDetailRepository.save(labDetail);
    }

    @Transactional
    public void saveWithTransactional(LabDetail labDetail,LabService labService){
        Lab lab = labService.findLabById(labDetail.getFkLabId());
        if (lab == null ||lab.getIsDelete())return;
        lab.setCount(lab.getCount()+1);
        labService.save(lab);
        labDetailRepository.save(labDetail);
    }

    public LabDetail findById(Long id){
        return labDetailRepository.findById(id).orElse(null);
    }

    public List<LabDetail> findAllByLabId(Long labId){
        return labDetailRepository.findAllByFkLabIdAndIsDelete(labId,false).orElse(null);
    }
    public List<LabDetail> saveInBatch(Collection<LabDetail> labDetails){
        return labDetailRepository.saveAll(labDetails);
    }
    public LabDetail findByAccountNameAndLabId(String name,Long labId){
       return labDetailRepository.findByFkAccountNameAndFkLabIdAndIsDelete(name,labId,false).orElseThrow(()->new NullPointerException("没有找到实验室成员"));
    }
    public LabDetail findByAccountNameAndLabIdAndWorkAndNotDelete(String name,Long labId){
        return labDetailRepository.findByFkAccountNameAndFkLabIdAndWorkAndIsDelete(name,labId,true,false).orElseThrow(()->new NullPointerException("没有找到实验室成员"));
    }

    public String findCurrentRoleByLabIdAndName(Long labId,String name){
       return labDetailRepository.findCurrentRoleByLabIdAndFkAccountNameAndWorkAndNotDelete(labId, name);
    }



    public Page<LabDetail> findAllByLabIdDynamic(LabDetailQo labDetailQo){
        Long labId = labDetailQo.getLabId();
        Integer index = labDetailQo.getIndex();
        Integer page= labDetailQo.getPageSize();
        List<String> ascProperties = labDetailQo.getAscProperties();
        List<String> descProperties = labDetailQo.getDescProperties();
        List<Sort.Order> orders = new LinkedList<>();
        if (ascProperties!=null){
            for (String p:ascProperties
            ) {
                orders.add(Sort.Order.asc(p));
            }
        }
        if (descProperties!=null){
            for (String p:descProperties
            ) {
                orders.add(Sort.Order.desc(p));
            }
        }

        if (orders.size()==0){
            return labDetailRepository.findAll(LabDetailSpec.findAllWithLabId(labDetailQo),PageRequest.of(index,page));
        }else {
            return labDetailRepository.findAll(LabDetailSpec.findAllWithLabId(labDetailQo),PageRequest.of(index,page, Sort.by(orders)));
        }
    }
    public List<LabDetail> findAllByAccountId(String accountName){
        return labDetailRepository.findAllByFkAccountNameAndWorkAndIsDelete(accountName,true,false).orElse(null);
    }

    public void deleteAll(List<LabDetail> labDetails){
//        绕开缓存
        labDetailRepository.deleteInBatch(labDetails);
    }

    @Transactional
    public void deleteAllInBatchWithTransactional(List<LabDetail> labDetails,LabService labService,Lab lab){
//        绕开缓存
        labDetailRepository.deleteInBatch(labDetails);
        lab.setCount(lab.getCount()-labDetails.size());
        labService.save(lab);
    }
    public Boolean isInLab(String accountName){
        return labDetailRepository.findByFkAccountNameAndWorkAndIsDelete(accountName,true,false).orElse(null)!=null;
    }

    public LabDetail getCurLab(String accountName){
        return labDetailRepository.findByFkAccountNameAndWorkAndIsDelete(accountName,true,false).orElse(null);
    }

    public List<LabDetail> findAllCurLabDetailById(Collection<Long> ids){
        return labDetailRepository.findAllByIdInAndWorkAndIsDelete(ids,true,false).orElse(null);
    }
    public List<LabDetail> findAllCurLabDetailByIdAndLabId(Collection<Long> ids,Long labId){
        return labDetailRepository.findAllByIdInAndWorkAndIsDelete(ids,true,false).orElse(null);
    }
    public LabDetail findCurLabDetailByIdAndLabIdAndWorkAndNotDelete(Long id,Long labId){
        return labDetailRepository.findByIdAndFkLabIdAndWorkAndIsDelete(id,labId,true,false).orElse(null);
    }


    public List<LabDetail> findAllLabDetailNameAndRoleAndIdByLabIdAndWorkAndNotDelete(Long labId){
        return labDetailRepository.findAllIdAndNameAndRoleByLabIdAndWorkAndNotDelete(labId).orElse(null);
    }

    public void updateRole(Long id,String role){
        labDetailRepository.updateLabMemberRole(id,role);
    }
    @Transactional
    public void moveOwner(Long id, Long targetId){

        labDetailRepository.moveOwner(id,targetId);
    }
    public void updateStates(List<Long> ids,Boolean state){
        labDetailRepository.updateLabMemberStates(ids,state);
    }



    @Transactional
    public void updateStatesWithTransactional(List<Long> ids,Boolean state,Lab lab ,LabService labService){
        Integer moveCount = labDetailRepository.updateLabMemberStates(ids,state);
        if (!state){
            lab.setCount(lab.getCount()-moveCount);
        }else {
            lab.setCount(lab.getCount()+moveCount);
        }
        labService.save(lab);
    }

    public void updateRoles(List<Long> ids,String role){
        labDetailRepository.updateLabMemberRoles(ids,role);
    }


    static class LabDetailSpec {
        public static Specification<LabDetail> findAllWithLabId(LabDetailQo qo){

            return (Specification<LabDetail>) (root, query, cb) -> {

                List<Predicate> predicates = new ArrayList<>();
                assert qo.getLabId()!=null;
                predicates.add(cb.equal(root.get("fkLabId"), qo.getLabId()));
                if (qo.getRole()!=null){
                    predicates.add(cb.equal(root.get("role"), qo.getRole()));
                }
                predicates.add(cb.equal(root.get("isDelete"),false));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }

    }
}
