package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;


/**
 * 事务申请
 * 事假
 * 病假
 *
 * 等待添加批示 和   已阅状态
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "application")
@Entity

public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    private String type;
    @Column(name = "manager_ids")
    private String managerIds;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "manager_names")
    private String managerNames;
    @Lob
    private String instruction;
    private String title;
    @Lob
    private String content;
    private String state;
    @Column(name = "sponsor_id")
    private Long sponsorId;
    @Column(name = "sponsor_name")
    private String sponsorName;
    @Column(name = "create_time")
    private Timestamp createTime;
    @Column(name = "is_delete")
    private Boolean isDelete = false;
    @Column(name = "is_cancel")
    private Boolean isCancel = false;
}
