package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.application.*;
import com.yswr.labprovider8003.dao.*;
import com.yswr.labprovider8003.entity.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.*;

/**
 * 事务申请相关服务类
 * */


@Service
@Slf4j
public class ApplicationService {
    @Resource
    ApplicationRepository applicationRepository;
    @Resource
    ApplicationDocumentRepository applicationDocumentRepository;
    @Resource
    InstrumentAppointmentRepository instrumentAppointmentRepository;
    @Resource
    InstrumentApplicationRepository instrumentApplicationRepository;
    @Resource
    MaterialApplicationRepository materialApplicationRepository;

    @Transactional
    public Application saveApplicationWithTransactional(Application application, Set<String> urls){
        application =  applicationRepository.save(application);
        List<ApplicationDocument> applicationDocuments = new LinkedList<>();
        if (urls!=null)
        {
            for (String url: urls
            ) {
                applicationDocuments.add(ApplicationDocument.builder().fkApplicationId(application.getId()).fkLabId(application.getFkLabId()).url(url).build());
            }
            applicationDocumentRepository.saveAll(applicationDocuments);
        }
        return application;
    }

    public InstrumentApplication findInstrumentApplicationByFkApplicationId(Long fk_id){
       return instrumentApplicationRepository.findByFkApplicationId(fk_id).orElse(null);
    }

    public MaterialApplication findMaterialApplicationByFkApplicationId(Long fk_id){
        return materialApplicationRepository.findByFkApplicationId(fk_id).orElse(null);
    }
    public Application saveApplication(Application application){
        return applicationRepository.save(application);
    }

    public void cancel(Application application){
        application.setIsCancel(true);
        if (application.getTitle().equals(ApplicationType.仪器申请.getValue())){
             InstrumentApplication i = instrumentApplicationRepository.findByFkApplicationId(application.getFkLabId()).orElse(null);
              if (i==null){
                  log.info("InstrumentApplication Not Found");
                  return;
              }
              i.setIsCancel(true);
              instrumentApplicationRepository.save(i);
        }else  if (application.getTitle().equals(ApplicationType.药剂申请.getValue())){
            MaterialApplication m = materialApplicationRepository.findByFkApplicationId(application.getFkLabId()).orElse(null);
            if (m==null){
                log.info("MaterialApplication Not Found");
                return;
            }
            m.setIsCancel(true);
            materialApplicationRepository.save(m);
        }else if (application.getTitle().equals(ApplicationType.仪器预约.getValue())){
            InstrumentAppointment i = instrumentAppointmentRepository.findByFkApplicationId(application.getFkLabId()).orElse(null);
            if (i==null){
                log.info("InstrumentAppointment Not Found");
                return;
            }
            i.setIsCancel(true);
            instrumentAppointmentRepository.save(i);
        }else {
            log.info("cancel else ");
        }

        applicationRepository.save(application);

    }

    public void saveAppointment(InstrumentAppointInsert instrumentAppointInsert, LabDetail sponsor){
        String startTime = instrumentAppointInsert.getStartTime();
        String endTime = instrumentAppointInsert.getEndTime();
        Timestamp start = Timestamp.valueOf(startTime);
        Timestamp end = Timestamp.valueOf(endTime);

        log.info("startTime :{} , endTime :{} ",start,end);
        instrumentAppointmentRepository.save(InstrumentAppointment.builder()
                .createTime(new Date(System.currentTimeMillis()))
                .endTime(end)
                .startTime(start)
                .fkLabId(instrumentAppointInsert.getLabId())
                .fkPid(instrumentAppointInsert.getPid())
                .isDelete(false)
                .isFail(false)
                .isSuccess(true)
                .isCancel(false)
                .name(instrumentAppointInsert.getName())
                .selfId(instrumentAppointInsert.getSelfId())
                .sponsorId(sponsor.getId())
                .sponsorName(sponsor.getRealName()).build());
    }
    @Transactional
    public Application saveAppointment(Application application, InstrumentAppointInsert instrumentAppointInsert,LabDetail sponsor){
        String startTime = instrumentAppointInsert.getStartTime();
        String endTime = instrumentAppointInsert.getEndTime();
        Timestamp start = Timestamp.valueOf(startTime);

        Timestamp end = Timestamp.valueOf(endTime);

        log.info("startTime :{} , endTime :{} ",start,end);
        application = applicationRepository.save(application);



        instrumentAppointmentRepository.save(InstrumentAppointment.builder()
                .createTime(new Date(System.currentTimeMillis()))
                .endTime(end)
                .startTime(start)
                .fkApplicationId(application.getId())
                .fkLabId(instrumentAppointInsert.getLabId())
                .fkPid(instrumentAppointInsert.getPid())
                .isDelete(false)
                .isSuccess(false)
                .isFail(false)
                .isCancel(false)
                .name(instrumentAppointInsert.getName())
                .selfId(instrumentAppointInsert.getSelfId())
                .sponsorId(sponsor.getId())
                .sponsorName(application.getSponsorName()).build());

        return application;
    }

    @Transactional
    public void saveInstrumentApplication(Application application, GoodsApplicationInsert goodsApplicationInsert, LabDetail sponsor){

        application = applicationRepository.save(application);
        instrumentApplicationRepository.save(InstrumentApplication.builder()
                .createTime(new Timestamp(System.currentTimeMillis()))
                .fkApplicationId(application.getId())
                .fkLabId(goodsApplicationInsert.getLabId())
                .fkPid(goodsApplicationInsert.getPid())
                .isDelete(false)
                .isFail(false)
                .isSuccess(false)
                .isCancel(false)
                .name(goodsApplicationInsert.getName())
                .selfId(goodsApplicationInsert.getSelfId())
                .sponsorId(sponsor.getId())
                .sponsorName(application.getSponsorName()).build());
    }

    @Transactional
    public void saveMaterialApplication(Application application, GoodsApplicationInsert goodsApplicationInsert, LabDetail sponsor){

        application = applicationRepository.save(application);
        materialApplicationRepository.save(MaterialApplication.builder()
                .createTime(new Timestamp(System.currentTimeMillis()))
                .fkApplicationId(application.getId())
                .fkLabId(goodsApplicationInsert.getLabId())
                .fkPid(goodsApplicationInsert.getPid())
                .isDelete(false)
                .isFail(false)
                .isCancel(false)
                .isSuccess(false)
                .name(goodsApplicationInsert.getName())
                .selfId(goodsApplicationInsert.getSelfId())
                .sponsorId(sponsor.getId())
                .sponsorName(application.getSponsorName()).build());
    }

    @Transactional
    public Integer examineApplicationAndAppointment(String managerName,String state,String instruction,Long applicationId,Long appointmentId){
        if (state.equals(ApplicationState.success.getValue())){
            instrumentAppointmentRepository.successAppointment(appointmentId,managerName);
        }else{
            instrumentAppointmentRepository.failAppointment(appointmentId,managerName);
        }
        return applicationRepository.examineApplication(applicationId,instruction,state);
    }


    @Transactional
    public Integer examineApplicationAndInstrumentApplication(String managerName,String state,String instruction,Long applicationId,Long instrumentApplicationId){
        if (ApplicationState.valueOf(state).equals(ApplicationState.success)){
            instrumentApplicationRepository.successApplication(instrumentApplicationId,managerName);
        }else{
            instrumentApplicationRepository.failApplication(instrumentApplicationId,managerName);
        }
        return applicationRepository.examineApplication(applicationId,instruction,ApplicationState.valueOf(state).getValue());
    }

    @Transactional
    public Integer examineApplicationAndMaterialApplication(String managerName,String state,String instruction,Long applicationId,Long materialApplicationId){
        if (ApplicationState.valueOf(state).equals(ApplicationState.success)){
            materialApplicationRepository.successApplication(materialApplicationId,managerName);
        }else{
            materialApplicationRepository.failApplication(materialApplicationId,managerName);
        }
        return applicationRepository.examineApplication(applicationId,instruction,ApplicationState.valueOf(state).getValue());
    }


    public Boolean anyAppointment(Long labId,String pid,Integer selfId,Timestamp start,Timestamp end){
        long result =instrumentAppointmentRepository.anyAppoint(labId,pid,selfId,start,end);
//        System.out.println(result);
        return result!=0L;
    }

    @Transactional
    public Integer  examineApplication(String state,String instruction,Long id){
      return   applicationRepository.examineApplication(id,instruction,state);
    }

    @Transactional
    public void deleteApplication(Application application){
//         applicationDocumentRepository.deleteAllByFkApplicationId(id);
//         applicationRepository.deleteById(id);
        applicationRepository.save(application);
        instrumentAppointmentRepository.failAppointmentByApplication(application.getId());
//
    }

    public Application findById(Long id){
        return applicationRepository.findById(id).orElse(null);
    }

    public List<InstrumentAppointment> findAllInstrumentAppointment(Long labId){
        return instrumentAppointmentRepository.findAllByFkLabId(labId).orElse(null);
    }
    public InstrumentAppointment findByApplicationId(Long applicationId){
        return instrumentAppointmentRepository.findByFkApplicationId(applicationId).orElse(null);
    }

    public Page<Application> findAllApplicationWithSpec(ApplicationQo applicationQo){
        Integer index = applicationQo.getIndex();
        Integer page = applicationQo.getPageSize();
        List<String> ascProperties = applicationQo.getAscProperties();
        List<String> descProperties = applicationQo.getDescProperties();
        List<Sort.Order> orders = new LinkedList<>();
        if (ascProperties!=null){
            for (String p:ascProperties
            ) {
                orders.add(Sort.Order.asc(p));
            }
        }
        if (descProperties!=null){
            for (String p:descProperties
            ) {
                orders.add(Sort.Order.desc(p));
            }
        }
        if (orders.size()==0){
            return applicationRepository.findAll(ApplicationService.ApplicationSpec.findAllWithApplicationQo(applicationQo), PageRequest.of(index,page));
        }else {
            Sort sort = Sort.by(orders);
            return applicationRepository.findAll(ApplicationService.ApplicationSpec.findAllWithApplicationQo(applicationQo),PageRequest.of(index,page,sort));
        }
    }

    public List<InstrumentAppointment> findAllDynamic(AppointQo appointQo){
        return  instrumentAppointmentRepository.findAll(ApplicationService.AppointSpec.findAllWithAppointQo(appointQo));
    }
    public Page<InstrumentApplication> findAllInstrumentApplicationDynamic(GoodsApplicationQo goodsApplicationQo){
        Integer index = goodsApplicationQo.getIndex();
        Integer page = goodsApplicationQo.getPageSize();
        List<String> ascProperties = goodsApplicationQo.getAscProperties();
        List<String> descProperties = goodsApplicationQo.getDescProperties();
        List<Sort.Order> orders = new LinkedList<>();
        if (ascProperties!=null){
            for (String p:ascProperties
            ) {
                orders.add(Sort.Order.asc(p));
            }
        }
        if (descProperties!=null){
            for (String p:descProperties
            ) {
                orders.add(Sort.Order.desc(p));
            }
        }
        if (orders.size()==0){
            return  instrumentApplicationRepository.findAll(ApplicationService.InstrumentApplicationSpec.findAllWithInstrumentApplicationQo(goodsApplicationQo),PageRequest.of(index,page));
        }else {
            Sort sort = Sort.by(orders);
            return  instrumentApplicationRepository.findAll(ApplicationService.InstrumentApplicationSpec.findAllWithInstrumentApplicationQo(goodsApplicationQo),PageRequest.of(index,page,sort));
        }

    }
    public Page<MaterialApplication> findAllMaterialApplicationDynamic(GoodsApplicationQo goodsApplicationQo){
        Integer index = goodsApplicationQo.getIndex();
        Integer page = goodsApplicationQo.getPageSize();
        List<String> ascProperties = goodsApplicationQo.getAscProperties();
        List<String> descProperties = goodsApplicationQo.getDescProperties();
        List<Sort.Order> orders = new LinkedList<>();
        if (ascProperties!=null){
            for (String p:ascProperties
            ) {
                orders.add(Sort.Order.asc(p));
            }
        }
        if (descProperties!=null){
            for (String p:descProperties
            ) {
                orders.add(Sort.Order.desc(p));
            }
        }
        if (orders.size()==0){
            return  materialApplicationRepository.findAll(ApplicationService.MaterialInstrumentApplicationSpec.findAllWithMaterialApplicationQo(goodsApplicationQo),PageRequest.of(index,page));
        }else {
            Sort sort = Sort.by(orders);
            return  materialApplicationRepository.findAll(ApplicationService.MaterialInstrumentApplicationSpec.findAllWithMaterialApplicationQo(goodsApplicationQo),PageRequest.of(index,page,sort));
        }
    }

    static class InstrumentApplicationSpec {

        protected static Specification<InstrumentApplication> findAllWithInstrumentApplicationQo(GoodsApplicationQo goodsApplicationQo){
            return (Specification<InstrumentApplication>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                // 查询单个Appoint
                if (goodsApplicationQo.getLabId()>0&&!StringUtils.isEmpty(goodsApplicationQo.getPid())&&goodsApplicationQo.getSelfId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),goodsApplicationQo.getLabId()));
                    predicates.add(cb.equal(root.get("fkPid"),goodsApplicationQo.getPid()));
                    predicates.add(cb.equal(root.get("selfId"),goodsApplicationQo.getSelfId()));
                    return cb.and(predicates.toArray(new Predicate[predicates.size()]));
                }
                // 查询某个时间端的Appoint
                if (goodsApplicationQo.getLabId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),goodsApplicationQo.getLabId()));
                }
                if (goodsApplicationQo.getIsSuccess()!=null){
                    predicates.add(cb.equal(root.get("isSuccess"),goodsApplicationQo.getIsSuccess()));
                }
                if (goodsApplicationQo.getIsCancel()!=null){
                    predicates.add(cb.equal(root.get("isCancel"),goodsApplicationQo.getIsCancel()));
                }
                if (goodsApplicationQo.getIsDelete()!=null){
                    predicates.add(cb.equal(root.get("isDelete"),goodsApplicationQo.getIsDelete()));
                }
                if (goodsApplicationQo.getIsFail()!=null){
                    predicates.add(cb.equal(root.get("isFail"),goodsApplicationQo.getIsFail()));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getName())){
                    predicates.add(cb.like(root.get("name"),goodsApplicationQo.getName()+"%"));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getSponsorName())){
                    predicates.add(cb.like(root.get("sponsorName"),goodsApplicationQo.getSponsorName()+"%"));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getManagerName())){
                    predicates.add(cb.like(root.get("managerName"),goodsApplicationQo.getManagerName()+"%"));
                }

                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }



    static class MaterialInstrumentApplicationSpec {

        protected static Specification<MaterialApplication> findAllWithMaterialApplicationQo(GoodsApplicationQo goodsApplicationQo){
            return (Specification<MaterialApplication>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                // 查询单个Appoint
                if (goodsApplicationQo.getLabId()>0&&!StringUtils.isEmpty(goodsApplicationQo.getPid())&&goodsApplicationQo.getSelfId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),goodsApplicationQo.getLabId()));
                    predicates.add(cb.equal(root.get("fkPid"),goodsApplicationQo.getPid()));
                    predicates.add(cb.equal(root.get("selfId"),goodsApplicationQo.getSelfId()));
                    return cb.and(predicates.toArray(new Predicate[predicates.size()]));
                }
                // 查询某个时间端的Appoint
                if (goodsApplicationQo.getLabId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),goodsApplicationQo.getLabId()));
                }
                if (goodsApplicationQo.getIsSuccess()!=null){
                    predicates.add(cb.equal(root.get("isSuccess"),goodsApplicationQo.getIsSuccess()));
                }
                if (goodsApplicationQo.getIsCancel()!=null){
                    predicates.add(cb.equal(root.get("isCancel"),goodsApplicationQo.getIsCancel()));
                }
                if (goodsApplicationQo.getIsDelete()!=null){
                    predicates.add(cb.equal(root.get("isDelete"),goodsApplicationQo.getIsDelete()));
                }
                if (goodsApplicationQo.getIsFail()!=null){
                    predicates.add(cb.equal(root.get("isFail"),goodsApplicationQo.getIsFail()));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getName())){
                    predicates.add(cb.like(root.get("name"),goodsApplicationQo.getName()+"%"));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getSponsorName())){
                    predicates.add(cb.like(root.get("sponsorName"),goodsApplicationQo.getSponsorName()+"%"));
                }
                if (!StringUtils.isEmpty(goodsApplicationQo.getManagerName())){
                    predicates.add(cb.like(root.get("managerName"),goodsApplicationQo.getManagerName()+"%"));
                }
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }


    static class AppointSpec {

        protected static Specification<InstrumentAppointment> findAllWithAppointQo(AppointQo appointQo){
            return (Specification<InstrumentAppointment>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                // 查询单个Appoint
                if (appointQo.getLabId()>0&&!StringUtils.isEmpty(appointQo.getPid())&&appointQo.getSelfId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),appointQo.getLabId()));
                    predicates.add(cb.equal(root.get("fkPid"),appointQo.getPid()));
                    predicates.add(cb.equal(root.get("selfId"),appointQo.getSelfId()));
                    return cb.and(predicates.toArray(new Predicate[predicates.size()]));
                }
                // 查询某个时间端的Appoint
                if (appointQo.getLabId()>0){
                    predicates.add(cb.equal(root.get("fkLabId"),appointQo.getLabId()));
                }
                if (!StringUtils.isEmpty(appointQo.getStartTimeGT())){
                    predicates.add(cb.greaterThanOrEqualTo(root.get("startTime"),Timestamp.valueOf(appointQo.getStartTimeGT())));
                }
                if (!StringUtils.isEmpty(appointQo.getEndTimeGT())){
                    predicates.add(cb.greaterThanOrEqualTo(root.get("endTime"),Timestamp.valueOf(appointQo.getEndTimeGT())));
                }
                if (!StringUtils.isEmpty(appointQo.getStartTimeLT())){
                    predicates.add(cb.lessThanOrEqualTo(root.get("startTime"),Timestamp.valueOf(appointQo.getStartTimeLT())));
                }
                if (!StringUtils.isEmpty(appointQo.getEndTimeLT())){
                    predicates.add(cb.lessThanOrEqualTo(root.get("endTime"),Timestamp.valueOf(appointQo.getEndTimeLT())));
                }
                if (appointQo.getIsSuccess()!=null){
                    predicates.add(cb.equal(root.get("isSuccess"),appointQo.getIsSuccess()));
                }
                if (appointQo.getIsDelete()!=null){
                    predicates.add(cb.equal(root.get("isDelete"),appointQo.getIsDelete()));
                }
                if (appointQo.getIsFail()!=null){
                    predicates.add(cb.equal(root.get("isFail"),appointQo.getIsFail()));
                }
                if (!StringUtils.isEmpty(appointQo.getName())){
                    predicates.add(cb.like(root.get("name"),appointQo.getName()+"%"));
                }
                if (!StringUtils.isEmpty(appointQo.getSponsorName())){
                    predicates.add(cb.like(root.get("sponsorName"),appointQo.getSponsorName()+"%"));
                }
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
    static class ApplicationSpec {

        protected static Specification<Application> findAllWithApplicationQo(ApplicationQo applicationQo){
            return (Specification<Application>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                Long labId = applicationQo.getLabId();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                String type= applicationQo.getType();
                if (!StringUtils.isEmpty(type)){
                    predicates.add(cb.equal(root.get("type"),type));
                }
                String sponsorName= applicationQo.getSponsorName();
                if (!StringUtils.isEmpty(sponsorName)){
                    predicates.add(cb.like(root.get("managerName"),sponsorName+"%"));
                }
                String managerName= applicationQo.getManagerName();
                if (!StringUtils.isEmpty(managerName)){
                    predicates.add(cb.like(root.get("managerName"),managerName+"%"));
                }
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
