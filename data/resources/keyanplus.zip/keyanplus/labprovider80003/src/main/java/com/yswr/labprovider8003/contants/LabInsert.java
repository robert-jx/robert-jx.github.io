package com.yswr.labprovider8003.contants;

import lombok.Data;

@Data
public class LabInsert {
    private String name;
    private String info;
}
