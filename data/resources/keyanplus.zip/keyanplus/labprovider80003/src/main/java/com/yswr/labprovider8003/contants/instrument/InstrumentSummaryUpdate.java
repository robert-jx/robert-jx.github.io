package com.yswr.labprovider8003.contants.instrument;

import com.alibaba.fastjson.JSONObject;
import com.yswr.labprovider8003.contants.material.MaterialSummaryUpdate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class InstrumentSummaryUpdate {
    private Long id;
    private Long labId;
    //标签名称
    private String typeName;

    private String unit;

    private String picture;
    private String supplierName;
    private String brand;

    private Long tagId;

    private String remark;
    private String attachment;
    public static void main(String[] args) {
        System.out.println(
                JSONObject.toJSONString(InstrumentSummaryUpdate.builder()
                        .id(1L)
                        .brand("test")
                        .remark("165426226")


                        .attachment("25")
                        .typeName("科技用品（标签）")
                        .unit("单位：毫升")

                        .labId(5L)
                        .picture("")
                        .supplierName("吴经纶的公司")

                        .tagId(1L)

                        .build())
        );
    }
}
