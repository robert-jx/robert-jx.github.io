package com.yswr.labprovider8003.contants.research_group;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;
@Data
public class ResearchGroupUpdate {
    private Long id;
    private Long fkLabId;
    private String name;
    private String leaderName;
    private Boolean showForAll;
    private String introduce;
}
