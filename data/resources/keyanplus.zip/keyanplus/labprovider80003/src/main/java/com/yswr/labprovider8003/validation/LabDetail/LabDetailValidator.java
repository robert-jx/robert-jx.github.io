package com.yswr.labprovider8003.validation.LabDetail;

import com.yswr.labprovider8003.contants.MvcResult;
import com.yswr.labprovider8003.dao.LabRepository;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.service.LabDetailService;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import org.bouncycastle.cert.ocsp.Req;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;

/**
 * 实验室人员表校验器
 * 1。判断不允许自定义字段
 * 2。校验用户是否存在
 * 3。判断实验室是否存在
 * 4。判断是否已经在实验室中
 * */
@Component
public class LabDetailValidator implements Validator {
    @Resource
    RestTemplate restTemplate;
    @Resource
    LabRepository labRepository;
    @Resource
    LabDetailService labDetailService;
    @Override
    public ValidateResult validate(Object... objects) {
        try {
            LabDetail labDetail = (LabDetail)objects[0];
            String token = objects[1].toString();
            if(labDetail==null||token==null){
                return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
            }
            if (labDetail.getId()!=null){
                return   ValidateResult.builder().isOk(false).message("不能指定ID字段").build();
            }
            if (labDetail.getRole()!=null){
                return   ValidateResult.builder().isOk(false).message("不能指定角色字段").build();
            }
            String url = "https://keyanplus.com/api/v1/user/exist?name=" + labDetail.getFkAccountName();
            MultiValueMap<String,String> multiValueMap = new LinkedMultiValueMap<>();
            multiValueMap.add("Authentication",token);
            HttpEntity<Object> requestEntity = new HttpEntity<>(null, multiValueMap);
            MvcResult body = restTemplate.exchange(new URI(url), HttpMethod.GET,requestEntity, MvcResult.class).getBody();
            assert body!=null;
            if ("false".equals(body.getData())){
                return   ValidateResult.builder().isOk(false).message("该用户尚未注册").build();
            }
            if (!labRepository.existsById(labDetail.getFkLabId())){
                return   ValidateResult.builder().isOk(false).message("没有找到实验室").build();
            }
            if (labDetailService.isInLab(labDetail.getFkAccountName())){
                return   ValidateResult.builder().isOk(false).message("您目前已经在该实验室或其他实验室中，一位用户只能加入一个实验室").build();
            }
            return ValidateResult.builder().isOk(true).build();
        }catch (Exception e){
            e.printStackTrace();
            return ValidateResult.builder().isOk(false).message("服务器错误").build();
        }
    }
}
