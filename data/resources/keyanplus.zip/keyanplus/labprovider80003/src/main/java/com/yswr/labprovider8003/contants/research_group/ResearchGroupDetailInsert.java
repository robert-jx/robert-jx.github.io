package com.yswr.labprovider8003.contants.research_group;


import com.yswr.labprovider8003.contants.labdetail.ResearchDetailInsert;
import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class ResearchGroupDetailInsert {
    Long labId;
    Long groupId;
    String groupName;
    Set<ResearchDetailInsert> detailInserts;
}
