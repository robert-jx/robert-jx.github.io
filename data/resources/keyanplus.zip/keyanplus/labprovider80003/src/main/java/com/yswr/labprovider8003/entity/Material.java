package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "lab_material")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Material {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "name")
    private String name;
    @Column(name = "fk_pid")
    private String fkPid;
    @Column(name = "self_id")
    private Integer selfId;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "cas")
    private String cas;
    @Column(name = "place")
    private String place;
    @Column(name = "create_time")
    private Timestamp createTime;
    @Column(name = "brand")
    private String brand;
    @Column(name = "supplier_name")
    private String supplierName;
    @Column(name = "concentration")
    private String concentration;
    @Column(name = "is_apply")
    private Boolean isApply;
    @Column(name = "alias")
    private String alias;
    @Column(name = "is_delete")
    private Boolean isDelete;
    @Column(name = "specifications")
    private String specifications;

}
