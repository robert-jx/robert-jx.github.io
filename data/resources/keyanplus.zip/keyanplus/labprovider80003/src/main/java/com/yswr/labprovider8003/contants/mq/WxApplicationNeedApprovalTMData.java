package com.yswr.labprovider8003.contants.mq;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WxApplicationNeedApprovalTMData {
    private WxTMDataUnit first;
    private WxTMDataUnit keyword1;
    private WxTMDataUnit keyword2;
    private WxTMDataUnit keyword3;
    private WxTMDataUnit remark;
}
