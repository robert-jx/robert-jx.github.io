package com.yswr.labprovider8003.validation;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Slf4j
public class ValidatorContext {
    Map<Class<?>,Validator>  validatorMap = new ConcurrentHashMap<>();

    public void putValidator(Class<?> clazz ,Validator validator){

        validatorMap.put(clazz,validator);
        log.info(" ValidatorContext put {} : {}",clazz,validator);
    }
    public ValidateResult validate(Class<?> clazz,Object... objects){
        Validator validator = validatorMap.get(clazz);
        if (validator==null){
            return ValidateResult.builder().isOk(false).message("校验失败").build();
        }
        return validator.validate(objects);
    }
}
