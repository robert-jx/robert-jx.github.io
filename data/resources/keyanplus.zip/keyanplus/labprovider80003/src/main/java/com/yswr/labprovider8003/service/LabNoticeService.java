package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.notice.NoticeDelete;
import com.yswr.labprovider8003.dao.LabNoticeRepository;
import com.yswr.labprovider8003.entity.Lab;
import com.yswr.labprovider8003.entity.LabNotice;
import com.yswr.labprovider8003.entity.MaterialSummary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class LabNoticeService {
    @Resource
    LabNoticeRepository labNoticeRepository;


    public LabNotice update(LabNotice labNotice){
        LabNotice labNotice2 = labNoticeRepository.findById(labNotice.getId()).orElse(null);
        if (labNotice2==null){
            return null;
        }
        labNotice2.setContent(labNotice.getContent());
        labNotice2.setPriority(labNotice.getPriority());
        labNotice2.setTitle(labNotice.getTitle());
        return save(labNotice2);
    }


    public LabNotice save(LabNotice labNotice){
        return labNoticeRepository.save(labNotice);
    }

    public void deleteInBatch(NoticeDelete noticeDelete){

        List<LabNotice> list = labNoticeRepository.findAllByIdInAndFkLabId(noticeDelete.getIds(),noticeDelete.getLabId()).orElse(null);
        if (list!=null){
            labNoticeRepository.deleteInBatch(list);
        }
    }

    public Page<LabNotice> findAllByLabIdDynamic(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return labNoticeRepository.findAll(LabNoticeService.LabNoticeSummarySpec.findAllWithLabId(labId), PageRequest.of(index,page));
        }else {
            return labNoticeRepository.findAll(LabNoticeService.LabNoticeSummarySpec.findAllWithLabId(labId),PageRequest.of(index,page,sort));
        }
    }

    static class LabNoticeSummarySpec {

        protected static Specification<LabNotice> findAllWithLabId(Long labId){
            return (Specification<LabNotice>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }


}
