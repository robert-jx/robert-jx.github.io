package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Application;
import com.yswr.labprovider8003.entity.InstrumentAppointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface InstrumentAppointmentRepository extends JpaRepository<InstrumentAppointment,Long>, JpaSpecificationExecutor<InstrumentAppointment> {

    Optional<InstrumentAppointment> findByFkApplicationId(Long applicationId);

    Optional<List<InstrumentAppointment>> findAllByFkLabId(Long labId);

    @Modifying
    @Query("update InstrumentAppointment as i set  i.isSuccess = true , i.managerName = ?2 where i.id = ?1")
    Integer successAppointment(Long id,String managerName);
    @Modifying
    @Query("update InstrumentAppointment as i set  i.isFail = true , i.managerName = ?2  where  i.id = ?1")
    Integer failAppointment(Long id,String managerName);
    @Modifying
    @Query("update InstrumentAppointment as i set  i.isFail = true  where  i.fkApplicationId = ?1")
    Integer failAppointmentByApplication(Long fkApplicationId);

    @Query("select count(i) from InstrumentAppointment as i where i.fkLabId = ?1 and  i.fkPid = ?2 and  i.selfId = ?3 and i.isSuccess = true and " +
            "( (i.startTime >= ?4 and i.startTime <= ?5 )or ( i.endTime <= ?5 and i.endTime >= ?4 )or (i.startTime<=?4 and i.endTime >=?5))")
    Long anyAppoint(Long labId, String pid, Integer sid, Timestamp startTime, Timestamp endTime);
}
