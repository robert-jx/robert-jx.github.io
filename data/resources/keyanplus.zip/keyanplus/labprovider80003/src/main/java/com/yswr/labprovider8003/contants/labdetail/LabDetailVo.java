package com.yswr.labprovider8003.contants.labdetail;

import com.yswr.labprovider8003.entity.LabDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LabDetailVo {
    private List<LabDetail> data;
    private Integer totalPages;
    private Long totalElements;
    private Integer size;
}
