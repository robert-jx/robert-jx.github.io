package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.tags.TagInsert;
import com.yswr.labprovider8003.dao.TagRepository;
import com.yswr.labprovider8003.entity.LabDetail;
import com.yswr.labprovider8003.entity.Logistics;
import com.yswr.labprovider8003.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.util.*;

@Service
public class TagService {
    @Resource
    TagRepository tagRepository;

    public static final String TAG_SEPARATOR = ",";

    public String getPermission(Long tagId)throws  NullPointerException{
        Tag tag=  tagRepository.findById(tagId).orElseThrow(()->new NullPointerException("没有找到对应权限"));
        return tag.getPermission();
    }
    public String getName(Long tagId)throws  NullPointerException{
        Tag tag=  tagRepository.findById(tagId).orElseThrow(()->new NullPointerException("没有找到对应权限"));
        return tag.getName();
    }
    public Tag getTag(Long tagId)throws  NullPointerException{
        return tagRepository.findById(tagId).orElseThrow(()->new NullPointerException("没有找到对应权限"));
    }

    public List<Tag> getTags(List<Long> tagIds ,Long labId)throws  NullPointerException{
        return tagRepository.findAllByIdInAndFkLabId(tagIds,labId).orElseThrow(()->new NullPointerException("没有找到对应权限"));
    }

    public List<Tag> getTagsByName(String name)throws  NullPointerException{
        return tagRepository.findAllByName(name).orElse(null);
    }

    public Page<Tag> findAllByLabIdDynamic(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return tagRepository.findAll(TagService.TagSpec.findAllWithLabId(labId), PageRequest.of(index,page));
        }else {
            return tagRepository.findAll(TagService.TagSpec.findAllWithLabId(labId),PageRequest.of(index,page,sort));
        }
    }

    public List<Tag> findAllByLabId(Long labId){
        return tagRepository.findAllByFkLabId(labId).orElse(null);
    }



    public List<Tag> findByNameLikeAndFkLabId(Long labId,String name){
        return tagRepository.findAllByFkLabIdAndNameLike(labId,name+"%").orElse(null);
    }
    @Transactional
    public void saveTagFixWithTransactional(Collection<LabDetail> labDetails, Tag tag,LabDetailService labDetailService){
        labDetailService.saveInBatch(labDetails);
        tagRepository.save(tag);
    }
    @Transactional
    public void saveWithTransactional(TagInsert tagInsert, List<LabDetail> labDetails, List<LabDetail> labCategories,String labAdminString,LabDetailService labDetailService){

        List<LabDetail> saveLabDetails = new LinkedList<>(labCategories);
        Tag tag =  tagRepository.save(Tag.builder().fkLabId(tagInsert.getFkLabId())
                .fkAdminIds(labAdminString)
                .permission(tagInsert.getPermission())
                .name(tagInsert.getName())
                .build());
        for (LabDetail l : labDetails
        ) {
            String tagIds = l.getTagIds();
            String[] strings = StringUtils.split(tagIds, TAG_SEPARATOR);
            boolean isInLabDetails = false;
            for (LabDetail m:saveLabDetails
                 ) {
                if (m.getId().equals(l.getId())){
                    isInLabDetails = true;
                    if (strings != null) {
                        Set<String> stringSet = new HashSet<>(Arrays.asList(strings));
//                    log.info("before add set : {}",stringSet);
                        stringSet.add(tag.getId() + "");
                        stringSet.remove("");
//                    log.info("after add set : {}",stringSet);

                        String splitSet = StringUtils.arrayToDelimitedString(stringSet.toArray(), TAG_SEPARATOR);

                        m.setTagIds(splitSet);
                    } else {
                        m.setTagIds(tag.getId() + "");
                    }
                }
            }
            if (!isInLabDetails){
                if (strings != null) {
                    Set<String> stringSet = new HashSet<>(Arrays.asList(strings));
//                    log.info("before add set : {}",stringSet);
                    stringSet.add(tag.getId() + "");
                    stringSet.remove("");
//                    log.info("after add set : {}",stringSet);

                    String splitSet = StringUtils.arrayToDelimitedString(stringSet.toArray(), TAG_SEPARATOR);

                    l.setTagIds(splitSet);
                } else {
                    l.setTagIds(tag.getId() + "");
                }
                saveLabDetails.add(l);
            }
        }
//        labDetails.addAll(labCategories);
        labDetailService.saveInBatch(saveLabDetails);
    }

    public void delete(List<Tag> tags){
        tagRepository.deleteInBatch(tags);
    }

    @Transactional
    public void deleteWithTransactional(List<Tag> tags,Long labId,List<Long> ids,InstrumentSummaryService instrumentSummaryService,MaterialSummaryService materialSummaryService){
        instrumentSummaryService.RemoveAllTagByFkLabIdAndFkTagIds(labId,ids);
        materialSummaryService.RemoveAllTagByFkLabIdAndFkTagIds(labId,ids);
        tagRepository.deleteAll(tags);
    }

    public void save(Tag tag){
        tagRepository.save(tag);
    }


    static class TagSpec {

        protected static Specification<Tag> findAllWithLabId(Long labId){
            return (Specification<Tag>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
