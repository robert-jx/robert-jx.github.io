package com.yswr.labprovider8003.validation;

public interface Validator {

     ValidateResult validate(Object ...objects);
}
