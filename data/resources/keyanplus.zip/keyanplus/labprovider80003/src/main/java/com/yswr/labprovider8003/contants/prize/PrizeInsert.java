package com.yswr.labprovider8003.contants.prize;

import lombok.Data;
import org.springframework.util.StringUtils;

import java.util.Set;

@Data
public class PrizeInsert {
    private String name;
    private String source;
    private Long labId;
    private String document;
    private String typeName;
    private String create_time;
}
