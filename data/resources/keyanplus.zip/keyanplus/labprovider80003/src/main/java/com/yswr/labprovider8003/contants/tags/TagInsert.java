package com.yswr.labprovider8003.contants.tags;

import lombok.Data;

import java.util.Set;

@Data
public class TagInsert {
    private String name;
    private String permission;
    private Set<Long> fkAdminIds;
    private Set<Long> fkLabDetailIds;
    private Long fkLabId;
}
