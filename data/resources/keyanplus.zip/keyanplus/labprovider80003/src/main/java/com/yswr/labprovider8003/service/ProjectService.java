package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.fee.FeeInsert;
import com.yswr.labprovider8003.contants.project.ProjectSpecQo;
import com.yswr.labprovider8003.dao.ProjectRepository;
import com.yswr.labprovider8003.entity.Fee;
import com.yswr.labprovider8003.entity.Project;
import com.yswr.labprovider8003.entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

@Service
public class ProjectService {

    @Resource
    ProjectRepository projectRepository;
    public Page<Project> findAllByProjectSpecQo(ProjectSpecQo projectSpecQo, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return projectRepository.findAll(ProjectSpec.findAllWithQo(projectSpecQo), PageRequest.of(index,page));
        }else {
            return projectRepository.findAll(ProjectSpec.findAllWithQo(projectSpecQo),PageRequest.of(index,page,sort));
        }
    }

    public Project findById(Long id){
      return   projectRepository.findById(id).orElse(null);
    }

    public Boolean isNameDuplicate(String name,Long labId){
        return projectRepository.existsByFkLabIdAndNameAndIsDelete(labId,name,false);
    }

//    public Project findByLabIdAndName(Long labId,String name){
//        return projectRepository.findByFkLabIdAndName(labId,name).orElse(null);
//    }

    public List<Project> findAllNameAndLevelAndTypeAndIdByLabId(Long labId){
        return projectRepository.findAllNameAndLevelAndTypeAndIdByLabId(labId);
    }

//    public List<Project> saveInBatch(Set<Project> projects){
//        return projectRepository.saveAll(projects);
//    }
    @Transactional
    public Project save(Project project,FeeService feeService, @Nullable Set<Fee> fees){
        project = projectRepository.save(project);
        if (fees!=null&&fees.size()!=0){
            for (Fee f:fees
            ) {
                f.setFkProjectId(project.getId());
                f.setProjectName(project.getName());
                f.setIsDelete(false);
            }
            feeService.saveInBatch(fees);
        }
        return project;
    }

    @Transactional
    public Project saveAndDelete(Project project,FeeService feeService, @Nullable Set<Fee> fees,@Nullable List<Fee> feesDeletes){
        project = projectRepository.save(project);
        if (feesDeletes!=null&&feesDeletes.size()!=0){
//            feeService.deleteInBatch(feesDeletes);
            for (Fee f:feesDeletes
                 ) {
                f.setIsDelete(true);
            }
            feeService.saveInBatch(feesDeletes);
        }

        if (fees!=null&&fees.size()!=0){
            for (Fee f:fees
            ) {
                f.setFkProjectId(project.getId());
                f.setProjectName(project.getName());
                f.setIsDelete(false);
            }
            feeService.saveInBatch(fees);
        }
        return project;
    }

    @Transactional
    public boolean delete(Project project,FeeService feeService){
        try {
            if (project ==null)
            {
                return false;
            }
            if (project.getIsDelete()){
                return false;
            }
            List<Fee> fees = feeService.findAllByLabIdAndProjectId(project.getFkLabId(), project.getId());
            if (!fees.isEmpty()){
                for (Fee f: fees
                ) {
                    f.setIsDelete(true);
                }
                feeService.saveInBatch(fees);
            }

            project.setIsDelete(true);

            projectRepository.save(project);
            return true;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }


    static class ProjectSpec {
        protected static Specification<Project> findAllWithQo(ProjectSpecQo projectSpecQo){
            return (Specification<Project>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                if (projectSpecQo.getLabId()!=null&&projectSpecQo.getLabId()!=0){
                    predicates.add(cb.equal(root.get("fkLabId"), projectSpecQo.getLabId()));
                }
                if (!StringUtils.isEmpty(projectSpecQo.getName())){
                    predicates.add(cb.like(root.get("name"), projectSpecQo.getName()+"%"));
                }
                if (projectSpecQo.getLevel()!=null&&projectSpecQo.getLevel().size()!=0){
//                    predicates.add(cb.equal(root.get("level"), projectSpecQo.getLevel()));
                    List<Predicate> list = new LinkedList<>();
                    for (String level:projectSpecQo.getLevel()
                         ) {
                        list.add(cb.equal(root.get("level"),level));
                    }
                    predicates.add(cb.or(list.toArray(new Predicate[list.size()])));
                }
                if (projectSpecQo.getType()!=null&&projectSpecQo.getType().size()!=0){
                    List<Predicate> list = new LinkedList<>();
                    for (String type:projectSpecQo.getType()
                    ) {
                        list.add(cb.equal(root.get("type"),type));
                    }
                    predicates.add(cb.or(list.toArray(new Predicate[list.size()])));
                }
                predicates.add(cb.equal(root.get("isDelete"),false));

                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
