package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application,Long>, JpaSpecificationExecutor<Application> {

    @Modifying
    @Query(value = "update  Application as a set  a.state = ?3 ,a.instruction = ?2  where a.id  = ?1")
    Integer examineApplication(Long id,String instruction,String state);


}
