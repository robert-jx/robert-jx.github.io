package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab_detail")
@Entity
public class LabDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "fk_account_name")
    private String fkAccountName;
    private String role;
    @Column(name = "work")
    private Boolean work = true;

    @Column(name = "record")
    private String record;
    @Column(name = "real_name")
    private String realName;
    @Column(name = "tag_ids")
    private String tagIds ;
    @Column(name = "create_time")
    private Date createTime = new Date();
    @Column(name = "is_delete")
    private Boolean isDelete = false;
    @Transient
    private List<Tag> tags;
}
