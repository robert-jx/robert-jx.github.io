package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.logistics.LabLogistics;
import com.yswr.labprovider8003.contants.logistics.LogisticsInsert;
import com.yswr.labprovider8003.contants.tags.LabTags;
import com.yswr.labprovider8003.dao.LogisticsRepository;
import com.yswr.labprovider8003.entity.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Log4j2
public class LabLogisticsService {
    @Resource
    LogisticsRepository logisticsRepository;

    public List<Logistics>  addLogisticsInBatch(List<Logistics> logistics){
        return  logisticsRepository.saveAll(logistics);
    }






























    public Logistics  addLogistics(Logistics logistic){
        return  logisticsRepository.save(logistic);
    }



























    @Transactional
    public void addLogisticsWithTransactional(LogisticsInsert logisticsInsert, Timestamp date, String pid, Tag tag,
                                              LabLogisticsService labLogisticsService, InstrumentService instrumentService, MaterialService materialService,
                                              InstrumentSummaryService instrumentSummaryService, MaterialSummaryService materialSummaryService){
        Long labId = logisticsInsert.getFkLabId();
        String name = logisticsInsert.getName();
        String detail = logisticsInsert.getUnit();
        Double price = logisticsInsert.getPrice();
        String picture = logisticsInsert.getPicture();
        String brand = logisticsInsert.getBrand();
        String place = logisticsInsert.getPlace();
        String supplierName = logisticsInsert.getSupplierName();
        String properties = logisticsInsert.getProperties();

        Logistics logistics = labLogisticsService.addLogistics(Logistics.builder()
                    .price(price)
                    .name(name)
                    .createTime(date)
                    .place(place)
                    .pid(pid)
                    .state(LabLogistics.EXIST_IN_LAB.getValue())
                    .brand(brand)

                    .supplierName(supplierName)
                    .total(logisticsInsert.getTotal())
                    .fkLabId(labId)
                    .properties(properties)
                    .build());
        switch (properties) {
            case "INSTRUMENT": {
                InstrumentSummary instrumentSummary = instrumentSummaryService.findInstrumentSummaryByLabIdAndNameAndNotDelete(labId, name);
                int num = instrumentSummary==null?0:instrumentSummary.getCurCount();
                if (tag!=null&&Tag.needHighManagement(tag)) {
                    List<Instrument> instruments = new LinkedList<>();
                    for (int i = 1; i <= logistics.getTotal(); i++) {
                        instruments.add(Instrument.builder()
                                .name(name)
                                .fkPid(pid)
                                .fkLabId(labId)
                                .selfId(i)
                                .isDelete(false)
                                .place(place)
                                .isApply(false)
                                .alias(name+"-"+(num+i))
                                .specifications(logisticsInsert.getSpecifications())
                                .brand(brand)
                                .supplierName(supplierName)
                                .createTime(date)
                                .specifications(logisticsInsert.getSpecifications())
                                .remark(logisticsInsert.getRemark())
                                .build()
                        );
                    }
                    instrumentService.saveInBatch(instruments);
                }

                if (instrumentSummary == null) {
                    instrumentSummary = new InstrumentSummary();
                    instrumentSummary.setCurCount(logistics.getTotal());

                    instrumentSummary.setFkLabId(labId);
                    instrumentSummary.setPlace(place);
                    instrumentSummary.setIsDelete(false);
                    instrumentSummary.setName(name);
                    if (tag!=null){
                        instrumentSummary.setTagName(tag.getName());
                        instrumentSummary.setFkTagId(tag.getId());
                    }
                    instrumentSummary.setPicture(picture);
                    instrumentSummary.setBrand(brand);
                    instrumentSummary.setSupplierName(supplierName);
                    instrumentSummary.setSpecifications(logisticsInsert.getSpecifications());
                    instrumentSummary.setUnit(detail);
                    instrumentSummary.setTypeName(logisticsInsert.getTypeName());
                    instrumentSummary.setRemark(logisticsInsert.getRemark());
                    instrumentSummary.setAttachment(logisticsInsert.getAttachment());
                } else {
                    instrumentSummary.setCurCount(instrumentSummary.getCurCount() + logistics.getTotal());
                    String []places = instrumentSummary.getPlace()==null?null:instrumentSummary.getPlace().split(",");
                    String splitSet = null;
                    if (places!=null&&!StringUtils.isEmpty(place)){
                        Set<String> stringSet = new HashSet<>(Arrays.asList(places));
                        if (place!=null){
                            stringSet.add(place);
                        }
                        splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");

                    }
                    if (splitSet!=null){
                        instrumentSummary.setPlace(splitSet);
                    }else {
                        if (!StringUtils.isEmpty(place)){
                            instrumentSummary.setPlace(place);
                        }
                    }
                }
                instrumentSummaryService.save(instrumentSummary);
                break;
            }
            case "MATERIAL": {
                MaterialSummary materialSummary = materialSummaryService.findMaterialSummaryByLabIdAndNameNotDelete(labId, name);

                int num = materialSummary==null?0:materialSummary.getCurCount();
                if (tag!=null&&Tag.needHighManagement(tag)) {
//                    log.info("needHighManagement,num is :{}",logistics);
                    List<Material> materials = new LinkedList<>();
                    for (int i = 1; i <= logistics.getTotal(); i++) {
                        materials.add(Material.builder()
                                .name(name)
                                .fkPid(pid)
                                .fkLabId(labId)
                                .brand(brand)
                                .alias(name+"-"+(num+i))
                                .supplierName(supplierName)
                                .createTime(date)
                                .selfId(i)
                                .isApply(false)
                                .isDelete(false)
                                .specifications(logisticsInsert.getSpecifications())
                                .place(place)
                                .cas(logisticsInsert.getCas())
                                .concentration(logisticsInsert.getConcentration())
                                .build());
                    }
//                    log.info("materials,num is :{}",materials.size());
                    materialService.saveInBatch(materials);
                }

                String cas = logisticsInsert.getCas();
                String concentration = logisticsInsert.getConcentration();
                if (materialSummary == null) {
                    materialSummary = new MaterialSummary();
                    materialSummary.setCurCount(logistics.getTotal());
                    materialSummary.setCas(cas);
                    materialSummary.setPicture(picture);
                    materialSummary.setBrand(brand);
                    materialSummary.setSupplierName(supplierName);
                    materialSummary.setUnit(detail);
                    materialSummary.setName(name);
                    materialSummary.setSpecifications(materialSummary.getSpecifications());
                    materialSummary.setFkLabId(labId);
                    materialSummary.setIsDelete(false);
                    materialSummary.setConcentration(concentration);
                    if (tag!=null){
                        materialSummary.setTagName(tag.getName());
                        materialSummary.setFkTagId(tag.getId());
                    }
                    materialSummary.setTypeName(logisticsInsert.getTypeName());
                } else {
                    materialSummary.setCurCount(materialSummary.getCurCount() + logistics.getTotal());
                }



                String []places = materialSummary.getPlace()==null?null:materialSummary.getPlace().split(",");
                String splitSet = null;
                if (places!=null&&!StringUtils.isEmpty(place)){
                    Set<String> stringSet = new HashSet<>(Arrays.asList(places));
                        stringSet.add(place);
                    splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");

                }
                if (splitSet!=null){
                    materialSummary.setPlace(splitSet);
                }else {
                    if (!StringUtils.isEmpty(place)){
                        materialSummary.setPlace(place);
                    }
                }

                materialSummaryService.save(materialSummary);
                break;
            }
            default:
                ;
        }

    }




    public Logistics  findById(Long id){
        return  logisticsRepository.findById(id).orElse(null);
    }
    public Page<Logistics> findAllByLabIdDynamic(boolean isInLab,Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return logisticsRepository.findAll(LabLogisticsService.LogisticsSpec.findAllWithLabId(labId,isInLab), PageRequest.of(index,page));
        }else {
            return logisticsRepository.findAll(LabLogisticsService.LogisticsSpec.findAllWithLabId(labId,isInLab),PageRequest.of(index,page,sort));
        }
    }

    static class LogisticsSpec {

        protected static Specification<Logistics> findAllWithLabId(Long labId,boolean isInLab){
            return (Specification<Logistics>) (root, query, cb) -> {
                List<Predicate> predicates = new ArrayList<>();
                predicates.add(cb.equal(root.get("fkLabId"), labId));
                if (isInLab){
                    predicates.add(cb.isNotNull(root.get("createTime")));
                }else {
                    predicates.add(cb.isNull(root.get("createTime")));
                }
                return cb.and(predicates.toArray(new Predicate[predicates.size()]));
            };
        }
    }
}
