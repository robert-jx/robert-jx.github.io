package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "lab_prize")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Prize {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "source")
    private String source;
    @Column(name = "type_name")
    private String typeName;
    @Column(name = "document")
    private String document;
    @Column(name = "create_time")
    private Date createTime;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    @Column(name = "name")
    private String name;
}
