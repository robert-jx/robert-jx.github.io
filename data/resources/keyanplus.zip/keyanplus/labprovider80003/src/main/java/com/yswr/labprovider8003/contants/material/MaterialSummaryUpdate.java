package com.yswr.labprovider8003.contants.material;

import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MaterialSummaryUpdate {
    private Long id;
    private Long labId;
    private Long tagId;
    private String cas;
    private String typeName;
    private String brand;
    private String unit;
    private String picture;
    private String supplierName;
    private String concentration;

    public static void main(String[] args) {
        System.out.println(
                JSONObject.toJSONString(MaterialSummaryUpdate.builder().id(1L)
                        .brand("test")
                        .cas("165426226")
                        .concentration("25")
                        .typeName("科技用品（标签）")
                        .unit("单位：毫升")
                        .labId(5L)
                        .picture("")
                        .supplierName("吴经纶的公司")
                        .tagId(1L)

                        .build())
        );
    }
}
