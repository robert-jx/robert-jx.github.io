package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.ResearchGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResearchGroupRepository  extends JpaRepository<ResearchGroup,Long> {

    Page<ResearchGroup> findAllByFkLabId(Long labId , Pageable pageable);
    Optional<List<ResearchGroup>> findAllByFkLabId(Long labId );
    Page<ResearchGroup> findAllByFkLabIdAndShowForAll(Long labId ,Boolean showForAll,Pageable pageable);
    @Query("select g.showForAll from ResearchGroup as g where g.id = ?1")
    Boolean isShowForAll(Long groupId);


}
