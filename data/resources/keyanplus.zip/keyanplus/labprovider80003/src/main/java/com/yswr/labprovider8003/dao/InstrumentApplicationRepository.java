package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.InstrumentApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InstrumentApplicationRepository extends JpaRepository<InstrumentApplication,Long> , JpaSpecificationExecutor<InstrumentApplication> {
    @Modifying
    @Query("update InstrumentApplication as i set  i.isSuccess = true , i.managerName = ?2   where i.id = ?1")
    Integer successApplication(Long id,String managerName);
    @Modifying
    @Query("update InstrumentApplication as i set  i.isFail = true , i.managerName = ?2  where  i.id = ?1")
    Integer failApplication(Long id,String managerName);


    Optional<InstrumentApplication> findByFkApplicationId(Long fk_id);

}
