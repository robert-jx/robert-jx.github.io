package com.yswr.labprovider8003.contants.borrowrecord;

import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BorrowRecordQo {

    private Long labId;

    private Long startTimestamp;
    private Long endTimestamp;
    private String managerName;
    private String borrowerName;
    private String goodsProperties;
    private String goodsPlace;
    private String goodsName;

    private Integer index;
    private Integer pageSize;
    private List<String> ascProperties;
    private List<String> descProperties;

    public static void main(String[] args) {
        System.out.println(JSONObject.toJSONString(BorrowRecordQo.builder()
                .borrowerName("test")
                .endTimestamp(System.currentTimeMillis())
                .goodsName("test")
                .goodsPlace("test")
                .goodsProperties("test")
                .labId(1L)
                .managerName("test")
                .startTimestamp(System.currentTimeMillis())
                .ascProperties(new LinkedList<>())
                .descProperties(new LinkedList<>())
                .index(0)
                .pageSize(10)
                .build()
        ));
    }

}

