package com.yswr.labprovider8003.validation.project;

import com.yswr.labprovider8003.contants.project.ProjectInsert;
import com.yswr.labprovider8003.contants.project.ProjectLevel;
import com.yswr.labprovider8003.contants.project.ProjectType;
import com.yswr.labprovider8003.controller.LabController;
import com.yswr.labprovider8003.entity.Project;
import com.yswr.labprovider8003.entity.ResearchGroup;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.text.ParseException;

/**
 * 缺少数据库校验
 * 1。负责人，成员是否在实验室中
 * */
@Component
public class ProjectInsertValidator implements Validator , InitializingBean
{
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        ProjectInsert project = (ProjectInsert) objects[0];
        if (project==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        //项目名称校验
        if (StringUtils.isEmpty(project.getName())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目名称不能为空").build();
        }else if (project.getName().length()>=30){
            return ValidateResult.builder().isOk(false).message("参数错误，项目名称长度需小于30个字符").build();
        }
        //项目等级校验
        if (StringUtils.isEmpty(project.getLevel())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不能为空").build();
        }else if (project.getLevel().length()>=10){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级需小于10个字符").build();
        }else if (!ProjectLevel.isIn(project.getLevel())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不符合规范").build();
        }
        //项目类型校验
        if (StringUtils.isEmpty(project.getType())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不能为空").build();
        }else if (project.getLevel().length()>=10){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级需小于10个字符").build();
        }else if (!ProjectType.isIn(project.getType())){
            return ValidateResult.builder().isOk(false).message("参数错误，项目等级不符合规范").build();
        }

        if (project.getLabId()==null||project.getLabId()==0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属实验室不能为空").build();
        }


        if (project.getLeaders()==null||project.getLeaders().size()==0) {
            return ValidateResult.builder().isOk(false).message("参数错误，负责人列表不能为空").build();
        }


        if (project.getMembers()==null||project.getMembers().size()==0) {
            return ValidateResult.builder().isOk(false).message("参数错误，负责人列表不能为空").build();
        }

        if (project.getCreateTime()==null){

            return ValidateResult.builder().isOk(false).message("参数错误，创建时间不能为空").build();
        }else {
            try {
                LabController.sdf.parse(project.getCreateTime());
            }catch (ParseException e){
                return ValidateResult.builder().isOk(false).message("参数错误，创建时间格式错误，目标格式：「1999-01-20」").build();
            }
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(ProjectInsert.class,this);
    }
}
