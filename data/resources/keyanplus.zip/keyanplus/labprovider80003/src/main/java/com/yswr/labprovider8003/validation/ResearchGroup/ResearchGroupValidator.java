package com.yswr.labprovider8003.validation.ResearchGroup;

import com.yswr.labprovider8003.contants.research_group.ResearchGroupInsert;
import com.yswr.labprovider8003.entity.ResearchGroup;
import com.yswr.labprovider8003.validation.ValidateResult;
import com.yswr.labprovider8003.validation.Validator;
import com.yswr.labprovider8003.validation.ValidatorContext;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;

@Component
public class ResearchGroupValidator  implements Validator , InitializingBean {
    @Resource
    ValidatorContext validatorContext;
    @Override
    public ValidateResult validate(Object... objects) {
        ResearchGroupInsert researchGroup = (ResearchGroupInsert) objects[0];
        if (researchGroup==null){
            return ValidateResult.builder().isOk(false).message("参数错误，没有找到参数").build();
        }
        if (StringUtils.isEmpty(researchGroup.getName())){
            return ValidateResult.builder().isOk(false).message("参数错误，实验室名称不能为空").build();
        }
        if (StringUtils.isEmpty(researchGroup.getLeaderName())){
            return ValidateResult.builder().isOk(false).message("参数错误，课题组带头人名称不能为空").build();
        }
        if (researchGroup.getFkLabId()==null||researchGroup.getFkLabId()<=0){
            return ValidateResult.builder().isOk(false).message("参数错误，所属实验室不能为空").build();
        }
        if (researchGroup.getShowForAll()==null) {
            return ValidateResult.builder().isOk(false).message("参数错误，展示选项不能为空").build();
        }
        return ValidateResult.builder().isOk(true).build();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        validatorContext.putValidator(ResearchGroupInsert.class,this);
    }
}
