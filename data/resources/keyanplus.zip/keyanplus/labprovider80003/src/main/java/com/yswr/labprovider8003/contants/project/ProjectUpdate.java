package com.yswr.labprovider8003.contants.project;

import com.yswr.labprovider8003.contants.fee.FeeInsert;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectUpdate {
    private Long id;
    private String name;
    private String level;
    private String type;
    private Long labId;
    private Set<String> leaders;
    private Set<String> members;
    private Set<FeeInsert> feeInserts;
    private Set<Long> feeDeletes;
}
