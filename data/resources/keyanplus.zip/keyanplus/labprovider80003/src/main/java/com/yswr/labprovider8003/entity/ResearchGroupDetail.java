package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab_collection")
@Entity
public class ResearchGroupDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    private Long fkLabDetailId;
    @Column(name = "detail_name")
    private String detailName;
    @Column(name = "group_name")
    private String groupName;
    @Column(name = "fk_lab_id")
    private Long fkLabId;
    private Long fkResearchGroupId;
}
