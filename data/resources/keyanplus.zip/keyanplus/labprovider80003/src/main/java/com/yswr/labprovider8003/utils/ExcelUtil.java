package com.yswr.labprovider8003.utils;

import com.alibaba.excel.EasyExcel;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.*;

import static io.netty.handler.codec.smtp.SmtpRequests.data;

@Component
public class ExcelUtil {
        public   <T>  void download(HttpServletResponse response, Class<T> clazz, List<T> data,@Nullable Set<String> excludeMap,String filename) throws IOException {
        // 这里注意 有同学反应使用swagger 会导致各种问题，请直接用浏览器或者用postman
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
//        String fileName = URLEncoder.encode(filename, "UTF-8").replaceAll("\\+", "%20");
        String fileName = URLEncoder.encode(filename+".xlsx", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename="+fileName);
        if (excludeMap==null){

                EasyExcel.write(response.getOutputStream(), clazz)
//                .a
//                .excludeColumnIndexes(excludeMap)
                        .sheet("模板")
                        .autoTrim(true).doWrite(data);
        }else {
                EasyExcel.write(response.getOutputStream(), clazz)

//                .a

                .excludeColumnFiledNames(excludeMap)
                        .sheet("模板").autoTrim(true).doWrite(data);
        }
        response.flushBuffer();
    }

        public static void main(String[] args) {

        }


}
