package com.yswr.labprovider8003.contants.instrument;


import com.yswr.labprovider8003.entity.Instrument;
import com.yswr.labprovider8003.entity.InstrumentSummary;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InstrumentFail {

    InstrumentSummary instrumentSummary;
    Set<Instrument> instrumentSet;
}
