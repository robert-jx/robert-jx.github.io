package com.yswr.labprovider8003.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "lab")
@Entity
public class Lab {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY )
    private Long id;
    private String name;
    private Integer count;
    private String info;
    @Column(name = "create_time")
    private Date createTime = new Date();
    @Column(name = "is_delete")
    private Boolean isDelete = false;
}
