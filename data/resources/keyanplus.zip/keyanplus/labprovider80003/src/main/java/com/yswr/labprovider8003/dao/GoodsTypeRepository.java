package com.yswr.labprovider8003.dao;

import com.yswr.labprovider8003.entity.GoodsType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GoodsTypeRepository extends JpaRepository<GoodsType, Long> , JpaSpecificationExecutor<GoodsType> {
    Optional<List<GoodsType>> findAllByTypeName(String name);


    Boolean existsByTypeNameAndAndFkLabId(String name,Long labId);

    @Query(value = "select g.typeName  from GoodsType as g where g.fkLabId = ?1")
    Optional<List<GoodsType>> findAllNameByLabId(Long labId);
}
