package com.yswr.labprovider8003.contants.application;

import lombok.Data;

import java.util.List;

@Data
public class GoodsApplicationQo {
    private Long labId;
    private String pid;
    private Integer selfId;
    private Boolean isSuccess;
    private Boolean isFail;
    private Boolean isDelete;
    private String isCancel;
    private String sponsorName;
    private String managerName;
    private String name;
    private Integer index;
    private Integer pageSize;
    private List<String> ascProperties;
    private List<String> descProperties;
}
