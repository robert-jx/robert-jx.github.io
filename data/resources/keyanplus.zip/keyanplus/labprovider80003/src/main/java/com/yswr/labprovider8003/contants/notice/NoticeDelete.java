package com.yswr.labprovider8003.contants.notice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoticeDelete {
    private List<Long> ids;
    private Long labId;
}
