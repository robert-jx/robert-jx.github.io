package com.yswr.labprovider8003.service;

import com.yswr.labprovider8003.contants.logistics.LabLogistics;
import com.yswr.labprovider8003.contants.logistics.LogisticsInsert;
import com.yswr.labprovider8003.contants.procurement.ProcurementInsert;
import com.yswr.labprovider8003.dao.ProcurementRepository;
import com.yswr.labprovider8003.entity.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Nullable;
import javax.annotation.Resource;
import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.*;

@Service
public class ProcurementService {
    @Resource
    ProcurementRepository procurementRepository;


    @Transactional
    public void moveInstrumentToRepository(Procurement procurement,Logistics logistics ,LabLogisticsService labLogisticsService ,
                                           InstrumentSummary instrumentSummary ,InstrumentSummaryService instrumentSummaryService,
                                           InstrumentService instrumentService,String place){
        logistics.setState(  LabLogistics.EXIST_IN_LAB.getValue());
        logistics.setPlace(place);
        logistics.setCreateTime(new Timestamp(System.currentTimeMillis()));
        instrumentSummary.setCurCount(instrumentSummary.getCurCount()+logistics.getTotal());
        String []places = instrumentSummary.getPlace()==null?null:instrumentSummary.getPlace().split(",");
        String splitSet = null;
        if (places!=null&&!StringUtils.isEmpty(place)){
            Set<String> stringSet = new HashSet<>(Arrays.asList(places));
            stringSet.add(place);
            splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");

        }
        if (splitSet!=null){
            instrumentSummary.setPlace(splitSet);
        }else {
            if (!StringUtils.isEmpty(place)){
                instrumentSummary.setPlace(place);
            }
        }
        if (instrumentService!=null){
            List<Instrument> instruments = new LinkedList<>();
            for (int i = 1; i <= logistics.getTotal(); i++) {
                instruments.add(Instrument.builder()
                        .name(instrumentSummary.getName())
                        .fkPid(logistics.getPid())
                        .fkLabId(logistics.getFkLabId())
                        .selfId( i)
                        .place(place)
                        .isDelete(false)
                        .specifications(procurement.getSpecifications())
                        .isApply(false)
                        .brand(logistics.getBrand())
                        .supplierName(logistics.getSupplierName())
                        .remark(instrumentSummary.getRemark())
                        .build()
                );
            }
            instrumentService.saveInBatch(instruments);
        }
        procurement.setIsInLab(true);

        procurementRepository.save(procurement);
        instrumentSummaryService.save(instrumentSummary);
        labLogisticsService.addLogistics(logistics);
    }

    @Transactional
    public void moveMaterialToRepository(Procurement procurement,Logistics logistics ,LabLogisticsService labLogisticsService ,
                                           MaterialSummary materialSummary ,MaterialSummaryService materialSummaryService,
                                           MaterialService materialService,String place){
        logistics.setState(  LabLogistics.EXIST_IN_LAB.getValue());
        logistics.setPlace(place);
        logistics.setCreateTime(new Timestamp(System.currentTimeMillis()));
        materialSummary.setCurCount(materialSummary.getCurCount()+logistics.getTotal());
        String []places = materialSummary.getPlace()==null?null:materialSummary.getPlace().split(",");
        String splitSet = null;
        if (places!=null&&!StringUtils.isEmpty(place)){
            Set<String> stringSet = new HashSet<>(Arrays.asList(places));
            stringSet.add(place);
            splitSet= StringUtils.arrayToDelimitedString(stringSet.toArray(), ",");
        }
        if (splitSet!=null){
            materialSummary.setPlace(splitSet);
        }else {
            if (!StringUtils.isEmpty(place)){
                materialSummary.setPlace(place);
            }
        }
        if (materialService!=null) {
            List<Material> materials = new LinkedList<>();
            for (int i = 1; i <= logistics.getTotal(); i++) {
                materials.add(Material.builder()
                        .name(materialSummary.getName())
                        .fkPid(logistics.getPid())
                        .fkLabId(logistics.getFkLabId())
                        .selfId(i)
                        .place(place)
                        .isApply(false)
                        .isDelete(false)
                        .specifications(procurement.getSpecifications())
                        .brand(logistics.getBrand())
                        .supplierName(logistics.getSupplierName())
                        .cas(materialSummary.getCas())
                        .concentration(materialSummary.getConcentration())
                        .build());
            }
            materialService.saveInBatch(materials);
        }
        procurement.setIsInLab(true);
        procurementRepository.save(procurement);
        materialSummaryService.save(materialSummary);
        labLogisticsService.addLogistics(logistics);
    }


    @Transactional
    public Procurement addProcurementWithInstrument(ProcurementInsert procurementInsert, Fee fee , String pid,
                                                    LabLogisticsService labLogisticsService, InstrumentSummaryService instrumentSummaryService,
                                                    FeeService feeService,InstrumentSummary instrumentSummary){
        LogisticsInsert logisticsInsert = procurementInsert.getLogisticsInsert();
        String name = logisticsInsert.getName();
        Double price = logisticsInsert.getPrice();
        String brand = logisticsInsert.getBrand();
        String supplierName = logisticsInsert.getSupplierName();
        Long labId = logisticsInsert.getFkLabId();
        Logistics logistics = labLogisticsService.addLogistics(Logistics.builder()
                .price(price)
                .name(name)
                .pid(pid)
                .state(LabLogistics.NOT_IN_LAB.getValue())
                .brand(brand)
                .supplierName(supplierName)
                .total(logisticsInsert.getTotal())
                .fkLabId(labId)
                .properties("INSTRUMENT")
                .build());
        Procurement procurement= Procurement.builder()
                .fkLogisticsId(logistics.getId())
                .feeName(fee.getName())
                .properties("INSTRUMENT")
                .isInLab(false)
                .fkFeeId(fee.getId())
                .createTime(new Timestamp(System.currentTimeMillis()))
                .goodsName(name)
                .goodsNum(logisticsInsert.getTotal())
                .specifications(instrumentSummary.getSpecifications())
                .goodsPrice(price)
                .isDelete(false)
                .fkLabId(labId)

                .managerName(procurementInsert.getManagerName())
                .build();
        labLogisticsService.addLogistics(logistics);
        instrumentSummaryService.save(instrumentSummary);
        double totalPrice = price*logisticsInsert.getTotal();
        fee.setCurFee(fee.getCurFee()-totalPrice);
        feeService.save(fee);
        return  procurementRepository.save(procurement);
    }
    @Transactional
    public Procurement addProcurementWithMaterial(ProcurementInsert procurementInsert, Fee fee , String pid,
                                                  LabLogisticsService labLogisticsService, MaterialSummaryService materialSummaryService,
                                                  FeeService feeService,MaterialSummary materialSummary){
        LogisticsInsert logisticsInsert = procurementInsert.getLogisticsInsert();
        String name = logisticsInsert.getName();
        Double price = logisticsInsert.getPrice();
        String brand = logisticsInsert.getBrand();
        String supplierName = logisticsInsert.getSupplierName();
        Long labId = logisticsInsert.getFkLabId();
        Logistics logistics = labLogisticsService.addLogistics(Logistics.builder()
                .price(price)
                .name(name)
                .pid(pid)
                .state(LabLogistics.NOT_IN_LAB.getValue())
                .brand(brand)
                .supplierName(supplierName)
                .total(logisticsInsert.getTotal())
                .properties("MATERIAL")
                .fkLabId(labId)
                .build());
        Procurement procurement = Procurement.builder()
                .fkLogisticsId(logistics.getId())
                .feeName(fee.getName())
                .fkFeeId(fee.getId())
                .properties("MATERIAL")
                .isInLab(false)
                .createTime(new Timestamp(System.currentTimeMillis()))
                .goodsName(name)
                .goodsNum(logisticsInsert.getTotal())
                .goodsPrice(price)
                .specifications(materialSummary.getSpecifications())
                .isDelete(false)
                .fkLabId(labId)
                .managerName(procurementInsert.getManagerName())
                .build();
        labLogisticsService.addLogistics(logistics);
        materialSummaryService.save(materialSummary);
        double totalPrice = price*logisticsInsert.getTotal();
        fee.setCurFee(fee.getCurFee()-totalPrice);
        feeService.save(fee);
        return procurementRepository.save(procurement);
    }
    public Procurement findById(Long id){
        return procurementRepository.findById(id).orElse(null);
    }

    public Page<Procurement> findAllByLabId(Long labId, Integer index, Integer page, @Nullable Sort sort){
        if (sort==null){
            return procurementRepository.findAllByFkLabId(labId,PageRequest.of(index,page));
        }else {
            return procurementRepository.findAllByFkLabId(labId,PageRequest.of(index,page,sort));
        }
    }


}
