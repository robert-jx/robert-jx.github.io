package com.yswr.labprovider8003.contants.material;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaterialSummaryInsert {
    @ExcelProperty(index = 0)
    private String name;
    @ExcelProperty(index = 1)
    private String cas;
    @ExcelProperty(index = 2)
    private String tagName;
    @ExcelProperty(index = 3)
    private String typeName;
    @ExcelProperty(index = 4)
    private String brand;
    @ExcelProperty(index = 5)
    private String supplierName;
    @ExcelProperty(index = 6   )
    private String place;
    @ExcelProperty(index = 7)
    private String unit;
    @ExcelProperty(index = 8)
    private String concentration;
    @ExcelProperty(index = 9)
    private String picture;
    @ExcelProperty(index = 10,value = "规格")
    private String specifications;
    @ExcelProperty(index = 11,value = "数量")
    private Integer number;

    private Long fkLabId;
    private Long fkTagId;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MaterialSummaryInsert that = (MaterialSummaryInsert) o;
        return name.equals(that.name) &&
                Objects.equals(cas, that.cas) &&
                Objects.equals(tagName, that.tagName) &&
                Objects.equals(typeName, that.typeName) &&
                Objects.equals(brand, that.brand) &&
                Objects.equals(supplierName, that.supplierName) &&
                Objects.equals(place, that.place) &&
                Objects.equals(unit, that.unit) &&
                Objects.equals(concentration, that.concentration) &&
                Objects.equals(picture, that.picture) &&
                Objects.equals(specifications, that.specifications) &&
                fkLabId.equals(that.fkLabId) &&
                Objects.equals(fkTagId, that.fkTagId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, cas, tagName, typeName, brand, supplierName, place, unit, concentration, picture, specifications, fkLabId, fkTagId);
    }
}
