package com.yswr.labprovider8003.contants.application;

import lombok.Data;

@Data
public class AppointQo {
    private Long labId;
    private String pid;
    private Integer selfId;
    private String startTimeGT;
    private String endTimeGT;
    private String startTimeLT;
    private String endTimeLT;
    private Boolean isSuccess;
    private Boolean isFail;
    private Boolean isDelete;
    private String sponsorName;
    private String name;
}
