mv ../target/lab8003-v1.jar .
docker-compose down



docker-compose up -d --build