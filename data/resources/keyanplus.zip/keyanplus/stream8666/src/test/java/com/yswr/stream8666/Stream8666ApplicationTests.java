package com.yswr.stream8666;

import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class Stream8666ApplicationTests {
    @Value("${rocket.consumer.topic.wx}")
    private String wxTopic;
    @Value("${rocket.consumer.expression.wxTemplateMessage}")
    private String wxTemplateMessage;
    @Resource(name = "wxMessageProducer")
    DefaultMQProducer wxMessageProducer;
    @Test
    void contextLoads() {

    }

}
