package com.yswr.stream8666;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Stream8666Application {
    public static void main(String[] args) {
        SpringApplication.run(Stream8666Application.class, args);
    }
}
